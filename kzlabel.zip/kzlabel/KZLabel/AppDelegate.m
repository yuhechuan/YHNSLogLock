//
//  AppDelegate.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import "KZNavigationController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
     self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    ViewController *rootVc = [[ViewController alloc]init];
    rootVc.view.backgroundColor = [UIColor whiteColor];
    KZNavigationController *rootNav = [[KZNavigationController alloc]initWithRootViewController:rootVc];
     [self.window setRootViewController:rootNav];
     [self.window makeKeyAndVisible];
    
#if DEBUG
   // [[NSBundle bundleWithPath:@"/Applications/InjectionIII.app/Contents/Resources/iOSInjection.bundle"] load];
#endif
    return YES;
}


@end
