//
//  ViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "ViewController.h"

#define COLOR_E9EFEF [UIColor colorWithRed:233/255.0 green:239/255.0 blue:239/255.0 alpha:1]
#define COLOR_333333 [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1]
#define COLOR_53CAC3 [UIColor colorWithRed:83/255.0 green:202/255.0 blue:195/255.0 alpha:1]
#define COLOR_BACK   [UIColor colorWithRed:214/255.0 green:214/255.0 blue:214/255.0 alpha:1]

@interface ViewController ()

@property (nonatomic, strong) NSMutableArray *titles;
@property (nonatomic, strong) NSMutableArray *classNames;


@end

@implementation ViewController
/// 修改2
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"✎       KZLabel Demo       ✎";
    self.titles = @[].mutableCopy;
    self.classNames = @[].mutableCopy;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([UITableViewCell class])];
    
    [self addCell:@"Text Attributes" class:@"KZAttributesViewController"];
    [self addCell:@"Text Truncating" class:@"KZTruncatingViewController"];
    [self addCell:@"Text Attachment" class:@"KZAttachmentViewController"];
    [self addCell:@"Text Selection" class:@"KZSelectionViewController"];
    [self addCell:@"Size Calculation" class:@"KZSizeCalculationViewController"];
    [self addCell:@"Auto Detect" class:@"KZAutoDetectViewController"];
    [self addCell:@"Gesture Clash" class:@"KZGestureClashViewController"];
    [self addCell:@"Border Text" class:@"KZBorderTextViewController"];
    [self addCell:@"Async Display" class:@"KZAsyncDisplayViewController"];
    [self addCell:@"Exclusion Path" class:@"KZExclusionPathsViewController"];
    [self addCell:@"Image Mark" class:@"KZImageMarkViewController"];
    [self addCell:@"Gradient Mark" class:@"KZGradientMarkViewController"];
    [self addCell:@"SeniorLabel Bug" class:@"KZSeniorLabelBugViewController"];
    [self addCell:@"Features Test" class:@"KZFeaturesTestViewController"];
    [self addCell:@"TextKit2" class:@"KZTextKit2ViewController"];
    [self addCell:@"ParagraphStyle" class:@"KZParagraphStyleViewController"];
    [self addCell:@"TextView" class:@"KZTextViewController"];
    [self addCell:@"TextRange" class:@"KZTextRangeController"];
    [self addCell:@"BreakLine" class:@"KZBreakLineController"];
    [self addCell:@"TableView" class:@"KZTableViewController"];
    [self addCell:@"BigText" class:@"KZBigTextController"];
    [self addCell:@"LineNumber" class:@"KZLineNumberViewController"];
    [self addCell:@"WWDC" class:@"KZUIKitNewsWWDCController"];
    [self addCell:@"BigTextList" class:@"KZBigTextListController"];
    [self.tableView reloadData];
}


- (void)addCell:(NSString *)title class:(NSString *)className {
    [self.titles addObject:title];
    [self.classNames addObject:className];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.titles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([UITableViewCell class]) forIndexPath:indexPath];
    cell.textLabel.text = self.titles[indexPath.row];
    cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 55;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *className = self.classNames[indexPath.item];
    Class aClass = NSClassFromString(className);
    UIViewController *viewController = [[aClass alloc]init];;
    if(!viewController) {
        return;
    }
    
    viewController.navigationItem.title = self.titles[indexPath.row];
    viewController.view.backgroundColor = [UIColor whiteColor];
    [self.navigationController pushViewController:viewController animated:YES];
}


@end
