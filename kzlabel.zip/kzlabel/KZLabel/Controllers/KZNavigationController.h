//
//  KZNavigationController.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZNavigationController : UINavigationController

@property (nonatomic, strong) UILabel *fpsLabel;

@end

NS_ASSUME_NONNULL_END
