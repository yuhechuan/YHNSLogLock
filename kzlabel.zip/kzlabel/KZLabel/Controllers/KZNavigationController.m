//
//  KZNavigationController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/13.
//

#import "KZNavigationController.h"
#import "YYFPSLabel.h"
#import "UIView+KZExample.h"

@interface KZNavigationController ()

@property (nonatomic, strong) UIView *toolBar;

@end

@implementation KZNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    YYFPSLabel *fpsLabel = [YYFPSLabel new];
    [fpsLabel sizeToFit];
    [self.view addSubview:fpsLabel];
        
    fpsLabel.translatesAutoresizingMaskIntoConstraints = NO;
    
    if (@available(iOS 11.0, *)) {
        [fpsLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:64].active = YES;
    } else {
    }
    [fpsLabel.rightAnchor constraintEqualToAnchor:self.view.rightAnchor constant:-15].active = YES;
    
    self.fpsLabel = fpsLabel;
}



@end
