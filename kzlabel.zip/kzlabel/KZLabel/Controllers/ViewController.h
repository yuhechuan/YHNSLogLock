//
//  ViewController.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController


@end

