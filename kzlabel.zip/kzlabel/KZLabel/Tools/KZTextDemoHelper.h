//
//  KZTextDemoHelper.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import <UIKit/UIKit.h>
#import "UIViewController+NavigationItem.h"

#define IS_IPAD     ([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad)
#define IS_PHONE    ([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPhone)
#define IS_IPHONEX  (IsIphoneX())


BOOL kz_IsIphoneX(void);
int kz_appGetNavHeight(void);

@interface KZTextDemoHelper : NSObject

+ (void)popGestureClose:(UIViewController *)VC;
+ (void)popGestureOpen:(UIViewController *)VC;

+ (void)cacuTimer:(void(^)(void))block;


@end
