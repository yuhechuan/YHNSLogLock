
//
//  NSString+KZExample.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (KZExample)

- (NSString *)stringByAppendingNameScale:(CGFloat)scale;

- (NSString *)stringByAppendingPathScale:(CGFloat)scale;

@end

NS_ASSUME_NONNULL_END
