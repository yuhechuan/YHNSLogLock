//
//  KZDemoText.h
//  KZLabel
//
//  Created by yuhechuan on 2024/8/13.
//

#import <Foundation/Foundation.h>

@interface KZDemoText : NSObject

+ (NSString *)bigTextDemo;
+ (NSString *)emojiString;

@end

