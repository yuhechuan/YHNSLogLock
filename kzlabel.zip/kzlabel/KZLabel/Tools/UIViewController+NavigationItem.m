//
//  UIViewController+NavigationItem.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/17.
//

#import "UIViewController+NavigationItem.h"
#import "UIView+KZExample.h"
#import <objc/runtime.h>

@implementation UIViewController (NavigationItem)

- (void)addRightSwitchNavigationItem:(void(^)(UISwitch *switcher))switchAction {
    UISwitch *switcher = [[UISwitch alloc] initWithFrame:CGRectMake(0, 0, 44, self.navigationController.navigationBar.height)];
    [switcher.layer setValue:@(0.8) forKeyPath:@"transform.scale"];
    [switcher addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    
    UIBarButtonItem *button = [[UIBarButtonItem alloc]initWithCustomView:switcher];
    button.width = 44;
    self.navigationItem.rightBarButtonItems = @[button];
    
    objc_setAssociatedObject(self, @selector(addRightSwitchNavigationItem:), switchAction, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}


- (void)addRightTitleNavigationItemTitle:(NSString *)title action:(void(^)(void))action {
    
    UIBarButtonItem *button = [[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStylePlain target:self action:@selector(rightTitleBarButtonItem:)];
    button.width = 44;
    self.navigationItem.rightBarButtonItems = @[button];
    objc_setAssociatedObject(self, @selector(addRightTitleNavigationItemTitle:action:), action, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)switchAction:(UISwitch *)switcher {
    id (^block)(UISwitch *switcher) = objc_getAssociatedObject(self, @selector(addRightSwitchNavigationItem:));
    if (block) {
        block(switcher);
    }
}

- (void)rightTitleBarButtonItem:(UIBarButtonItem *)b {
    id (^block)(void) = objc_getAssociatedObject(self, @selector(addRightTitleNavigationItemTitle:action:));
    if (block) {
        block();
    }
}

@end
