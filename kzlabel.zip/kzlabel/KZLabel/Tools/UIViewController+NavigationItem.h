//
//  UIViewController+NavigationItem.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (NavigationItem)

- (void)addRightSwitchNavigationItem:(void(^)(UISwitch *switcher))switchAction;
- (void)addRightTitleNavigationItemTitle:(NSString *)title action:(void(^)(void))action;

@end

NS_ASSUME_NONNULL_END
