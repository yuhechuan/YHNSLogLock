//
//  KZTextDemoHelper.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZTextDemoHelper.h"

int kz_appGetNavHeight(void) {
    if (IS_IPAD) {
        return 64;
    }
    return kz_IsIphoneX() ? 88 : 64;
}

BOOL kz_IsIphoneX(void) {
    static int iphoneX = -1;
    if(iphoneX < 0) {
        iphoneX = 0 ;
        if([[UIDevice currentDevice]userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            if(@available(iOS 11.0, *)){
                UIWindow *window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
                if(window.safeAreaInsets.bottom > 0) {
                    iphoneX = 1;
                }
            }
        }
    }
    return iphoneX;
}

@implementation KZTextDemoHelper

+ (void)popGestureClose:(UIViewController *)VC {
    // 禁用侧滑返回手势
    if ([VC.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        //这里对添加到右滑视图上的所有手势禁用
        for (UIGestureRecognizer *popGesture in VC.navigationController.interactivePopGestureRecognizer.view.gestureRecognizers) {
            popGesture.enabled = NO;
        }
    }
}

+ (void)popGestureOpen:(UIViewController *)VC {
    // 启用侧滑返回手势
    if ([VC.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        //这里对添加到右滑视图上的所有手势启用
        for (UIGestureRecognizer *popGesture in VC.navigationController.interactivePopGestureRecognizer.view.gestureRecognizers) {
            popGesture.enabled = YES;
        }
    }
}

static CFTimeInterval _g_startWorkTime = -1;

+ (void)cacuTimer:(void (^)(void))block {
     _g_startWorkTime = CACurrentMediaTime();
    if(block){
        block();
    }
    
    double gapMsec = (CACurrentMediaTime() - _g_startWorkTime);
    NSLog(@"用时: %f 秒",gapMsec);
}


@end
