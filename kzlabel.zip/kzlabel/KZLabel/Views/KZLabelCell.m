//
//  KZLabelCell.m
//  KZLabel
//
//  Created by yuhechuan on 2023/10/26.
//

#import "KZLabelCell.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZTextDemoHelper.h"

@interface KZLabelCell ()<KZLabelDelegate>

@property (nonatomic, strong) KZLabel *label;

@end

@implementation KZLabelCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUp];
    }
    return self;
}

- (void)setUp {
    KZLabel *label = [[KZLabel alloc]initWithFrame:CGRectMake(20, 20, 0, 0)];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.delegate = self;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.contentView addSubview:label];
    self.label = label;
    self.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.3];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    __weak __typeof(self)weakSelf = self;
    CGSize size = [self.label calculateSizeForConstraintWidth:250];
    self.label.frame = CGRectMake(20, 20, size.width, size.height);

}

- (void)refreshContent:(NSAttributedString *)attr {
    self.label.attributedText = attr;
}

@end
