//
//  KZLabelCell.h
//  KZLabel
//
//  Created by yuhechuan on 2023/10/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZLabelCell : UITableViewCell

- (void)refreshContent:(NSAttributedString *)attr;

@end

NS_ASSUME_NONNULL_END
