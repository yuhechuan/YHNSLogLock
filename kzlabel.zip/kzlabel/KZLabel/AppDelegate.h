//
//  AppDelegate.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

