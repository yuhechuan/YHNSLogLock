//
//  KZTextRendererEngine.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "KZTextRendererEngine.h"
#import "KZContextRefKey.h"
#import "KZContextRef.h"
#import "KZTextBodyRenderer.h"
#import "KZTextTruncationRenderer.h"
#import "KZTextAttributes.h"
#import "KZTextLinkRenderer.h"
#import "KZTextBorderRenderer.h"
#import "KZTextQuoteRenderer.h"
#import "KZTextAttachmentRenderer.h"
#import "KZTextKitComponents.h"
#import "KZBigTextHandler.h"

@interface KZTextRendererEngine ()

@property (nonatomic, strong) KZTextKitComponents *textKitComponents;
@property (nonatomic, strong) KZBigTextHandler *bigTextHandler;
@property (atomic, strong) KZContextRef *contextRefLayouting;
@property (nonatomic, strong) KZContextRef *contextRef;
@property (nonatomic, strong) KZTextAttributes *curAttributes;
@property (nonatomic, assign) CGSize curContainerSize;

@end

@implementation KZTextRendererEngine

- (instancetype)init {
    if(self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceiveMemoryWarning:) name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
    }
    return self;
}

- (void)willDisplay:(CALayer *)layer {
    self.displayFinish = NO;
    /// 清除动画key
    [layer removeAnimationForKey:kAsyncFadeAnimationKey];
    
    /// 保存之前附件状态
    BOOL existedAttachment  = _contextRef.existedAttachment;
    /// 存在附件清空
    if(existedAttachment) {
        UIView *label = (UIView *)layer.delegate;
        KZTextAttachmentRenderer *render = [_contextRef textRendererForKey:NSStringFromClass([KZTextAttachmentRenderer class])];
        [render clearAttachmentViewsAndLayersWithAttachmetsInfo:label];
    }
    
    CGSize fitSize = [self containerSizeForFitSize:CGSizeZero];;
    if(_layoutNeedUpdate || !CGSizeEqualToSize(fitSize, self.curContainerSize)) {
        self.curContainerSize = fitSize;
        self.curAttributes = [self nowTextAttributes];
        _layoutNeedUpdate = YES;
    }
    
    /// 大文本处理
    if(!self.bigTextHandler.bigTextLoading) {
        [self.bigTextHandler bigTextHandlerWithAttributes: self.curAttributes containerSize:self.curContainerSize];
    }
}

- (void)display {
    /// 计算所需上下文
    if(self.contextRefLayouting) {
        [self clearContextRefLayout];
        _contextRef = self.contextRefLayouting;
        [self clearBigContextRefLayout];
    } else if (!_contextRef || _layoutNeedUpdate) {
        [self clearContextRefLayout];
        _contextRef = [self readContextRefForTextAttributes:self.curAttributes containerSize:self.curContainerSize];
    } else {
    }
    /// 处理高亮
    if(_contextExtension.highLightAttributedText) {
        _contextExtension.preActiveLinkAttributedText = _contextRef.textStorage;;
        [_contextRef refreshTextStorege:_contextExtension.highLightAttributedText];
    } else if(_contextExtension.preActiveLinkAttributedText) {
        [_contextRef refreshTextStorege:_contextExtension.preActiveLinkAttributedText];
        _contextExtension.preActiveLinkAttributedText = nil;
    }
    [self rendererBeginDisplay:_contextRef];
}

- (void)didDisplay:(CALayer *)layer {
    /// 存在附件 画 view and layer
    if(_contextRef.existedAttachment) {
        UIView *label = (UIView *)layer.delegate;
        KZTextAttachmentRenderer *render = [_contextRef textRendererForKey:NSStringFromClass([KZTextAttachmentRenderer class])];
        [render drawViewAndLayerAttchmentsWithAttachments:_contextRef.glyphPoint textView:label];
    }
    
    if (_contextExtension.highLightAttributedText) {
        CATransition *transition = [CATransition animation];
        transition.duration = kHighlightFadeDuration;
        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
        transition.type = kCATransitionFade;
        [layer addAnimation:transition forKey:kAsyncFadeAnimationKey];
    }
    
    if([_contextRef.attributes.delegate respondsToSelector:@selector(didLayoutWithTextCalculateSize:)] && !CGSizeEqualToSize(_contextRef.calculatedSize, CGSizeZero)) {
        [_contextRef.attributes.delegate didLayoutWithTextCalculateSize:_contextRef.calculatedSize];
    }
    self.displayFinish = YES;
    _layoutNeedUpdate = NO;
}

- (void)didDisplayUnfinished:(CALayer *)layer {
    ///  未完成布局时 存在附件 清除所有附件
    if(_contextRef.existedAttachment) {
        UIView *label = (UIView *)layer.delegate;
        KZTextAttachmentRenderer *render = [_contextRef textRendererForKey:NSStringFromClass([KZTextAttachmentRenderer class])];
        [render clearAttachmentViewsAndLayers:label];
    }
    _layoutNeedUpdate = NO;
}

- (KZTextAttributes *)nowTextAttributes {
    KZTextAttributes *textAttributes = nil;
    if([self.delegate respondsToSelector:@selector(textAttributesForRenderer)]) {
        textAttributes = [self.delegate textAttributesForRenderer];
    }
    return textAttributes;
}

- (CGSize)containerSizeForFitSize:(CGSize)fitSize {
    CGSize containerSize = CGSizeZero;
    if([self.delegate respondsToSelector:@selector(textRendererContainerSizeForFitSize:)]) {
        containerSize = [self.delegate textRendererContainerSizeForFitSize:fitSize];
    }
    return containerSize;
}

- (KZContextRef *)contextRef {
    return _contextRef;
}


- (KZContextRef *)readContextRefForTextAttributes:(KZTextAttributes *)textAttributes
                                    containerSize:(CGSize)containerSize {
    KZContextRef *ref =[[KZContextRef alloc]initWithAttributes:textAttributes
                                    containerSize:containerSize];
   
    ref.extension = self.contextExtension;
    
    ref.layoutManager.willDrawGlyphs = ^(KZContextRef *ref, NSRange glyphsToShow, CGPoint point) {
        /// 先画一部分
        for (id<KZTextRenderer> renderer in ref.textRenderersClassList) {
            if([renderer respondsToSelector:@selector(beginRendererAtPoint:)]) {
                [renderer beginRendererAtPoint:point];
            }
        }
    };
    ref.layoutManager.didDrawGlyphs = ^(KZContextRef *ref, NSRange glyphsToShow, CGPoint point) {
        /// 有的需要其他画完之后画
        for (id<KZTextRenderer> renderer in ref.textRenderersClassList) {
            if([renderer respondsToSelector:@selector(endRendererAtPoint:)]) {
                [renderer endRendererAtPoint:point];
            }
        }
    };
    return ref;
}

- (CGSize)calculateSizeForfForFitSize:(CGSize)fitSize {
    KZTextAttributes *textAttributes = [self nowTextAttributes];
    CGSize containerSize = [self containerSizeForFitSize:fitSize];
    CGSize calcSize = [self.textKitComponents calculateSizeForConstraintSize:containerSize attributes:textAttributes];
    return calcSize;
}

- (void)rendererBeginDisplay:(KZContextRef *)contextRef {
    NSRange glyphRange = contextRef.glyphRange;
    if(glyphRange.location == NSNotFound) {
        return;
    }
    CGPoint point = contextRef.glyphPoint;
    /// 画文字  主题背景优先
    [contextRef.layoutManager drawBackgroundForGlyphRange:glyphRange atPoint:point];
    [contextRef.layoutManager drawGlyphsForGlyphRange:glyphRange atPoint:point];
}

- (BOOL)viewDispplayFinish {
    return self.displayFinish;
}

- (void)touchesBeganAtPoint:(CGPoint)point {
    for (id<KZTextRenderer> renderer in _contextRef.textRenderersClassList) {
        if([renderer respondsToSelector:@selector(touchesBeganAtPoint:)]) {
            [renderer touchesBeganAtPoint:point];
        }
    }
}
- (void)touchesEndAtPoint:(CGPoint)point {
    for (id<KZTextRenderer> renderer in  _contextRef.textRenderersClassList) {
        if([renderer respondsToSelector:@selector(touchesEndAtPoint:)]) {
            [renderer touchesEndAtPoint:point];
        }
    }
}

- (BOOL)rendererPointInside:(CGPoint)point {
    for (id<KZTextRenderer> renderer in _contextRef.textRenderersClassList) {
        if([renderer respondsToSelector:@selector(rendererPointInside:)] && [renderer rendererPointInside:point]) {
            return NO;
        }
    }
    return YES;
}

- (KZTextKitComponents *)textKitComponents {
    if(!_textKitComponents) {
        _textKitComponents = [[KZTextKitComponents alloc]init];
    }
    return _textKitComponents;
}

- (KZBigTextHandler *)bigTextHandler {
    if(!_bigTextHandler) {
        _bigTextHandler = [[KZBigTextHandler alloc]init];
        _bigTextHandler.maxLimitLength = self.contextExtension.maxLimitLength;
        __weak __typeof(self)weakSelf = self;
        _bigTextHandler.asyncCreateContextRef = ^(KZTextAttributes *attributes, CGSize containerSize) {
            weakSelf.contextRefLayouting = [weakSelf readContextRefForTextAttributes:attributes containerSize:containerSize];
            weakSelf.layoutNeedUpdate = YES;
            dispatch_async(dispatch_get_main_queue(), ^{
                if([weakSelf.delegate respondsToSelector:@selector(toSetNeedsDisplay)]) {
                    [weakSelf.delegate toSetNeedsDisplay];
                }
            });
        };
    }
    return _bigTextHandler;
}


- (void)didReceiveMemoryWarning:(NSNotification *)notification {
    _contextRef = nil;
}

- (void)clearContextRefLayout {
    if (!_contextRef) return;
    KZContextRef *contextRef = _contextRef;
    _contextRef = nil;
    dispatch_async(KZTextAsyncLayerGetReleaseQueue(), ^{
        [contextRef class];
    });
}

- (void)clearBigContextRefLayout {
    if (!self.contextRefLayouting) return;
    KZContextRef *contextRef = self.contextRefLayouting;
    self.contextRefLayouting = nil;
    dispatch_async(KZTextAsyncLayerGetReleaseQueue(), ^{
        [contextRef class];
    });
}


- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


@end
