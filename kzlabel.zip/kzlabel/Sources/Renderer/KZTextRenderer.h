//
//  KZTextRenderer.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#ifndef KZTextRenderer_h
#define KZTextRenderer_h

#import <UIKit/UIKit.h>
#import "KZContextRef.h"
#import "KZLayoutManager.h"
#import "KZTextAttributes.h"
#import "KZRendererFrame.h"

@protocol KZTextRenderer <NSObject>

@optional

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef;
- (void)didCalculateTextRenderer:(NSArray <KZRendererRect *>*)rendererRectList;

- (void)beginRendererAtPoint:(CGPoint)point;
- (void)endRendererAtPoint:(CGPoint)point;

- (void)touchesBeganAtPoint:(CGPoint)point;
- (void)touchesEndAtPoint:(CGPoint)point;

- (BOOL)rendererPointInside:(CGPoint)point;

- (NSArray *)rectsForAttribute:(NSObject *)attribute
                characterRange:(NSRange)characterRange;
@end

#endif /* KZTextRenderer_h */
