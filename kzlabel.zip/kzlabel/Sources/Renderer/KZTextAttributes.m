//
//  KZTextAttributes.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "KZTextAttributes.h"
#import "KZTextHelper.h"

@implementation KZTextAttributes

- (NSUInteger)hash {
    struct {
        NSUInteger attributedTextHash;
        NSLineBreakMode lineBreakModeHash;
        NSUInteger numberOfLinesHash;
        NSUInteger exclusionPathsHash;
        NSUInteger truncationAttributedTextHash;
        NSUInteger additionalTruncationAttributedText;
        NSUInteger extendRendererMapHash;
        NSUInteger textVerticalAlignmentHash;
        NSUInteger textContainerInsetHash;
        NSUInteger lineFragmentPaddingHash;
    } data = {
        [_attributedText hash],
        _lineBreakMode,
        _numberOfLines,
        [_exclusionPaths hash],
        [_truncationAttributedText hash],
        [_additionalTruncationAttributedText hash],
        [_extendRendererMap hash],
        _textVerticalAlignment,
        [[NSValue valueWithUIEdgeInsets:_textContainerInset] hash],
        _lineFragmentPadding,
    };
    return KZTextHashBytes(&data, sizeof(data));
}

- (BOOL)isEqual:(KZTextAttributes *)object {
    if (self == object) {
        return YES;
    }
    
    if (![object isKindOfClass:self.class]) {
        return NO;
    }
    
    BOOL ret1 = _lineBreakMode == object.lineBreakMode;
    BOOL ret2 = _numberOfLines == object.numberOfLines;
    BOOL ret3 = _textVerticalAlignment == object.textVerticalAlignment;
    BOOL ret4 = UIEdgeInsetsEqualToEdgeInsets(_textContainerInset, object.textContainerInset);
    BOOL ret5 = KZTextObjectIsEqual(_attributedText, object.attributedText);
    BOOL ret6 = KZTextObjectIsEqual(_exclusionPaths, object.exclusionPaths);
    BOOL ret7 = KZTextObjectIsEqual(_truncationAttributedText, object.truncationAttributedText);
    BOOL ret8 = KZTextObjectIsEqual(_additionalTruncationAttributedText, object.additionalTruncationAttributedText);
    BOOL ret9 = KZTextObjectIsEqual(_extendRendererMap, object.extendRendererMap);
    BOOL ret10 = _lineFragmentPadding - object.lineFragmentPadding < CGFLOAT_MIN;
    return ret1 && ret2 && ret3 && ret4 && ret5 && ret6 && ret7 && ret8 && ret9 && ret10;
}

@end

@implementation KZContextExtension

- (NSMutableArray<UIView *> *)attachmentViews {
    if(!_attachmentViews) {
        _attachmentViews = [NSMutableArray array];
    }
    return _attachmentViews;
}

- (NSMutableArray<CALayer *> *)attachmentLayers {
    if(!_attachmentLayers) {
        _attachmentLayers = [NSMutableArray array];
    }
    return _attachmentLayers;
}

@end

@implementation KZCustomMenuBackInfo
@end

@implementation KZTextLink
@end

@implementation KZTextBorder
@end

@implementation KZTextQuote
@end

@implementation KZTextAttachment

@synthesize content = _content;

- (instancetype)init {
    self = [super init];
    if (self) {
        // If you use Xcode 11 to generate applications on iOS 13 systems, attachment will render redundant decorative patterns.
        // We use the following code to avoid this behavior.
        if (@available(iOS 13, *)) {
            self.image = [[UIImage alloc]init];
        }
        _aligment = KZTextVerticalAlignmentCenter;
        _contentMode = UIViewContentModeScaleAspectFill;
    }
    return self;
}

- (void)setContent:(id)content {
    if (_content == content) {
        return;
    }
    if([content isKindOfClass:UIImage.class]) {
        self.image = content;
    }
    _content = content;
    CGSize contentSize = self.contentSize;
    if (CGSizeEqualToSize(CGSizeZero, contentSize)) {
        if ([content isKindOfClass:UIImage.class]) {
            UIImage *image = content;
            contentSize = [image size];
        } else {
            contentSize = [content bounds].size;
        }
        self.contentSize = contentSize;
    }
}

- (id)content {
    if(_content) {
        return _content;
    }
    [self asyncFetchAttach];
    return _content;
}

- (CGSize)attachmentSize {
    CGSize size = self.bounds.size;
    if (CGSizeEqualToSize(CGSizeZero, size)) {
        size = self.contentSize;
    }
    if (CGSizeEqualToSize(CGSizeZero, size)) {
        size = [self asyncFetchAttach];
    }
    return size;
}

- (CGSize)asyncFetchAttach {
    if(_content) {
        return self.contentSize;
    }
    id content = nil;
    CGSize contentSize = self.contentSize;
    if(self.AsyncFetchAttachContent) {
        content = self.AsyncFetchAttachContent(contentSize);
    }
    if(content && CGSizeEqualToSize(CGSizeZero, contentSize)) {
        if ([content isKindOfClass:UIImage.class]) {
            UIImage *image = content;
            contentSize = [image size];
        } else {
            contentSize = [content bounds].size;
        }
        self.contentSize = contentSize;
    }
    _content = content;
    return self.contentSize;
}

- (void)setContentSize:(CGSize)contentSize {
    _contentSize = CGSizeMake(floor(contentSize.width), floor(contentSize.height));
}

#pragma mark - KZTextAttachmentContainer

// Returns the layout bounds to the layout manager.  The bounds origin is interpreted to match position inside lineFrag.  The NSTextAttachment implementation returns -bounds if not CGRectZero; otherwise, it derives the bounds value from -[image size].  Conforming objects can implement more sophisticated logic for negotiating the frame size based on the available container space and proposed line fragment rect.
- (CGRect)attachmentBoundsForTextContainer:(nullable NSTextContainer *)textContainer proposedLineFragment:(CGRect)lineFrag glyphPosition:(CGPoint)position characterIndex:(NSUInteger)charIndex {
    UIFont *font = self.alignToFont ?: [textContainer.layoutManager.textStorage attribute:NSFontAttributeName atIndex:charIndex effectiveRange:nil];
    if(!font) {
        font = [UIFont systemFontOfSize:17];
    }
    CGSize attachmentSize = self.attachmentSize;
    CGFloat y = font.descender; // align to text bottom.
    switch (self.aligment) {
        case KZTextVerticalAlignmentTop: {
            y -= (attachmentSize.height - font.lineHeight);
        } break;
        case KZTextVerticalAlignmentCenter: {
            y -= (attachmentSize.height - font.lineHeight) * 0.5;
        } break;
        case KZTextVerticalAlignmentBottom: {
        } break;
    }

    // The origin is relative to text baseline and based on core text coordinate system, negative means downward offset and positive upward offset.
    return (CGRect){ .origin = CGPointMake(0, y), .size = attachmentSize };
}

@end
