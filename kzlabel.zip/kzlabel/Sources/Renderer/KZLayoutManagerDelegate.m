//
//  KZLayoutManagerDelegate.m
//  KZLabel
//
//  Created by yuhechuan on 2023/9/11.
//

#import "KZLayoutManagerDelegate.h"
#import "KZContextRef.h"
#import "KZTextAttributes.h"

@interface KZLayoutManagerDelegate ()

@property (nonatomic, assign) BOOL characterActionConfirming;
@property (nonatomic, strong) NSMutableDictionary * actionCache;

@end

@implementation KZLayoutManagerDelegate

- (NSControlCharacterAction)layoutManager:(NSLayoutManager *)layoutManager shouldUseAction:(NSControlCharacterAction)action forControlCharacterAtIndex:(NSUInteger)charIndex {
    if(self.delegate && [self.delegate respondsToSelector:@selector(layoutManager:shouldUseAction:controlCharacter:charIndex:)]) {
        NSString *charAttr = [layoutManager.textStorage attributedSubstringFromRange:NSMakeRange(charIndex, 1)].string;
        return [self.delegate layoutManager:layoutManager shouldUseAction:action controlCharacter:charAttr charIndex:charIndex];
    }
    if(!self.lineBreakControlCharacter || self.lineBreakControlCharacter.length == 0) {
        return action;
    }
    
    if(self.characterActionConfirming) {
        NSNumber *v = self.actionCache[@(charIndex)];
        if(v) {
            return [v integerValue];
        } else {
            return action;
        }
    }
    NSMutableAttributedString *attr = layoutManager.textStorage;
    NSString *charIndexStr = [attr attributedSubstringFromRange:NSMakeRange(charIndex, 1)].string;
    if(![charIndexStr isEqualToString: self.lineBreakControlCharacter]) {
        return action;
    }
    if(charIndex + 1 >= attr.length) {
        return action;
    }
    NSDictionary *dict = [attr attributesAtIndex:charIndex + 1 effectiveRange:NULL];
    id value = dict[KZTextBorderAttributedStringKey];
    if(!value || ![value isKindOfClass:[KZTextBorder class]]) {
        return action;
    }
    KZTextBorder *b = (KZTextBorder *)value;
    if(!b.avoidLineBreak) {
        return action;
    }
    self.characterActionConfirming = YES;
    NSInteger lineCount = [self displayLineForGlyphRange:b.range layoutManager:layoutManager];
    self.characterActionConfirming = NO;
    if(lineCount == 2) {
        self.actionCache[@(charIndex)] = @(NSControlCharacterActionLineBreak);
        return NSControlCharacterActionLineBreak;
    }
    return action;
}

- (NSInteger)displayLineForGlyphRange:(NSRange)range layoutManager:(NSLayoutManager *)layoutManager {
    __block NSInteger count = 0;
    [layoutManager enumerateLineFragmentsForGlyphRange:range usingBlock:^(CGRect rect, CGRect usedRect, NSTextContainer * _Nonnull textContainer, NSRange glyphRange, BOOL * _Nonnull stop) {
        count ++;
        if(count > 1) {
            *stop = YES;
        }
    }];
    return count;
}

- (void)layoutManager:(NSLayoutManager *)layoutManager didCompleteLayoutForTextContainer:(nullable NSTextContainer *)textContainer atEnd:(BOOL)layoutFinishedFlag {
    if(layoutFinishedFlag && _actionCache) {
        [_actionCache removeAllObjects];
    }
}

- (NSMutableDictionary *)actionCache {
    if(!_actionCache) {
        _actionCache = [NSMutableDictionary dictionary];
    }
    return _actionCache;
}

@end
