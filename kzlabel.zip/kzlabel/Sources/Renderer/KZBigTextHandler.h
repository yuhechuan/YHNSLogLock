//
//  KZBigTextHandler.h
//  KZLabel
//
//  Created by yuhechuan on 2023/11/9.
//

#import <Foundation/Foundation.h>

@class KZTextAttributes;
@class KZTextKitComponents;
@class KZContextRef;

@interface KZBigTextHandler : NSObject

@property (nonatomic, assign) NSUInteger maxLimitLength;
@property (nonatomic, assign) BOOL bigTextLoading;

@property (nonatomic, copy) void(^asyncCreateContextRef)(KZTextAttributes *attributes, CGSize containerSize);

- (void)bigTextHandlerWithAttributes:(KZTextAttributes *)attributes
                       containerSize:(CGSize)containerSize;

@end

