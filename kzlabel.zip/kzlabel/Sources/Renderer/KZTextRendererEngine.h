//
//  KZTextRendererEngine.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <Foundation/Foundation.h>
#import "KZTextRenderer.h"
#import "KZTextUserInteractionManager.h"

@class KZTextAttributes;
@class KZContextRef;
@class KZContextExtension;

@protocol KZTextRendererEngineDelegate <NSObject>
@required

- (CGSize)textRendererContainerSizeForFitSize:(CGSize)fitSize;
- (KZTextAttributes *)textAttributesForRenderer;


@optional
- (void)toSetNeedsDisplay;

@end

@interface KZTextRendererEngine : NSObject<KZTextGestureRecognizerDelegate>

@property (nonatomic, weak) id<KZTextRendererEngineDelegate>delegate;
@property (nonatomic, strong, readonly) KZContextRef *contextRef;
@property (nonatomic, strong) KZContextExtension *contextExtension;
@property (nonatomic, assign) BOOL displayFinish;
@property (nonatomic, assign) BOOL layoutNeedUpdate;


- (void)willDisplay:(CALayer *)layer;
- (void)display;
- (void)didDisplay:(CALayer *)layer;
- (void)didDisplayUnfinished:(CALayer *)layer;

- (CGSize)calculateSizeForfForFitSize:(CGSize)fitSize;
- (KZContextRef *)readContextRefForTextAttributes:(KZTextAttributes *)textAttributes
                                    containerSize:(CGSize)containerSize;

@end
