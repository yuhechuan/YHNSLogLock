//
//  KZTextDebugRenderer.h
//  KZLabel
//
//  Created by yuhechuan on 2023/11/14.
//

#import "KZTextRenderer.h"

@interface KZTextDebugRenderer : NSObject<KZTextRenderer>

@end
