//
//  KZRendererFrame.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/16.
//

#import "KZRendererFrame.h"
#import "KZContextRef.h"
#import "KZTextAttributes.h"
#import "KZLayoutManager.h"
#import "KZTextRenderer.h"

@implementation KZLayoutInfo

@end

@implementation KZRendererRect

- (KZLayoutInfo *)rectValuesIncludeAtPoint:(CGPoint)point {
    for (KZLayoutInfo *info in self.rectValues) {
        if(CGRectContainsPoint(info.rect, point)) {
            return info;
        }
    }
    return nil;
}

- (NSMutableArray<KZLayoutInfo *> *)rectValues {
    if(!_rectValues) {
        _rectValues = [NSMutableArray array];
    }
    return _rectValues;
}

- (NSMutableArray *)rangeValues {
    if(!_rangeValues) {
        _rangeValues = [NSMutableArray array];
    }
    return _rangeValues;
}

@end

@interface KZRendererFrame () {
    NSMutableDictionary *_rendererRectMap;
    NSMutableDictionary *_textAttributeMap;
}

@property (nonatomic, weak) KZContextRef *contextRef;

@end

@implementation KZRendererFrame

- (instancetype)initWithContextRef:(KZContextRef *)contextRef {
    if(self = [super init]) {
        self.contextRef = contextRef;
        _rendererRectMap = [NSMutableDictionary dictionary];
        _textAttributeMap = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)textRenderer:(id<KZTextRenderer>)textRenderer value:(NSObject *)value range:(NSRange)range key:(NSAttributedStringKey)key {
    if(!value) {
        return;
    }
    if([key isEqualToString:NSAttachmentAttributeName] && ![value isMemberOfClass:[KZTextAttachment class]]) {
        return;
    }
    
    KZLayoutManager *layoutManager = self.contextRef.layoutManager;
    NSTextContainer *textContainer = self.contextRef.textContainer;
    NSRange truncRange = NSMakeRange(NSNotFound, 0);
    if(!self.contextRef.truncationInfo) {
        truncRange = [layoutManager truncatedGlyphRangeInLineFragmentForGlyphAtIndex:range.location];
    }
   
    if(truncRange.location !=NSNotFound && range.location >= truncRange.location) {
        return;
    }
    
    NSNumber *textKey = @([value hash]);
    KZRendererRect *renderRect = _rendererRectMap[textKey];
    if(!renderRect) {
        renderRect = [[KZRendererRect alloc]init];
        _rendererRectMap[textKey] = renderRect;
    }
    renderRect.textAttribute = value;
    [renderRect.rangeValues addObject:[NSValue valueWithRange:range]];
    
  
    CGPoint point = self.contextRef.glyphPoint;
    
    NSArray *rects = @[];
    if([textRenderer respondsToSelector:@selector(rectsForAttribute:characterRange:)]) {
        rects = [textRenderer rectsForAttribute:value characterRange:range];
    } else {
        rects = [layoutManager enumerateRectsForGlyphRange:range inTextContainer:textContainer insets:UIEdgeInsetsZero point:point];
    }
    [renderRect.rectValues addObjectsFromArray:rects];

    
    NSString *classKey = NSStringFromClass([textRenderer class]);
    NSMutableArray *renderRectArray = _textAttributeMap[classKey];
    if(!renderRectArray) {
        renderRectArray = [NSMutableArray array];
        _textAttributeMap[classKey] = renderRectArray;
    }
    if(![renderRectArray containsObject:renderRect]) {
        [renderRectArray addObject:renderRect];
    }
}

- (NSArray <KZRendererRect *>*)rendererRectListForKey:(NSString *)classKey {
    if(!classKey || classKey.length == 0) {
        return @[];
    }
    return _textAttributeMap[classKey];
}

@end
