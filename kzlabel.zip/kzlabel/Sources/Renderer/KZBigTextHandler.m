//
//  KZBigTextHandler.m
//  KZLabel
//
//  Created by yuhechuan on 2023/11/9.
//

#import "KZBigTextHandler.h"
#import "KZTextHelper.h"
#import "KZTextAttributes.h"

@interface KZBigTextHandler ()

@end

@implementation KZBigTextHandler

- (instancetype)init {
    if(self = [super init]) {
        self.maxLimitLength = CGFLOAT_MAX;
    }
    return self;
}

- (void)bigTextHandlerWithAttributes:(KZTextAttributes *)attributes
                       containerSize:(CGSize)containerSize {
    self.bigTextLoading = NO;
    NSAttributedString *attributedText = attributes.attributedText;
    if(attributedText.length < self.maxLimitLength) {
        return;
    }
 
    NSRange range = NSMakeRange(0, self.maxLimitLength);
    NSAttributedString *attributedTextLimit = [attributedText attributedSubstringFromRange:range];
    attributes.attributedText = attributedTextLimit;
    
    /// 此处异步调用
    dispatch_async(KZTextAsyncLayerGetDisplayQueue(), ^{
        if(self.asyncCreateContextRef) {
            KZTextAttributes *attr = [[KZTextAttributes alloc]init];
            attr.attributedText = attributedText;
            attr.lineBreakMode = attributes.lineBreakMode;
            attr.numberOfLines = attributes.numberOfLines;
            attr.exclusionPaths = attributes.exclusionPaths;
            attr.truncationAttributedText = attributes.truncationAttributedText;
            attr.additionalTruncationAttributedText = attributes.additionalTruncationAttributedText;
            attr.textVerticalAlignment = attributes.textVerticalAlignment;
            attr.textContainerInset = attributes.textContainerInset;
            attr.exclusionPaths = attributes.exclusionPaths;
            attr.lineFragmentPadding = attributes.lineFragmentPadding;
            attr.extendRendererMap = attributes.extendRendererMap;
            attr.delegate = attributes.delegate;
            attr.avoidLineBreak = attributes.avoidLineBreak;
            attr.enbleDebugOption = attributes.enbleDebugOption;
            attr.lineBreakControlCharacter = attributes.lineBreakControlCharacter;
            self.asyncCreateContextRef(attr, containerSize);
        }
        self.bigTextLoading = YES;
    });
}

@end
