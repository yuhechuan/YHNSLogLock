//
//  KZTextLinkRenderer.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/28.
//

#import "KZTextRenderer.h"

@interface KZTextLinkRenderer : NSObject<KZTextRenderer>

@end
