//
//  KZTextLinkRenderer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/28.
//

#import "KZTextLinkRenderer.h"
#import "KZTextAttributes.h"

@interface KZTextLinkRenderer ()

@property (nonatomic, copy) NSArray *rendererRectList;
@property (nonatomic, strong) KZRendererRect *touchLinkRect;

@end

@implementation KZTextLinkRenderer {
    KZContextRef *_contextRef;
    NSTimeInterval _callPhoneInterval;
}

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef {
    _contextRef = contextRef;
    self.rendererRectList = @[];
}

- (void)didCalculateTextRenderer:(NSArray <KZRendererRect *>*)rendererRectList {
    self.rendererRectList = rendererRectList;
    if(rendererRectList.count == 0) {
        return;
    }

    NSMutableDictionary *rangeValuesDict = [NSMutableDictionary dictionary];
    
    for (KZRendererRect *value in rendererRectList) {
        if(![value.textAttribute isMemberOfClass:[KZTextLink class]]) {
            continue;
        }
        KZTextLink *link = (KZTextLink *)value.textAttribute;
        if(self.touchLinkRect.textAttribute == link) {
            continue;
        }
        for (NSValue *rv in value.rangeValues) {
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            if(link.fillColor) {
                attributes[NSBackgroundColorAttributeName] = link.fillColor;
            }
            if(link.linkTextColor) {
                attributes[NSForegroundColorAttributeName] = link.linkTextColor;
            }
            rangeValuesDict[rv] = attributes.copy;
        }
    }
    NSTextStorage *textStorage = _contextRef.textStorage;
    /// 属性设置
    [rangeValuesDict enumerateKeysAndObjectsUsingBlock:^(NSValue *value, NSDictionary *attributes, BOOL * _Nonnull stop) {
        [textStorage addAttributes:attributes range:value.rangeValue];
    }];
}


- (void)touchesBeganAtPoint:(CGPoint)point {
    KZRendererRect *touchLinkRect = nil;
    for (KZRendererRect *link in self.rendererRectList) {
        KZLayoutInfo *yinfo = [link rectValuesIncludeAtPoint:CGPointMake(point.x, point.y)];
        if(yinfo) {
            touchLinkRect = link;
            touchLinkRect.layoutInfo = yinfo;
            break;
        }
    }
    self.touchLinkRect = touchLinkRect;
    if(!touchLinkRect) {
        return;
    }
  
    NSMutableAttributedString *highlightedAttributedText = [self highlightedAttributedTextForLink:touchLinkRect];
    if(highlightedAttributedText) {
        if(_contextRef.extension.displayAction) _contextRef.extension.displayAction(highlightedAttributedText);
    }
}

- (void)touchesEndAtPoint:(CGPoint)point {
    KZRendererRect *touchLinkRect = self.touchLinkRect;
    if(!touchLinkRect) {
        return;
    }
    
    if(self.touchLinkRect && _contextRef.extension.highLightAttributedText) {
        if(_contextRef.extension.displayAction) _contextRef.extension.displayAction(nil);
        self.touchLinkRect = nil;
    }
    
    NSTextStorage *textStorage = _contextRef.textStorage;
    NSRange range = touchLinkRect.layoutInfo.parentRange;
    NSAttributedString *linkAttr = [textStorage attributedSubstringFromRange:range];
    KZTextLink *touchLink = touchLinkRect.textAttribute;
    
    if(touchLink.clickAction) {
        touchLink.clickAction(linkAttr, range);
    } else if (touchLink.checkResult) {
        if(_contextRef.extension.linkTypeAction) {
            _contextRef.extension.linkTypeAction(touchLink.checkResult, linkAttr, range);
        } else {
            [self handleDetectTextCheckingResult:touchLink.checkResult];
        }
    } else {
        if(_contextRef.extension.linkTypeAction) {
            _contextRef.extension.linkTypeAction(nil, linkAttr, range);
        }
    }
}

- (BOOL)rendererPointInside:(CGPoint)point {
    for (KZRendererRect *link in self.rendererRectList) {
        if(![link.textAttribute isMemberOfClass:[KZTextLink class]]) {
            continue;
        }
        KZTextLink *l = (KZTextLink *)link.textAttribute;
        if((l.clickAction || l.checkResult) && [link rectValuesIncludeAtPoint:CGPointMake(point.x, point.y)]) {
            return YES;
        }
    }
    return NO;
}

- (NSMutableAttributedString *)highlightedAttributedTextForLink:(KZRendererRect *)touchLinkRect {
    KZTextLink *touchLink = touchLinkRect.textAttribute;
    NSRange range = touchLinkRect.layoutInfo.parentRange;
    NSMutableAttributedString *highlightedLinkAttributedText = [[_contextRef.textStorage attributedSubstringFromRange:range] mutableCopy];
    NSMutableDictionary<NSString *, id> *textAttributes = [NSMutableDictionary dictionary];
    if(touchLink.highlightColor) {
        textAttributes[NSForegroundColorAttributeName] = touchLink.highlightColor;
    }
    if(touchLink.highlightBackViewColor) {
        textAttributes[NSBackgroundColorAttributeName] = touchLink.highlightBackViewColor;
    }
    if(textAttributes.count == 0) {
        return nil;
    }
    
    if (textAttributes) {
        [highlightedLinkAttributedText addAttributes:textAttributes range:NSMakeRange(0, highlightedLinkAttributedText.length)];
    }
    NSMutableAttributedString *highlightedAttributedText = [[NSMutableAttributedString alloc] initWithAttributedString:_contextRef.textStorage];
    [highlightedAttributedText replaceCharactersInRange:range withAttributedString:highlightedLinkAttributedText];
    return highlightedAttributedText;
}

- (void)handleDetectTextCheckingResult:(NSTextCheckingResult *)result {
    switch (result.resultType) {
        case NSTextCheckingTypeLink:
            [self applicationOpenUrl:result.URL];

            break;
            
        case NSTextCheckingTypePhoneNumber:
        {
             NSTimeInterval currentTimeInterval = [[NSDate date] timeIntervalSince1970] * 1000;
             if (currentTimeInterval - _callPhoneInterval < 1000) {
                 //In order to solve the problem of continuous calls causing a status bar exception.
                return;
             }
             _callPhoneInterval = currentTimeInterval;
            NSURL *phoneUrl = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",[result.phoneNumber stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]]];
            [self applicationOpenUrl:phoneUrl];
            
        }
            break;
        default:
            break;
    }
}

- (void)applicationOpenUrl:(NSURL *)url {
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url options:@{UIApplicationOpenURLOptionUniversalLinksOnly : @NO} completionHandler:nil];
    }
}

@end
