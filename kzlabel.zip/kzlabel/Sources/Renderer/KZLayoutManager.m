//
//  KZLayoutManager.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "KZLayoutManager.h"
#import "KZTextHelper.h"
#import "KZTextAttributes.h"
#import "KZRendererFrame.h"
#import "NSMutableAttributedString+KZ.h"
#import <CoreText/CoreText.h>

@implementation KZLayoutManager

- (void)drawBackgroundForGlyphRange:(NSRange)glyphsToShow atPoint:(CGPoint)origin {
    if(self.willDrawBackground) {
        self.willDrawBackground(self.contextRef,glyphsToShow,origin);
    }
    [super drawBackgroundForGlyphRange:glyphsToShow atPoint:origin];
    
    if(self.didDrawBackground) {
        self.didDrawBackground(self.contextRef,glyphsToShow,origin);
    }
}
- (void)drawGlyphsForGlyphRange:(NSRange)glyphsToShow atPoint:(CGPoint)origin {
    if(self.willDrawGlyphs) {
        self.willDrawGlyphs(self.contextRef,glyphsToShow,origin);
    }
    [super drawGlyphsForGlyphRange:glyphsToShow atPoint:origin];
    if(self.didDrawGlyphs) {
        self.didDrawGlyphs(self.contextRef,glyphsToShow,origin);
    }
}


- (NSArray <KZLayoutInfo *>*)enumerateRectsForGlyphRange:(NSRange)range
                                         inTextContainer:(NSTextContainer *)textContainer
                                                  insets:(UIEdgeInsets)insets
                                                   point:(CGPoint)point {
    NSRange glyphRange = [self glyphRangeForCharacterRange:range actualCharacterRange:NULL];
    if (glyphRange.location == NSNotFound) {
        return @[];
    }
    NSMutableArray<KZLayoutInfo *> *rects = [NSMutableArray new];
    [self enumerateEnclosingRectsForGlyphRange:glyphRange withinSelectedGlyphRange:NSMakeRange(NSNotFound, 0) inTextContainer:textContainer usingBlock:^(CGRect rect, BOOL *stop) {
        CGRect proposedRect = rect;
        // This method may return a larger value.
        // NSRange glyphRange = [self glyphRangeForBoundingRect:proposedRect inTextContainer:textContainer];
        NSUInteger startGlyphIndex = [self glyphIndexForPoint:CGPointMake(KZTextCGFloatPixelCeil(CGRectGetMinX(proposedRect)), CGRectGetMidY(proposedRect)) inTextContainer:textContainer];
        NSUInteger endGlyphIndex = [self glyphIndexForPoint:CGPointMake(KZTextCGFloatPixelFloor(CGRectGetMaxX(proposedRect)), CGRectGetMidY(proposedRect)) inTextContainer:textContainer];
        NSRange glyphLayoutRange = NSMakeRange(startGlyphIndex, endGlyphIndex - startGlyphIndex + 1);
        NSRange characterRange = [self characterRangeForGlyphRange:glyphLayoutRange actualGlyphRange:NULL];
        
        proposedRect = UIEdgeInsetsInsetRect(proposedRect, insets);
        proposedRect.origin.x += point.x;
        proposedRect.origin.y += point.y;
        KZLayoutInfo *layout = [[KZLayoutInfo alloc]init];
        layout.rect = proposedRect;
        layout.glyphRange = glyphLayoutRange;
        layout.characterRange = characterRange;
        layout.parentRange = range;
        [rects addObject:layout];
    }];
    return rects.copy;
}

- (NSArray <KZLayoutInfo *>*)borderEnumerateRectsForGlyphRange:(NSRange)range
                                         inTextContainer:(NSTextContainer *)textContainer
                                                  insets:(UIEdgeInsets)insets
                                                   point:(CGPoint)point {
    NSRange glyphRange = [self glyphRangeForCharacterRange:range actualCharacterRange:NULL];
    if (glyphRange.location == NSNotFound) {
        return @[];
    }
    NSMutableArray<KZLayoutInfo *> *rects = [NSMutableArray new];
    UIFont *font = [self.textStorage attribute:NSFontAttributeName atIndex:glyphRange.location effectiveRange:NULL];
    CGFloat lineHeight = font.lineHeight;
    
    [self enumerateEnclosingRectsForGlyphRange:glyphRange withinSelectedGlyphRange:NSMakeRange(NSNotFound, 0) inTextContainer:textContainer usingBlock:^(CGRect rect, BOOL *stop) {
        CGRect proposedRect = rect;
        if(rect.size.height != lineHeight) {
            proposedRect = [self borderFitRectForGlyphRangeRect:rect glyphRange:glyphRange textContainer:textContainer];
        }
        // This method may return a larger value.
        // NSRange glyphRange = [self glyphRangeForBoundingRect:proposedRect inTextContainer:textContainer];
        NSUInteger startGlyphIndex = [self glyphIndexForPoint:CGPointMake(KZTextCGFloatPixelCeil(CGRectGetMinX(proposedRect)), CGRectGetMidY(proposedRect)) inTextContainer:textContainer];
        NSUInteger endGlyphIndex = [self glyphIndexForPoint:CGPointMake(KZTextCGFloatPixelFloor(CGRectGetMaxX(proposedRect)), CGRectGetMidY(proposedRect)) inTextContainer:textContainer];
        NSRange glyphLayoutRange = NSMakeRange(startGlyphIndex, endGlyphIndex - startGlyphIndex + 1);
        NSRange characterRange = [self characterRangeForGlyphRange:glyphLayoutRange actualGlyphRange:NULL];
        
        proposedRect = UIEdgeInsetsInsetRect(proposedRect, insets);
        proposedRect.origin.x += point.x;
        proposedRect.origin.y += point.y;
        KZLayoutInfo *layout = [[KZLayoutInfo alloc]init];
        layout.rect = proposedRect;
        layout.glyphRange = glyphLayoutRange;
        layout.characterRange = characterRange;
        layout.parentRange = range;
        [rects addObject:layout];
    }];
    return rects.copy;
}

- (NSArray <KZLayoutInfo *>*)underLineEnumerateRectsForGlyphRange:(NSRange)range
                                         inTextContainer:(NSTextContainer *)textContainer
                                                  insets:(UIEdgeInsets)insets
                                                   point:(CGPoint)point {
    int count = (int)[self displayLineForGlyphRange:range];
    if(count == 1) {
        return [self borderEnumerateRectsForGlyphRange:range inTextContainer:textContainer insets:insets point:point];
    }
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    for (int i = 0; i < range.length; i ++) {
        CGRect proposedRect = [self glyphRectForGlyphIndex:range.location + i inTextContainer:textContainer];
        proposedRect.origin.x += point.x;
        proposedRect.origin.y += point.y;
        NSNumber *key = @(proposedRect.origin.y);
        NSMutableSet *rects = dict[key];
        if(!rects) {
            rects = [NSMutableSet set];
            dict[key] = rects;
        }
        [rects addObject:[NSValue valueWithCGRect:proposedRect]];
    }
    NSMutableArray<KZLayoutInfo *> *rectList = [NSMutableArray new];
    for (NSMutableArray *list in dict.allValues) {
        CGRect proposedRect = CGRectZero;
        for (NSValue *v in list) {
            if(CGRectEqualToRect(proposedRect, CGRectZero)) {
                proposedRect = v.CGRectValue;
            } else {
                proposedRect = CGRectUnion(proposedRect, v.CGRectValue);
            }
        }
        KZLayoutInfo *layout = [[KZLayoutInfo alloc]init];
        layout.rect = proposedRect;
        [rectList addObject:layout];
    }
    return rectList.copy;
}

- (NSArray <KZLayoutInfo *>*)queteEnumerateRectsForGlyphRange:(NSRange)range
                                              inTextContainer:(NSTextContainer *)textContainer
                                                        point:(CGPoint)point {
    NSRange glyphRange = [self glyphRangeForCharacterRange:range actualCharacterRange:NULL];
    if (glyphRange.location == NSNotFound) {
        return @[];
    }
    
    NSParagraphStyle *style = [self.textStorage attribute:NSParagraphStyleAttributeName atIndex:glyphRange.location effectiveRange:NULL];
    
    NSMutableArray<KZLayoutInfo *> *rects = [NSMutableArray new];
    [self enumerateEnclosingRectsForGlyphRange:glyphRange withinSelectedGlyphRange:NSMakeRange(NSNotFound, 0) inTextContainer:textContainer usingBlock:^(CGRect rect, BOOL *stop) {
        CGRect proposedRect = CGRectZero;
        if(style.paragraphSpacingBefore > 0) {
            proposedRect = CGRectMake(rect.origin.x, rect.origin.y - style.paragraphSpacingBefore, rect.size.width, rect.size.height + style.paragraphSpacingBefore);
        } else {
            proposedRect = rect;
        }
        // This method may return a larger value.
        // NSRange glyphRange = [self glyphRangeForBoundingRect:proposedRect inTextContainer:textContainer];
        NSUInteger startGlyphIndex = [self glyphIndexForPoint:CGPointMake(KZTextCGFloatPixelCeil(CGRectGetMinX(proposedRect)), CGRectGetMidY(proposedRect)) inTextContainer:textContainer];
        NSUInteger endGlyphIndex = [self glyphIndexForPoint:CGPointMake(KZTextCGFloatPixelFloor(CGRectGetMaxX(proposedRect)), CGRectGetMidY(proposedRect)) inTextContainer:textContainer];
        NSRange glyphLayoutRange = NSMakeRange(startGlyphIndex, endGlyphIndex - startGlyphIndex + 1);
        NSRange characterRange = [self characterRangeForGlyphRange:glyphLayoutRange actualGlyphRange:NULL];
        
        proposedRect.origin.x += point.x;
        proposedRect.origin.y += point.y;
        KZLayoutInfo *layout = [[KZLayoutInfo alloc]init];
        layout.rect = proposedRect;
        layout.glyphRange = glyphLayoutRange;
        layout.characterRange = characterRange;
        layout.parentRange = range;
        [rects addObject:layout];
    }];
    return rects.copy;
}


- (NSArray <KZLayoutInfo *>*)enumerateBlockRectsForGlyphRange:(NSRange)range
                                              inTextContainer:(NSTextContainer *)textContainer
                                                       insets:(UIEdgeInsets)insets
                                                        point:(CGPoint)point {
    NSRange glyphRange = [self glyphRangeForCharacterRange:range actualCharacterRange:NULL];
    if (glyphRange.location == NSNotFound) {
        return @[];
    }
    
    CGRect blockRect;
    NSRange effectiveStartGlyphRange;
    CGRect startLineFragmentRect = [self lineFragmentRectForGlyphAtIndex:glyphRange.location effectiveRange:&effectiveStartGlyphRange];
    startLineFragmentRect = [self boundingRectForGlyphRange:effectiveStartGlyphRange inTextContainer:textContainer];

    NSUInteger maxGlyphIndex = NSMaxRange(glyphRange) - 1;
    if (NSLocationInRange(maxGlyphIndex, effectiveStartGlyphRange)) { // in the same line
        blockRect = startLineFragmentRect;
    } else {
        NSRange effectiveEndGlyphRange;
        CGRect endLineFragmentRect = [self lineFragmentRectForGlyphAtIndex:maxGlyphIndex effectiveRange:&effectiveEndGlyphRange];
        endLineFragmentRect = [self boundingRectForGlyphRange:effectiveEndGlyphRange inTextContainer:textContainer];
        
        blockRect = endLineFragmentRect;
        blockRect = CGRectUnion(startLineFragmentRect, blockRect);
    }
    
    blockRect = UIEdgeInsetsInsetRect(blockRect, insets);
    blockRect.origin.x += point.x;
    blockRect.origin.y += point.y;
    KZLayoutInfo *layout = [[KZLayoutInfo alloc]init];
    layout.rect = blockRect;
    layout.glyphRange = glyphRange;
    layout.characterRange = range;
    layout.parentRange = range;

    return @[layout];
}


- (NSArray <KZLayoutInfo *>*)enumerateUsedBlockRectsForGlyphRange:(NSRange)range
                                                  inTextContainer:(NSTextContainer *)textContainer
                                                           insets:(UIEdgeInsets)insets
                                                            point:(CGPoint)point {
    NSRange glyphRange = [self glyphRangeForCharacterRange:range actualCharacterRange:NULL];
    if (glyphRange.location == NSNotFound) {
        return @[];
    }
    CGRect blockRect;
    NSRange effectiveGlyphRange;
    CGRect startUsedLineFragmentRect = [self lineFragmentUsedRectForGlyphAtIndex:glyphRange.location effectiveRange:&effectiveGlyphRange];
    NSUInteger maxGlyphIndex = NSMaxRange(glyphRange) - 1;
    if (NSLocationInRange(maxGlyphIndex, effectiveGlyphRange)) { // in the same line
        blockRect = startUsedLineFragmentRect;
    } else {
        CGRect endLineUsedFragmentRect = [self lineFragmentUsedRectForGlyphAtIndex:maxGlyphIndex effectiveRange:NULL];
        blockRect = endLineUsedFragmentRect;
        blockRect = CGRectUnion(startUsedLineFragmentRect, blockRect);
    }
    blockRect = UIEdgeInsetsInsetRect(blockRect, insets);
    blockRect.origin.x += point.x;
    blockRect.origin.y += point.y;
    KZLayoutInfo *layout = [[KZLayoutInfo alloc]init];
    layout.rect = blockRect;
    layout.glyphRange = glyphRange;
    layout.characterRange = range;
    layout.parentRange = range;
    return @[layout];
}

- (CGRect)borderFitRectForGlyphRangeRect:(CGRect)rect
                              glyphRange:(NSRange)glyphRange
                           textContainer:(NSTextContainer *)textContainer{
    NSRange lineRange = [self glyphRangeForBoundingRect:rect inTextContainer:textContainer];
    NSRange intersectionRange = NSIntersectionRange(glyphRange,lineRange);
    /// 取中间的 index算内容
    NSUInteger glyphIndex = intersectionRange.location + (intersectionRange.length - 1) / 2;
    CGRect indexRect = [self glyphRectForGlyphIndex:glyphIndex inTextContainer:textContainer];
    /// 修补 y 和 height时算出来的出现异常 则不进行修复
    if (indexRect.size.width < 1 || indexRect.size.height < 1) {
        indexRect = rect;
    }
    CGRect proposedRect = CGRectMake(rect.origin.x, indexRect.origin.y, rect.size.width , indexRect.size.height);
    return proposedRect;
}

- (NSInteger)displayLineForGlyphRange:(NSRange)range {
    __block NSInteger count = 0;
    [self enumerateLineFragmentsForGlyphRange:range usingBlock:^(CGRect rect, CGRect usedRect, NSTextContainer * _Nonnull textContainer, NSRange glyphRange, BOOL * _Nonnull stop) {
        count ++;
    }];
    return count;
}

- (CGRect)glyphRectForGlyphIndex:(NSUInteger)glyphIndex inTextContainer:(NSTextContainer *)textContainer {
    NSUInteger charIndex = [self characterIndexForGlyphAtIndex:glyphIndex];
    CGGlyph glyph = [self CGGlyphAtIndex:glyphIndex];
    CTFontRef font = (__bridge_retained CTFontRef)[self.textStorage attribute:NSFontAttributeName
                                                                      atIndex:charIndex
                                                               effectiveRange:NULL];
    if (font == nil) {
        font = (__bridge_retained CTFontRef)[UIFont systemFontOfSize:17];
    }
    //                                    Glyph Advance
    //                             +-------------------------+
    //                             |                         |
    //                             |                         |
    // +------------------------+--|-------------------------|--+-----------+-----+ What TextKit returns sometimes
    // |                        |  |             XXXXXXXXXXX +  |           |     | (approx. correct height, but
    // |               ---------|--+---------+  XXX       XXXX +|-----------|-----|  sometimes inaccurate bounding
    // |               |        |             XXX          XXXXX|           |     |  widths)
    // |               |        |             XX             XX |           |     |
    // |               |        |            XX                 |           |     |
    // |               |        |           XXX                 |           |     |
    // |               |        |           XX                  |           |     |
    // |               |        |      XXXXXXXXXXX              |           |     |
    // |   Cap Height->|        |          XX                   |           |     |
    // |               |        |          XX                   |  Ascent-->|     |
    // |               |        |          XX                   |           |     |
    // |               |        |          XX                   |           |     |
    // |               |        |          X                    |           |     |
    // |               |        |          X                    |           |     |
    // |               |        |          X                    |           |     |
    // |               |        |         XX                    |           |     |
    // |               |        |         X                     |           |     |
    // |               ---------|-------+ X +-------------------------------------|
    // |                        |        XX                     |                 |
    // |                        |        X                      |                 |
    // |                        |      XX         Descent------>|                 |
    // |                        | XXXXXX                        |                 |
    // |                        |  XXX                          |                 |
    // +------------------------+-------------------------------------------------+
    //                                                          |
    //                                                          +--+Actual bounding box
    
    CGFloat advance = CTFontGetAdvancesForGlyphs(font, kCTFontOrientationHorizontal, &glyph, NULL, 1);
    CGFloat ascent = CTFontGetAscent(font);
    CGFloat descent = CTFontGetDescent(font);
    
    CFRelease(font);
    
    // Textkit's glyphs count not equal CoreText glyphs count, and the CoreText removed glyphs if glyph == 0. It's means the glyph not suitable for font.
    if (glyph == 0 && glyphIndex > 0) {
        return [self glyphRectForGlyphIndex:glyphIndex - 1 inTextContainer:textContainer];
    }
    
    CGRect glyphRect = [self boundingRectForGlyphRange:NSMakeRange(glyphIndex, 1) inTextContainer:textContainer];
    
    // If it is a NSTextAttachment(glyph == kCGFontIndexInvalid), we don't have the matched glyph and use width of glyphRect instead of advance.
    CGFloat lineHeight = (glyph == kCGFontIndexInvalid) ? glyphRect.size.height : ascent + descent;
    CGPoint location = [self locationForGlyphAtIndex:glyphIndex];
    CGRect lineFragmentRect = [self lineFragmentRectForGlyphAtIndex:glyphIndex effectiveRange:NULL];
    CGFloat baseline = location.y + CGRectGetMinY(lineFragmentRect);
    
    CGRect properGlyphRect;
    // We are just measuring the line heights here, so we can use the
    // heights used by TextKit, which tend to be pretty good.
    properGlyphRect = CGRectMake(CGRectGetMinX(lineFragmentRect) + location.x,
                                 (glyph == kCGFontIndexInvalid) ? CGRectGetMinY(glyphRect) : baseline - ascent,
                                 (glyph == kCGFontIndexInvalid) ? CGRectGetWidth(glyphRect) : advance,
                                 lineHeight);
    return properGlyphRect;
}

@end
