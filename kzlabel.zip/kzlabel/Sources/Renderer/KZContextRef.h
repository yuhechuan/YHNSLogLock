//
//  KZContextRef.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <Foundation/Foundation.h>

@class KZTextAttributes;
@class KZLayoutManager;
@class NSTextStorage;
@class NSTextContainer;
@class KZContextExtension;
@class KZTextSelectionRect;
@class KZTextAttachment;
@class KZTextDebugOption;

@protocol KZTextRenderer;

@interface KZTextTruncationInfo : NSObject

@property (nonatomic, assign) NSRange truncationTextContainerRange;
@property (nonatomic, assign) CGRect truncationTextContainerRect;
@property (nonatomic, assign) CGRect truncationRect;

@property (nonatomic, assign) NSRange visibleCharacterRange;
@property (nonatomic, assign) CGRect truncatedBoundingRect;

@end


@interface KZContextRef : NSObject

@property (nonatomic, strong, readonly) KZLayoutManager *layoutManager;
@property (nonatomic, strong, readonly) NSTextStorage *textStorage;
@property (nonatomic, strong, readonly) NSTextContainer *textContainer;
@property (nonatomic, assign, readonly) NSRange glyphRange;
@property (nonatomic, strong, readonly) KZTextAttributes *attributes;

@property (nonatomic, assign) CGPoint glyphPoint;
@property (nonatomic, assign) CGSize containerSize;
@property (nonatomic, assign) CGSize calculatedSize;

@property (nonatomic, copy, readonly) NSArray *textRenderersClassList;

@property (nonatomic, strong) KZTextTruncationInfo *truncationInfo;
@property (nonatomic, assign) BOOL existedAttachment;
@property (nonatomic, strong) KZContextExtension *extension;
@property (nonatomic, copy) NSArray *kzLineBreakModeKeys;

- (instancetype)initWithAttributes:(KZTextAttributes *)attributes
                     containerSize:(CGSize)containerSize;

- (void)refreshTextStorege:(NSAttributedString *)attributedText;
- (void)onlyRefreshTextStorege:(NSAttributedString *)attributedText;

/// key 为 id<KZTextRenderer>  NSStringFromClass([renderer class]
- (id<KZTextRenderer>)textRendererForKey:(NSString *)key;

@end


@interface KZContextRef (KZTextExtendedContextRef)

- (NSUInteger)characterIndexForPoint:(CGPoint)point rangeSuffixIndex:(BOOL)rangeSuffixIndex;
- (NSRange)rangeEnclosingCharacterForIndex:(NSUInteger)characterIndex;

- (NSArray<KZTextSelectionRect *> *)selectionRectsForCharacterRange:(NSRange)characterRange;
- (CGRect)lineFragmentUsedRectForCharacterAtIndex:(NSUInteger)characterIndex effectiveRange:( NSRangePointer)effectiveCharacterRange;
- (CGRect)lineFragmentRectForCharacterAtIndex:(NSUInteger)characterIndex effectiveRange:( NSRangePointer)effectiveCharacterRange;

@end

