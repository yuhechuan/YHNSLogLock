//
//  KZTextHelper.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/4.
//

#import <UIKit/UIKit.h>
#import <stdatomic.h>
/**
 * The hashing algorithm copied from CoreFoundation CFHashBytes function.
 * https://opensource.apple.com/source/CF/CF-1153.18/CFUtilities.c.auto.html
 */
#define KZText_ELF_STEP(B) T1 = (H << 4) + B; T2 = T1 & 0xF0000000; if (T2) T1 ^= (T2 >> 24); T1 &= (~T2); H = T1;

typedef void (^KZLabelGraphicsImageDrawingActions)(CGContextRef context);

typedef NS_ENUM(int, KZTextVerticalAlignment) {
    KZTextVerticalAlignmentTop =    0, ///< Top alignment.
    KZTextVerticalAlignmentCenter = 1, ///< Center alignment.
    KZTextVerticalAlignmentBottom = 2, ///< Bottom alignment.
};

typedef NS_ENUM(int, KZTextSelectionGrabberType) {
    KZTextSelectionGrabberTypeNone,
    KZTextSelectionGrabberTypeStart,
    KZTextSelectionGrabberTypeEnd
};

/// Magnifier type
typedef NS_ENUM(int, KZTextMagnifierType) {
    KZTextMagnifierTypeRanged = 0, ///< Round rectangle magnifier
    KZTextMagnifierTypeCaret,      ///< Circular magnifier
};

typedef NS_OPTIONS(NSUInteger, KZAutoDetectCheckType) {
    KZAutoDetectCheckTypeNone  = 0,
    KZAutoDetectCheckTypeLink  = 1 << 0, //email or url
    KZAutoDetectCheckTypePhone = 1 << 1,
    KZAutoDetectCheckTypeEmoji = 1 << 2,
    KZAutoDetectCheckTypeAll   = KZAutoDetectCheckTypeLink | KZAutoDetectCheckTypePhone | KZAutoDetectCheckTypeEmoji,
};

/// Magnifier type
typedef NS_ENUM(int, KZTextMenuType) {
    KZTextMenuTypeYPMenu = 0,  ///YPMenuController
    KZTextMenuTypeUIMenu,      ///UIMenuController
};

/// Magnifier type
typedef NS_ENUM(int, KZLabelType) {
    KZLabelTypeNormal = 0,  /// 同步
    KZLabelTypeImageMark,   ///  带image的mark
    KZLabelTypeGradientMark,/// 带渐变的 mark
};

static CGFloat const kAsyncFadeDuration = 0.09; // Time in seconds for async display fadeout animation.
static CGFloat const kHighlightFadeDuration = 0.15; // Time in seconds for async display fadeout animation.
static NSString *const kAsyncFadeAnimationKey = @"contents";

FOUNDATION_EXTERN const CGSize KZTextContainerMaxSize;
FOUNDATION_EXTERN CGAffineTransform KZTextCGAffineTransformGetFromViews(UIView *from, UIView *to);
FOUNDATION_EXTERN CGAffineTransform KZTextCGAffineTransformGetFromPoints(CGPoint before[3], CGPoint after[3]);

UIKIT_EXTERN NSAttributedStringKey const KZTextLinkAttributedStringKey;
UIKIT_EXTERN NSAttributedStringKey const KZTextBorderAttributedStringKey;
UIKIT_EXTERN NSAttributedStringKey const KZTextQuoteAttributedStringKey;
UIKIT_EXTERN NSAttributedStringKey const KZTextBodyAttributedStringKey;
UIKIT_EXTERN NSAttributedStringKey const KZTextTrunctionAttributedStringKey;
UIKIT_EXTERN NSAttributedStringKey const KZTextDebugAttributedStringKey;

UIKIT_EXTERN NSAttributedStringKey const KZTextOriginalFontAttributeName;

UIKIT_EXTERN NSString *const KZAttachmentPlaceholder;

NSDictionary *KZTextRenderersMap(void);
CGFloat       KZTextScreenScale(void);
CGSize        KZTextScreenSize(void);
NSUInteger    KZTextHashBytes(void *bytesarg, size_t length);
UIWindow *    KZTextKeyWindow(void);

NSAttributedString *KZTextPrepareTruncationTextForDrawing(NSAttributedString *attributedText, NSAttributedString *truncationText);
NSAttributedString *KZTextDefaultTruncationAttributedToken(void);
NSAttributedString *KZTextTruncationAttributedTextWithToken(NSAttributedString *attributedText,
                                                            NSAttributedString *token);

CGRect KZTextCGRectFitWithContentMode(CGRect rect, CGSize size, UIViewContentMode mode);

#pragma mark - UIGraphicsImageRenderer
/**
 * 替换 UIGraphicsBeginImageContextWithOptions
 */
UIImage *kzlabel_appGraphicsRendererWithOptions(CGSize size, BOOL opaque, CGFloat scale, KZLabelGraphicsImageDrawingActions actions);

/// Global display queue, used for content rendering.
static dispatch_queue_t KZTextAsyncLayerGetDisplayQueue(void) {
#define MAX_QUEUE_COUNT 16
    static int queueCount;
    static dispatch_queue_t queues[MAX_QUEUE_COUNT];
    static dispatch_once_t onceToken;
    static atomic_int counter = 0;
    dispatch_once(&onceToken, ^{
        queueCount = (int)[NSProcessInfo processInfo].activeProcessorCount;
        queueCount = (queueCount < 1 ? 1 : queueCount) > MAX_QUEUE_COUNT ? MAX_QUEUE_COUNT : queueCount;
        for (NSUInteger i = 0; i < queueCount; i++) {
            dispatch_queue_attr_t attr = dispatch_queue_attr_make_with_qos_class(DISPATCH_QUEUE_SERIAL, QOS_CLASS_USER_INITIATED, 0);
            queues[i] = dispatch_queue_create("com.kz.text.render", attr);
        }
    });
    atomic_fetch_add_explicit(&counter, 1, __ATOMIC_SEQ_CST);
    return queues[(counter) % queueCount];
#undef MAX_QUEUE_COUNT
}

static dispatch_queue_t KZTextAsyncLayerGetReleaseQueue(void) {
    return dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0);
}


static inline BOOL KZTextObjectIsEqual(id<NSObject> obj, id<NSObject> otherObj)
{
    return obj == otherObj || [obj isEqual:otherObj];
}

#pragma mark -- CGFloat

/// floor point value for pixel-aligned
static inline CGFloat KZTextCGFloatPixelFloor(CGFloat value) {
    CGFloat scale = KZTextScreenScale();
    return floor(value * scale) / scale;
}

/// round point value for pixel-aligned
static inline CGFloat KZTextCGFloatPixelRound(CGFloat value) {
    CGFloat scale = KZTextScreenScale();
    return round(value * scale) / scale;
}

/// ceil point value for pixel-aligned
static inline CGFloat KZTextCGFloatPixelCeil(CGFloat value) {
    CGFloat scale = KZTextScreenScale();
    return ceil((value - FLT_EPSILON) * scale) / scale;
}

/// Convert pixel to point.
static inline CGFloat KZTextCGFloatFromPixel(CGFloat value) {
    return value / KZTextScreenScale();
}

/// round point value to .5 pixel for path stroke (odd pixel line width pixel-aligned)
static inline CGFloat KZTextCGFloatPixelHalf(CGFloat value) {
    CGFloat scale = KZTextScreenScale();
    return (floor(value * scale) + 0.5) / scale;
}

/// Returns the distance between two points.
static inline CGFloat KZTextCGPointGetDistanceToPoint(CGPoint p1, CGPoint p2) {
    return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}

/// Convert radians to degrees.
static inline CGFloat KZTextRadiansToDegrees(CGFloat radians) {
    return radians * 180 / M_PI;
}

/// Get the transform rotation.
/// @return the rotation in radians [-PI,PI] ([-180°,180°])
static inline CGFloat KZTextCGAffineTransformGetRotation(CGAffineTransform transform) {
    return atan2(transform.b, transform.a);
}

#pragma mark -- CGPoint

/// round point value to .5 pixel for path stroke (odd pixel line width pixel-aligned)
static inline CGPoint KZTextCGPointPixelHalf(CGPoint point) {
    CGFloat scale = KZTextScreenScale();
    return CGPointMake((floor(point.x * scale) + 0.5) / scale,
                       (floor(point.y * scale) + 0.5) / scale);
}

/// Returns the center for the rectangle.
static inline CGPoint KZTextCGRectGetCenter(CGRect rect) {
    return CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
}

/// round point value for pixel-aligned
static inline CGPoint KZTextCGPointPixelRound(CGPoint point) {
    CGFloat scale = KZTextScreenScale();
    return CGPointMake(round(point.x * scale) / scale,
                       round(point.y * scale) / scale);
}


#pragma mark -- CGRect
/// round point value to .5 pixel for path stroke (odd pixel line width pixel-aligned)
static inline CGRect KZTextCGRectPixelHalf(CGRect rect) {
    CGPoint origin = KZTextCGPointPixelHalf(rect.origin);
    CGPoint corner = KZTextCGPointPixelHalf(CGPointMake(rect.origin.x + rect.size.width,
                                                         rect.origin.y + rect.size.height));
    return CGRectMake(origin.x, origin.y, corner.x - origin.x, corner.y - origin.y);
}

/// round point value for pixel-aligned
static inline CGRect KZTextCGRectPixelRound(CGRect rect) {
    CGPoint origin = KZTextCGPointPixelRound(rect.origin);
    CGPoint corner = KZTextCGPointPixelRound(CGPointMake(rect.origin.x + rect.size.width,
                                                          rect.origin.y + rect.size.height));
    return CGRectMake(origin.x, origin.y, corner.x - origin.x, corner.y - origin.y);
}

static inline NSRegularExpression* kz_getEmojiRegex(void) {
    static NSRegularExpression *regex = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSError *error = nil;
        regex = [NSRegularExpression regularExpressionWithPattern:@"\\[[^ \\[\\]]+?\\]" options:kNilOptions error:&error];
    });
    return regex;
}

#pragma mark -- CGSize
static inline BOOL KZTextCGSizeContainsSize(CGSize size1, CGSize size2) {
    return (size1.width >= size2.width) && (size1.height >= size2.height);
}

static inline BOOL KZTextCGSizeSingleContainsSize(CGSize size1, CGSize size2) {
    if(size1.width == size2.width && size1.height >= size2.height) {
        return YES;
    }
    if(size1.height == size2.height && size1.width >= size2.width) {
        return YES;
    }
    return NO;
}

#pragma mark -- Custom detect
static inline NSRegularExpression* kz_getPhoneNumberRegex(NSString *phoneRegex) {
    if (phoneRegex && phoneRegex.length > 1) {
        NSError *error = nil;
        return [NSRegularExpression regularExpressionWithPattern:phoneRegex options:kNilOptions error:&error];
    }
    static NSRegularExpression *regex = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSError *error = nil;
        regex = [NSRegularExpression regularExpressionWithPattern:@"(\\+\\d{1,2}\\s?)?1?\\-?\\.?\\s?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4,5}" options:kNilOptions error:&error];
    });
    return regex;
}

static inline NSRegularExpression* kz_getEmailRegex(NSString *emailRegex) {
    if (emailRegex && emailRegex.length > 1) {
        NSError *error = nil;
        return [NSRegularExpression regularExpressionWithPattern:emailRegex options:kNilOptions error:&error];
    }
    static NSRegularExpression *regex = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSError *error = nil;
        regex = [NSRegularExpression regularExpressionWithPattern:@"[a-zA-Z0-9\\+\\.\\_\\%\\-\\+\\－]{1,256}\\@[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}(\\.[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25})+"
                  options:kNilOptions error:&error];
    });
    return regex;
}

static inline NSRegularExpression* kz_getURLRegex(NSString *linkRegex) {
    if (linkRegex && linkRegex.length > 1) {
        NSError *error = nil;
        return [NSRegularExpression regularExpressionWithPattern:linkRegex options:kNilOptions error:&error];
    }
    static NSRegularExpression *regex = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSError *error = nil;
        regex = [NSRegularExpression regularExpressionWithPattern:@"((http|ftp|https)://)(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\\&%_\\./-~-]*)?|(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\\&%_\\./-~-]*)?" options:kNilOptions error:&error];
    });
    return regex;
}

static inline BOOL kz_HasSeparatorSuffix(NSString *string) {
    if ([string hasSuffix:@"\n"] ||
        [string hasSuffix:@"\u2028"] ||
        [string hasSuffix:@"\u2029"]) {
        return YES;
    }
    return NO;
}

#pragma mark -- Auto detect
static inline NSPredicate* kz_getDatePredicate(void) {
    static NSPredicate *predicate = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^\\d{4}-\\d{1,2}-\\d{1,2}"];
    });
    return predicate;

}

static inline NSDataDetector* kz_getDetector(NSTextCheckingTypes checkType) {
    static NSDataDetector *detector = nil;
    if (detector && detector.checkingTypes == checkType) {
        return detector;
    }else{
        NSError *error = nil;
        detector = [[NSDataDetector alloc] initWithTypes:checkType error:&error];
        return detector;
    }
}

static inline NSCharacterSet *KZTextDefaultAvoidTruncationCharacterSet(void) {
    static NSCharacterSet *truncationCharacterSet;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSMutableCharacterSet *mutableCharacterSet = [[NSMutableCharacterSet alloc] init];
        [mutableCharacterSet formUnionWithCharacterSet:[NSCharacterSet newlineCharacterSet]];
        truncationCharacterSet = mutableCharacterSet;
    });
    return truncationCharacterSet;
}


static inline NSCache *sharedRendererCache(void) {
    static dispatch_once_t onceToken;
    static NSCache *rendererCache = nil;
    dispatch_once(&onceToken, ^{
        rendererCache = [[NSCache alloc] init];
        rendererCache.countLimit = 500;
    });
    return rendererCache;
}

static inline NSCache *sharedTextSizeCache(void) {
    static dispatch_once_t onceToken;
    static NSCache *textViewSizeCache = nil;
    dispatch_once(&onceToken, ^{
        textViewSizeCache = [[NSCache alloc] init];
        textViewSizeCache.countLimit = 500;
    });
    return textViewSizeCache;
}

