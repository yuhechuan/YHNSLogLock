//
//  KZTextAttachmentRenderer.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import "KZTextRenderer.h"

@interface KZTextAttachmentRenderer : NSObject<KZTextRenderer>

/// 化 View  或者 Layer 类型的附件
- (void)drawViewAndLayerAttchmentsWithAttachments:(CGPoint)point
                                         textView:(UIView *)textView;
/// 清除 附件
- (void)clearAttachmentViewsAndLayersWithAttachmetsInfo:(UIView *)textView;
- (void)clearAttachmentViewsAndLayers:(UIView *)textView;


@end
