//
//  KZTextBorderRenderer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import "KZTextBorderRenderer.h"

@interface KZTextBorderRenderer ()

@property (nonatomic, copy) NSArray *rendererRectList;

@end

@implementation KZTextBorderRenderer {
    KZContextRef *_contextRef;
}

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef {
    _contextRef = contextRef;
    self.rendererRectList = @[];
}

- (NSArray *)rectsForAttribute:(NSObject *)attribute characterRange:(NSRange)characterRange {
    KZTextBorder *border = (KZTextBorder *)attribute;
    KZLayoutManager *layoutManager = _contextRef.layoutManager;
    NSTextContainer *textContainer = _contextRef.textContainer;
    CGPoint point = _contextRef.glyphPoint;

    NSArray *rects = @[];
    if(border.underlineColor && border.underlineWidth > 0) {
        rects = [layoutManager underLineEnumerateRectsForGlyphRange:characterRange inTextContainer:textContainer insets:border.insets point:point];
    } else if (border.borderStyle == KZBorderBlockAround) {
        rects = [layoutManager enumerateUsedBlockRectsForGlyphRange:characterRange inTextContainer:textContainer insets:border.insets point:point];
    } else if(border.borderStyle == KZBorderBlockTiled) {
        rects = [layoutManager enumerateBlockRectsForGlyphRange:characterRange inTextContainer:textContainer insets:border.insets point:point];
    } else if(border.borderStyle == KZBorderNormalFullLine) {
        rects = [layoutManager enumerateRectsForGlyphRange:characterRange inTextContainer:textContainer insets:border.insets point:point];
    } else {
        rects = [layoutManager borderEnumerateRectsForGlyphRange:characterRange inTextContainer:textContainer insets:border.insets point:point];
    }
    return rects;
}

- (void)didCalculateTextRenderer:(NSArray <KZRendererRect *>*)rendererRectList {
    self.rendererRectList = rendererRectList;
}

- (void)beginRendererAtPoint:(CGPoint)point {
    for (KZRendererRect *value in self.rendererRectList) {
        if(![value.textAttribute isMemberOfClass:[KZTextBorder class]]) {
            continue;;
        }
        KZTextBorder *border = value.textAttribute;
        for (KZLayoutInfo *info in value.rectValues) {
            [self drawUnderLineBgWithBorder:border rect:info.rect];
        }
    }
}

- (void)endRendererAtPoint:(CGPoint)point {
    for (KZRendererRect *value in self.rendererRectList) {
        if(![value.textAttribute isMemberOfClass:[KZTextBorder class]]) {
            continue;
        }
        KZTextBorder *border = value.textAttribute;
        if(border.underLineLevel == KZBorderUnderLineLevelBottom) {
            continue;
        }
        for (KZLayoutInfo *info in value.rectValues) {
            [self drawUnderLineWithBorder:border rect:info.rect];
        }
    }
}

- (void)drawUnderLineBgWithBorder:(KZTextBorder *)value rect:(CGRect)rect {
    
    BOOL fill = value.fillColor;
    BOOL boder = value.borderColor && value.borderWidth > 0;
    if(!fill && !boder) {
        return;
    }
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSaveGState(contextRef);
    
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:value.cornerRadius];
    [path closePath];
    
    if (fill) {
        CGContextAddPath(contextRef, path.CGPath);
        CGContextSetFillColorWithColor(contextRef, value.fillColor.CGColor);
        CGContextFillPath(contextRef);
    }
    if(boder){
        CGContextAddPath(contextRef, path.CGPath);
        CGContextSetLineWidth(contextRef, value.borderWidth);
        CGContextSetStrokeColorWithColor(contextRef, value.borderColor.CGColor);
        CGContextStrokePath(contextRef);
    }
    CGContextRestoreGState(contextRef);
    
    if(value.underLineLevel == KZBorderUnderLineLevelBottom) {
        [self drawUnderLineWithBorder:value rect:rect];
    }
}

- (void)drawUnderLineWithBorder:(KZTextBorder *)value rect:(CGRect)rect {
    //boder underline
    if (value.underlineColor && value.underlineWidth > 0) {
        CGContextRef contextRef = UIGraphicsGetCurrentContext();

        CGFloat oringinY = CGRectGetMaxY(rect);
        if (value.underlineStyle == KZBorderUnderLineCenterNormal || value.underlineStyle == KZBorderUnderLineCenterDash) {
            oringinY = CGRectGetMidY(rect);
        }
        oringinY -= value.underlineOffset;
        
        CGPoint startPoint = CGPointMake(rect.origin.x, oringinY);
        CGPoint endPoint = CGPointMake(CGRectGetMaxX(rect), oringinY);
        UIBezierPath *underlinePath = [UIBezierPath bezierPath];
        [underlinePath moveToPoint:startPoint];
        [underlinePath addLineToPoint:endPoint];
        
        CGContextSaveGState(contextRef);
        CGContextAddPath(contextRef, underlinePath.CGPath);
        CGContextSetLineWidth(contextRef,  value.underlineWidth);
        CGContextSetStrokeColorWithColor(contextRef, value.underlineColor.CGColor);
        
        if (value.underlineStyle == KZBorderUnderLineDash || value.underlineStyle == KZBorderUnderLineCenterDash) {
            CGFloat painted = value.dashPaintedLength > 0 ? value.dashPaintedLength : 4;
            CGFloat notPainted = value.dashNotPaintedLength > 0 ? value.dashNotPaintedLength : 4;
            CGFloat dash[] = {painted, notPainted};
            CGContextSetLineDash(contextRef, 0, dash, 2);
        }
        CGContextStrokePath(contextRef);
        CGContextRestoreGState(contextRef);
    }
}



@end
