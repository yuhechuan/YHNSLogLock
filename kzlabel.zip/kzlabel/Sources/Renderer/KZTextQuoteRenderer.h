//
//  KZTextQuoteRenderer.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import "KZTextRenderer.h"

@interface KZTextQuoteRenderer : NSObject<KZTextRenderer>

@end
