//
//  KZTextAttachmentRenderer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import "KZTextAttachmentRenderer.h"

@interface KZTextAttachmentRenderer ()

@property (nonatomic, strong) NSArray <KZRendererRect *>*rendererRectList;

@end

@implementation KZTextAttachmentRenderer {
    KZContextRef *_contextRef;
}

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef {
    _contextRef = contextRef;
    self.rendererRectList = @[];
}

- (NSArray *)rectsForAttribute:(NSObject *)attribute characterRange:(NSRange)characterRange {
    if (![attribute isKindOfClass:KZTextAttachment.class]) {
        return @[];
    }
    KZTextAttachment *attachment = (KZTextAttachment *)attribute;
    KZLayoutManager *layoutManager = _contextRef.layoutManager;
    NSTextContainer *textContainer = _contextRef.textContainer;
    CGPoint point = _contextRef.glyphPoint;
    
    NSRange glyphRange = [layoutManager glyphRangeForCharacterRange:characterRange actualCharacterRange:NULL];
    CGRect attachmentFrame = [layoutManager boundingRectForGlyphRange:glyphRange inTextContainer:textContainer];
    CGPoint location = [layoutManager locationForGlyphAtIndex:glyphRange.location];
    
    // location.y is attachment's frame maxY，this behaviors depends on TextKit and KZTextAttachment implementation.
    attachmentFrame.origin.y += location.y;
    attachmentFrame.origin.y -= attachment.attachmentSize.height;
    attachmentFrame.size.height = attachment.attachmentSize.height;
    
    attachmentFrame.origin.x += point.x;
    attachmentFrame.origin.y += point.y;
    KZLayoutInfo *info = [[KZLayoutInfo alloc]init];
    info.rect = attachmentFrame;
    info.glyphRange = glyphRange;
    info.characterRange = characterRange;
    return @[info];
}

- (void)didCalculateTextRenderer:(NSArray <KZRendererRect *>*)rendererRectList {
    self.rendererRectList = rendererRectList;
}

- (void)beginRendererAtPoint:(CGPoint)point {
}


- (void)drawViewAndLayerAttchmentsWithAttachments:(CGPoint)point
                                         textView:(UIView *)textView {
    for (KZRendererRect *attachmentRect in self.rendererRectList) {
        if(![attachmentRect.textAttribute isMemberOfClass:[KZTextAttachment class]]) {
            continue;
        }
        KZTextAttachment *attachment = attachmentRect.textAttribute;
        if([attachment.content isKindOfClass:[UIImage class]]) {
            continue;
        }
        [self addAttachmentViewsAndLayersToCaches:attachment];
        KZLayoutInfo *layoutInfo = attachmentRect.rectValues.firstObject;
        [self drawAttachmentInDrawRect:layoutInfo.rect attachment:attachment textView:textView];
    }
}


- (void)drawAttachmentInDrawRect:(CGRect)drawRect
                      attachment:(KZTextAttachment *)attachment
                        textView:(UIView *)textView {
    CGRect rect = drawRect;
    rect = CGRectOffset(rect, attachment.bounds.origin.x, attachment.bounds.origin.y);
    rect = UIEdgeInsetsInsetRect(rect, attachment.contentInsets);
    rect = KZTextCGRectFitWithContentMode(rect, attachment.attachmentSize, attachment.contentMode);
    rect = KZTextCGRectPixelRound(rect);
    
    UIView *view = nil;
    CALayer *layer = nil;
    UIImage *image = nil;
    if ([attachment.content isKindOfClass:[UIView class]]) {
        view = attachment.content;
    } else if ([attachment.content isKindOfClass:[CALayer class]]) {
        layer = attachment.content;
    } else if ([attachment.content isKindOfClass:UIImage.class]) {
        image = attachment.content;
    }
    if (image) {
        [image drawInRect:rect];
    } else if (view) {
        if (!CGRectEqualToRect(view.frame, rect)) {
            view.frame = rect;
        }
        if (view.superview != textView) {
            [_contextRef.extension.attachmentViews addObject:view];
            [textView addSubview:view];
        }
    }else if (layer){
        if (!CGRectEqualToRect(layer.frame, rect)) {
            layer.frame = rect;
        }
        if (layer.superlayer != textView.layer) {
            [_contextRef.extension.attachmentLayers addObject:layer];
            [textView.layer addSublayer:layer];
        }
    }
    
}


- (void)clearAttachmentViewsAndLayersWithAttachmetsInfo:(UIView *)textView {
    NSMutableArray *attachmentViews  =_contextRef.extension.attachmentViews.mutableCopy;
    NSMutableArray *attachmentLayers = _contextRef.extension.attachmentLayers.mutableCopy;
    for (UIView *view in attachmentViews) {
        if (view.superview == textView) {
            [view removeFromSuperview];
        }
    }
    for (CALayer *layer in attachmentLayers) {
        if (layer.superlayer == textView.layer) {
            [layer removeFromSuperlayer];
        }
    }
    [attachmentViews removeAllObjects];
    [attachmentLayers removeAllObjects];
}

- (void)clearAttachmentViewsAndLayers:(UIView *)textView  {
    NSMutableArray *attachmentViews  =_contextRef.extension.attachmentViews;
    NSMutableArray *attachmentLayers = _contextRef.extension.attachmentLayers;
    for (UIView *view in attachmentViews) {
        if (view.superview == textView) {
            [view removeFromSuperview];
        }
    }
    for (CALayer *layer in attachmentLayers) {
        if (layer.superlayer == textView.layer) {
            [layer removeFromSuperlayer];
        }
    }
    [attachmentViews removeAllObjects];
    [attachmentLayers removeAllObjects];
}

- (void)addAttachmentViewsAndLayersToCaches:(KZTextAttachment *)attachment {
    id content = attachment.content;
    if ([content isKindOfClass:UIView.class]) {
        [_contextRef.extension.attachmentViews addObject:content];
    } else if ([content isKindOfClass:CALayer.class]) {
        [_contextRef.extension.attachmentLayers addObject:content];
    }
}


- (void)touchesBeganAtPoint:(CGPoint)point {
    KZRendererRect *touchAttachmentInfo = nil;
    for (KZRendererRect *attachmentRect in self.rendererRectList) {
        KZLayoutInfo *layoutInfo = [attachmentRect rectValuesIncludeAtPoint:point];
        if(layoutInfo) {
            touchAttachmentInfo = attachmentRect;
            touchAttachmentInfo.layoutInfo = layoutInfo;
            break;
        }
    }
    if(!touchAttachmentInfo) {
        return;
    }
    if(![touchAttachmentInfo.textAttribute isMemberOfClass:[KZTextAttachment class]]) {
        return;
    }
    KZTextAttachment *attachment = touchAttachmentInfo.textAttribute;
    if(attachment.clickAction) {
        attachment.clickAction(attachment, touchAttachmentInfo.layoutInfo.characterRange);
    }
}

- (BOOL)rendererPointInside:(CGPoint)point {
    for (KZRendererRect *attachmentRect in self.rendererRectList) {
        if(![attachmentRect.textAttribute isMemberOfClass:[KZTextAttachment class]]) {
            continue;
        }
        KZTextAttachment *attachment = attachmentRect.textAttribute;
        if(attachment.clickAction &&[attachmentRect rectValuesIncludeAtPoint:point]) {
            return YES;
        }
    }
    return NO;
}

@end
