//
//  KZContextRefKey.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <Foundation/Foundation.h>

@class KZTextAttributes;

@interface KZContextRefKey : NSObject<NSCopying>

@property (nonatomic, readonly) KZTextAttributes *attributes;
@property (nonatomic, readonly) CGSize containerSize;

- (instancetype)initWithAttributes:(KZTextAttributes *)attributes containerSize:(CGSize)containerSize;


@end
