//
//  KZRendererFrame.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/16.
//

#import <UIKit/UIKit.h>

@class KZContextRef;
@protocol KZTextRenderer;

@interface KZLayoutInfo : NSObject

@property (nonatomic, assign) CGRect  rect;
@property (nonatomic, assign) NSRange glyphRange;
@property (nonatomic, assign) NSRange characterRange;
@property (nonatomic, assign) NSRange parentRange;

@end

@interface KZRendererRect : NSObject

@property (nonatomic, strong) NSMutableArray *rangeValues;
@property (nonatomic, strong) NSMutableArray <KZLayoutInfo *>*rectValues;
@property (nonatomic, strong) id textAttribute;
@property (nonatomic, strong) KZLayoutInfo *layoutInfo;
@property (nonatomic, strong) NSArray <NSValue *>*quoteRectValues;


- (KZLayoutInfo *)rectValuesIncludeAtPoint:(CGPoint)point;

@end

@interface KZRendererFrame : NSObject

- (instancetype)initWithContextRef:(KZContextRef *)contextRef;

- (void)textRenderer:(id<KZTextRenderer>)textRenderer value:(NSObject *)value range:(NSRange)range key:(NSAttributedStringKey)key;

- (NSArray <KZRendererRect *>*)rendererRectListForKey:(NSString *)classKey;

@end
