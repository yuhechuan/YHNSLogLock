//
//  KZTextQuoteRenderer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import "KZTextQuoteRenderer.h"

@interface KZTextQuoteRenderer ()

@property (nonatomic, copy) NSArray *rendererRectList;

@end

@implementation KZTextQuoteRenderer {
    KZContextRef *_contextRef;
}

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef {
    _contextRef = contextRef;
    self.rendererRectList = @[];
}

- (NSArray *)rectsForAttribute:(NSObject *)attribute characterRange:(NSRange)characterRange {
    KZLayoutManager *layoutManager = _contextRef.layoutManager;
    NSTextContainer *textContainer = _contextRef.textContainer;
    CGPoint point = _contextRef.glyphPoint;
    NSArray *rects = [layoutManager queteEnumerateRectsForGlyphRange:characterRange
                                                     inTextContainer:textContainer
                                                               point:point];
    return rects;
}

- (void)didCalculateTextRenderer:(NSArray <KZRendererRect *>*)rendererRectList{
    self.rendererRectList = rendererRectList;
    for (KZRendererRect *quoteRect in rendererRectList) {
        if(![quoteRect.textAttribute isMemberOfClass:[KZTextQuote class]]) {
            continue;;
        }
        KZTextQuote *quote = quoteRect.textAttribute;
        CGFloat offset = quote.quoteLeft > 0 ? quote.quoteLeft : 0;
        NSMutableDictionary *rectDict = [NSMutableDictionary dictionary];
        for (KZLayoutInfo *info in quoteRect.rectValues) {
            NSNumber *key = @(info.rect.origin.y);
            if(rectDict[key]) {
                continue;
            }
            CGRect qrect = CGRectMake(offset, info.rect.origin.y, quote.quoteWidth, info.rect.size.height);
            rectDict[key] = [NSValue valueWithCGRect:qrect];
        }
        quoteRect.quoteRectValues = rectDict.allValues;
    }
}

- (void)beginRendererAtPoint:(CGPoint)point {
    if(self.rendererRectList.count == 0) {
        return;
    }
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSaveGState(contextRef);
    
    for (KZRendererRect *quoteRect in self.rendererRectList) {
        if(![quoteRect.textAttribute isMemberOfClass:[KZTextQuote class]]) {
            continue;;
        }
        KZTextQuote *quote = quoteRect.textAttribute;
        for (NSValue *value in quoteRect.quoteRectValues) {
            CGRect pathRect;
            if (UIEdgeInsetsEqualToEdgeInsets(quote.insets, UIEdgeInsetsZero)) {
                pathRect = value.CGRectValue;
            } else {
                pathRect = UIEdgeInsetsInsetRect(value.CGRectValue, quote.insets);
            }
            UIBezierPath *path = [UIBezierPath bezierPathWithRect:pathRect];
            [path closePath];
            UIColor *fillColor = quote.quoteColor ? quote.quoteColor : UIColor.lightGrayColor;
            CGContextSaveGState(contextRef);
            CGContextAddPath(contextRef, path.CGPath);
            CGContextSetFillColorWithColor(contextRef, fillColor.CGColor);
            CGContextFillPath(contextRef);
            CGContextRestoreGState(contextRef);
        }
    }
    CGContextRestoreGState(contextRef);
}

@end
