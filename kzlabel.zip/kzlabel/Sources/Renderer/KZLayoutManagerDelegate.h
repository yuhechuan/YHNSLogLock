//
//  KZLayoutManagerDelegate.h
//  KZLabel
//
//  Created by yuhechuan on 2023/9/11.
//

#import <UIKit/UIKit.h>
#import "KZLabelProtocol.h"

@class KZContextRef;

@interface KZLayoutManagerDelegate : NSObject<NSLayoutManagerDelegate>

@property (nonatomic, copy) NSString *lineBreakControlCharacter;
@property (nonatomic, weak) id <KZLabelDelegate> delegate;

@end

