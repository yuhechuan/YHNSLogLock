//
//  KZContextRef.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "KZContextRef.h"
#import "KZTextRenderer.h"
#import "KZRendererFrame.h"
#import "KZTextInput.h"
#import "KZLayoutManagerDelegate.h"

@implementation KZTextTruncationInfo
@end

@interface KZContextRef ()

@property (nonatomic, strong) KZLayoutManager *layoutManager;
@property (nonatomic, strong) NSTextStorage *textStorage;
@property (nonatomic, strong) NSTextContainer *textContainer;
@property (nonatomic, assign) NSRange glyphRange;
@property (nonatomic, strong) KZTextAttributes *attributes;

@property (nonatomic, strong) NSDictionary *renderersClassMap;
@property (nonatomic, strong) NSMutableDictionary *renderersMap;

@property (nonatomic, copy, readwrite) NSArray *textRenderersClassList;
@property (nonatomic, strong) KZRendererFrame *rendererFrame;
@property (nonatomic, strong) KZLayoutManagerDelegate *layoutManagerDelegate;

@end

@implementation KZContextRef 

- (instancetype)initWithAttributes:(KZTextAttributes *)attributes
                     containerSize:(CGSize)containerSize {
    if(self = [super init]) {
        [self initializeContextRefWithAttributes:attributes
                         containerSize:containerSize];
    }
    return self;
}


- (void)initializeContextRefWithAttributes:(KZTextAttributes *)attributes
                             containerSize:(CGSize)containerSize {
    [self initializeAttributes:attributes containerSize:containerSize];
    [self calculate];
}

- (void)initializeAttributes:(KZTextAttributes *)attributes
               containerSize:(CGSize)containerSize {
    
    _attributes = attributes;
    _containerSize = containerSize;
 
    _layoutManager = [[KZLayoutManager alloc] init];
    _layoutManager.usesFontLeading = NO;
    _layoutManager.contextRef = self;
    
    // Create the TextKit component stack with our default configuration.
    if(attributes.avoidLineBreak) {
        _layoutManagerDelegate =  [[KZLayoutManagerDelegate alloc]init];
        _layoutManagerDelegate.lineBreakControlCharacter = attributes.lineBreakControlCharacter;
        _layoutManagerDelegate.delegate = attributes.delegate;
        _layoutManager.delegate = _layoutManagerDelegate;
    }

    // CJK language layout issues.
    NSMutableAttributedString *attributedText = attributes.attributedText.mutableCopy;
    if(attributes.additionalTruncationAttributedText.length > 0) {
        [attributedText appendAttributedString:attributes.additionalTruncationAttributedText];
    }
    
    [attributedText enumerateAttribute:NSFontAttributeName inRange:NSMakeRange(0, attributedText.length) options:kNilOptions usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
        if (value) {
            [attributedText addAttribute:KZTextOriginalFontAttributeName value:value range:range];
        }
    }];
    
    _textStorage = attributedText ? [[NSTextStorage alloc] initWithAttributedString:attributedText] : [[NSTextStorage alloc]init];
    [_textStorage addLayoutManager:_layoutManager];
    
    _textContainer = [[NSTextContainer alloc] initWithSize:containerSize];
    
    NSLineBreakMode lineBreakMode = attributes.lineBreakMode;
    /// 需要 自定义 trunc 时才 替换 lineBreakMode  不需要自定义用系统默认
    if ((lineBreakMode == NSLineBreakByTruncatingTail ||
        lineBreakMode == NSLineBreakByTruncatingHead ||
        lineBreakMode == NSLineBreakByTruncatingMiddle) &&
        attributes.truncationAttributedText.length > 0) {
        lineBreakMode = NSLineBreakByWordWrapping;
    }
    
    if(lineBreakMode != NSLineBreakByCharWrapping) {
        _textContainer.lineBreakMode = lineBreakMode;
    }

    _textContainer.lineFragmentPadding = attributes.lineFragmentPadding;
    _textContainer.maximumNumberOfLines = attributes.numberOfLines;
    _textContainer.exclusionPaths = attributes.exclusionPaths;
    [_layoutManager addTextContainer:_textContainer];
    _glyphPoint = CGPointMake(attributes.textContainerInset.left, attributes.textContainerInset.top);
}


- (void)calculate {
    /// 环境配置
    self.kzLineBreakModeKeys = @[KZTextLinkAttributedStringKey, KZTextBorderAttributedStringKey];
    if(_attributes.extendRendererMap && _attributes.extendRendererMap.count > 0) {
        NSMutableDictionary *renderersClassMap = [NSMutableDictionary dictionaryWithDictionary:KZTextRenderersMap()];
        [renderersClassMap addEntriesFromDictionary:_attributes.extendRendererMap];
        self.renderersClassMap = renderersClassMap.copy;
    } else {
        self.renderersClassMap = KZTextRenderersMap();
    }
    
    [self calculateTextRendererInitialized];
    [self calculatedRendererFrame];
    [self calculatedRenderersClassList];
    [self didCalculateRendererRcetList];
}

- (void)calculateTextRendererInitialized {
    NSDictionary *mappingTable = self.renderersClassMap;
    NSMutableArray *allKeysSort = [NSMutableArray arrayWithArray:mappingTable.allKeys];
    [allKeysSort removeObject:KZTextTrunctionAttributedStringKey];
    [allKeysSort removeObject:KZTextBodyAttributedStringKey];
    
    if(!self.attributes.enbleDebugOption) {
        [allKeysSort removeObject:KZTextDebugAttributedStringKey];
    }

    if([self.attributes.delegate respondsToSelector:@selector(didLayoutWithTextCalculateSize:)]) {
        [allKeysSort insertObject:KZTextBodyAttributedStringKey atIndex:0];
    }
    
    if(self.attributes.truncationAttributedText.length > 0) {
        [allKeysSort insertObject:KZTextTrunctionAttributedStringKey atIndex:0];
    }

    for (NSString *key in allKeysSort) {
        Class cls = mappingTable[key];
        id<KZTextRenderer> renderer = [[cls alloc]init];
        if(![renderer conformsToProtocol:@protocol(KZTextRenderer)]) {
            break;
        }
        if([renderer respondsToSelector:@selector(willCalculateTextRenderer:)]) {
            [renderer willCalculateTextRenderer:self];
        }
        NSString *key = NSStringFromClass([renderer class]);
        self.renderersMap[key] = renderer;
    }
    _glyphRange = [_layoutManager glyphRangeForTextContainer:_textContainer];
}

- (void)calculatedRendererFrame {
    NSDictionary *mappingTable = self.renderersClassMap;
    NSMutableArray *allKeys = [NSMutableArray arrayWithArray:mappingTable.allKeys];
    [allKeys removeObject:KZTextTrunctionAttributedStringKey];
    
    NSRange glyphsToShow = [_layoutManager glyphRangeForTextContainer:_textContainer];
    NSRange characterRange = [_layoutManager characterRangeForGlyphRange:glyphsToShow actualGlyphRange:NULL];
    KZRendererFrame *rendererFrame = self.rendererFrame;
    
    NSTextStorage *textStorage = _layoutManager.textStorage;
    for (NSAttributedStringKey key in allKeys) {
        [textStorage enumerateAttribute:key inRange:characterRange options:kNilOptions usingBlock:^(id text, NSRange range, BOOL * _Nonnull stop) {
            NSString *classKey = NSStringFromClass(mappingTable[key]);
            id renderer = self.renderersMap[classKey];
            [rendererFrame textRenderer:renderer value:text range:range key:key];

        }];
    }
}

- (void)calculatedRenderersClassList  {
    
    NSDictionary *mappingTable = self.renderersClassMap;
    
    NSMutableArray *rendererClasses = [NSMutableArray array];
    ///  截断单独处理
    if(self.truncationInfo) {
        NSString *truncationKey = NSStringFromClass(mappingTable[KZTextTrunctionAttributedStringKey]);
        [rendererClasses addObject:truncationKey];
    }
    
    if(self.attributes.enbleDebugOption) {
        NSString *debugKey = NSStringFromClass(mappingTable[KZTextDebugAttributedStringKey]);
        [rendererClasses addObject:debugKey];
    }

    /// 其他处理
    [mappingTable enumerateKeysAndObjectsUsingBlock:^(NSAttributedStringKey key, Class cls, BOOL * _Nonnull stop) {
        NSString *infoKey = NSStringFromClass(mappingTable[key]);
        NSArray *list = [self.rendererFrame rendererRectListForKey:infoKey];
        if(list.count > 0) {
            [rendererClasses addObject:infoKey];
        }
    }];
    
    /// 判断是否存在 附件
    NSString *attachmentKey = NSStringFromClass(mappingTable[NSAttachmentAttributeName]);
    self.existedAttachment = [rendererClasses containsObject:attachmentKey];
   
    NSMutableArray *renderList = [NSMutableArray array];
    for (NSString *key in rendererClasses) {
        id renderer = self.renderersMap[key];
        [renderList addObject:renderer];
    }
    self.textRenderersClassList = renderList;
}

- (void)didCalculateRendererRcetList {
    for (id<KZTextRenderer> renderer in self.textRenderersClassList) {
        if([renderer respondsToSelector:@selector(didCalculateTextRenderer:)]) {
            NSString *infoKey = NSStringFromClass([renderer class]);
            NSArray *rendererRectList = [self.rendererFrame rendererRectListForKey:infoKey];
            [renderer didCalculateTextRenderer:rendererRectList];
        }
    }
}

- (void)onlyRefreshTextStorege:(NSAttributedString *)attributedText {
    [_textStorage removeLayoutManager:_layoutManager];
    _textStorage = attributedText? [[NSTextStorage alloc] initWithAttributedString:attributedText] : [[NSTextStorage alloc]init];
    [_textStorage addLayoutManager:_layoutManager];
}

- (void)refreshTextStorege:(NSAttributedString *)attributedText {
    [_textStorage removeLayoutManager:_layoutManager];
    _textStorage = attributedText? [[NSTextStorage alloc] initWithAttributedString:attributedText] : [[NSTextStorage alloc]init];
    [_textStorage addLayoutManager:_layoutManager];
    [self didCalculateRendererRcetList];
}

- (id<KZTextRenderer>)textRendererForKey:(NSString *)key {
    if(!key || key.length == 0) {
        return nil;
    }
    return self.renderersMap[key];
}

- (NSMutableDictionary *)renderersMap {
    if(!_renderersMap) {
        _renderersMap = [NSMutableDictionary dictionary];
    }
    return _renderersMap;
}

- (KZRendererFrame *)rendererFrame {
    if(!_rendererFrame) {
        _rendererFrame = [[KZRendererFrame alloc]initWithContextRef:self];
    }
    return _rendererFrame;
}

@end

@implementation KZContextRef (KZTextExtendedContextRef)

- (NSUInteger)characterIndexForPoint:(CGPoint)point rangeSuffixIndex:(BOOL)rangeSuffixIndex {
    CGFloat fractionOfDistance;
    NSUInteger characterIndex = [self.layoutManager characterIndexForPoint:point inTextContainer:self.textContainer fractionOfDistanceBetweenInsertionPoints:&fractionOfDistance];
    if (!rangeSuffixIndex) {
        return characterIndex;
    }
    NSRange range = [self.textStorage.string rangeOfComposedCharacterSequenceAtIndex:characterIndex];    
    CGRect rect = [self.layoutManager boundingRectForGlyphRange:NSMakeRange(characterIndex, range.length) inTextContainer:self.textContainer];
    /// glyphIndexForPoint 算错的情况  不做处理
    if(!CGRectContainsPoint(rect, point)) {
        CGRect lastRect = [self.layoutManager boundingRectForGlyphRange:NSMakeRange(self.glyphRange.length -range.length, range.length) inTextContainer:self.textContainer];
        if(point.x < lastRect.origin.x) {
            return NSNotFound;
        }
    }
    if (fractionOfDistance > 0.5) {
        characterIndex += range.length;
    }
    if (characterIndex > self.textStorage.length) {
        characterIndex = self.textStorage.length;
    }
    return characterIndex;
}

- (NSRange)rangeEnclosingCharacterForIndex:(NSUInteger)characterIndex {
    NSString *text = self.textStorage.string;
    NSRange resultRange = NSMakeRange(NSNotFound, 0);
    CFStringRef string = (__bridge CFStringRef)(text);
    CFRange range = CFRangeMake(0, text.length);
    CFOptionFlags flag = kCFStringTokenizerUnitWord;
    CFLocaleRef locale = CFLocaleCopyCurrent();
    CFStringTokenizerRef tokenizer = CFStringTokenizerCreate(kCFAllocatorDefault, string, range, flag, locale);
    CFStringTokenizerTokenType tokenType = CFStringTokenizerAdvanceToNextToken(tokenizer);
    
    while (tokenType != kCFStringTokenizerTokenNone) {
        CFRange currentTokenRange = CFStringTokenizerGetCurrentTokenRange(tokenizer);
        if (currentTokenRange.location <= characterIndex &&
            currentTokenRange.location + currentTokenRange.length > characterIndex) {
            resultRange = NSMakeRange(currentTokenRange.location, currentTokenRange.length);
            break;
        }
        tokenType = CFStringTokenizerAdvanceToNextToken(tokenizer);
    }
    
    CFRelease(tokenizer);
    CFRelease(locale);
    NSRange characterIndexRange = [self.textStorage.string rangeOfComposedCharacterSequenceAtIndex:characterIndex];;
    if (resultRange.location == NSNotFound || resultRange.length < characterIndexRange.length) {
        resultRange = characterIndexRange;
    }
    return resultRange;
}


- (NSArray<KZTextSelectionRect *> *)selectionRectsForCharacterRange:(NSRange)characterRange {
    NSMutableArray<KZTextSelectionRect *> *selectionRects = [NSMutableArray new];
    NSRange glyphRange = [self.layoutManager glyphRangeForCharacterRange:characterRange actualCharacterRange:NULL];
    
    [self.layoutManager enumerateEnclosingRectsForGlyphRange:glyphRange withinSelectedGlyphRange:glyphRange inTextContainer:self.textContainer usingBlock:^(CGRect rect, BOOL *stop) {
        if(rect.size.width > 0 && rect.size.height > 0) {
            KZTextSelectionRect *selectionRect = [[KZTextSelectionRect alloc]init];
            selectionRect.rect = rect;
            [selectionRects addObject:selectionRect];
        }
    }];
    if (selectionRects.count > 0) {
        KZTextSelectionRect *startSelectionRect = selectionRects[0];
        startSelectionRect.containsStart = YES;
        
        KZTextSelectionRect *endSelectionRect = selectionRects[selectionRects.count - 1];
        endSelectionRect.containsEnd = YES;
    }
    return selectionRects.copy;
}


- (CGRect)lineFragmentUsedRectForCharacterAtIndex:(NSUInteger)characterIndex effectiveRange:(nullable NSRangePointer)effectiveCharacterRange {
    CGRect lineFragmentUsedRect = CGRectZero;
    NSUInteger glyphIndex = [self.layoutManager glyphIndexForCharacterAtIndex:characterIndex];
    NSRange effectiveGlyphRange;
    lineFragmentUsedRect = [self.layoutManager lineFragmentUsedRectForGlyphAtIndex:glyphIndex effectiveRange:&effectiveGlyphRange];
    if (effectiveCharacterRange) {
        *effectiveCharacterRange = [self.layoutManager characterRangeForGlyphRange:effectiveGlyphRange actualGlyphRange:NULL];
    }
    return lineFragmentUsedRect;
}

- (CGRect)lineFragmentRectForCharacterAtIndex:(NSUInteger)characterIndex effectiveRange:(nullable NSRangePointer)effectiveCharacterRange {
    CGRect lineFragmentRect = CGRectZero;
    NSUInteger glyphIndex = [self.layoutManager glyphIndexForCharacterAtIndex:characterIndex];
    NSRange effectiveGlyphRange;
    lineFragmentRect = [self.layoutManager lineFragmentRectForGlyphAtIndex:glyphIndex effectiveRange:&effectiveGlyphRange];
    if (effectiveCharacterRange) {
        *effectiveCharacterRange = [self.layoutManager characterRangeForGlyphRange:effectiveGlyphRange actualGlyphRange:NULL];
    }
    return lineFragmentRect;
}


@end

