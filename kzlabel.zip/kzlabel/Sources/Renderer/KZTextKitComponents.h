//
//  KZTextKitComponents.h
//  KZLabel
//
//  Created by yuhechuan on 2023/11/3.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class KZTextAttributes;

@interface KZTextKitComponents : NSObject

- (CGSize)calculateSizeForConstraintSize:(CGSize)constraintSize
                              attributes:(KZTextAttributes *)attributes;

- (void)performBlockWithAttributes:(KZTextAttributes *)attributes
                      constraintSize:(CGSize)constraintSize
                               block:(void (^)(NSLayoutManager *layoutManager,
                                             NSTextStorage *textStorage,
                                             NSTextContainer *textContainer,
                                               CGSize cacuSize))block;

@end

