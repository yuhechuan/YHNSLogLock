//
//  KZLayoutManager.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <UIKit/UIKit.h>

@class KZContextRef;
@class KZLayoutInfo;

typedef void(^KZLayoutManagerBlock)(KZContextRef *ref,NSRange glyphsToShow,CGPoint point);

@interface KZLayoutManager : NSLayoutManager

@property (nonatomic, weak) KZContextRef *contextRef;
@property (nonatomic, copy) KZLayoutManagerBlock willDrawBackground;
@property (nonatomic, copy) KZLayoutManagerBlock didDrawBackground;
@property (nonatomic, copy) KZLayoutManagerBlock willDrawGlyphs;
@property (nonatomic, copy) KZLayoutManagerBlock didDrawGlyphs;


- (NSArray <KZLayoutInfo *>*)enumerateRectsForGlyphRange:(NSRange)range
                                         inTextContainer:(NSTextContainer *)textContainer
                                                  insets:(UIEdgeInsets)insets
                                                   point:(CGPoint)point;

- (NSArray <KZLayoutInfo *>*)borderEnumerateRectsForGlyphRange:(NSRange)range
                                               inTextContainer:(NSTextContainer *)textContainer
                                                        insets:(UIEdgeInsets)insets
                                                         point:(CGPoint)point;

- (NSArray <KZLayoutInfo *>*)queteEnumerateRectsForGlyphRange:(NSRange)range
                                              inTextContainer:(NSTextContainer *)textContainer
                                                        point:(CGPoint)point;

- (NSArray <KZLayoutInfo *>*)enumerateBlockRectsForGlyphRange:(NSRange)range
                                              inTextContainer:(NSTextContainer *)textContainer
                                                       insets:(UIEdgeInsets)insets
                                                        point:(CGPoint)point ;
- (NSArray <KZLayoutInfo *>*)enumerateUsedBlockRectsForGlyphRange:(NSRange)range
                                                  inTextContainer:(NSTextContainer *)textContainer
                                                           insets:(UIEdgeInsets)insets
                                                            point:(CGPoint)point ;
- (NSArray <KZLayoutInfo *>*)underLineEnumerateRectsForGlyphRange:(NSRange)range
                                                  inTextContainer:(NSTextContainer *)textContainer
                                                           insets:(UIEdgeInsets)insets
                                                            point:(CGPoint)point;

- (NSInteger)displayLineForGlyphRange:(NSRange)range;

@end
