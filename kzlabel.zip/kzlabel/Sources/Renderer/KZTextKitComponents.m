//
//  KZTextKitComponents.m
//  KZLabel
//
//  Created by yuhechuan on 2023/11/3.
//

#import "KZTextKitComponents.h"
#import "KZTextAttributes.h"
#import "KZContextRefKey.h"
#import "KZLayoutManagerDelegate.h"

@interface KZTextKitComponents ()

@property (nonatomic) KZTextAttributes *attributes;
@property (nonatomic) CGSize containerSize;
@property (nonatomic, strong) NSCharacterSet *avoidTailTruncationSet;
@property (nonatomic, strong) NSValue *truncationUsedRectValue;
@property (nonatomic, strong) NSValue *additionalTruncationUsedRectValue;
@property (nonatomic, assign) BOOL truncked;
@property (nonatomic, strong) KZLayoutManagerDelegate *layoutManagerDelegate;

@end

@implementation KZTextKitComponents


- (CGSize)calculateSizeForConstraintSize:(CGSize)constraintSize
                              attributes:(KZTextAttributes *)attributes {
    __block CGSize textSize = CGSizeZero;
    [self performBlockWithAttributes:attributes constraintSize:constraintSize block:^(NSLayoutManager *layoutManager, NSTextStorage *textStorage, NSTextContainer *textContainer, CGSize cacuSize) {
        textSize = cacuSize;
    }];
    return textSize;
}


- (void)performBlockWithAttributes:(KZTextAttributes *)attributes
                      constraintSize:(CGSize)constraintSize
                               block:(void (^)(NSLayoutManager *layoutManager,
                                             NSTextStorage *textStorage,
                                             NSTextContainer *textContainer,
                                             CGSize cacuSize))block {
    self.truncked = NO;
    self.containerSize = constraintSize;
    self.attributes = attributes;
    __weak typeof(self) weakSelf = self;
    __block CGSize textSize = CGSizeZero;
    [self performBlockWithTextKit:^(NSLayoutManager *layoutManager, NSTextStorage *textStorage, NSTextContainer *textContainer) {
        [layoutManager ensureLayoutForTextContainer:textContainer];
        CGRect boundingRect = [layoutManager usedRectForTextContainer:textContainer];
        /// 修复由于 tailIndent存在时 宽度未 包含 tailIndent情况  导致展示不全
        __block CGFloat tailIndentOffset = 0;
        [textStorage enumerateAttribute:NSParagraphStyleAttributeName inRange:NSMakeRange(0, textStorage.length) options:kNilOptions usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
            if(value && [value isKindOfClass:[NSParagraphStyle class]]) {
                NSParagraphStyle *p = (NSParagraphStyle *)value;
                if(p.tailIndent < 0) {
                    tailIndentOffset = MAX(tailIndentOffset, fabs(p.tailIndent)) ;
                }
            }
        }];
        
        if (weakSelf.truncked) {
            [layoutManager ensureLayoutForTextContainer:textContainer];
            CGRect truncatedBoundingRect = [layoutManager usedRectForTextContainer:textContainer];
            // We should use the maximum height.
            boundingRect.size.height = MAX(CGRectGetHeight(truncatedBoundingRect), CGRectGetHeight(boundingRect));
        }

        // TextKit often returns incorrect glyph bounding rects in the horizontal direction, so we clip to our bounding rect
        // to make sure our width calculations aren't being offset by glyphs going beyond the constrained rect.
        boundingRect.size = CGSizeMake(ceil(boundingRect.size.width), ceil(boundingRect.size.height));
        
        CGSize size = boundingRect.size;
        
        // Update textContainer's size if needed.
        CGSize newConstrainedSize = constraintSize;
        if (constraintSize.width > KZTextContainerMaxSize.width - FLT_EPSILON) {
            newConstrainedSize.width = size.width;
        }
        if (constraintSize.height > KZTextContainerMaxSize.height - FLT_EPSILON) {
            newConstrainedSize.height = size.height;
        }
        
        if (!CGSizeEqualToSize(newConstrainedSize, constraintSize)) {
            weakSelf.containerSize = newConstrainedSize;
            textContainer.size = newConstrainedSize;
            [layoutManager ensureLayoutForTextContainer:textContainer];
        }
        UIEdgeInsets edge = attributes.textContainerInset;
        textSize = CGSizeMake(size.width + edge.left + edge.right + boundingRect.origin.x + tailIndentOffset, size.height + edge.top + edge.bottom +  boundingRect.origin.y);
        if(block) {
            block(layoutManager, textStorage, textContainer, textSize);
        }
    }];
}

- (void)performBlockWithTextKit:(void (^)(NSLayoutManager *layoutManager,
                                                          NSTextStorage *textStorage,
                                                          NSTextContainer *textContainer))textKit {
    CGSize containerSize = self.containerSize;
    KZTextAttributes *attributes = self.attributes;
 
    // Create the TextKit component stack with our default configuration.
    
    NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
    layoutManager.usesFontLeading = NO;
    if(attributes.avoidLineBreak) {
        self.layoutManagerDelegate.lineBreakControlCharacter = attributes.lineBreakControlCharacter;
        self.layoutManagerDelegate.delegate = attributes.delegate;
        layoutManager.delegate = self.layoutManagerDelegate;
    }
    
    NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:containerSize];
    
    NSLineBreakMode lineBreakMode = attributes.lineBreakMode;
    /// 需要 自定义 trunc 时才 替换 lineBreakMode  不需要自定义用系统默认
    if ((lineBreakMode == NSLineBreakByTruncatingTail ||
        lineBreakMode == NSLineBreakByTruncatingHead ||
        lineBreakMode == NSLineBreakByTruncatingMiddle) &&
        attributes.truncationAttributedText.length > 0) {
        lineBreakMode = NSLineBreakByWordWrapping;
    }
    
    if(lineBreakMode != NSLineBreakByCharWrapping) {
        textContainer.lineBreakMode = lineBreakMode;
    }
    
    textContainer.lineFragmentPadding = attributes.lineFragmentPadding;
    textContainer.maximumNumberOfLines = attributes.numberOfLines;
    textContainer.exclusionPaths = attributes.exclusionPaths;
    [layoutManager addTextContainer:textContainer];
    
    // CJK language layout issues.
    NSMutableAttributedString *attributedText = attributes.attributedText.mutableCopy;
    if(attributes.additionalTruncationAttributedText.length > 0) {
        [attributedText appendAttributedString:attributes.additionalTruncationAttributedText];
    }
    
    [attributedText enumerateAttribute:NSFontAttributeName inRange:NSMakeRange(0, attributedText.length) options:kNilOptions usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
        if (value) {
            [attributedText addAttribute:KZTextOriginalFontAttributeName value:value range:range];
        }
    }];
    
    NSTextStorage *textStorage = attributedText ? [[NSTextStorage alloc] initWithAttributedString:attributedText] : [[NSTextStorage alloc]init];
    [textStorage addLayoutManager:layoutManager];
    
    /// 处理一下 截断
    [self textTruncationInfo:layoutManager textContainer:textContainer textStorage:textStorage];
    
    if(textKit) {
        textKit(layoutManager, textStorage, textContainer);
    }
}


- (void)textTruncationInfo:(NSLayoutManager *)layoutManager
             textContainer:(NSTextContainer *)textContainer
               textStorage:(NSTextStorage *)textStorage {
    
    NSAttributedString *truncationAttributedText = self.attributes.truncationAttributedText;
    NSUInteger originalLength = textStorage.length;
    if (originalLength == 0 || truncationAttributedText.length == 0) {
        return;
    }
    [layoutManager ensureLayoutForTextContainer:textContainer];
    NSRange visibleGlyphRange = [layoutManager glyphRangeForBoundingRect:(CGRect){ .size = textContainer.size }
                                                         inTextContainer:textContainer];
    NSRange visibleCharacterRange = [layoutManager characterRangeForGlyphRange:visibleGlyphRange actualGlyphRange:NULL];
    
    // Check if text is truncated, and if so apply our truncation string
    
    if(visibleCharacterRange.length >= originalLength) {
        return;
    }
    
    NSUInteger firstCharacterIndexToReplace = [self _calculateCharacterIndexBeforeTruncationMessage:layoutManager
                                                                                        textStorage:textStorage
                                                                                      textContainer:textContainer];
    CGRect additionalTruncationUsedRect = _additionalTruncationUsedRectValue ?_additionalTruncationUsedRectValue.CGRectValue : CGRectZero;

    if (firstCharacterIndexToReplace == 0 || firstCharacterIndexToReplace == NSNotFound) {
        return;
    }
    
    // Update/truncate the visible range of text
    visibleCharacterRange = NSMakeRange(visibleCharacterRange.location, firstCharacterIndexToReplace - visibleCharacterRange.location);
    
    NSRange truncationReplacementRange = NSMakeRange(firstCharacterIndexToReplace, originalLength - firstCharacterIndexToReplace);
    
    // Replace the end of the visible message with the truncation string
    [textStorage replaceCharactersInRange:truncationReplacementRange
                     withAttributedString:truncationAttributedText];

    if(additionalTruncationUsedRect.size.width > 0) {
        [textStorage appendAttributedString:self.attributes.additionalTruncationAttributedText];
    }
    self.truncked = YES;
}


/**
 Calculates the intersection of the truncation message within the end of the last line.
 */
- (NSUInteger)_calculateCharacterIndexBeforeTruncationMessage:(NSLayoutManager *)layoutManager
                                                  textStorage:(NSTextStorage *)textStorage
                                                textContainer:(NSTextContainer *)textContainer {
    NSRange visibleGlyphRange = [layoutManager glyphRangeForBoundingRect:(CGRect){ .size = textContainer.size }
                                                         inTextContainer:textContainer];
    
    NSUInteger lastVisibleGlyphIndex = NSMaxRange(visibleGlyphRange) - 1;
    if (lastVisibleGlyphIndex < 0) {
        return NSNotFound;
    }
    
    NSRange lastLineRange;
    CGRect lastLineRect = [layoutManager lineFragmentRectForGlyphAtIndex:lastVisibleGlyphIndex
                                                          effectiveRange:&lastLineRange];
    
    CGRect constrainedRect = (CGRect){ .size = textContainer.size };
    CGRect lastLineUsedRect = [layoutManager lineFragmentUsedRectForGlyphAtIndex:lastVisibleGlyphIndex
                                                                  effectiveRange:NULL];
    
    NSUInteger lastVisibleCharacterIndex = [layoutManager characterIndexForGlyphAtIndex:lastVisibleGlyphIndex];
    if (lastVisibleCharacterIndex >= textStorage.length) {
        return NSNotFound;
    }

    NSParagraphStyle *paragraphStyle = [textStorage attribute:NSParagraphStyleAttributeName atIndex:lastVisibleCharacterIndex effectiveRange:NULL];
    
    // We assume LTR so long as the writing direction is not
    BOOL rtlWritingDirection = paragraphStyle ? paragraphStyle.baseWritingDirection == NSWritingDirectionRightToLeft : NO;
    // We only want to treat the truncation rect as left-aligned in the case that we are right-aligned and our writing
    // direction is RTL.
    BOOL leftAligned = CGRectGetMinX(lastLineRect) == CGRectGetMinX(lastLineUsedRect) || !rtlWritingDirection;
    
    if (!_truncationUsedRectValue) {
        NSAttributedString *truncationAttributedText = self.attributes.truncationAttributedText;

        CGRect truncationUsedRect =
        [truncationAttributedText boundingRectWithSize:KZTextContainerMaxSize
                                                 options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingTruncatesLastVisibleLine
                                                 context:nil];
        _truncationUsedRectValue = [NSValue valueWithCGRect:truncationUsedRect];
    }
    
    /// 补充信息
    if(!_additionalTruncationUsedRectValue) {
        NSAttributedString *additionalTruncationAttributedText = self.attributes.additionalTruncationAttributedText;
        if(leftAligned && additionalTruncationAttributedText && additionalTruncationAttributedText.length > 0) {
            CGRect additionalTruncationUsedRect =
            [additionalTruncationAttributedText boundingRectWithSize:KZTextContainerMaxSize
                                                     options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingTruncatesLastVisibleLine
                                                     context:nil];
            _additionalTruncationUsedRectValue = [NSValue valueWithCGRect:additionalTruncationUsedRect];
        } else {
            _additionalTruncationUsedRectValue = nil;
        }
    }
    
    CGRect truncationUsedRect = _truncationUsedRectValue.CGRectValue;
    CGRect additionalTruncationUsedRect = _additionalTruncationUsedRectValue ?_additionalTruncationUsedRectValue.CGRectValue : CGRectZero;

    CGFloat truncationOriginX = (leftAligned ?
                                 CGRectGetMaxX(constrainedRect) - truncationUsedRect.size.width - additionalTruncationUsedRect.size.width:
                                 CGRectGetMinX(constrainedRect));
    CGRect translatedTruncationRect = CGRectMake(truncationOriginX,
                                                 CGRectGetMinY(lastLineRect),
                                                 truncationUsedRect.size.width,
                                                 truncationUsedRect.size.height);
    
    // Determine which glyph is the first to be clipped / overlaps the truncation message.
    CGFloat truncationMessageX = (leftAligned ?
                                  CGRectGetMinX(translatedTruncationRect) :
                                  CGRectGetMaxX(translatedTruncationRect));
    CGPoint beginningOfTruncationMessage = CGPointMake(truncationMessageX,
                                                       CGRectGetMidY(translatedTruncationRect));
    NSUInteger firstClippedGlyphIndex = [layoutManager glyphIndexForPoint:beginningOfTruncationMessage
                                                          inTextContainer:textContainer
                                           fractionOfDistanceThroughGlyph:NULL];
    
    // If it didn't intersect with any text then it should just return the last visible character index, since the
    // truncation rect can fully fit on the line without clipping any other text.
    if (firstClippedGlyphIndex == NSNotFound) {
        return [layoutManager characterIndexForGlyphAtIndex:lastVisibleGlyphIndex];
    }
    NSUInteger firstCharacterIndexToReplace = [layoutManager characterIndexForGlyphAtIndex:firstClippedGlyphIndex];
    
    // Break on word boundaries
    return [self _findTruncationInsertionPointAtOrBeforeCharacterIndex:firstCharacterIndexToReplace
                                                         layoutManager:layoutManager
                                                           textStorage:textStorage];
}

/**
 Finds the first whitespace at or before the character index do we don't truncate in the middle of words
 If there are multiple whitespaces together (say a space and a newline), this will backtrack to the first one
 */
- (NSUInteger)_findTruncationInsertionPointAtOrBeforeCharacterIndex:(NSUInteger)firstCharacterIndexToReplace
                                                      layoutManager:(NSLayoutManager *)layoutManager
                                                        textStorage:(NSTextStorage *)textStorage {
    // Don't attempt to truncate beyond the end of the string
    if (firstCharacterIndexToReplace >= textStorage.length) {
        return 0;
    }
    
    NSRange rangeOfLastVisibleAvoidedChars = { .location = NSNotFound };
    if (_avoidTailTruncationSet) {
        // Find the glyph range of the line fragment containing the first character to replace.
        NSRange lineGlyphRange;
        [layoutManager lineFragmentRectForGlyphAtIndex:[layoutManager glyphIndexForCharacterAtIndex:firstCharacterIndexToReplace]
                                        effectiveRange:&lineGlyphRange];
        
        // Look for the first whitespace from the end of the line, starting from the truncation point
        NSUInteger startingSearchIndex = [layoutManager characterIndexForGlyphAtIndex:lineGlyphRange.location];
        NSUInteger endingSearchIndex = firstCharacterIndexToReplace;
        NSRange rangeToSearch = NSMakeRange(startingSearchIndex, (endingSearchIndex - startingSearchIndex));
        
        rangeOfLastVisibleAvoidedChars = [textStorage.string rangeOfCharacterFromSet:_avoidTailTruncationSet
                                                                             options:NSBackwardsSearch
                                                                               range:rangeToSearch];
    }
    
    // Couldn't find a good place to truncate. Might be because there is no whitespace in the text, or we're dealing
    // with a foreign language encoding. Settle for truncating at the original place, which may be mid-word.
    if (rangeOfLastVisibleAvoidedChars.location == NSNotFound) {
        return firstCharacterIndexToReplace;
    } else {
        return rangeOfLastVisibleAvoidedChars.location;
    }
}

- (KZLayoutManagerDelegate *)layoutManagerDelegate {
    if(!_layoutManagerDelegate) {
        _layoutManagerDelegate = [[KZLayoutManagerDelegate alloc]init];
    }
    return _layoutManagerDelegate;
}

@end
