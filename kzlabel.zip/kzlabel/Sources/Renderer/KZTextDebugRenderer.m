//
//  KZTextDebugRenderer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/11/14.
//

#import "KZTextDebugRenderer.h"
#import "KZTextDebugOption.h"
#import <CoreText/CoreText.h>

@implementation KZTextDebugRenderer {
    KZContextRef *_contextRef;
}

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef {
    _contextRef = contextRef;
}

- (void)beginRendererAtPoint:(CGPoint)point {
    KZTextDebugOption *op = [[KZTextDebugOption alloc]init];
    if([_contextRef.attributes.delegate respondsToSelector:@selector(willRendererDebugOption:)]) {
        [_contextRef.attributes.delegate willRendererDebugOption:op];
    }
    [self drawDebugWithDebugOption:op forGlyphRange:_contextRef.glyphRange atPoint:point];
}

- (void)drawDebugWithDebugOption:(KZTextDebugOption *)op forGlyphRange:(NSRange)glyphsToShow atPoint:(CGPoint)point {
    CGContextRef context = UIGraphicsGetCurrentContext();
    UIGraphicsPushContext(context);
    CGContextSaveGState(context);
    CGContextTranslateCTM(context, point.x, point.y);
    CGContextSetLineWidth(context, 1.0 / KZTextScreenScale());
    CGContextSetLineDash(context, 0, NULL, 0);
    CGContextSetLineJoin(context, kCGLineJoinMiter);
    CGContextSetLineCap(context, kCGLineCapButt);
    
    [_contextRef.layoutManager enumerateLineFragmentsForGlyphRange:glyphsToShow usingBlock:^(CGRect rect, CGRect usedRect, NSTextContainer * _Nonnull textContainer, NSRange glyphRange, BOOL * _Nonnull stop) {
        if (op.lineFragmentFillColor) {
            [op.lineFragmentFillColor setFill];
            CGContextAddRect(context, KZTextCGRectPixelRound(rect));
            CGContextFillPath(context);
        }
        if (op.lineFragmentBorderColor) {
            [op.lineFragmentBorderColor setStroke];
            CGContextAddRect(context, KZTextCGRectPixelHalf(rect));
            CGContextStrokePath(context);
        }
        if (op.lineFragmentUsedFillColor) {
            [op.lineFragmentUsedFillColor setFill];
            CGContextAddRect(context, KZTextCGRectPixelRound(usedRect));
            CGContextFillPath(context);
        }
        if (op.lineFragmentUsedBorderColor) {
            [op.lineFragmentUsedBorderColor setStroke];
            CGContextAddRect(context, KZTextCGRectPixelHalf(usedRect));
            CGContextStrokePath(context);
        }
        if (op.baselineColor) {
            CGFloat baselineOffset = [self baselineOffsetForGlyphRange:glyphRange];
            [op.baselineColor setStroke];
            CGFloat x1 = KZTextCGFloatPixelHalf(usedRect.origin.x);
            CGFloat x2 = KZTextCGFloatPixelHalf(usedRect.origin.x + usedRect.size.width);
            CGFloat y =  KZTextCGFloatPixelHalf(CGRectGetMinY(rect) + baselineOffset);
            CGContextMoveToPoint(context, x1, y);
            CGContextAddLineToPoint(context, x2, y);
            CGContextStrokePath(context);
        }
        if (op.glyphFillColor || op.glyphBorderColor) {
            for (NSUInteger g = 0; g < glyphRange.length; g++) {
                CGRect glyphRect = [self glyphRectForGlyphIndex:glyphRange.location + g inTextContainer:textContainer];
                
                if (op.glyphFillColor) {
                    [op.glyphFillColor setFill];
                    CGContextAddRect(context, KZTextCGRectPixelRound(glyphRect));
                    CGContextFillPath(context);
                }
                if (op.glyphBorderColor) {
                    [op.glyphBorderColor setStroke];
                    CGContextAddRect(context, KZTextCGRectPixelHalf(glyphRect));
                    CGContextStrokePath(context);
                }
            }
        }
    }];
    CGContextRestoreGState(context);
    UIGraphicsPopContext();
}


- (CGFloat)baselineOffsetForGlyphRange:(NSRange)glyphRange {
    NSUInteger maxRange = NSMaxRange(glyphRange);
    NSUInteger index = glyphRange.location;
    CGGlyph glyph = kCGFontIndexInvalid;
    while (glyph == kCGFontIndexInvalid && index < maxRange) {
        glyph = [_contextRef.layoutManager CGGlyphAtIndex:index];
        index++;
    }
    
    NSUInteger glyphIndex = index - 1;
    CGFloat baselineOffset = [_contextRef.layoutManager locationForGlyphAtIndex:glyphIndex].y;
    
    if (glyph == kCGFontIndexInvalid) {
        NSUInteger charIndex = [_contextRef.layoutManager characterIndexForGlyphAtIndex:glyphIndex];
        UIFont *font = [_contextRef.layoutManager.textStorage attribute:NSFontAttributeName
                                           atIndex:charIndex
                                    effectiveRange:NULL];
        return baselineOffset + font.descender;
    }
    
    return baselineOffset;
}

- (CGRect)glyphRectForGlyphIndex:(NSUInteger)glyphIndex inTextContainer:(NSTextContainer *)textContainer {
    NSUInteger charIndex = [_contextRef.layoutManager characterIndexForGlyphAtIndex:glyphIndex];
    CGGlyph glyph = [_contextRef.layoutManager CGGlyphAtIndex:glyphIndex];
    CTFontRef font = (__bridge_retained CTFontRef)[_contextRef.layoutManager.textStorage attribute:NSFontAttributeName
                                                                      atIndex:charIndex
                                                               effectiveRange:NULL];
    if (font == nil) {
        font = (__bridge_retained CTFontRef)[UIFont systemFontOfSize:17];
    }
    //                                    Glyph Advance
    //                             +-------------------------+
    //                             |                         |
    //                             |                         |
    // +------------------------+--|-------------------------|--+-----------+-----+ What TextKit returns sometimes
    // |                        |  |             XXXXXXXXXXX +  |           |     | (approx. correct height, but
    // |               ---------|--+---------+  XXX       XXXX +|-----------|-----|  sometimes inaccurate bounding
    // |               |        |             XXX          XXXXX|           |     |  widths)
    // |               |        |             XX             XX |           |     |
    // |               |        |            XX                 |           |     |
    // |               |        |           XXX                 |           |     |
    // |               |        |           XX                  |           |     |
    // |               |        |      XXXXXXXXXXX              |           |     |
    // |   Cap Height->|        |          XX                   |           |     |
    // |               |        |          XX                   |  Ascent-->|     |
    // |               |        |          XX                   |           |     |
    // |               |        |          XX                   |           |     |
    // |               |        |          X                    |           |     |
    // |               |        |          X                    |           |     |
    // |               |        |          X                    |           |     |
    // |               |        |         XX                    |           |     |
    // |               |        |         X                     |           |     |
    // |               ---------|-------+ X +-------------------------------------|
    // |                        |        XX                     |                 |
    // |                        |        X                      |                 |
    // |                        |      XX         Descent------>|                 |
    // |                        | XXXXXX                        |                 |
    // |                        |  XXX                          |                 |
    // +------------------------+-------------------------------------------------+
    //                                                          |
    //                                                          +--+Actual bounding box
    
    CGFloat advance = CTFontGetAdvancesForGlyphs(font, kCTFontOrientationHorizontal, &glyph, NULL, 1);
    CGFloat ascent = CTFontGetAscent(font);
    CGFloat descent = CTFontGetDescent(font);
    
    CFRelease(font);
    
    // Textkit's glyphs count not equal CoreText glyphs count, and the CoreText removed glyphs if glyph == 0. It's means the glyph not suitable for font.
    if (glyph == 0 && glyphIndex > 0) {
        return [self glyphRectForGlyphIndex:glyphIndex - 1 inTextContainer:textContainer];
    }
    
    CGRect glyphRect = [_contextRef.layoutManager boundingRectForGlyphRange:NSMakeRange(glyphIndex, 1) inTextContainer:textContainer];
    
    // If it is a NSTextAttachment(glyph == kCGFontIndexInvalid), we don't have the matched glyph and use width of glyphRect instead of advance.
    CGFloat lineHeight = (glyph == kCGFontIndexInvalid) ? glyphRect.size.height : ascent + descent;
    CGPoint location = [_contextRef.layoutManager locationForGlyphAtIndex:glyphIndex];
    CGRect lineFragmentRect = [_contextRef.layoutManager lineFragmentRectForGlyphAtIndex:glyphIndex effectiveRange:NULL];
    CGFloat baseline = location.y + CGRectGetMinY(lineFragmentRect);
    
    CGRect properGlyphRect;
    // We are just measuring the line heights here, so we can use the
    // heights used by TextKit, which tend to be pretty good.
    properGlyphRect = CGRectMake(CGRectGetMinX(lineFragmentRect) + location.x,
                                 (glyph == kCGFontIndexInvalid) ? CGRectGetMinY(glyphRect) : baseline - ascent,
                                 (glyph == kCGFontIndexInvalid) ? CGRectGetWidth(glyphRect) : advance,
                                 lineHeight);
    return properGlyphRect;
}


@end
