//
//  KZTextBodyRenderer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "KZTextBodyRenderer.h"
#import "KZTextAttributes.h"

@interface KZTextBodyRenderer ()

@end

@implementation KZTextBodyRenderer {
    KZContextRef *_contextRef;
}

- (void)willCalculateTextRenderer:(KZContextRef *)contextRef {
    _contextRef = contextRef;
    [self calculatedTextBodyRenderer];
}


- (void)calculatedTextBodyRenderer {
    
    KZLayoutManager *layoutManager = _contextRef.layoutManager;
    NSTextContainer *textContainer = _contextRef.textContainer;
    NSTextStorage *textStorage = _contextRef.textStorage;

    [layoutManager ensureLayoutForTextContainer:textContainer];
    CGRect boundingRect = [layoutManager usedRectForTextContainer:textContainer];
    /// 修复由于 tailIndent存在时 宽度未 包含 tailIndent情况  导致展示不全
    __block CGFloat tailIndentOffset = 0;
    [textStorage enumerateAttribute:NSParagraphStyleAttributeName inRange:NSMakeRange(0, textStorage.length) options:kNilOptions usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
        if(value && [value isKindOfClass:[NSParagraphStyle class]]) {
            NSParagraphStyle *p = (NSParagraphStyle *)value;
            if(p.tailIndent < 0) {
                tailIndentOffset = MAX(tailIndentOffset, fabs(p.tailIndent)) ;
            }
        }
    }];
    
    if (_contextRef.truncationInfo) {
        [layoutManager ensureLayoutForTextContainer:textContainer];
        CGRect truncatedBoundingRect = [layoutManager usedRectForTextContainer:textContainer];
        // We should use the maximum height.
        boundingRect.size.height = MAX(CGRectGetHeight(truncatedBoundingRect), CGRectGetHeight(boundingRect));
    }

    // TextKit often returns incorrect glyph bounding rects in the horizontal direction, so we clip to our bounding rect
    // to make sure our width calculations aren't being offset by glyphs going beyond the constrained rect.
    boundingRect.size = CGSizeMake(ceil(boundingRect.size.width), ceil(boundingRect.size.height));
    
    CGSize size = boundingRect.size;
    
    // Update textContainer's size if needed.
    CGSize newConstrainedSize = _contextRef.containerSize;
    if (_contextRef.containerSize.width > KZTextContainerMaxSize.width - FLT_EPSILON) {
        newConstrainedSize.width = size.width;
    }
    if (_contextRef.containerSize.height > KZTextContainerMaxSize.height - FLT_EPSILON) {
        newConstrainedSize.height = size.height;
    }
    
    if (!CGSizeEqualToSize(newConstrainedSize, _contextRef.containerSize)) {
        _contextRef.containerSize = newConstrainedSize;
        textContainer.size = newConstrainedSize;
        [layoutManager ensureLayoutForTextContainer:textContainer];
    }
    UIEdgeInsets edge = _contextRef.attributes.textContainerInset;
    CGSize fitSize = CGSizeMake(size.width + edge.left + edge.right + boundingRect.origin.x + tailIndentOffset, size.height + edge.top + edge.bottom +  boundingRect.origin.y);
    _contextRef.calculatedSize = fitSize;
}

- (CGPoint)convertPointFromTextKitForBounds:(CGRect)bounds textSize:(CGSize)textSize {
    CGRect textRect = [self textRectForBounds:bounds textSize:textSize];
    return CGPointMake(textRect.origin.x, textRect.origin.y);
}

- (CGRect)textRectForBounds:(CGRect)bounds textSize:(CGSize)textSize {
    CGRect textRect = UIEdgeInsetsInsetRect(bounds, _contextRef.attributes.textContainerInset);
    CGFloat yOffset = 0.0f;
    KZTextVerticalAlignment textVerticalAlignment = _contextRef.attributes.textVerticalAlignment;
    switch (textVerticalAlignment) {
        case KZTextVerticalAlignmentCenter:
            yOffset = (textRect.size.height - textSize.height) / 2.0f;
            break;
        case KZTextVerticalAlignmentBottom:
            yOffset = textRect.size.height - textSize.height;
            break;
        case KZTextVerticalAlignmentTop:
        default:
            break;
    }
    textRect.origin.y += yOffset;
    return textRect;
}

@end
