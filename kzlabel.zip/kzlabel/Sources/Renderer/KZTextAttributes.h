//
//  KZTextAttributes.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import <UIKit/UIKit.h>
#import "KZTextHelper.h"
#import "KZLabelProtocol.h"

@class KZAutoDetectConfig;
@class KZTextAttributes;
@class KZAutoDetectConfig;
@class KZContextRef;

typedef void(^KZTextCommonActionBlock)(void);
typedef void(^KZTextDisplayActionBlock)(NSAttributedString *highLightAttributedText);
typedef void(^KZTextLinkTypeActionBlock)(NSTextCheckingResult *result, NSAttributedString *attributedText, NSRange range);
typedef void(^KZTextAutoDetectConfigBlock)(KZAutoDetectConfig *config);
typedef void(^KZTextAttributesBlock)(KZTextAttributes *attributes);
typedef BOOL(^KZTextBreakLineBlock)(NSUInteger charIndex);

@interface KZTextAttributes : NSObject

@property (nonatomic, copy) NSAttributedString *attributedText;
@property (nonatomic, assign) NSLineBreakMode lineBreakMode;
@property (nonatomic, assign) NSUInteger numberOfLines;
@property (nonatomic, assign) KZTextVerticalAlignment textVerticalAlignment;
@property (nonatomic, assign) UIEdgeInsets textContainerInset;

@property (nonatomic, copy) NSArray<UIBezierPath *> *exclusionPaths;
@property (nonatomic, copy) NSAttributedString *truncationAttributedText;
@property (nonatomic, copy) NSAttributedString *additionalTruncationAttributedText;
@property (nonatomic, copy) NSDictionary <NSString *, Class>*extendRendererMap;
// Default value: 0.0  The layout padding at the beginning and end of the line fragment rects insetting the layout width available for the contents.
// This value is utilized by NSLayoutManager for determining the layout width.
@property (nonatomic, assign) CGFloat lineFragmentPadding;
// AutoDetect
@property (nonatomic, strong) KZAutoDetectConfig *detectConfig;
// delegate
@property (nonatomic, weak) id <KZLabelDelegate> delegate;
// 是否开启 自定义 换行
@property (nonatomic, assign) BOOL avoidLineBreak;
// 特殊符号控制
@property (nonatomic, copy) NSString *lineBreakControlCharacter;
// 是否开启 debug 模式
@property (nonatomic, assign) BOOL enbleDebugOption;

@end

@interface KZContextExtension : NSObject

@property (nonatomic, copy) KZTextCommonActionBlock truncationAction;
@property (nonatomic, copy) KZTextDisplayActionBlock displayAction;
@property (nonatomic, copy) KZTextLinkTypeActionBlock linkTypeAction;
@property (nonatomic, copy) KZTextBreakLineBlock breakLineBlock;

@property (nonatomic, assign) BOOL selectable;
@property (nonatomic, assign) BOOL forbidSelectableWhenTruncated;
@property (nonatomic, assign) BOOL canShowMagnifier;
@property (nonatomic, assign) BOOL useWordSelect;
@property (nonatomic, copy) NSAttributedString *highLightAttributedText;
@property (nonatomic, copy) NSAttributedString *preActiveLinkAttributedText;
@property (nonatomic, strong) NSMutableArray<UIView *> *attachmentViews;
@property (nonatomic, strong) NSMutableArray<CALayer *> *attachmentLayers;

@property (nonatomic, assign) UIEdgeInsets truncationActionExpendInset;
@property (nonatomic, assign) UIEdgeInsets pointInsideInset;

@property (nonatomic, assign) NSUInteger maxLimitLength;
@property (nonatomic, assign) CGSize containerSize;

@end

@interface KZCustomMenuBackInfo : NSObject

@property (nonatomic, assign) CGRect targetRect;
/**
 YPMenuControllerArrowDefault,  0
 YPMenuControllerArrowUp,  1
 YPMenuControllerArrowDown , 2
 */
@property (nonatomic, assign) int arrowDirection;

@end

@class KZTextAttachment;

typedef void(^KZAttributedActionBlock)(NSAttributedString *attributedString, NSRange range);
typedef void(^KZAttributedAlignmentActionBlock)(KZTextAttachment *attachment, NSRange range);


@interface KZTextLink : NSObject
/**
 Highlight color when click link.
 */
@property (nonatomic, strong) UIColor *highlightColor;
/**
 Highlight link background color when click link.
 */
@property (nonatomic, strong) UIColor *highlightBackViewColor;
/**
会覆盖掉 NSBackgroundColorAttributeName
 */
@property (nonatomic, strong) UIColor *fillColor;
/**
会覆盖掉 NSForegroundColorAttributeName
 */
@property (nonatomic, strong) UIColor *linkTextColor;
/**
 inner fill color
 */
@property (nonatomic, copy) KZAttributedActionBlock clickAction;

//Auto detect result.
@property (nonatomic, strong) NSTextCheckingResult *checkResult;
/**
 * 避免 完整的Link 由于换行 被打断
 * 设置为YES 在一行末尾 放不下时 整个 Link 全部换行
 */
@property (nonatomic, assign) BOOL avoidLineBreak;

@end

typedef NS_ENUM(NSInteger, KZBorderStyle) {
    /**
     General border for text, .
    | xtext |
    | xtext |
     */
    KZBorderNormal = 0,
    /**
     General border for text, .
     ———————
    | xtext |
     ———————
     ———————
    | xtext |
     ———————
     */
    KZBorderNormalFullLine,
    /**
     block border for text.
     ———————
    | xtext |
    | xtext |
     ———————
     */
    KZBorderBlockAround,
    /**
     block border for text.
     ————————————————————————————
         ————————————————————
        | xtext              |
        | xtext              |
         ————————————————————
     ————————————————————————————
     */
    KZBorderBlockTiled,
};

typedef NS_ENUM(NSInteger, KZBorderUnderLineStyle) {
    KZBorderUnderLineNormal = 0,
    KZBorderUnderLineDash,
    KZBorderUnderLineCenterNormal,
    KZBorderUnderLineCenterDash
};

typedef NS_ENUM(NSInteger, KZBorderUnderLineLevel) {
    KZBorderUnderLineLevelTop = 0, // 文字上面
    KZBorderUnderLineLevelBottom,  // 文字下面
};

@interface KZTextBorder : NSObject
///Border Properties
/**
 Border style.
 Block border style which should only use in paragraph.
 Default normal style.
 */
@property (nonatomic, assign) KZBorderStyle borderStyle;
/**
 Border line color.
 */
@property (nonatomic, strong) UIColor *borderColor;
/**
 Border line width.
 */
@property (nonatomic, assign) CGFloat borderWidth;
/**
 Border corner radius.
 */
@property (nonatomic, assign) CGFloat cornerRadius;
/**
 Border fill color.
 */
@property (nonatomic, strong) UIColor *fillColor;
/**
 Border insets.
 注意  NSMutableParagraphStyle.tailIndent ;// 结束 x位置（不是右边间距，与inset 不一样）
 */
@property (nonatomic, assign) UIEdgeInsets insets;

///Underline Properties
/**
 Border underline style.
 */
@property (nonatomic, assign) KZBorderUnderLineStyle underlineStyle;
/**
 Border underline width.
 */
@property (nonatomic, assign) CGFloat underlineWidth;
/**
 Border underline color.
 */
@property (nonatomic, strong) UIColor *underlineColor;
/**
 Border underline dash segment painted length.
 Default length is 4;
 */
@property (nonatomic, assign) CGFloat dashPaintedLength;
/**
 Border underline dash segment not painted length.
 Default length is 4;
 */
@property (nonatomic, assign) CGFloat dashNotPaintedLength;
/**
 underlineColor and underlineWidth exist
 underlineOffset  大于0向上 偏移 小于 0 向下偏移
 */
@property (nonatomic, assign) CGFloat underlineOffset;
/**
 * UnderLine  level with the text
 * Default is KZBorderUnderLineLevelTop
 */
@property (nonatomic, assign) KZBorderUnderLineLevel underLineLevel;
/**
 * 避免 完整的Border 由于换行 被打断
 * 设置为YES 在一行末尾 放不下时 整个 border 全部换行
 */
@property (nonatomic, assign) BOOL avoidLineBreak;
/**
 * 当前border 对象 生效的范围
 */
@property (nonatomic, assign) NSRange range;


@end


@interface KZTextQuote : NSObject
/**
 Quote color.
 */
@property (nonatomic, strong) UIColor *quoteColor;
/**
 Quote width.
 Default 4.0.
 */
@property (nonatomic, assign) CGFloat quoteWidth;
/**
 Quote distance to the left.
 Default 0.
 */
@property (nonatomic, assign) CGFloat quoteLeft;
/**
 Quote insets.
 */
@property (nonatomic, assign) UIEdgeInsets insets;

@end

@interface KZTextAttachment : NSTextAttachment
/**
 Attachment align to text，default is KZTextVerticalAlignmentCenter。
 */
@property (nonatomic, assign) KZTextVerticalAlignment aligment;

/**
 Supported type: UIImage, UIView, CALayer.
 */
@property (nonatomic, strong) id content;
/**
 content 优先级高 存在不会去取 AsyncFetchAttachContent
 Supported type: UIImage, UIView, CALayer.
 */
@property (nonatomic, copy) id(^AsyncFetchAttachContent)(CGSize contentSize);
/**
 Content size，if content is a image, it's image.size otherwise content.bounds.size instead。
 */
@property (nonatomic, assign) CGSize contentSize;
/**
 Content display mode.
 */
@property (nonatomic, assign) UIViewContentMode contentMode;

/**
 The insets when drawing content.
 */
@property (nonatomic, assign) UIEdgeInsets contentInsets;

/**
 Attachment's size, depends content and bounds.
 */
@property (nonatomic, assign, readonly) CGSize attachmentSize;
/**
 Current attachment represent string such as emoji image and so on.
 */
@property (nonatomic, copy) NSString *representString;
/**
 * 对齐时会以 alignToFont.lineHeight 作为计算标准 如果不存在会取
 * layoutManager.textStorage  的 NSFontAttributeName
 *  如果都不存在 默认是 [UIFont systemFontOfSize:14];
 */
@property (nonatomic, strong) UIFont *alignToFont;
/**
 Attachment click
 */
@property (nonatomic, copy) KZAttributedAlignmentActionBlock clickAction;

@end
