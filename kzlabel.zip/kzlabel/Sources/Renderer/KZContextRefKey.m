//
//  KZContextRefKey.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/26.
//

#import "KZContextRefKey.h"
#import "KZTextAttributes.h"

@interface KZContextRefKey ()

@property (nonatomic) KZTextAttributes *attributes;
@property (nonatomic) CGSize containerSize;

@end

@implementation KZContextRefKey

- (instancetype)initWithAttributes:(KZTextAttributes *)attributes containerSize:(CGSize)containerSize {
    if(self = [super init]) {
        _attributes = attributes;
        _containerSize = containerSize;
    }
    return self;
}

- (id)copyWithZone:(NSZone *)zone {
    typeof(self) one = [[self.class allocWithZone:zone] init];
    one.attributes = self.attributes;
    one.containerSize = self.containerSize;
    return one;
}

- (NSUInteger)hash {
    struct {
        size_t attributesHash;
        CGSize constrainedSize;
    } data = {
        _attributes.hash,
        _containerSize
    };
    return KZTextHashBytes(&data, sizeof(data));
}

- (BOOL)isEqual:(KZContextRefKey *)object {
    if (self == object) {
        return YES;
    }
    
    if (!object) {
      return NO;
    }
    // NOTE: Skip the class check for this specialized, internal Key object.
    BOOL equal =    KZTextObjectIsEqual(_attributes, object->_attributes) &&
    CGSizeEqualToSize(_containerSize, object->_containerSize);
    return equal;
}


@end
