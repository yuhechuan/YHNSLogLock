//
//  KZImageMarkLabel.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZLabel.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZImageMarkLabel : KZLabel

@end

NS_ASSUME_NONNULL_END
