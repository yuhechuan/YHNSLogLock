//
//  KZGradientMarkLabel.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZGradientMarkLabel.h"

@interface KZGradientMarkLabel ()

@property (nonatomic, strong) UILabel *markLabel;
@property (nonatomic, strong) CAGradientLayer *gradientMarkLayer;
@property (nonatomic, strong) CAGradientLayer *markLayer;

@end

@implementation KZGradientMarkLabel

+ (Class)layerClass {
    return [CALayer class];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _markLabel.frame = self.bounds;
    _markLayer.frame = self.bounds;
}


- (CGSize)sizeThatFits:(CGSize)size {
    return [self.markLabel sizeThatFits:size];
}

- (NSString *)text {
    return self.markLabel.text;
}

- (void)setText:(NSString *)text {
    self.markLabel.text = text;
}

- (void)setAttributedText:(NSAttributedString *)attributedText {
    self.markLabel.attributedText = attributedText;
}

- (void)setFont:(UIFont *)font {
    self.markLabel.font = font;
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    self.markLabel.textAlignment = textAlignment;
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    self.markLabel.lineBreakMode = lineBreakMode;
}

- (void)setNumberOfLines:(NSInteger)numberOfLines {
    self.markLabel.numberOfLines = numberOfLines;
}

- (void)setGradientLayer:(CAGradientLayer *)gradientLayer {
    if(!gradientLayer) {
        return;
    }
    if(self.gradientLayer) {
        [self.gradientLayer removeFromSuperlayer];
    }
    [super setGradientLayer:gradientLayer];
    _markLayer = gradientLayer;
    
    [self.layer insertSublayer:gradientLayer atIndex:0];
    gradientLayer.mask = self.markLabel.layer;
}

- (void)setGradientColors:(NSArray<UIColor *> *)gradientColors {
    if(gradientColors.count < 2 || self.gradientLayer) {
        return;
    }
    _markLayer = self.gradientMarkLayer;
    self.gradientMarkLayer.mask = self.markLabel.layer;
    NSMutableArray *colors = [NSMutableArray array];
    for (UIColor *color in gradientColors) {
        [colors addObject:(__bridge id)color.CGColor];
    }
    self.gradientMarkLayer.colors = colors;
}

- (CAGradientLayer *)gradientMarkLayer {
    if (!_gradientMarkLayer) {
        _gradientMarkLayer = [CAGradientLayer layer];
        _gradientMarkLayer.startPoint = CGPointMake(0, 0.5);
        _gradientMarkLayer.endPoint = CGPointMake(1, 0.5);
        _gradientMarkLayer.locations = @[ @(0), @(1.0f) ];
        [self.layer insertSublayer:_gradientMarkLayer atIndex:0];
    }
    return _gradientMarkLayer;
}


- (UILabel *)markLabel {
    if (!_markLabel) {
        _markLabel = [[UILabel alloc]init];
        [self addSubview:_markLabel];
    }
    return _markLabel;
}


@end
