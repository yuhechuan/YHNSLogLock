//
//  KZImageMarkLabel.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZImageMarkLabel.h"

@interface KZImageMarkLabel ()

@property (nonatomic, strong) UIImageView *markImageView;
@property (nonatomic, strong) UILabel *markLabel;

@end

@implementation KZImageMarkLabel

+ (Class)layerClass {
    return [CALayer class];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _markImageView.frame = self.bounds;
    _markLabel.frame = self.bounds;
}


- (CGSize)sizeThatFits:(CGSize)size {
    return [self.markLabel sizeThatFits:size];
}

- (NSString *)text {
    return self.markLabel.text;
}

- (void)setText:(NSString *)text {
    self.markLabel.text = text;
}

- (void)setAttributedText:(NSAttributedString *)attributedText {
    self.markLabel.attributedText = attributedText;
}

- (void)setFont:(UIFont *)font {
    self.markLabel.font = font;
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    self.markLabel.textAlignment = textAlignment;
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    self.markLabel.lineBreakMode = lineBreakMode;
}

- (void)setNumberOfLines:(NSInteger)numberOfLines {
    self.markLabel.numberOfLines = numberOfLines;
}


- (void)setMarkImage:(UIImage *)markImage {
    if(KZTextObjectIsEqual(markImage, self.markImage)) {
        return;
    }
    [super setMarkImage:markImage];
    self.markImageView.frame = self.bounds;
    self.markImageView.image = markImage;
    self.markImageView.layer.mask = self.markLabel.layer;
    self.markImageView.userInteractionEnabled = YES;
}

- (UIImageView *)markImageView {
    if (!_markImageView) {
        _markImageView = [[UIImageView alloc]init];
        [self addSubview:_markImageView];
    }
    return _markImageView;
}

- (UILabel *)markLabel {
    if (!_markLabel) {
        _markLabel = [[UILabel alloc]init];
        [self addSubview:_markLabel];
    }
    return _markLabel;
}


@end
