//
//  KZAsyncLayer.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/11.
//

#import "KZAsyncLayer.h"
#import "KZTextHelper.h"

@implementation KZTextAsyncLayerDisplayTask
@end


@implementation KZAsyncLayer {
    atomic_int _sentinel;
}

- (instancetype)init {
    if(self = [super init]) {
        self.contentsScale = KZTextScreenScale();
        _displaysAsynchronously = YES;
    }
    return self;
}


- (void)setNeedsDisplay {
    [self _cancelAsyncDisplay];
    [super setNeedsDisplay];
}

- (void)display {
    super.contents = super.contents;
    [self _display];
}

- (void)_display {
    __strong id<KZTextAsyncLayerDelegate> delegate = (id)self.delegate;
    KZTextAsyncLayerDisplayTask *task = [delegate newAsyncDisplayTask];
    BOOL async = _displaysAsynchronously;

    if (!task.display) {
        if (task.willDisplay) task.willDisplay(self);
        self.contents = nil;
        if (task.didDisplay) task.didDisplay(self, YES);
        return;
    }
    if (async) {
        if (task.willDisplay) task.willDisplay(self);
        int32_t value = _sentinel;
        BOOL (^isCancelled)(void) = ^BOOL() {
            return value != self->_sentinel;
        };
        
        CGSize size = self.bounds.size;
        BOOL opaque = self.opaque;
        CGFloat scale = self.contentsScale;
        CGColorRef backgroundColor = (opaque && self.backgroundColor) ? CGColorRetain(self.backgroundColor) : NULL;
        if (size.width < 1 || size.height < 1) {
            CGImageRef image = (__bridge_retained CGImageRef)(self.contents);
            self.contents = nil;
            if (image) {
                dispatch_async(KZTextAsyncLayerGetReleaseQueue(), ^{
                    CFRelease(image);
                });
            }
            if (task.didDisplay) task.didDisplay(self, YES);
            CGColorRelease(backgroundColor);
            return;
        }
        
        dispatch_async(KZTextAsyncLayerGetDisplayQueue(), ^{
            if (isCancelled()) {
                CGColorRelease(backgroundColor);
                return;
            }
            UIImage *image = kzlabel_appGraphicsRendererWithOptions(size, opaque, scale, ^(CGContextRef context) {
                if (opaque && context) {
                    CGContextSaveGState(context); {
                        if (!backgroundColor || CGColorGetAlpha(backgroundColor) < 1) {
                            CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);
                            CGContextAddRect(context, CGRectMake(0, 0, size.width * scale, size.height * scale));
                            CGContextFillPath(context);
                        }
                        if (backgroundColor) {
                            CGContextSetFillColorWithColor(context, backgroundColor);
                            CGContextAddRect(context, CGRectMake(0, 0, size.width * scale, size.height * scale));
                            CGContextFillPath(context);
                        }
                    } CGContextRestoreGState(context);
                    CGColorRelease(backgroundColor);
                }
                task.display(context, size, isCancelled);
            });
            
            if (isCancelled()) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (task.didDisplay) task.didDisplay(self, NO);
                });
                return;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if (isCancelled()) {
                    if (task.didDisplay) task.didDisplay(self, NO);
                } else {
                    self.contents = (__bridge id)(image.CGImage);
                    if (task.didDisplay) task.didDisplay(self, YES);
                }
            });
        });
    } else {
        [self _cancelAsyncDisplay];
        CGSize size = self.bounds.size;
        if (task.willDisplay) task.willDisplay(self);
        
        if (size.width < 1 || size.height < 1) {
            self.contents = nil;
            if (task.didDisplay) task.didDisplay(self, YES);
            return;
        }
        
        UIImage *image = kzlabel_appGraphicsRendererWithOptions(size, self.opaque, self.contentsScale, ^(CGContextRef context) {
            if (self.opaque && context) {
                CGSize size = self.bounds.size;
                size.width *= self.contentsScale;
                size.height *= self.contentsScale;
                CGContextSaveGState(context); {
                    if (!self.backgroundColor || CGColorGetAlpha(self.backgroundColor) < 1) {
                        CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);
                        CGContextAddRect(context, CGRectMake(0, 0, size.width, size.height));
                        CGContextFillPath(context);
                    }
                    if (self.backgroundColor) {
                        CGContextSetFillColorWithColor(context, self.backgroundColor);
                        CGContextAddRect(context, CGRectMake(0, 0, size.width, size.height));
                        CGContextFillPath(context);
                    }
                } CGContextRestoreGState(context);
            }
            task.display(context, self.bounds.size, ^{return NO;});
        });
        self.contents = (__bridge id)(image.CGImage);
        if (task.didDisplay) task.didDisplay(self, YES);
    }
}
    

- (void)_cancelAsyncDisplay {
    atomic_fetch_add_explicit(&_sentinel, 1, __ATOMIC_SEQ_CST);
}

@end
