//
//  KZLabel.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/21.
//

#import <UIKit/UIKit.h>
#import "KZTextAttributes.h"
#import "KZLabelProtocol.h"
#import "KZAutoDetectConfig.h"
#import "KZAutoDetector.h"
#import "NSMutableAttributedString+KZ.h"

@interface KZLabel : UIView

@property (nonatomic, weak) id <KZLabelDelegate> delegate;
@property (nonatomic, weak) id <KZLabelMenuDelegate> menuDelegate;
@property (nonatomic, weak) id <KZLabelAutoDetectDelegate> autoDetectDelegate;

/**
 The text displayed by the label. Default is nil.
 Set a new value to this property also replaces the text in `attributedText`.
 Get the value returns the plain text in `attributedText`.
 */
@property (nonatomic, copy) NSString *text;
/**
 The underlying attributed string drawn by the label.
 NOTE: If set, the label ignores other properties.
 */
@property (nonatomic, copy) NSAttributedString *attributedText;
/**
 The font of the text. Default is 17-point system font.
 Set a new value to this property also causes the new font to be applied to the entire `attributedText`.
 */
@property (nonatomic, strong) UIFont  *font;
/**
 The color of the text. Default is black.
 Set a new value to this property also causes the new color to be applied to the entire `attributedText`.
 */
@property (nonatomic, strong) UIColor *textColor;
/**
 The shadow color of the text. Default is nil.
 Set a new value to this property also causes the shadow color to be applied to the entire `attributedText`.
 */
@property (nonatomic, strong) UIColor *shadowColor;
/**
 The shadow offset of the text. Default is CGSizeMake(0, -1) -- a top shadow.
 Set a new value to this property also causes the shadow offset to be applied to the entire `attributedText`.
 */
@property (nonatomic, assign) CGSize shadowOffset;
/**
 The shadow blur of the text. Default is 0.
 Set a new value to this property also causes the shadow blur to be applied to the entire `attributedText`.
 */
@property (nonatomic, assign) CGFloat shadowBlurRadius;
/**
 The technique to use for aligning the text. Default is NSTextAlignmentLeft.
 Set a new value to this property also causes the new alignment to be applied to the entire `attributedText`.
 */
@property (nonatomic, assign) NSTextAlignment    textAlignment;
/**
 The technique to use for wrapping and truncating the label's text.
 Default is NSLineBreakByTruncatingTail.
 Notice: Currently, only tail is supported for truncating.
 */
@property (nonatomic, assign) NSLineBreakMode    lineBreakMode;
/**
 The text vertical aligmnent in container. Default is KZTextVerticalAlignmentCenter.
 */
@property (nonatomic, assign) KZTextVerticalAlignment textVerticalAlignment;
/**
 The maximum number of lines to use for rendering text. Default value is 1.
 0 means no limit.
 */
@property (nonatomic, assign) NSInteger numberOfLines;
/**
 An array of UIBezierPath representing the exclusion paths inside the receiver's bounding rect.
 The default value is empty.
 */
@property (nonatomic, copy) NSArray<UIBezierPath *> *exclusionPaths;
/**
 Setting the custom truncation. 只支持尾部截断
 设置此属性 会改变   lineBreakMode 的值为 NSLineBreakByTruncatingTail;
 */
@property (nonatomic, copy) NSAttributedString *truncationAttributedText;
/**
 not truncated this appended behind the attributedText
 when truncated this appended behind the truncation.
 @default nil
 */
@property (nonatomic, copy) NSAttributedString *additionalTruncationAttributedText;
/**
 Click truncatin call back Action.
 */
@property (nonatomic, copy) KZTextCommonActionBlock truncationAction;
/**
 可以设置此属性扩大 truncation的点击范围  这样可能导致 其他 事件同事触发 比如 link  Attachment等 
 Default value is UIEdgeInsetsZero.
 负值 为扩大
 正值 为缩小
 */
@property (nonatomic, assign) UIEdgeInsets truncationActionExpendInset;

/**
 If automatic detection is configured, this callback will be called automatically;
 if the configured custom link does not have a callback, the callback will also be called.
 */
@property (nonatomic, copy) KZTextLinkTypeActionBlock linkTypeAction;

/**
 The inset of the text container's layout area within the text view's content area.
 Default value is UIEdgeInsetsZero.
 */
@property (nonatomic, assign) UIEdgeInsets textContainerInset;

/**
 The inset of the label pointInside .
 Default value is UIEdgeInsetsMake(-10, -10, -10, -10);.
 when selectable is  yes  come into effect
 */
@property (nonatomic, assign) UIEdgeInsets pointInsideInset;

/**
Whether or not the text is truncated. It's expensive if text not rendered.
*/
@property (nonatomic, readonly, getter=isTruncated) BOOL truncated;
/**
 * Label 的事件是否高于手势响应 默认是YES  label或者父视图存在手势时,  Label Action高于手势响应      设置为NO 手势响应优先于 Label Action
 */
@property (nonatomic, assign) BOOL cancelsGestureWhenLabelAction;
/**
 Ignoring redrawing can improve performance when using
 `-configAutoDetectWith....` methods.
 General properties include attributedString, font, textColor,
 numberOfLines, lineBreakMode, alignment, truncationAttrStr.
 Default NO.
*/
@property (nonatomic, assign) BOOL ignorGeneralProperties;
/*
 Drawing operations execute asynchronously.
 Default NO.
 */
@property (nonatomic, assign) BOOL seniorDrawsAsynchronously;

#pragma mark -- pan select
/**
 Custom whether you need to make a selection. Default NO.
 toggle selectability, which controls the ability of the user to select content and interact with URLs & attachments. On tvOS this also makes the text view focusable.
 */
@property(nonatomic, getter=isSelectable) BOOL selectable;
/**
 forbid make a selection when the text is truncated. Default NO
  when YES  the text is truncated can,t make a selection
 */
@property(nonatomic, assign) BOOL forbidSelectableWhenTruncated;
/**
 Custom whether you need to make a magnifier. Default YES.
 */
@property (nonatomic, assign) BOOL canShowMagnifier;
/**
 Use auto word select. Default YES.
 */
@property (nonatomic, assign) BOOL useWordSelect;
/**
 * The current selection range of the receiver.
 */
@property (nonatomic, assign) NSRange selectedRange;
/**
 * The Magnifier Type. Default KZTextMagnifierTypeRanged.
 */
@property (nonatomic, assign) KZTextMagnifierType magnifierType;
/**
 * The startGrabber and endGrabber color Default  [UIColor colorWithRed:69 / 255.0 green:111 / 255.0 blue:238 / 255.0 alpha:1]
 *  .tintColor can  cover this
 */
@property (nonatomic, strong) UIColor *grabberColor;
/**
 * The startGrabber and endGrabber  width Default 2.0
 */
@property (nonatomic, assign) CGFloat grabberWidth;
/**
  the Dot  Diameter of the grabber
 */
@property (nonatomic, assign) CGFloat grabberDotDiameter;
/**
  the offfset about the Dot
 grabberDotOffset 大于0 是向内部偏移  设置小于0 无效
 */
@property (nonatomic, assign) CGFloat grabberDotOffset;
/**
 * The selectView bgColor  [[UIColor colorWithRed:69/255.0 green:111/255.0 blue:238/255.0 alpha:1] colorWithAlphaComponent:0.2]
 *  .tintColor can  cover this
 */
@property (nonatomic, strong) UIColor *selectBackgroundColor;
/**
 * The textMenuType . Default KZTextMenuTypeYPMenu.
 */
@property (nonatomic, assign) KZTextMenuType textMenuType;
/**
 *  给外部一个机会 来自定义 渲染
 *  key 是字符串
 *  如果key 是以下几个的话会覆盖掉  原始的渲染类 非特殊情况不建议这么做
 *  KZTextTrunctionAttributedStringKey:
 *  KZTextLinkAttributedStringKey:
 *  KZTextBorderAttributedStringKey:
 *  KZTextQuoteAttributedStringKey:
 *  NSAttachmentAttributeName:
 *  class 必须是遵循  <KZTextRenderer> 协议的类  如果不是的话不会加入渲染 引擎
 */
@property (nonatomic, copy) NSDictionary <NSString *, Class>*extendRendererMap;
/**
 |     text    |
 |     text    |
 Default value: 0.0  The layout padding at the beginning and end of the line fragment rects insetting the layout width available for the contents.
 This value is utilized by NSLayoutManager for determining the layout width.
 */
@property (nonatomic, assign) CGFloat lineFragmentPadding;
/**
 * a mark image for kzlabel 只有用 allocWithType:KZLabelTypeImageMark 生效
 * 设置此属性会导致 KZLabel 退化成 UIlabel
 */
@property (nonatomic, strong) UIImage *markImage;
/**
 * a mark gradientLayer for kzlabel 只有用 allocWithType:KZLabelTypeGradientMark 生效
 * 设置此属性会导致 KZLabel 退化成 UIlabel
 * 若要适配暗黑 请使用此属性
 */
@property (nonatomic, strong) CAGradientLayer *gradientLayer;
/**
 * a mark gradientLayer for kzlabel 只有用 allocWithType:KZLabelTypeGradientMark 生效
 * 设置此属性会导致 KZLabel 退化成 UIlabel
 * 如果存在 gradientLayer 设置 此属性无效
 */
@property (nonatomic, copy) NSArray <UIColor *>*gradientColors;
/**
 * 是否开启 自定义截断  (现在存在问题  当遇到 系统认为的 单词不可截断时  自定义截断失效)
 * 默认是 NO
 */
@property (nonatomic, assign) BOOL avoidLineBreak;
/**
 * lineBreak 的控制符 不存在de话不会启动
 */
@property (nonatomic, copy) NSString *lineBreakControlCharacter;
/**
 * 当遇到大文本时  超出这个文本长度 才开启大文本处理
 * 默认是 500
 */
@property (nonatomic, assign) NSUInteger maxBigLimitLength;
/**
 * label 文本赋值之后 渲染用的size  默认是 CGSizeZero   渲染是会拿 self.bounds.size
 */
@property (nonatomic, assign) CGSize containerSize;
/**
 * 是否开启debug 模式 默认是 NO
 */
@property (nonatomic, assign) BOOL enbleDebugOption;

/// Initializes a KZLabel with labelType
+ (instancetype)allocWithType:(KZLabelType)labelType;

/// 修改选中范围之后 是否弹起菜单
/// 在KZLabelMenuDelegate 回调里面不要设置为YES
- (void)setSelectedRange:(NSRange)selectedRange showMenuController:(BOOL)showMenuController;

@end

@interface KZLabel (Replenish)
/**
 * Supported type: UIImage, UIView, CALayer.
 * cover truncationAttributedText
 * 配置此方法 会改变   lineBreakMode 的值为 NSLineBreakByTruncatingTail;
 */
- (void)configTruncationWithContent:(id)content
                        contentSize:(CGSize)contentSize
                        clickAction:(KZTextCommonActionBlock)clickAction;
/**
 Get current label object content size.
 @param constraintWidth The constraint width.
 */
- (CGSize)calculateSizeForConstraintWidth:(CGFloat)constraintWidth;
/**
 Get current label object content size.
 @param constraintSize The constraint size.
 */
- (CGSize)calculateSizeForConstraintSize:(CGSize)constraintSize;

/**
 根据range 换rect
 @param textRange  range of text.
 */
- (NSArray *)textRectsAtTextRange:(NSRange)textRange;

@end


@interface KZLabel (AutoDetect)

#pragma mark -- Basic methods
/**
 Setting with detecting config
 
 @param detectType       The detect type
 @param emojiDict         The emoji dictionary which key is string and value is iamge name.
 @param emojiSize        Emoji size. If CGSizeZero, use the emoji image size.
 @param emojiBundle      Emoji bundle. If nil, use main bundle.
 @param linkColor        The link color.
 @param underlineStyle   The link underline style.
 @param underlineColor   The link underline color, default is nil which same as link color.
 */
- (void)configAutoDetectWithDetectType:(KZAutoDetectCheckType)detectType
                              emojiDict:(NSDictionary *)emojiDict
                             emojiSize:(CGSize)emojiSize
                           emojiBundle:(NSBundle *)emojiBundle
                             linkColor:(UIColor *)linkColor
                        underlineStyle:(NSUnderlineStyle)underlineStyle
                        underlineColor:(UIColor *)underlineColor;

/**
 Setting with detecting config
 
 @param config       The detect config.
 */
- (void)configAutoDetectWithConfig:(KZAutoDetectConfig *)config;
/**
 Setting with detecting config
 
 @param configBlock     The detect config block.
 */
- (void)configAutoDetectWithConfigBlock:(KZTextAutoDetectConfigBlock)configBlock;

@end

@interface KZLabel (MenuController)

- (void)dissmissMenuWithAnimated:(BOOL)animated;

@end
