//
//  KZLabel.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/21.
//

#import "KZLabel.h"
#import "KZTextRendererEngine.h"
#import "KZContextRef.h"
#import "KZTextUserInteractionManager.h"
#import "KZTextSelectionManager.h"
#import "KZTextSelectionView.h"
#import "KZImageMarkLabel.h"
#import "KZGradientMarkLabel.h"
#import "KZAsyncLayer.h"

@interface KZLabel ()<KZTextRendererEngineDelegate,KZTextAsyncLayerDelegate> {
    KZTextRendererEngine *_rendererEngine;
    KZContextExtension *_contextExtension;
    KZTextUserInteractionManager *_userInteractionManager;
    KZTextSelectionManager *_selectionManager;
}

@property (nonatomic, strong) KZAutoDetectConfig *autoDetectConfig;
@property (nonatomic, copy) NSAttributedString *drawTruncationAttributedText;
@property (nonatomic, copy) NSAttributedString *autoDetectConfigAttributedText;

@end

@implementation KZLabel

#pragma mark - Initialization

+ (instancetype)allocWithType:(KZLabelType)labelType {
    KZLabel *label = nil;
    if (labelType == KZLabelTypeImageMark) {
        label = [[KZImageMarkLabel alloc]init];
    } else if (labelType == KZLabelTypeGradientMark) {
        label = [[KZGradientMarkLabel alloc]init];
    } else {
        label = [[self alloc]init];
    }
    return label;
}

+ (Class)layerClass {
    return [KZAsyncLayer class];
}


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self _commonInit];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self _commonInit];
    }
    return self;
}

- (void)_commonInit {
    if([self isMemberOfClass:[KZImageMarkLabel class]] || [self isMemberOfClass:[KZGradientMarkLabel class]] ) {
        return;
    }
    _rendererEngine = [[KZTextRendererEngine alloc]init];
    _rendererEngine.delegate = self;
    _contextExtension = [[KZContextExtension alloc]init];
    __weak typeof(self) weakSelf = self;
    _contextExtension.displayAction = ^(NSAttributedString *highLightAttributedText) {
        [weakSelf displayActionBlock:highLightAttributedText];
    };
    _rendererEngine.contextExtension = _contextExtension;
    _selectionManager = [[KZTextSelectionManager alloc]initWithRendererEngine:_rendererEngine interactView:self];
    _userInteractionManager = [[KZTextUserInteractionManager alloc]initWithInteractView:self selectioner:_selectionManager];
    _userInteractionManager.recognizerDelegate = _rendererEngine;
    
    _lineBreakMode = NSLineBreakByTruncatingTail;
    self.layer.contentsScale = KZTextScreenScale();
    self.contentMode = UIViewContentModeRedraw;
    self.opaque = NO;
    self.isAccessibilityElement = YES;
    self.backgroundColor = [UIColor clearColor];
    
    _numberOfLines = 1;
    _textAlignment = NSTextAlignmentLeft;
    _textVerticalAlignment = KZTextVerticalAlignmentCenter;
    _shadowOffset = CGSizeMake(0, -1);
    self.maxBigLimitLength = 10000;
    self.containerSize = CGSizeZero;
    self.pointInsideInset = UIEdgeInsetsMake(-10, -10, -10, -10);
    self.canShowMagnifier = YES;
    self.selectable = NO;
    self.useWordSelect = YES;
    self.cancelsGestureWhenLabelAction = YES;
    self.seniorDrawsAsynchronously = NO;
}


- (void)displayActionBlock:(NSAttributedString *)highLightAttributedText {
    _contextExtension.highLightAttributedText = highLightAttributedText;
    [self.layer setNeedsDisplay];
}

- (BOOL)canBecomeFirstResponder {
    if (!self.isSelectable) {
        return NO;
    }
    return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    if (!self.isSelectable) {
        return NO;
    }
    return [_selectionManager.menuManager canPerformAction:action withSender:sender];
}

- (id)forwardingTargetForSelector:(SEL)aSelector {
    if ([self.menuDelegate respondsToSelector:aSelector]) {
        return self.menuDelegate;
    }
    NSLog(@"KZLabel unrecognized selector(%@) sent to menuObject(%@) object",NSStringFromSelector(aSelector),NSStringFromClass(self.menuDelegate.class));
    return nil;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (_selectionManager.selectionView) {
        _selectionManager.selectionView.frame = self.bounds;
    }
}

- (void)setFrame:(CGRect)frame {
    CGSize oldSize = self.bounds.size;
    [super setFrame:frame];
    CGSize newSize = self.bounds.size;
    if (!CGSizeEqualToSize(oldSize, newSize)) {
        [self setNeedsDisplayLabelContent];
    }
}

- (void)setBounds:(CGRect)bounds {
    CGSize oldSize = self.bounds.size;
    [super setBounds:bounds];
    CGSize newSize = self.bounds.size;
    if (!CGSizeEqualToSize(oldSize, newSize)) {
        [self setNeedsDisplayLabelContent];
    }
}

- (CGSize)intrinsicContentSize {
    CGFloat width = CGRectGetWidth(self.frame);
    if (self.numberOfLines == 1) {
        width = KZTextContainerMaxSize.width;
    }
    return [self sizeThatFits:CGSizeMake(width, KZTextContainerMaxSize.height)];
}

- (CGSize)sizeThatFits:(CGSize)size {
    if (CGSizeEqualToSize(self.bounds.size, size)) { // sizeToFit called.
        size.height = KZTextContainerMaxSize.height;
    }
    return [self _onlyCalculateLabelSizeForSize:size];
}

- (void)setNeedsDisplayLabelContent {
    if(self.ignorGeneralProperties) return;
    if (_attributedText.length == 0) {
        return;
    }
    if(self.seniorDrawsAsynchronously && self.clearsContextBeforeDrawing) {
        [self clearContentsIfNeeded];
    }
    [self _updateContextRef];
    [self.layer setNeedsDisplay];
}

- (void)clearContentsIfNeeded {
    if (self.layer.contents) {
        CGImageRef image = (__bridge_retained CGImageRef)(self.layer.contents);
        self.layer.contents = nil;
        if (!image) {
            return;
        }
        dispatch_async(KZTextAsyncLayerGetReleaseQueue(), ^{
           if (image) CFRelease(image);
        });
    }
}

- (void)_updateContextRef {
    _rendererEngine.layoutNeedUpdate = YES;
}

#pragma mark - KZTextAsyncLayerDelegate

- (KZTextAsyncLayerDisplayTask *)newAsyncDisplayTask {
    KZTextRendererEngine *engin = _rendererEngine;
    KZTextAsyncLayerDisplayTask *task = [[KZTextAsyncLayerDisplayTask alloc]init];
    
    task.willDisplay = ^(CALayer * _Nonnull layer) {
        if (!layer.delegate) {
            return;
        }
        [engin willDisplay:layer];
    };
    
    task.display = ^(CGContextRef  _Nonnull context, CGSize size, BOOL (^ _Nonnull isCancelled)(void)) {
        if (isCancelled()) {
            return;
        }
        // 渲染
        [engin display];
    };
    
    task.didDisplay = ^(CALayer * _Nonnull layer, BOOL finished) {
        if (!layer.delegate) {
            return;
        }
        if (!finished) {
            [engin didDisplayUnfinished:layer];
            return;
        }
        [engin didDisplay:layer];
    };
    return task;
}


#pragma mark - UIAccessibility

- (NSString *)accessibilityLabel {
    return [super accessibilityLabel] ? : self.text;
}

- (NSAttributedString *)accessibilityAttributedLabel {
    return [super accessibilityAttributedLabel] ? : self.attributedText;
}

#pragma mark - Defalut Values

- (UIFont *)defalutFont {
    return [UIFont systemFontOfSize:17];
}

- (UIColor *)defalutTextColor {
    return [UIColor blackColor];
}

#pragma mark - Attributes

- (NSDictionary *)attributesByProperties {
    UIFont *font = self.font ? : [self defalutFont];
    UIColor *textColor = self.textColor ? : [self defalutTextColor];
    NSMutableDictionary *attributes = [@{NSForegroundColorAttributeName: textColor,
                                         NSFontAttributeName: font} mutableCopy];
    if (self.shadowColor && self.shadowBlurRadius > FLT_EPSILON){
        NSShadow *shadow = [self shadowByProperties];
        attributes[NSShadowAttributeName] = shadow;
    }
    return [attributes copy];
}

- (NSShadow *)shadowByProperties {
    NSShadow *shadow = [NSShadow new];
    shadow.shadowColor = self.shadowColor;
    shadow.shadowOffset = self.shadowOffset;
    shadow.shadowBlurRadius = self.shadowBlurRadius;
    return shadow;
}

#pragma mark -- KZTextRendererEngineDelegate
- (CGSize)textRendererContainerSizeForFitSize:(CGSize)fitSize {
    CGRect rect = self.bounds;
    if(!CGSizeEqualToSize(fitSize, CGSizeZero)) {
        rect = (CGRect){.size = fitSize};
    } else if(!CGSizeEqualToSize(self.containerSize, CGSizeZero)) {
        CGFloat width = self.bounds.size.width > 0 ? self.bounds.size.width : MIN(self.containerSize.width, KZTextContainerMaxSize.width);
        rect = (CGRect){.size = CGSizeMake(width, MIN(self.containerSize.height,KZTextContainerMaxSize.height))};
    }
    CGRect frame = UIEdgeInsetsInsetRect(rect, self.textContainerInset);
    CGSize constrainedSize = frame.size;
    return constrainedSize;
}

- (KZTextAttributes *)textAttributesForRenderer {
    KZTextAttributes *textAttributes = [[KZTextAttributes alloc]init];
    textAttributes.attributedText = self.attributedText;
    textAttributes.lineBreakMode = self.lineBreakMode;
    textAttributes.numberOfLines = self.numberOfLines;
    textAttributes.exclusionPaths = self.exclusionPaths;
    textAttributes.truncationAttributedText = self.drawTruncationAttributedText;
    textAttributes.additionalTruncationAttributedText = self.additionalTruncationAttributedText;
    textAttributes.textVerticalAlignment = self.textVerticalAlignment;
    textAttributes.textContainerInset = self.textContainerInset;
    textAttributes.exclusionPaths = self.exclusionPaths;
    textAttributes.lineFragmentPadding = self.lineFragmentPadding;
    textAttributes.extendRendererMap = self.extendRendererMap;
    textAttributes.avoidLineBreak = self.avoidLineBreak;
    textAttributes.delegate = self.delegate;
    textAttributes.enbleDebugOption = self.enbleDebugOption;
    textAttributes.lineBreakControlCharacter = self.lineBreakControlCharacter;
    [textAttributes.attributedText enumerateAttribute:NSAttachmentAttributeName inRange:NSMakeRange(0, textAttributes.attributedText.length) options:0 usingBlock:^(KZTextAttachment *value, NSRange range, BOOL * _Nonnull stop) {
        if([value isKindOfClass:[KZTextAttachment class]]) {
            [value.content class];
        }
    }];
    return textAttributes;
}

- (void)toSetNeedsDisplay {
    [self setNeedsDisplayLabelContent];
}

- (void)propertiesUpdate {
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithAttributedString:_attributedText];
    //handle properties for layout attributed string.
    if (self.textAlignment) {
        attr.kzAlignment = self.textAlignment;
    }
    
    if (self.lineBreakMode == NSLineBreakByCharWrapping) {
        /// 修复 NSTextContainer. lineBreakMode 类型为 NSLineBreakByCharWrapping失效问题
        attr.kzLineBreakMode = NSLineBreakByCharWrapping;
    }
    
    if (self.font || self.textColor || self.shadowColor || !CGSizeEqualToSize(self.shadowOffset,  CGSizeMake(0, -1)) || self.shadowBlurRadius > FLT_EPSILON) {
        [attr enumerateAttributesInRange:NSMakeRange(0, attr.length) options:0 usingBlock:^(NSDictionary<NSAttributedStringKey,id> * _Nonnull attrs, NSRange range, BOOL * _Nonnull stop) {
              if (!attrs[NSFontAttributeName] && self.font) {
                  [attr kzSetFont:self.font range:range];
              }
              if (!attrs[NSForegroundColorAttributeName] && self.textColor) {
                  [attr kzSetColor:self.textColor range:range];
              }
              if(!attrs[NSShadowAttributeName] && self.shadowColor && self.shadowBlurRadius > FLT_EPSILON) {
                  [attr kzSetShadow:[self shadowByProperties] range:range];
              }
          }];
    }
    _attributedText = attr.copy;
}

- (CGSize)_onlyCalculateLabelSizeForSize:(CGSize)fitsSize {
    if (_attributedText.length == 0) {
        return CGSizeZero;
    }
    
    if (fitsSize.width < FLT_EPSILON || fitsSize.width > KZTextContainerMaxSize.width) {
        fitsSize.width = KZTextContainerMaxSize.width;
    }
    if (fitsSize.height < FLT_EPSILON || fitsSize.height > KZTextContainerMaxSize.width) {
        fitsSize.height = KZTextContainerMaxSize.height;
    }
    CGSize calculateSize = [_rendererEngine calculateSizeForfForFitSize:fitsSize];
    return calculateSize;
}

#pragma mark -- touch methods

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    [_userInteractionManager touchesBegan:touches withEvent:event];
    if(![self isSelectOperating]) {
        [super touchesBegan:touches  withEvent:event];
    }
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    [_userInteractionManager touchesMoved:touches withEvent:event];
    if(![self isSelectOperating]) {
       [super touchesMoved: touches withEvent:event];
    }
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    [_userInteractionManager touchesEnded:touches withEvent:event];
    if(![self isSelectOperating]) {
        [super touchesEnded:touches withEvent:event];
    }
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    [_userInteractionManager touchesCancelled:touches withEvent:event];
    if(![self isSelectOperating]) {
       [super touchesCancelled:touches withEvent:event];
    }
}

/// 是否处于选中状态
- (BOOL)isSelectOperating {
    if(_selectionManager.selectionView) {
        return !_selectionManager.selectionView.hidden;
    }
    return NO;
}

#pragma mark -- setter or getter

- (NSString *)text {
    return self.attributedText.string;
}

- (void)setText:(NSString *)text {
    if (text) {
        NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text attributes:[self attributesByProperties]];
        [attributedText kzSetAlignment:self.textAlignment range:NSMakeRange(0, attributedText.length)];
        self.attributedText = attributedText;
    } else {
        self.attributedText = nil;
    }
}

- (void)setAttributedText:(NSAttributedString *)attributedText {
    if ([_attributedText isEqualToAttributedString:attributedText]) {
        return;
    }
    _attributedText = attributedText.copy;
    if(self.ignorGeneralProperties) return;
    
    [self propertiesUpdate];
    [self setNeedsDisplayLabelContent];
}


- (void)setFont:(UIFont *)font {
    if (KZTextObjectIsEqual(_font, font)) {
        return;
    }
    _font = font ?: [self defalutFont];
    [self updateAttributedTextAttribute:NSFontAttributeName
                                  value:_font];
}

- (void)setTextColor:(UIColor *)textColor {
    if (KZTextObjectIsEqual(_textColor, textColor)) {
        return;
    }
    _textColor = textColor ?: [self defalutTextColor];
    [self updateAttributedTextAttribute:NSForegroundColorAttributeName
                                  value:_textColor];
}

- (void)setShadowColor:(UIColor *)shadowColor {
    if (KZTextObjectIsEqual(_shadowColor, shadowColor)) {
        return;
    }
    _shadowColor = shadowColor;
    [self updateAttributedTextAttribute:NSShadowAttributeName
                                  value:[self shadowByProperties]];
}

- (void)setShadowOffset:(CGSize)shadowOffset {
    if (CGSizeEqualToSize(_shadowOffset, shadowOffset)) {
        return;
    }
    _shadowOffset = shadowOffset;
    [self updateAttributedTextAttribute:NSShadowAttributeName
                                  value:[self shadowByProperties]];
}

- (void)setShadowBlurRadius:(CGFloat)shadowBlurRadius {
    if (ABS(_shadowBlurRadius - shadowBlurRadius) < FLT_EPSILON) {
        return;
    }
    _shadowBlurRadius = shadowBlurRadius;
    [self updateAttributedTextAttribute:NSShadowAttributeName
                                  value:[self shadowByProperties]];
}

- (void)setNumberOfLines:(NSInteger)numberOfLines {
    if (_numberOfLines == numberOfLines) {
        return;
    }
    _numberOfLines = numberOfLines;
    [self setNeedsDisplayLabelContent];
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    if(_lineBreakMode == lineBreakMode) {
        return;
    }
    _lineBreakMode = lineBreakMode;
    if (_lineBreakMode== NSLineBreakByCharWrapping) {
        /// 修复 NSTextContainer. lineBreakMode 类型为 NSLineBreakByCharWrapping失效问题
        NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithAttributedString:_attributedText];
        attr.kzLineBreakMode = NSLineBreakByCharWrapping;
        _attributedText = attr;
    }
    [self setNeedsDisplayLabelContent];
}

- (void)setTruncationAttributedText:(NSAttributedString *)truncationAttributedText {
    if (KZTextObjectIsEqual(_truncationAttributedText, truncationAttributedText)) {
        return;
    }
    _truncationAttributedText = truncationAttributedText;
    _drawTruncationAttributedText = nil;
    [self setNeedsDisplayLabelContent];
}

- (void)setAdditionalTruncationAttributedText:(NSAttributedString *)additionalTruncationAttributedText {
    if (KZTextObjectIsEqual(_additionalTruncationAttributedText, additionalTruncationAttributedText)) {
        return;
    }
    _additionalTruncationAttributedText = additionalTruncationAttributedText;
    [self setNeedsDisplayLabelContent];
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    if(_textAlignment == textAlignment) {
        return;
    }
    _textAlignment = textAlignment;
    
    NSMutableAttributedString *attributedText = self.attributedText.mutableCopy;
    [attributedText kzSetAlignment:self.textAlignment range:NSMakeRange(0, attributedText.length)];
    self.attributedText = attributedText;
}

- (void)setTruncationAction:(KZTextCommonActionBlock)truncationAction {
    _truncationAction = truncationAction;
    _contextExtension.truncationAction = truncationAction;
}

-(void)setTruncationActionExpendInset:(UIEdgeInsets)truncationActionExpendInset {
    _truncationActionExpendInset = truncationActionExpendInset;
    _contextExtension.truncationActionExpendInset = truncationActionExpendInset;
}

- (void)setLinkTypeAction:(KZTextLinkTypeActionBlock)linkTypeAction {
    _linkTypeAction = linkTypeAction;
    _contextExtension.linkTypeAction = linkTypeAction;
}

- (void)setTextContainerInset:(UIEdgeInsets)textContainerInset {
    if (UIEdgeInsetsEqualToEdgeInsets(_textContainerInset, textContainerInset)) {
        return;
    }
    _textContainerInset = textContainerInset;
    [self setNeedsDisplayLabelContent];
}

- (void)setExclusionPaths:(NSArray<UIBezierPath *> *)exclusionPaths {
    if (KZTextObjectIsEqual(_exclusionPaths, exclusionPaths)) {
        return;
    }
    _exclusionPaths = exclusionPaths.copy;
    CGPoint point = _rendererEngine.contextRef.glyphPoint;
    [_exclusionPaths enumerateObjectsUsingBlock:^(UIBezierPath * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj applyTransform:CGAffineTransformMakeTranslation(-point.x, -point.y)];
    }];
    
    [self setNeedsDisplayLabelContent];
}

- (void)setExtendRendererMap:(NSDictionary<NSString *,Class> *)extendRendererMap {
    if (KZTextObjectIsEqual(_extendRendererMap, extendRendererMap)) {
        return;
    }
    _extendRendererMap = extendRendererMap;
    [self setNeedsDisplayLabelContent];
}

- (void)setLineFragmentPadding:(CGFloat)lineFragmentPadding {
    if(lineFragmentPadding == _lineFragmentPadding) {
        return;
    }
    _lineFragmentPadding = lineFragmentPadding;
    [self setNeedsDisplayLabelContent];
}

- (BOOL)isTruncated {
    return _rendererEngine.contextRef.truncationInfo;
}

- (void)setSeniorDrawsAsynchronously:(BOOL)seniorDrawsAsynchronously {
    _seniorDrawsAsynchronously = seniorDrawsAsynchronously;
    ((KZAsyncLayer *)self.layer).displaysAsynchronously = seniorDrawsAsynchronously;
}

- (void)setSelectable:(BOOL)selectable {
    _selectable = selectable;
    _contextExtension.selectable = selectable;
    [_userInteractionManager gestureRecognizerEnbled:selectable];
}

- (void)setForbidSelectableWhenTruncated:(BOOL)forbidSelectableWhenTruncated {
    _forbidSelectableWhenTruncated = forbidSelectableWhenTruncated;
    _contextExtension.forbidSelectableWhenTruncated = forbidSelectableWhenTruncated;
}

- (void)setCanShowMagnifier:(BOOL)canShowMagnifier {
    _canShowMagnifier = canShowMagnifier;
    _contextExtension.canShowMagnifier = canShowMagnifier;
}

- (void)setUseWordSelect:(BOOL)useWordSelect {
    _useWordSelect = useWordSelect;
    _contextExtension.useWordSelect = useWordSelect;
}

- (void)setMagnifierType:(KZTextMagnifierType)magnifierType {
    if(!self.isSelectable) {
        return;
    }
    _magnifierType = magnifierType;
    [_selectionManager setTextMagnifierType:magnifierType];
}

- (void)setGrabberColor:(UIColor *)grabberColor {
    _selectionManager.selectionView.grabberColor = grabberColor;
}

- (void)setSelectBackgroundColor:(UIColor *)selectBackgroundColor {
    _selectionManager.selectionView.selectionColor = selectBackgroundColor;
}

- (void)setGrabberWidth:(CGFloat)grabberWidth {
    _selectionManager.selectionView.grabberWidth = grabberWidth;
}

- (void)setGrabberDotDiameter:(CGFloat)grabberDotDiameter {
    _selectionManager.selectionView.grabberDotDiameter = grabberDotDiameter;
}

- (void)setGrabberDotOffset:(CGFloat)grabberDotOffset {
    _selectionManager.selectionView.grabberDotOffset = grabberDotOffset;
}

- (void)setTintColor:(UIColor *)tintColor {
    [super setTintColor:tintColor];
    _selectionManager.selectionView.tintColor = tintColor;
}

- (void)setSelectedRange:(NSRange)selectedRange {
    [self setSelectedRange:selectedRange showMenuController:NO];
}

/// 修改选中 范围之后弹起菜单
- (void)setSelectedRange:(NSRange)selectedRange showMenuController:(BOOL)showMenuController {
    if (selectedRange.location >= _attributedText.length ||
        NSMaxRange(selectedRange) > _attributedText.length) {
        return;
    }
    if(!_rendererEngine.displayFinish) {
        return;
    }
    [_selectionManager updateTextSelectedRange:selectedRange showMenu:showMenuController];
}


- (NSRange)selectedRange {
    return _selectionManager.selectedRange;
}

- (void)updateAttributedTextAttribute:(NSAttributedStringKey)name
                                value:(id)value {
    NSMutableAttributedString *attributedText = self.attributedText.mutableCopy;
    if(attributedText.length == 0) {
        return;
    }
    if (name) {
        [attributedText addAttribute:name value:value range:NSMakeRange(0, attributedText.length)];
    }
    self.attributedText = attributedText.copy;
}

- (void)setTextMenuType:(KZTextMenuType)textMenuType {
    if(textMenuType == _textMenuType) {
        return;
    }
    _textMenuType = textMenuType;
    _selectionManager.menuManager.textMenuType = textMenuType;
}

- (void)setPointInsideInset:(UIEdgeInsets)pointInsideInset {
    _pointInsideInset = pointInsideInset;
    _contextExtension.pointInsideInset = pointInsideInset;
}

- (void)setMenuDelegate:(id<KZLabelMenuDelegate>)menuDelegate {
    if (KZTextObjectIsEqual(_menuDelegate, menuDelegate)) {
        return;
    }
    _menuDelegate = menuDelegate;
    _selectionManager.menuManager.menuDelegate = menuDelegate;
}

- (void)setDelegate:(id<KZLabelDelegate>)delegate {
    if (KZTextObjectIsEqual(_delegate, delegate)) {
        return;
    }
    _delegate = delegate;
    _selectionManager.delegate = delegate;
}

- (void)setMaxBigLimitLength:(NSUInteger)maxBigLimitLength {
    _contextExtension.maxLimitLength = maxBigLimitLength;
}

- (void)setEnbleDebugOption:(BOOL)enbleDebugOption {
    if(_enbleDebugOption == enbleDebugOption) {
        return;
    }
    _enbleDebugOption = enbleDebugOption;
#ifdef DEBUG
    [self setNeedsDisplayLabelContent];
#endif
}

- (void)setContainerSize:(CGSize)containerSize {
    if(CGSizeEqualToSize(_containerSize, containerSize)) {
        return;
    }
    _containerSize = containerSize;
    [self setNeedsDisplayLabelContent];
}

- (NSAttributedString *)drawTruncationAttributedText {
    if (self.truncationAttributedText.length == 0) {
        return nil;
    }
    if(!_drawTruncationAttributedText) {
        _drawTruncationAttributedText = KZTextTruncationAttributedTextWithToken(self.attributedText, self.truncationAttributedText);
    }
    return _drawTruncationAttributedText;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if(self.cancelsGestureWhenLabelAction) {
        return [_userInteractionManager labelGestureRecognizerShouldBegin:gestureRecognizer];
    }
    return YES;
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    if(!self.selectable) {
        return [super pointInside:point withEvent:event];
    }
    CGRect frame = UIEdgeInsetsInsetRect(self.bounds, self.pointInsideInset);
    if(CGRectContainsPoint(frame, point)) {
        return YES;
    }
    return NO;
}


@end

@implementation KZLabel (Replenish)

- (void)configTruncationWithContent:(id)content
                        contentSize:(CGSize)contentSize
                        clickAction:(KZTextCommonActionBlock)clickAction {
    KZTextAttachment *truncation = [[KZTextAttachment alloc]init];
    truncation.content = content;
    truncation.contentSize = contentSize;
    self.truncationAction = clickAction;
    NSMutableAttributedString *attachText = [[NSAttributedString attributedStringWithAttachment:truncation] mutableCopy];
    self.truncationAttributedText = attachText;
}

- (CGSize)calculateSizeForConstraintWidth:(CGFloat)constraintWidth {
    if(constraintWidth < 1) {
        return CGSizeZero;
    }
    return [self _onlyCalculateLabelSizeForSize:CGSizeMake(constraintWidth, CGFLOAT_MAX)];
}

- (CGSize)calculateSizeForConstraintSize:(CGSize)constraintSize {
    if(constraintSize.width < 1 || constraintSize.height < 1) {
        return CGSizeZero;
    }
    return [self _onlyCalculateLabelSizeForSize:constraintSize];
}

- (NSArray *)textRectsAtTextRange:(NSRange)textRange {
    KZContextRef *contextRef = _rendererEngine.contextRef;
    if(!contextRef) {
        return @[];
    }
    if (textRange.location >= _attributedText.length ||
        NSMaxRange(textRange) > _attributedText.length) {
        return @[];
    }
    NSMutableArray *mrect = [NSMutableArray array];

    NSArray<KZTextSelectionRect *> *selectionRects = [contextRef selectionRectsForCharacterRange:textRange];
    [selectionRects enumerateObjectsUsingBlock:^(KZTextSelectionRect * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CGRect rect =  obj.rect;
        rect = CGRectOffset(rect, contextRef.glyphPoint.x, contextRef.glyphPoint.y);
        rect = CGRectStandardize(rect);
        rect = KZTextCGRectPixelRound(rect);
        if (rect.size.width > 0 && rect.size.height > 0) {
            [mrect addObject:[NSValue valueWithCGRect:rect]];
        }
    }];
    return mrect.copy;
}

@end

@implementation KZLabel (AutoDetect)

- (void)configAutoDetectWithDetectType:(KZAutoDetectCheckType)detectType
                              emojiDict:(NSDictionary *)emojiDict
                             emojiSize:(CGSize)emojiSize
                           emojiBundle:(NSBundle *)emojiBundle
                             linkColor:(UIColor *)linkColor
                        underlineStyle:(NSUnderlineStyle)underlineStyle
                        underlineColor:(UIColor *)underlineColor {
    KZAutoDetectConfig *config = [[KZAutoDetectConfig alloc] initWithDetectType:detectType];
    config.emojiDict = emojiDict;
    config.emojiSize = emojiSize;
    config.emojiBundle = emojiBundle;
    config.linkColor = linkColor;
    config.underlineStyle = underlineStyle;
    config.underlineColor = underlineColor;
    [self configAutoDetectWithConfig:config];
}

- (void)configAutoDetectWithConfigBlock:(KZTextAutoDetectConfigBlock)configBlock {
    KZAutoDetectConfig *config = [[KZAutoDetectConfig alloc] init];
    if(configBlock) {
        configBlock(config);
    }
    [self configAutoDetectWithConfig:config];
}

- (void)configAutoDetectWithConfig:(KZAutoDetectConfig *)config {
    if(KZTextObjectIsEqual(config, self.autoDetectConfig) && [self.attributedText isEqualToAttributedString:self.autoDetectConfigAttributedText]) {
        [self.layer setNeedsDisplay];
        return;
    }
    config.autoDetectDelegate = self.autoDetectDelegate;
    self.autoDetectConfig = config;
    
    NSMutableAttributedString *attributedString = [KZAutoDetector autoDetectWithAttributedString:self.attributedText detectConfig:config];
    self.attributedText = attributedString;
    self.autoDetectConfigAttributedText = attributedString;
}

@end

@implementation KZLabel (MenuController)

- (void)dissmissMenuWithAnimated:(BOOL)animated {
    [_selectionManager dissmissMenuWithAnimated:animated];
}

@end
