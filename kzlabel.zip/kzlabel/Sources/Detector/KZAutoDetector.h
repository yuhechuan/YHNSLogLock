//
//  KZAutoDetector.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/12.
//

#import <Foundation/Foundation.h>

@class KZAutoDetectConfig;

@interface KZAutoDetector : NSObject

+ (NSMutableAttributedString *)autoDetectWithAttributedString:(NSAttributedString*)attributedString
                                                 detectConfig:(KZAutoDetectConfig *)detectConfig;

@end
