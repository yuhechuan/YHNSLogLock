//
//  KZAutoDetectConfig.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/12.
//

#import <UIKit/UIKit.h>
#import "KZTextHelper.h"
#import "KZLabelProtocol.h"

@interface KZAutoDetectConfig : NSObject

- (instancetype)initWithDetectType:(KZAutoDetectCheckType)detectType;

//The detect type
@property (nonatomic, assign) KZAutoDetectCheckType detectType;

/**
 The emoji dictionary which key is string and value is iamge name.
 */
@property (nonatomic, copy) NSDictionary *emojiDict;

//If it is CGSizeZero ,use the emoji image size
@property (nonatomic, assign) CGSize emojiSize;

//The bundle to which emoji image file belongs. If nil, use main bundle.
@property (nonatomic, strong) NSBundle *emojiBundle;

//The emoji align font, default will align system font with 14 size.
@property (nonatomic, strong) UIFont *emojiAlignFont;

//Change back view color when click link.
@property (nonatomic, strong) UIColor *tapBackViewColor;

//Change string color when click link.
@property (nonatomic, strong) UIColor *highLightColor;

//Link string's color.
@property (nonatomic, strong) UIColor *linkColor;

//`NSUnderlineStyle` line style.
@property (nonatomic, assign) NSUnderlineStyle underlineStyle;

//Line color. Default nil: same as link color.
@property (nonatomic, strong) UIColor *underlineColor;

//  The emoji Alignmen style
@property (nonatomic, assign) KZTextVerticalAlignment aligment;

#pragma mark -- Detect
//whether need custom detect default No.
@property (nonatomic, assign) BOOL customDetect;

//custom phone number regular expression, default is nil.
@property (nonatomic, copy) NSString *customPhoneNumberRegex;

//custom link regular expression, default is nil.
@property (nonatomic, copy) NSString *customLinkRegex;

//custom Email regular expression, default is nil.
@property (nonatomic, copy) NSString *customEmailRegex;

#pragma mark -- 内部用
// 检测配置代理
@property (nonatomic, weak) id<KZLabelAutoDetectDelegate> autoDetectDelegate;

@end
