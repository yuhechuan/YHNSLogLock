//
//  KZAutoDetector.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/12.
//

#import "KZAutoDetector.h"
#import "KZAutoDetectConfig.h"
#import "YPImage.h"
#import "KZTextHelper.h"
#import "NSMutableAttributedString+KZ.h"

@implementation KZAutoDetector

+ (NSMutableAttributedString *)autoDetectWithAttributedString:(NSAttributedString*)attributedString
                                                 detectConfig:(KZAutoDetectConfig *)detectConfig {
    if (attributedString.length < 1 || !attributedString || detectConfig.detectType == KZAutoDetectCheckTypeNone) {
        return attributedString.mutableCopy;
    }
    NSMutableAttributedString *assembleAttributeString = attributedString.mutableCopy;
    
    if(detectConfig.detectType & KZAutoDetectCheckTypeEmoji) {
        [self detectEmojiAttributedString:assembleAttributeString detectConfig:detectConfig];
    }
    if (detectConfig.customDetect) {
        [self customAutoDetectAttributedString:assembleAttributeString detectConfig:detectConfig];
    } else {
        [self systemAutoDetectAttributedString:assembleAttributeString detectConfig:detectConfig];
    }

    return assembleAttributeString;
}

+ (void)detectEmojiAttributedString:(NSMutableAttributedString*)assembleAttributeString
                       detectConfig:(KZAutoDetectConfig *)detectConfig {
    if(!detectConfig.emojiDict) {
        return;
    }
    
    BOOL autoDetectEmojiEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(shouldEffectEmojiDetectAttributedString:range:)];
    BOOL emojiStrEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(emojiImageForDetectAttributedString:emojiDict:emojiStr:range:)];
    BOOL emojiSizeEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(emojiImageSiseForDetectAttributedString:emojiDict:emojiStr:range:emojiImageSise:emojiImage:)];

    NSMutableAttributedString *originAttributeString = assembleAttributeString.mutableCopy;

    NSRegularExpression *regex = kz_getEmojiRegex();
    NSArray <NSTextCheckingResult *> *matchArr = [regex matchesInString:originAttributeString.string options:kNilOptions range:NSMakeRange(0, originAttributeString.length)];
    NSUInteger cutEmojiCharLength = 0;
    for (NSTextCheckingResult *result in matchArr) {
        if (result.range.location == NSNotFound || result.range.length <= 1) {
            continue;
        }
        NSRange range = result.range;
        range.location -= cutEmojiCharLength;

        if(autoDetectEmojiEnbled && ![detectConfig.autoDetectDelegate shouldEffectEmojiDetectAttributedString:assembleAttributeString range:range]) {
            continue;
        }
        
        NSAttributedString *subEmojiAttr = [assembleAttributeString attributedSubstringFromRange:range];
        NSString *emoString = subEmojiAttr.string;
        UIImage *emojiImage = nil;
        if(emojiStrEnbled) {
            emojiImage = [detectConfig.autoDetectDelegate emojiImageForDetectAttributedString:assembleAttributeString
                                                                       emojiDict:detectConfig.emojiDict
                                                                        emojiStr:emoString
                                                                           range:range];
        } else {
            NSString *imageName = [detectConfig.emojiDict objectForKey:emoString];
            emojiImage = [YPImage imageNamed:imageName inBundle:detectConfig.emojiBundle];
        }
    
        
        if (!emojiImage) continue;
        UIFont *alignFont = detectConfig.emojiAlignFont;
        if (!alignFont) {
            alignFont = [UIFont systemFontOfSize:17];
        }
        CGSize emojiSize = detectConfig.emojiSize;
        if(emojiSizeEnbled) {
            emojiSize = [detectConfig.autoDetectDelegate emojiImageSiseForDetectAttributedString:assembleAttributeString
                                                                                       emojiDict:detectConfig.emojiDict
                                                                                        emojiStr:emoString
                                                                                           range:range
                                                                                  emojiImageSise:emojiSize
                                                                                      emojiImage:emojiImage];
        }
        
        NSMutableAttributedString *emojiAttrStr = [NSMutableAttributedString configKzEmojiStringImage:emojiImage imageSize:emojiSize alignToFont:alignFont emojiString:emoString aligment:detectConfig.aligment];
        NSDictionary *subAttributes = [subEmojiAttr attributesAtIndex:0 effectiveRange:NULL];
        if (subAttributes) {
            [emojiAttrStr addAttributes:subAttributes range:NSMakeRange(0, emojiAttrStr.length)];
        }
        [assembleAttributeString replaceCharactersInRange:range withAttributedString:emojiAttrStr];
        
        cutEmojiCharLength += (range.length - emojiAttrStr.length);
    }
}

+ (void)systemAutoDetectAttributedString:(NSMutableAttributedString *)assembleAttributeString
                            detectConfig:(KZAutoDetectConfig *)detectConfig {
    NSTextCheckingType checkType = 0; //NSTextCheckingType
    if(detectConfig.detectType & KZAutoDetectCheckTypeLink) {
        checkType |= NSTextCheckingTypeLink;
    }
    if(detectConfig.detectType & KZAutoDetectCheckTypePhone) {
        checkType |= NSTextCheckingTypePhoneNumber;
    }
    
    if(checkType == 0){
        return;
    }
    
    BOOL autoDetectLinkEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(shouldEffectLinkDetectAttributedString:range:)];
    BOOL autoDetectPhoneEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(shouldEffectPhoneDetectAttributedString:range:)];
    
    NSDataDetector *detector = kz_getDetector(checkType);
    [detector enumerateMatchesInString:assembleAttributeString.string options:kNilOptions range:NSMakeRange(0, assembleAttributeString.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
        switch (result.resultType) {
            case NSTextCheckingTypeLink:
            case NSTextCheckingTypePhoneNumber:
            {
                if (result.phoneNumber) {
                    //exclude `0000[emoji]000` and `date(ex:0000-00-00)` pattern
                    if ([result.phoneNumber containsString:KZAttachmentPlaceholder] ||
                        [kz_getDatePredicate() evaluateWithObject:result.phoneNumber]) {
                        break;
                    }
                }
                
                if(result.resultType ==NSTextCheckingTypeLink && autoDetectLinkEnbled && ![detectConfig.autoDetectDelegate shouldEffectLinkDetectAttributedString:assembleAttributeString range:result.range]) {
                    break;
                } else if (result.resultType ==NSTextCheckingTypePhoneNumber && autoDetectPhoneEnbled && ![detectConfig.autoDetectDelegate shouldEffectPhoneDetectAttributedString:assembleAttributeString range:result.range]) {
                    break;
                }
                
                if (detectConfig.linkColor) {
                    [assembleAttributeString kzSetColor:detectConfig.linkColor range:result.range];
                }
                if (detectConfig.underlineStyle) {
                    [assembleAttributeString kzSetUnderlineStyle:detectConfig.underlineStyle range:result.range];
                    [assembleAttributeString kzSetUnderlineColor:detectConfig.underlineColor range:result.range];
                }
                
                KZTextLink *link = [[KZTextLink alloc] init];
                link.linkTextColor = detectConfig.linkColor;
                link.highlightColor = detectConfig.highLightColor;
                link.highlightBackViewColor = detectConfig.tapBackViewColor;
                link.checkResult = result;
                [assembleAttributeString kzSetLink:link range:result.range];
            }
                break;
            default:
                break;
        }
    }];
    
}

+ (void)customAutoDetectAttributedString:(NSMutableAttributedString *)assembleAttributeString
                            detectConfig:(KZAutoDetectConfig *)detectConfig {
    
    /// detect phone
    if(detectConfig.detectType & KZAutoDetectCheckTypePhone) {
        [self customAutoDetectAttributedString:assembleAttributeString
                                  detectConfig:detectConfig
                                       regular:kz_getPhoneNumberRegex(detectConfig.customPhoneNumberRegex)
                                    detectType:KZAutoDetectCheckTypePhone
                                checkingResult:^NSTextCheckingResult *(NSString *string, NSRange range) {
            NSString *number = [string substringWithRange:range];
            number = [number stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            return [NSTextCheckingResult phoneNumberCheckingResultWithRange:range phoneNumber:number];
        }];
    }
    
    if(detectConfig.detectType & KZAutoDetectCheckTypeLink) {
        // detect email
        [self customAutoDetectAttributedString:assembleAttributeString
                                  detectConfig:detectConfig
                                       regular:kz_getEmailRegex(nil)
                                    detectType:KZAutoDetectCheckTypeLink
                                checkingResult:^NSTextCheckingResult *(NSString *string, NSRange range) {
            NSURL *url = [[NSURL alloc] initWithString:@""];
            NSString *urlstr = [string substringWithRange:range];
            if (!urlstr) return nil;
            if (![urlstr hasPrefix:@"mailto:"]) {
                urlstr = [@"mailto:" stringByAppendingString:urlstr];
            }
            url = [NSURL URLWithString:urlstr];
            return [NSTextCheckingResult linkCheckingResultWithRange:range URL:url];
        }];
        //detect link
        [self customAutoDetectAttributedString:assembleAttributeString
                                  detectConfig:detectConfig
                                       regular:kz_getURLRegex(detectConfig.customLinkRegex)
                                    detectType:KZAutoDetectCheckTypeLink
                                checkingResult:^NSTextCheckingResult *(NSString *string, NSRange range) {
            NSURL *url = [[NSURL alloc] initWithString:@""];
            NSString *urlstr = [string substringWithRange:range];
            if (!urlstr) return nil;;
            if (![urlstr hasPrefix:@"http"] && ![urlstr hasSuffix:@"ftp"]) {
                urlstr = [@"http://" stringByAppendingString:urlstr];
            }
            url = [NSURL URLWithString:urlstr];
            return [NSTextCheckingResult linkCheckingResultWithRange:range URL:url];
        }];
    }
}

+ (void)customAutoDetectAttributedString:(NSMutableAttributedString *)assembleAttributeString
                            detectConfig:(KZAutoDetectConfig *)detectConfig
                                 regular:(NSRegularExpression *)regular
                              detectType:(KZAutoDetectCheckType)detectType
                          checkingResult:(NSTextCheckingResult *(^)(NSString *string, NSRange range))checkingResult {
    BOOL autoDetectLinkEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(shouldEffectLinkDetectAttributedString:range:)];
    BOOL autoDetectPhoneEnbled = detectConfig.autoDetectDelegate && [detectConfig.autoDetectDelegate respondsToSelector:@selector(shouldEffectPhoneDetectAttributedString:range:)];
    
    NSArray <NSTextCheckingResult *> *umatchArr = [regular matchesInString:assembleAttributeString.string options:kNilOptions range:NSMakeRange(0, assembleAttributeString.length)];
    for (NSTextCheckingResult *result in umatchArr) {
        if (result.range.location == NSNotFound || result.range.length <= 1) {
            continue;
        }
        //whether has link attr object, for example email link.
        NSDictionary *lastAttrDic = [assembleAttributeString attributesAtIndex:result.range.location effectiveRange:NULL];
        if (lastAttrDic[KZTextLinkAttributedStringKey]) {
            continue;;
        }
        
        if(detectType == KZAutoDetectCheckTypeLink && autoDetectLinkEnbled && ![detectConfig.autoDetectDelegate shouldEffectLinkDetectAttributedString:assembleAttributeString range:result.range]) {
            break;
        } else if (detectType ==KZAutoDetectCheckTypePhone && autoDetectPhoneEnbled && ![detectConfig.autoDetectDelegate shouldEffectPhoneDetectAttributedString:assembleAttributeString range:result.range]) {
            break;
        }
        
        if (detectConfig.underlineStyle) {
            [assembleAttributeString kzSetUnderlineStyle:detectConfig.underlineStyle range:result.range];
            [assembleAttributeString kzSetUnderlineColor:detectConfig.underlineColor range:result.range];
        }
        
        KZTextLink *link = [[KZTextLink alloc] init];
        link.linkTextColor = detectConfig.linkColor;
        link.highlightColor = detectConfig.highLightColor;
        link.highlightBackViewColor = detectConfig.tapBackViewColor;
        if(checkingResult) {
            link.checkResult = checkingResult(assembleAttributeString.string, result.range);
        }
        if(!link.checkResult) {
            continue;
        }
        [assembleAttributeString kzSetLink:link range:result.range];
    }
}


@end
