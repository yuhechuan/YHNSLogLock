//
//  KZAutoDetectConfig.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/12.
//

#import "KZAutoDetectConfig.h"

@implementation KZAutoDetectConfig

- (instancetype)init {
    if(self = [super init]) {
        _detectType = KZAutoDetectCheckTypeAll;
        _aligment = KZTextVerticalAlignmentCenter;
    }
    return self;
}

- (instancetype)initWithDetectType:(KZAutoDetectCheckType)detectType {
    if(self = [super init]) {
        _detectType = detectType;
        _aligment = KZTextVerticalAlignmentCenter;
    }
    return self;
}


- (NSUInteger)hash {
    struct {
        KZAutoDetectCheckType detectTypeHash;
        NSUInteger emojiDictHash;
        NSUInteger emojiSizeHash;
        NSUInteger emojiBundleHash;
        NSUInteger emojiAlignFontHash;
        NSUInteger tapBackViewColorHash;
        NSUInteger highLightColorHash;
        NSUInteger linkColorHash;
        NSUnderlineStyle underlineStyleHash;
        NSUInteger underlineColorHash;
        KZTextVerticalAlignment aligmentHash;
        NSUInteger customDetectHash;
        NSUInteger customPhoneNumberRegexHash;
        NSUInteger customLinkRegexHash;
        NSUInteger customEmailRegexHash;

    } data = {
        _detectType,
        [_emojiDict hash],
        [[NSValue valueWithCGSize:_emojiSize] hash],
        [_emojiBundle hash],
        [_emojiAlignFont hash],
        [_tapBackViewColor hash],
        [_highLightColor hash],
        [_linkColor hash],
        _underlineStyle,
        [_underlineColor hash],
        _aligment,
        _customDetect,
        [_customPhoneNumberRegex hash],
        [_customLinkRegex hash],
        [_customEmailRegex hash],
    };
    return KZTextHashBytes(&data, sizeof(data));
}

- (BOOL)isEqual:(KZAutoDetectConfig *)object {
    if (self == object) {
        return YES;
    }
    
    if (![object isKindOfClass:self.class]) {
        return NO;
    }
    
    return _detectType == object.detectType &&
    KZTextObjectIsEqual(_emojiDict, object.emojiDict) &&
    CGSizeEqualToSize(_emojiSize, object.emojiSize) &&
    KZTextObjectIsEqual(_emojiBundle, object.emojiBundle) &&
    KZTextObjectIsEqual(_emojiAlignFont, object.emojiAlignFont) &&
    KZTextObjectIsEqual(_tapBackViewColor, object.tapBackViewColor) &&
    KZTextObjectIsEqual(_highLightColor, object.highLightColor) &&
    KZTextObjectIsEqual(_linkColor, object.linkColor) &&
    _underlineStyle == object.underlineStyle &&
    KZTextObjectIsEqual(_underlineColor, object.underlineColor) &&
    _aligment == object.aligment &&
    _customDetect == object.customDetect &&
    [_customPhoneNumberRegex isEqualToString:object.customPhoneNumberRegex] &&
    [_customLinkRegex isEqualToString:object.customLinkRegex] &&
    [_customEmailRegex isEqualToString:object.customEmailRegex];
}




@end
