//
//  KZTextUserInteractionManager.h
//  KZLabel
//
//  Created by yuhechuan on 2023/4/28.
//

#import <UIKit/UIKit.h>

@class KZTextSelectionManager;
@class KZLabel;

@protocol KZTextSelection <NSObject>

- (void)gestureRecognizerEnbled:(BOOL)enbled;
- (void)beginSelectionAtPoint:(CGPoint)point;
- (BOOL)panShouldBeginSelectionAtPoint:(CGPoint)point;
- (void)moveSelectionAtPoint:(CGPoint)point state:(UIGestureRecognizerState)state;

@end;


@protocol KZTextGestureRecognizerDelegate <NSObject>

@optional

- (void)touchesBeganAtPoint:(CGPoint)point;
- (void)touchesEndAtPoint:(CGPoint)point;
- (BOOL)rendererPointInside:(CGPoint)point;
- (BOOL)viewDispplayFinish;
- (BOOL)trunkedGestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer;
- (BOOL)selectionerGestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer point:(CGPoint)point;

@end;


@interface KZTextUserInteractionManager : UIResponder

- (instancetype)initWithInteractView:(UIView *)interactView
                         selectioner:(KZTextSelectionManager *)selectioner;

@property (nonatomic, weak) id<KZTextGestureRecognizerDelegate> recognizerDelegate;

- (void)gestureRecognizerEnbled:(BOOL)enbled;
- (BOOL)labelGestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer;


@end
