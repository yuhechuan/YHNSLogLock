//
//  KZTextInput.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import <UIKit/UIKit.h>

@interface KZTextSelectionRect : NSObject

@property (nonatomic) CGRect rect;
@property (nonatomic) BOOL containsStart;
@property (nonatomic) BOOL containsEnd;

@end
