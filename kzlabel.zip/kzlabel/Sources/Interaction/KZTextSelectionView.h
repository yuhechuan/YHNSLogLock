//
//  KZTextSelectionView.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import <UIKit/UIKit.h>
#import "KZTextInput.h"

@interface KZTextGrabber : UIView

@property(nonatomic, strong) UIView *knob;

@property(nonatomic, assign) UITextLayoutDirection knobDirection;

@property(nonatomic, assign) CGFloat knobDiameter;

@property(nonatomic, strong) UIColor *grabberColor;

@end

@interface KZTextSelectionView : UIView

@property (nonatomic, readonly) KZTextGrabber *startGrabber;
@property (nonatomic, readonly) KZTextGrabber *endGrabber;


@property(nonatomic, strong) UIColor *selectionColor;
@property(nonatomic, strong) UIColor *grabberColor;
/// default is 2.0
@property(nonatomic, assign) CGFloat grabberWidth;
/// default is 10.0
@property (nonatomic, assign) CGFloat grabberDotDiameter;
/// default is 0
@property (nonatomic, assign) CGFloat grabberDotOffset;

@property(nonatomic, copy, readonly) NSArray<KZTextSelectionRect *> *selectionRects;

- (BOOL)isGrabberContainsPoint:(CGPoint)point;
- (BOOL)isStartGrabberContainsPoint:(CGPoint)point;
- (BOOL)isEndGrabberContainsPoint:(CGPoint)point;
- (BOOL)isSelectionRectsContainsPoint:(CGPoint)point;

- (void)updateSelectionRects:(NSArray<KZTextSelectionRect *> *)selectionRects
          startGrabberHeight:(CGFloat)startGrabberHeight
            endGrabberHeight:(CGFloat)endGrabberHeight;

@end
