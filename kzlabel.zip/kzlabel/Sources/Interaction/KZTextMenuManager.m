//
//  KZTextMenuManager.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/9.
//

#import "KZTextMenuManager.h"
#import "YPMenuController.h"
#import "YPCalloutBar.h"
#import "KZTextAttributes.h"

@interface KZTextMenuManager () 
@end

@implementation KZTextMenuManager {
    YPMenuController *_customMenuController;   /// 自定义控制器
}

- (instancetype)init {
    if(self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didHideMenuController) name:UIMenuControllerDidHideMenuNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didHideMenuController) name:YPMenuControllerDidHideMenuNotification object:nil];
    }
    return self;
}

- (void)showMenuFromView:(UIView *)targetView unionRect:(CGRect)unionRect originalRects:(NSArray *)originalRects {
    NSArray *menuItems = @[];
    if([self.menuDelegate respondsToSelector:@selector(menuItemsForLabel:)]) {
        menuItems = [self.menuDelegate menuItemsForLabel:self.label];
    }
    if(menuItems.count == 0) {
        return;
    }
    if(self.textMenuType == KZTextMenuTypeUIMenu) {
        [self system_showMenuFromView:targetView rect:unionRect menuItems:menuItems];
    } else {
        [self yp_showMenuFromView:targetView originalRects:originalRects menuItems:menuItems];
    }
}

- (void)hideMenu:(BOOL)animated {
    if(![self isMenuVisible]) {
        return;
    }
    if(self.textMenuType == KZTextMenuTypeUIMenu) {
        [self system_hideMenu:animated];
    } else {
        [self yp_hideMenu:animated];
    }
}


- (BOOL)isMenuVisible {
    if(self.textMenuType == KZTextMenuTypeUIMenu) {
        return UIMenuController.sharedMenuController.isMenuVisible;
    } else {
        return [self menuController].menuVisible;
    }
}

- (void)system_showMenuFromView:(UIView *)targetView
                           rect:(CGRect)targetRect
                      menuItems:(NSArray *)menuItems {
    UIMenuController.sharedMenuController.menuItems = menuItems;
    if (@available(iOS 13, *)) {
        [UIMenuController.sharedMenuController showMenuFromView:targetView rect:targetRect];
    } else {
        [UIMenuController.sharedMenuController setTargetRect:targetRect inView:targetView];
        [UIMenuController.sharedMenuController setMenuVisible:YES animated:YES];
    }
}

- (void)system_hideMenu:(BOOL)animated {
    if (@available(iOS 13, *)) {
        [UIMenuController.sharedMenuController hideMenu];
    } else {
        [UIMenuController.sharedMenuController setMenuVisible:NO animated:animated];
    }
    
}

- (void)yp_showMenuFromView:(UIView *)targetView
              originalRects:(NSArray *)originalRects
                  menuItems:(NSArray *)menuItems {
    
    YPMenuController *menuController = [self menuController];
    /// 给用户自定义的机会
    __block CGRect menuArrowTargetRect = CGRectZero;
    __block YPMenuControllerArrowDirection arrowDirection = menuController.styleConfig.arrowDirection;
    if ([self.menuDelegate respondsToSelector:@selector(label:customMenuShowForSelectRect:menuShowRect:completionHandler:)]) {
        NSArray *menuShowRects = [self ypmenuVisibleRect:originalRects];
        CGRect r1 = [[menuShowRects firstObject] CGRectValue];
        CGRect r2 = [[menuShowRects lastObject] CGRectValue];
        [self.menuDelegate label:self.label customMenuShowForSelectRect:r1 menuShowRect:r2 completionHandler:^(KZCustomMenuBackInfo *menuBackInfo) {
            menuArrowTargetRect = menuBackInfo.targetRect;
            if(menuBackInfo.arrowDirection == 0) {
                arrowDirection = YPMenuControllerArrowDefault;
            } else if(menuBackInfo.arrowDirection == 1) {
                arrowDirection = YPMenuControllerArrowUp;
            } else if(menuBackInfo.arrowDirection == 2) {
                arrowDirection = YPMenuControllerArrowDown;
            }
        }];
        [self yp_hideMenu:NO];
    }
    if (!CGRectEqualToRect(menuArrowTargetRect, CGRectZero)) {
        menuController.styleConfig.arrowDirection = arrowDirection;
        [menuController menuVisibleInView:targetView targetRect:menuArrowTargetRect animated:YES];
        return;
    }
    
    /// 开始展示
    menuController.menuItems = menuItems;
    //show on top margin
    CGRect topRect = [[originalRects firstObject] CGRectValue];
    menuController.styleConfig.arrowDirection = YPMenuControllerArrowDown;
    [menuController menuVisibleInView:targetView targetRect:topRect animated:YES];
    if (!menuController.menuVisible) {
        //show on bottom margin with arrow up.
        CGRect bottomRect = [[originalRects lastObject] CGRectValue];
        
        menuController.styleConfig.arrowDirection = YPMenuControllerArrowUp;
        [menuController menuVisibleInView:targetView targetRect:bottomRect animated:YES];
        if (!menuController.menuVisible) {
            //show on bottom margin with arrow down.
            menuController.styleConfig.arrowDirection = YPMenuControllerArrowDown;
            [menuController menuVisibleInView:targetView targetRect:bottomRect animated:YES];
            if (!menuController.menuVisible) {
                //show on middle window.
                menuController.styleConfig.arrowDirection = YPMenuControllerArrowDown;
                CGFloat targetX = topRect.origin.x + topRect.size.width / 2.0;
                [menuController menuVisibleInView:targetView targetX:targetX menuWindowY:KZTextScreenSize().height / 2.0 animated:YES];
            }
        }
    }
}

- (void)yp_hideMenu:(BOOL)animated {
    if(self.isSelectingBlock && self.isSelectingBlock()) {
        [[self menuController] menuInvisibleWithAnimatedWithoutNotifi:animated];
    } else {
        [[self menuController] menuInvisibleWithAnimated:animated];
    }
}

- (void)hideMenuWithoutNotifi:(BOOL)animated {
    if(self.textMenuType == KZTextMenuTypeUIMenu) {
        [self system_hideMenu:animated];
    } else {
        [[self menuController] menuInvisibleWithAnimatedWithoutNotifi:animated];
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    KZLabel *label = self.label;
    if([self.menuDelegate respondsToSelector:@selector(canPerfomSelector:)]) {
        return [self.menuDelegate respondsToSelector:action];
    }
    
    NSArray *menuLists = @[];
    if([self.menuDelegate respondsToSelector:@selector(menuItemsForLabel:)]) {
        menuLists = [self.menuDelegate menuItemsForLabel:label];
    }
    if(menuLists.count == 0) {
        return NO;
    }
    for (id menu in menuLists) {
        SEL sel = NULL;
        if(_textMenuType == KZTextMenuTypeUIMenu) {
            UIMenuItem *item = (UIMenuItem *)menu;
            sel = item.action;
        } else {
            YPMenuItem *item = (YPMenuItem *)menu;
            sel = item.action;
        }
        if(sel == action) {
            return YES;
        }
    }
    return NO;
}

- (void)setMenuDelegate:(id<KZLabelMenuDelegate>)menuDelegate {
    _menuDelegate = menuDelegate;
    if(menuDelegate) {
        [self cacheCustomMenuController:menuDelegate];
    }
}


- (void)systemMenuControllerDidHide {
    if(self.textMenuType != KZTextMenuTypeUIMenu) {
        return;
    }
    [self didHideMenuController];
}


- (void)cacheCustomMenuController:(id<KZLabelMenuDelegate>)menuDelegate {
    if(!menuDelegate || ![menuDelegate respondsToSelector:@selector(labelForCustomMenuController:)]) {
        return;
    }
    _customMenuController = [menuDelegate labelForCustomMenuController:self.label];
}

- (NSArray *)ypmenuVisibleRect:(NSArray *)originalRects {
    YPMenuController *menuController = [self menuController];

    menuController.styleConfig.arrowDirection = YPMenuControllerArrowDown;
    CGRect targetRect =  [[originalRects firstObject] CGRectValue];
    CGRect barRect = [self calloutBarRect:targetRect];
    if (!CGRectEqualToRect(barRect, CGRectZero)) {
        NSValue *r1 = [NSValue valueWithCGRect:targetRect];
        NSValue *r2 = [NSValue valueWithCGRect:barRect];
        return @[r1,r2];
    }
    
    menuController.styleConfig.arrowDirection = YPMenuControllerArrowUp;
    targetRect = [[originalRects lastObject] CGRectValue];
    barRect = [self calloutBarRect:targetRect];
    if (!CGRectEqualToRect(barRect, CGRectZero)) {
        NSValue *r1 = [NSValue valueWithCGRect:targetRect];
        NSValue *r2 = [NSValue valueWithCGRect:barRect];
        return @[r1,r2];
    }
    
    menuController.styleConfig.arrowDirection = YPMenuControllerArrowDown;
    barRect = [self calloutBarRect:targetRect];
    if (!CGRectEqualToRect(barRect, CGRectZero)) {
        NSValue *r1 = [NSValue valueWithCGRect:targetRect];
        NSValue *r2 = [NSValue valueWithCGRect:barRect];
        return @[r1,r2];
    }
    
    menuController.styleConfig.arrowDirection = YPMenuControllerArrowDown;
    CGRect topRect = [[originalRects firstObject] CGRectValue];
    CGFloat targetX = topRect.origin.x + topRect.size.width / 2.0;

    targetRect = CGRectMake(targetX, KZTextScreenSize().height / 2.0, 0, 0);
    barRect = [self calloutBarRect:targetRect];
    if (!CGRectEqualToRect(barRect, CGRectZero)) {
        NSValue *r1 = [NSValue valueWithCGRect:targetRect];
        NSValue *r2 = [NSValue valueWithCGRect:barRect];
        return @[r1,r2];
    }
    return @[[NSValue valueWithCGRect:CGRectZero],[NSValue valueWithCGRect:CGRectZero]];
}

- (CGRect)calloutBarRect:(CGRect)rect {
    rect = [KZTextKeyWindow() convertRect:rect fromView:(UIView *)self.label];
    YPMenuController *menuController = [self menuController];
    NSArray *items = menuController.menuItems;
    if (items.count < 1) return CGRectZero;
    YPCalloutBar *callBar = [YPCalloutBar createCallBarWithMenuItems:items transformRect:rect styleConfig:menuController.styleConfig];
    if (callBar.frame.origin.y < menuController.styleConfig.topLimitMargin) {
        //Bar cannot be displayed when less than `topLimitMargin`.
        return CGRectZero;
    }else if (CGRectGetMaxY(callBar.frame) >= CGRectGetHeight([UIScreen mainScreen].bounds)){
        return CGRectZero;
    }
    return callBar.frame;
}

- (void)didHideMenuController {
    if(self.didHideMenuControllerBlock) {
        self.didHideMenuControllerBlock();
    }
}


- (YPMenuController *)menuController {
    if(_customMenuController) {
        return _customMenuController;
    }
    return [YPMenuController sharedMenuController];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
