//
//  KZTextEffectWindow.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import "KZTextEffectWindow.h"
#import "KZTextHelper.h"
#import "UIView+KZ.h"

@interface KZTextEffectWindowViewController : UIViewController

@end

@implementation KZTextEffectWindowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (BOOL)shouldAutorotate {
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
     return UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight | UIInterfaceOrientationMaskPortraitUpsideDown;
}

@end

@implementation KZTextEffectWindow

+ (instancetype)sharedWindow {
    static KZTextEffectWindow *window = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        window = [[KZTextEffectWindow alloc]initWithFrame:(CGRect){.size = KZTextScreenSize()}];
    });
    return window;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.windowLevel = UIWindowLevelStatusBar + 1.;
        self.userInteractionEnabled = NO;
        self.backgroundColor = [UIColor clearColor];
        [self iOS13ShowCustomWindowWithWindow];
    }
    return self;
}

//iOS 13以上 window不再由AppDelegate来管理，所以通过AppDelegate来设置keyWindowAndVisable无效；需通过connectedScenes来获取处于活跃状态的Scene，并将window的windowScene设置为活跃状态的Scene，完成windowScene的注册。此时该window则由该Scene来管理，才能显示
//iOS13以下 window 的 windowScene 属性有值；iOS13以上 window 的 windowScene 属性无值，需要手动赋值
- (void)iOS13ShowCustomWindowWithWindow {
    if (@available(iOS 13.0, *)) {
        NSArray *array = [[[UIApplication sharedApplication] connectedScenes] allObjects];
        if (!self.windowScene) {
            for (UIWindowScene *windowScene in array) {
                if (windowScene.activationState == UISceneActivationStateForegroundActive) {
                    self.windowScene = windowScene;
                    return;
                }
            }
        }
    }
}


- (void)showMagnifier:(KZTextMagnifier *)mag {
    if (!mag) return;
    
    [self showEffectWindow];

    if (mag.superview != self) {
        [self addSubview:mag];
    }
    CGFloat rotation = [self _updateMagnifier:mag];
    CGPoint center = [self kz_convertPoint:mag.hostPopoverCenter fromViewOrWindow:mag.hostView];
    CGAffineTransform trans = CGAffineTransformMakeRotation(rotation);
    trans = CGAffineTransformScale(trans, 0.3, 0.3);
    mag.transform = trans;
    mag.center = center;
    if (mag.type == KZTextMagnifierTypeRanged) {
        mag.alpha = 0;
    }
    NSTimeInterval time = mag.type == KZTextMagnifierTypeCaret ? 0.08 : 0.1;
    [UIView animateWithDuration:time delay:0 options:UIViewAnimationOptionCurveEaseInOut | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionBeginFromCurrentState animations:^{
        if (mag.type == KZTextMagnifierTypeCaret) {
            CGPoint newCenter = CGPointMake(0, -mag.fitsSize.height / 2);
            newCenter = CGPointApplyAffineTransform(newCenter, CGAffineTransformMakeRotation(rotation));
            newCenter.x += center.x;
            newCenter.y += center.y;
            mag.center = [self _correctedCenter:newCenter forMagnifier:mag rotation:rotation];
        } else {
            mag.center = [self _correctedCenter:center forMagnifier:mag rotation:rotation];
        }
        mag.transform = CGAffineTransformMakeRotation(rotation);
        mag.alpha = 1;
    } completion:^(BOOL finished) {
        
    }];
}

- (void)moveMagnifier:(KZTextMagnifier *)mag {
    if (!mag) return;
    CGFloat rotation = [self _updateMagnifier:mag];
    CGPoint center = [self kz_convertPoint:mag.hostPopoverCenter fromViewOrWindow:mag.hostView];
    if (mag.type == KZTextMagnifierTypeCaret) {
        CGPoint newCenter = CGPointMake(0, -mag.fitsSize.height / 2);
        newCenter = CGPointApplyAffineTransform(newCenter, CGAffineTransformMakeRotation(rotation));
        newCenter.x += center.x;
        newCenter.y += center.y;
        mag.center = [self _correctedCenter:newCenter forMagnifier:mag rotation:rotation];
    } else {
        mag.center = [self _correctedCenter:center forMagnifier:mag rotation:rotation];
    }
    mag.transform = CGAffineTransformMakeRotation(rotation);
}

- (void)hideMagnifier:(KZTextMagnifier *)mag {
    if (!mag) return;
    if (mag.superview != self) return;
    
    [self hiddenEffectWindow];
    
    CGFloat rotation = [self _updateMagnifier:mag];
    CGPoint center = [self kz_convertPoint:mag.hostPopoverCenter fromViewOrWindow:mag.hostView];
    NSTimeInterval time = mag.type == KZTextMagnifierTypeCaret ? 0.20 : 0.15;
    [UIView animateWithDuration:time delay:0 options:UIViewAnimationOptionCurveEaseInOut | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionBeginFromCurrentState animations:^{
        
        CGAffineTransform trans = CGAffineTransformMakeRotation(rotation);
        trans = CGAffineTransformScale(trans, 0.01, 0.01);
        mag.transform = trans;
        
        if (mag.type == KZTextMagnifierTypeCaret) {
            CGPoint newCenter = CGPointMake(0, -mag.fitsSize.height / 2);
            newCenter = CGPointApplyAffineTransform(newCenter, CGAffineTransformMakeRotation(rotation));
            newCenter.x += center.x;
            newCenter.y += center.y;
            mag.center = [self _correctedCenter:newCenter forMagnifier:mag rotation:rotation];
        } else {
            mag.center = [self _correctedCenter:center forMagnifier:mag rotation:rotation];
            mag.alpha = 0;
        }
        
    } completion:^(BOOL finished) {
        if (finished) {
            [mag removeFromSuperview];
            mag.transform = CGAffineTransformIdentity;
            mag.alpha = 1;
        }
    }];
}

#pragma mark - Private

- (CGPoint)_correctedCenter:(CGPoint)center forMagnifier:(KZTextMagnifier *)mag rotation:(CGFloat)rotation {
    CGFloat degree = KZTextRadiansToDegrees(rotation);
    
    degree /= 45.0;
    if (degree < 0) degree += (int)(-degree/8.0 + 1) * 8;
    if (degree > 8) degree -= (int)(degree/8.0) * 8;
    
    CGFloat caretExt = 10;
    if (degree <= 1 || degree >= 7) { //top
        if (mag.type == KZTextMagnifierTypeCaret) {
            if (center.y < caretExt)
                center.y = caretExt;
        } else if (mag.type == KZTextMagnifierTypeRanged) {
            if (center.y < mag.bounds.size.height)
                center.y = mag.bounds.size.height;
        }
    } else if (1 < degree && degree < 3) { // right
        if (mag.type == KZTextMagnifierTypeCaret) {
            if (center.x > self.bounds.size.width - caretExt)
                center.x = self.bounds.size.width - caretExt;
        } else if (mag.type == KZTextMagnifierTypeRanged) {
            if (center.x > self.bounds.size.width - mag.bounds.size.height)
                center.x = self.bounds.size.width - mag.bounds.size.height;
        }
    } else if (3 <= degree && degree <= 5) { // bottom
        if (mag.type == KZTextMagnifierTypeCaret) {
            if (center.y > self.bounds.size.height - caretExt)
                center.y = self.bounds.size.height - caretExt;
        } else if (mag.type == KZTextMagnifierTypeRanged) {
            if (center.y > mag.bounds.size.height)
                center.y = mag.bounds.size.height;
        }
    } else if (5 < degree && degree < 7) { // left
        if (mag.type == KZTextMagnifierTypeCaret) {
            if (center.x < caretExt)
                center.x = caretExt;
        } else if (mag.type == KZTextMagnifierTypeRanged) {
            if (center.x < mag.bounds.size.height)
                center.x = mag.bounds.size.height;
        }
    }
    
    return center;
}

/**
 Capture screen snapshot and set it to magnifier.
 @return Magnifier rotation radius.
 */
- (CGFloat)_updateMagnifier:(KZTextMagnifier *)mag {
    UIView *hostView = mag.hostView;
    UIWindow *hostWindow = [hostView isKindOfClass:[UIWindow class]] ? (id)hostView : hostView.window;
    if (!hostView || !hostWindow) return 0;
    CGPoint captureCenter = [self kz_convertPoint:mag.hostCaptureCenter fromViewOrWindow:hostView];
    CGRect captureRect = {.size = mag.snapshotSize};
    captureRect.origin.x = captureCenter.x - captureRect.size.width / 2;
    captureRect.origin.y = captureCenter.y - captureRect.size.height / 2;
    
    CGAffineTransform trans = KZTextCGAffineTransformGetFromViews(hostView, self);
    CGFloat rotation = KZTextCGAffineTransformGetRotation(trans);
    
    if (mag.captureDisabled) {
        if (!mag.snapshot || mag.snapshot.size.width > 1) {
            static UIImage *placeholder;
            static dispatch_once_t onceToken;
            dispatch_once(&onceToken, ^{
                CGRect rect = mag.bounds;
                rect.origin = CGPointZero;
                placeholder = kzlabel_appGraphicsRendererWithOptions(rect.size, NO, 0, ^(CGContextRef context) {
                    [[UIColor colorWithWhite:1 alpha:0.8] set];
                    CGContextFillRect(context, rect);
                });
            });
            mag.captureFadeAnimation = YES;
            mag.snapshot = placeholder;
            mag.captureFadeAnimation = NO;
        }
        return rotation;
    }
    
    __block CGContextRef curContext = NULL;
    UIImage *image = kzlabel_appGraphicsRendererWithOptions(captureRect.size, NO, 0, ^(CGContextRef context) {
        curContext = context;
        if (!context) {
            return;
        }
        CGPoint tp = CGPointMake(captureRect.size.width / 2, captureRect.size.height / 2);
        tp = CGPointApplyAffineTransform(tp, CGAffineTransformMakeRotation(rotation));
        CGContextRotateCTM(context, -rotation);
        CGContextTranslateCTM(context, tp.x - captureCenter.x, tp.y - captureCenter.y);
        CGContextSaveGState(context);
        CGContextConcatCTM(context, KZTextCGAffineTransformGetFromViews(hostWindow, self));
        [hostWindow.layer renderInContext:context];
        CGContextRestoreGState(context);
    });
    
    if (!curContext) return rotation;
    
    if (mag.snapshot.size.width == 1) {
        mag.captureFadeAnimation = YES;
    }
    mag.snapshot = image;
    mag.captureFadeAnimation = NO;
    return rotation;
}

- (void)showEffectWindow {
    self.hidden = NO;
    self.rootViewController = [[KZTextEffectWindowViewController alloc]init];
}

- (void)hiddenEffectWindow {
    self.hidden = YES;
    self.rootViewController = nil;
}


@end

