//
//  KZTextSelectionManager.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import "KZTextSelectionManager.h"
#import "KZTextSelectionView.h"
#import "KZTextRendererEngine.h"
#import "KZContextRef.h"
#import "KZTextHelper.h"
#import "KZTextEffectWindow.h"
#import "KZTextMagnifier.h"
#import "KZTextMenuManager.h"
#import "YPMenuItem.h"

@interface KZTextSelectionManager ()

@property (nonatomic, strong) KZTextSelectionView *selectionView;
@property (nonatomic, strong) KZTextMagnifier *rangedMagnifier;
@property (nonatomic, weak)   UIView *interactView;
@property (nonatomic, assign) KZTextSelectionGrabberType grabberTpye;
@property (nonatomic, assign) NSUInteger pinnedGrabberIndex;
@property (nonatomic, assign) BOOL showingRangedMagnifier;
@property (nonatomic, assign) BOOL showingMenu;
@property (nonatomic, strong) KZTextMenuManager *menuManager;
@property (nonatomic, assign) BOOL moveSelecting;

@end

@implementation KZTextSelectionManager {
    KZTextRendererEngine *_engine;
    KZTextMagnifierType _magnifierType;
}

- (instancetype)initWithRendererEngine:(KZTextRendererEngine *)engine
                          interactView:(UIView *)interactView {
    if(self = [super init]) {
        _engine = engine;
        _interactView = interactView;
        _selectedRange = NSMakeRange(NSNotFound, 0);
        _magnifierType = KZTextMagnifierTypeRanged;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientationChanged:) name:UIDeviceOrientationDidChangeNotification object:nil];
    }
    return self;
}

/// 横竖屏发生变化
- (void)orientationChanged:(NSNotification *)noti {
    if(_selectionView && !self.selectionView.hidden) {
        [self endTextSelectionView];
    }
}


- (void)touchesBeganAtPoint:(CGPoint)point {
}

- (void)touchesEndAtPoint:(CGPoint)point {
    if(_selectionView && !self.selectionView.hidden) {
        [self endTextSelectingAndHideMenuController];
    }
}


- (void)gestureRecognizerEnbled:(BOOL)enbled {
    if(enbled && !_selectionView) {
        _selectionView = [[KZTextSelectionView alloc]init];
        [self.interactView addSubview:_selectionView];
    }
    [self updateSelectionView];
}

- (void)beginSelectionAtPoint:(CGPoint)point {
    [self hideMenuController];
    KZContextRef *contextRef = _engine.contextRef;
    NSUInteger characterIndex = [self characterIndexForPoint:point rangeSuffixIndex:NO];
    if (characterIndex == NSNotFound) {
        [self endTextSelectionView];
        return;
    }
    NSRange selectedRange;
    if(contextRef.extension.useWordSelect) {
        selectedRange = [contextRef rangeEnclosingCharacterForIndex:characterIndex];
    } else {
        selectedRange = contextRef.glyphRange;
    }
    
    if (selectedRange.location == NSNotFound) {
        [self endTextSelectionView];
        return;
    }
    
    BOOL shouldBeginSelecting = YES;
    if ([self.delegate respondsToSelector:@selector(label:shouldBeginSelectingAtPoint:range:)]) {
        shouldBeginSelecting = [self.delegate label:(KZLabel *)self.interactView shouldBeginSelectingAtPoint:point range:selectedRange];
    }
    if(!shouldBeginSelecting) {
        [self endTextSelectionView];
        return;
    }
    
    self.selectedRange = selectedRange;
    [self showMenuController];
}

- (BOOL)trunkedGestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    KZContextRef *contextRef = _engine.contextRef;
    if(contextRef.truncationInfo && _engine.contextExtension.forbidSelectableWhenTruncated) {
        return NO;
    }
    return YES;
}

- (BOOL)selectionerGestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer point:(CGPoint)point {
    return ![self pointInsideTruncationRectAtPoint:point];
}


- (BOOL)panShouldBeginSelectionAtPoint:(CGPoint)point {
    self.moveSelecting = NO;
    KZTextSelectionGrabberType grabberTpye = KZTextSelectionGrabberTypeNone;
    if ([self.selectionView isStartGrabberContainsPoint:point]) {
        grabberTpye = KZTextSelectionGrabberTypeStart;
    } else if ([self.selectionView isEndGrabberContainsPoint:point]) {
        grabberTpye = KZTextSelectionGrabberTypeEnd;
    }
    self.grabberTpye = grabberTpye;
    BOOL ret = grabberTpye != KZTextSelectionGrabberTypeNone;
    if(!ret &&_selectionView && !self.selectionView.hidden) {
        [self endTextSelectingAndHideMenuController];
    }
    return ret;
}

- (void)moveSelectionAtPoint:(CGPoint)point state:(UIGestureRecognizerState)state {
    self.moveSelecting = YES;
    NSUInteger characterIndex = [self characterIndexForPoint:point rangeSuffixIndex:YES];
    if(characterIndex != NSNotFound) {
        KZTextSelectionGrabberType grabberType = self.grabberTpye;
        if (state == UIGestureRecognizerStateBegan) {
            [self hideMenuController];
            if (grabberType == KZTextSelectionGrabberTypeStart) {
                self.pinnedGrabberIndex = NSMaxRange(self.selectedRange);
            } else if (grabberType == KZTextSelectionGrabberTypeEnd) {
                self.pinnedGrabberIndex = self.selectedRange.location;
            }
        }
        if(self.pinnedGrabberIndex != NSNotFound) {
            NSUInteger pinnedGrabberIndex = self.pinnedGrabberIndex;
            NSRange selectedRange = self.selectedRange;
            if (characterIndex < pinnedGrabberIndex) {
                selectedRange = NSMakeRange(characterIndex,
                                            pinnedGrabberIndex - characterIndex);
            } else if (characterIndex > pinnedGrabberIndex) {
                selectedRange = NSMakeRange(pinnedGrabberIndex,
                                            characterIndex - pinnedGrabberIndex);
            }
            self.selectedRange = selectedRange;
        }
    }
    
    if (state == UIGestureRecognizerStateBegan) {
        [self showRangedMagnifierAtCharacterIndex:characterIndex];
    } else if (state == UIGestureRecognizerStateChanged) {
        [self moveRangedMagnifierAtCharacterIndex:characterIndex];
    } else if(state == UIGestureRecognizerStateEnded ||
              state == UIGestureRecognizerStateCancelled ||
              state == UIGestureRecognizerStateFailed) {
        self.moveSelecting = NO;
        [self hideRangedMagnifier];
        [self showMenuController];
        self.grabberTpye = KZTextSelectionGrabberTypeNone;
        self.pinnedGrabberIndex = NSNotFound;
    }
}

- (void)updateSelectionView {
    if (!_selectionView) {
        return;
    }
    
    KZContextRef *contextRef = _engine.contextRef;
    self.selectionView.hidden = !contextRef.extension.selectable || ![self selectedRangeEffective];
    if (self.selectionView.isHidden) {
        return;
    }
    
    NSRange selectedRange = self.selectedRange;
    NSArray<KZTextSelectionRect *> *selectionRects = [contextRef selectionRectsForCharacterRange:selectedRange];
    if(selectionRects.count == 0) {
        self.selectionView.hidden = YES;
        [self hideMenuController];
        return;
    }
    
    [selectionRects enumerateObjectsUsingBlock:^(KZTextSelectionRect * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.rect = CGRectOffset(obj.rect, contextRef.glyphPoint.x, contextRef.glyphPoint.y);
    }];
    CGFloat startGrabberHeight;
    if (selectionRects.count > 1) {
        CGRect startLineFragmentRect = [contextRef lineFragmentRectForCharacterAtIndex:selectedRange.location effectiveRange:NULL];
        startGrabberHeight = CGRectGetHeight(startLineFragmentRect);
    } else {
        CGRect startLineFragmentUsedRect = [contextRef lineFragmentUsedRectForCharacterAtIndex:selectedRange.location effectiveRange:NULL];
        startGrabberHeight = CGRectGetHeight(startLineFragmentUsedRect);
    }
    CGRect endLineFragmentUsedRect = [contextRef lineFragmentUsedRectForCharacterAtIndex:NSMaxRange(selectedRange) - 1 effectiveRange:NULL];
    [self.selectionView updateSelectionRects:selectionRects
                          startGrabberHeight:startGrabberHeight
                            endGrabberHeight:CGRectGetHeight(endLineFragmentUsedRect)];
}



- (void)showRangedMagnifierAtCharacterIndex:(NSUInteger)characterIndex {
    if(!_engine.contextExtension.canShowMagnifier) {
        return;
    }
    if(![self selectedRangeEffective]) {
        return;
    }
    self.showingRangedMagnifier = YES;
    [self updateRangedMagnifierSettingWithCharacterIndex:characterIndex];
    [[KZTextEffectWindow sharedWindow] showMagnifier:self.rangedMagnifier];
}

- (void)moveRangedMagnifierAtCharacterIndex:(NSUInteger)characterIndex {
    if(!_engine.contextExtension.canShowMagnifier) {
        return;
    }
    if(![self selectedRangeEffective]) {
        return;
    }
    [self updateRangedMagnifierSettingWithCharacterIndex:characterIndex];
    [[KZTextEffectWindow sharedWindow] moveMagnifier:self.rangedMagnifier];
}

- (void)updateRangedMagnifierSettingWithCharacterIndex:(NSUInteger)characterIndex {
    KZTextSelectionGrabberType grabberType = characterIndex < self.pinnedGrabberIndex ? KZTextSelectionGrabberTypeStart : KZTextSelectionGrabberTypeEnd;
    CGRect grabberRect = [self grabberRectForGrabberType:grabberType];
    CGPoint grabberCenter = CGPointMake(CGRectGetMidX(grabberRect), CGRectGetMidY(grabberRect));
    self.rangedMagnifier.hostCaptureCenter = grabberCenter;
    self.rangedMagnifier.hostPopoverCenter = CGPointMake(grabberCenter.x, CGRectGetMinY(grabberRect));
}

- (void)hideMenuController {
    [self.menuManager hideMenu:YES];
    self.showingMenu = NO;
}

- (void)showMenuController {
    if(![self selectedRangeEffective]) {
        [self hideMenuController];
        return;
    }
    NSRange range = self.selectedRange;
    KZContextRef *contextRef = _engine.contextRef;
    NSAttributedString *menuSelectAttr = [[NSAttributedString alloc] initWithString:@""];
    NSRange menuSeletRange = NSMakeRange(NSNotFound, 0);
    if (NSMaxRange(range) <= contextRef.textStorage.length) {
        menuSelectAttr = [contextRef.textStorage attributedSubstringFromRange:range];
        menuSeletRange = range;
    }
    
    BOOL shouldShwoMenu = YES;
    if ([self.menuManager.menuDelegate respondsToSelector:@selector(label:shouldShowMenuForRange:selectContent:)]) {
        shouldShwoMenu = [self.menuManager.menuDelegate label:self.menuManager.label shouldShowMenuForRange:menuSeletRange selectContent:menuSelectAttr];
    }
    if(!shouldShwoMenu) {
        [self hideMenuController];
        return;
    }
    
    if([self.menuManager.menuDelegate respondsToSelector:@selector(label:didChangeSelectContent:)]) {
        NSString *selectContent = [self selectStringWithAttributedString:contextRef.textStorage seletedRange:menuSeletRange];
        [self.menuManager.menuDelegate label:self.menuManager.label didChangeSelectContent:selectContent];
    }
    if([self.menuManager.menuDelegate respondsToSelector:@selector(label:didChangeSelectContent:selectRange:)]) {
        NSString *selectContent = [self selectStringWithAttributedString:contextRef.textStorage seletedRange:menuSeletRange];
        [self.menuManager.menuDelegate label:self.menuManager.label didChangeSelectContent:selectContent selectRange:menuSeletRange];
    }
    
    __block CGRect targetRect = CGRectNull;
    NSMutableArray *selectedRects = [NSMutableArray array];
    [self.selectionView.selectionRects enumerateObjectsUsingBlock:^(KZTextSelectionRect * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        targetRect = CGRectUnion(targetRect, obj.rect);
        [selectedRects addObject:[NSValue valueWithCGRect:obj.rect]];
    }];
    if(selectedRects.count == 0) {
        [self hideMenuController];
        return;
    }
    
    [self.menuManager showMenuFromView:self.interactView unionRect:targetRect originalRects:selectedRects.copy];
    self.showingMenu = YES;
}

- (void)hideRangedMagnifier {
    if (!self.showingRangedMagnifier) {
        return;
    }
    self.showingRangedMagnifier = NO;
    [[KZTextEffectWindow sharedWindow] hideMagnifier:self.rangedMagnifier];
}


- (CGRect)grabberRectForGrabberType:(KZTextSelectionGrabberType)grabberType {
    if (grabberType == KZTextSelectionGrabberTypeStart) {
        return self.selectionView.startGrabber.frame;
    } else if (grabberType == KZTextSelectionGrabberTypeEnd) {
        return self.selectionView.endGrabber.frame;
    }
    return CGRectZero;
}


/// 获取当前点击位置  的文字 索引
- (NSUInteger)characterIndexForPoint:(CGPoint)point rangeSuffixIndex:(BOOL)rangeSuffixIndex{
    KZContextRef *contextRef = _engine.contextRef;
    CGPoint beginPoint = contextRef.glyphPoint;
    point.x -= beginPoint.x;
    point.y -= beginPoint.y;
    
    CGRect bounces = self.interactView.bounds;
    /// 适配球
    CGFloat offset = 5;
    CGFloat overY = point.y - bounces.size.height;
    
    if(overY > 0 && overY <= offset) {
        point.y = bounces.size.height - 1;
    }
    if(point.y < 0 && point.y >= - offset) {
        point.y = 1;
    }
    CGFloat overX = point.x - bounces.size.width;

    if(overX > 0 && overX >= offset) {
        point.x = bounces.size.width - 1;
    }
    if(point.x < 0 && point.x >= - offset) {
        point.x = 1;
    }
    NSUInteger characterIndex = [contextRef characterIndexForPoint:point rangeSuffixIndex:rangeSuffixIndex];
    return characterIndex;
}


/// 获取原始字符串
- (NSString *)selectStringWithAttributedString:(NSMutableAttributedString *)attributedString
                                  seletedRange:(NSRange)seletedRange {
    NSMutableString *originalString = [[NSMutableString alloc] init];
    if (seletedRange.length + seletedRange.location > attributedString.length) {
        return originalString;
    }
    [attributedString enumerateAttribute:NSAttachmentAttributeName inRange:seletedRange options:kNilOptions usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
        if([value isKindOfClass:[KZTextAttachment class]]) {
            KZTextAttachment *att = (KZTextAttachment *)value;
            if(att.representString.length > 0) {
                [originalString appendString:att.representString];
            }
        } else {
            [originalString appendString:[attributedString attributedSubstringFromRange:range].string];
        }
    }];
    return originalString;
}

- (void)endTextSelectionView {
    self.selectionView.hidden = YES;
    _selectedRange = NSMakeRange(NSNotFound, 0);
}

- (void)endTextSelectingAndHideMenuController {
    [self hideMenuController];
    [self endTextSelectionView];
}


- (BOOL)isSelectionDisplaying {
    if (!self.selectionView) {
        return NO;
    }
    if (self.selectionView.isHidden) {
        return NO;
    }
    return YES;
}

/// 判断点是否在截断里面
- (BOOL)pointInsideTruncationRectAtPoint:(CGPoint)point {
    KZContextRef *contextRef = _engine.contextRef;
    if(contextRef.truncationInfo) {
        if (CGRectContainsPoint(contextRef.truncationInfo.truncationRect, point)) {
            return YES;
        }
    }
    return NO;
}

- (void)setSelectedRange:(NSRange)selectedRange {
    if (NSEqualRanges(_selectedRange, selectedRange)) {
        return;
    }
    KZContextRef *contextRef = _engine.contextRef;
    if(contextRef.truncationInfo) {
        if (NSLocationInRange(contextRef.truncationInfo.truncationTextContainerRange.location, selectedRange)) {
            selectedRange = NSMakeRange(selectedRange.location, contextRef.truncationInfo.truncationTextContainerRange.location - selectedRange.location);
        } else if (NSLocationInRange(selectedRange.location, contextRef.truncationInfo.truncationTextContainerRange)) {
            selectedRange = NSMakeRange(NSNotFound, 0);
        }
    }
    _selectedRange = selectedRange;
    [self updateSelectionView];
}

- (BOOL)selectedRangeEffective {
    NSRange range = self.selectedRange;
    if(range.location == NSNotFound || range.length == 0 || NSMaxRange(range) > NSMaxRange( _engine.contextRef.glyphRange)) {
        return NO;
    }
    return YES;
}

- (void)setTextMagnifierType:(KZTextMagnifierType)magnifierType {
    if(magnifierType == _magnifierType) {
        return;
    }
    if(self.showingRangedMagnifier) {
        return;
    }
    _magnifierType = magnifierType;
    self.rangedMagnifier = nil;
}

- (void)dissmissMenuWithAnimated:(BOOL)animated {
    [self.menuManager hideMenu:animated];
    self.showingMenu = NO;
    [self endTextSelectionView];
}

/// 更新 选中的range
- (void)updateTextSelectedRange:(NSRange)selectedRange
                       showMenu:(BOOL)showMenu {
    self.selectedRange = selectedRange;
    if (showMenu) {
        [self.menuManager hideMenuWithoutNotifi:YES];
        self.showingMenu = NO;
        [self showMenuController];
    }
}


- (KZTextMagnifier *)rangedMagnifier {
    if (!_rangedMagnifier) {
        _rangedMagnifier = [KZTextMagnifier magnifierWithType:_magnifierType];
        _rangedMagnifier.hostView = self.interactView;
    }
    return _rangedMagnifier;
}

- (KZTextMenuManager *)menuManager {
    if(!_menuManager) {
        _menuManager = [[KZTextMenuManager alloc]init];
        _menuManager.label = (KZLabel *)self.interactView;
        _menuManager.pointInsideInset = _engine.contextExtension.pointInsideInset;
        __weak __typeof(self)weakSelf = self;
        _menuManager.didHideMenuControllerBlock = ^{
            if(!weakSelf.moveSelecting) {
                [weakSelf endTextSelectionView];
            }
        };
        _menuManager.isSelectingBlock = ^BOOL{
            return weakSelf.moveSelecting;
        };
    }
    return _menuManager;
}

@end
