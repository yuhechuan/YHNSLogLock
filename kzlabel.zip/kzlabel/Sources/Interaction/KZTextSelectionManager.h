//
//  KZTextSelectionManager.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import <Foundation/Foundation.h>
#import "KZTextUserInteractionManager.h"
#import "KZTextHelper.h"
#import "KZLabelProtocol.h"
#import "KZTextMenuManager.h"

@class KZTextRendererEngine;
@class KZTextSelectionView;

@interface KZTextSelectionManager : NSObject<KZTextGestureRecognizerDelegate,KZTextSelection>

@property (nonatomic, strong, readonly) KZTextSelectionView *selectionView;
@property (nonatomic, assign) NSRange selectedRange;
@property (nonatomic, strong, readonly) KZTextMenuManager *menuManager;
@property (nonatomic, weak) id <KZLabelDelegate> delegate;

- (instancetype)initWithRendererEngine:(KZTextRendererEngine *)engine
                          interactView:(UIView *)interactView;

- (void)setTextMagnifierType:(KZTextMagnifierType)magnifierType;

- (void)dissmissMenuWithAnimated:(BOOL)animated;
/// 更新 选中的range
- (void)updateTextSelectedRange:(NSRange)selectedRange
                       showMenu:(BOOL)showMenu;

@end
