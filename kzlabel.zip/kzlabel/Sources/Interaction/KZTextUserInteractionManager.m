//
//  KZTextUserInteractionManager.m
//  KZLabel
//
//  Created by yuhechuan on 2023/4/28.
//

#import "KZTextUserInteractionManager.h"
#import "KZTextSelectionManager.h"

@interface KZTextUserInteractionManager ()<UIGestureRecognizerDelegate> {
    //gestures
    UILongPressGestureRecognizer *_longPressGesture;
    UIPanGestureRecognizer *_panGesture;
    BOOL _selectEnable;
}

@property (nonatomic, weak) KZTextSelectionManager *selectioner;
@property (nonatomic, weak) UIView *interactView;

@end

@implementation KZTextUserInteractionManager


- (instancetype)initWithInteractView:(UIView *)interactView
                         selectioner:(KZTextSelectionManager *)selectioner {
    if(self = [super init]) {
        _interactView = interactView;
        self.selectioner = selectioner;
        [self initializeGestureRecognizer];
    }
    return self;
}

- (void)initializeGestureRecognizer {
    //long press gesture
    _longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longAction:)];
    _longPressGesture.delegate = self;
    /**
     The purpose of using delaysTouchesBegan is to first respond to a long-press gesture,
     rather than a click action, when long-press a link.
     */
    _longPressGesture.delaysTouchesBegan = YES;
    [_interactView addGestureRecognizer:_longPressGesture];
    //pan gesture
    _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
    _panGesture.delaysTouchesBegan = YES;
    _panGesture.delegate = self;
    [_interactView addGestureRecognizer:_panGesture];
    _longPressGesture.enabled = NO;
    _panGesture.enabled = NO;
}

- (void)gestureRecognizerEnbled:(BOOL)enbled {
    if(enbled == _selectEnable) {
        return;
    }
    _selectEnable = enbled;
    _longPressGesture.enabled = enbled;
    _panGesture.enabled = enbled;
    if([self.selectioner respondsToSelector:@selector(gestureRecognizerEnbled:)]) {
        [self.selectioner gestureRecognizerEnbled:enbled];
    }
}

- (void)longAction:(UILongPressGestureRecognizer *)recognizer {
    if([self.recognizerDelegate respondsToSelector:@selector(viewDispplayFinish)]) {
        if(![self.recognizerDelegate viewDispplayFinish]) {
            return;
        }
    }
    CGPoint location = [recognizer locationInView:_interactView];
    UIGestureRecognizerState state = recognizer.state;
    if (state == UIGestureRecognizerStateBegan) {
        [self beginSelectionAtPoint:location];
    }
}

- (void)panAction:(UIPanGestureRecognizer *)recognizer {
    CGPoint location = [recognizer locationInView:_interactView];
    UIGestureRecognizerState state = recognizer.state;
    if([self.selectioner respondsToSelector:@selector(moveSelectionAtPoint:state:)]) {
        [self.selectioner moveSelectionAtPoint:location state:state];
    }
}

- (void)beginSelectionAtPoint:(CGPoint)point {
    if([self.selectioner respondsToSelector:@selector(beginSelectionAtPoint:)]) {
        [self.selectioner beginSelectionAtPoint:point];
    }
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = touches.anyObject;
    CGPoint tapPoint = [touch locationInView:_interactView];
    if([self.recognizerDelegate respondsToSelector:@selector(touchesBeganAtPoint:)]) {
        [self.recognizerDelegate touchesBeganAtPoint:tapPoint];
    }
    if([self.selectioner respondsToSelector:@selector(touchesBeganAtPoint:)]) {
        [self.selectioner touchesBeganAtPoint:tapPoint];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = touches.anyObject;
    CGPoint tapPoint = [touch locationInView:_interactView];
    if([self.recognizerDelegate respondsToSelector:@selector(touchesEndAtPoint:)]) {
        [self.recognizerDelegate touchesEndAtPoint:tapPoint];
    }
    if([self.selectioner respondsToSelector:@selector(touchesEndAtPoint:)]) {
        [self.selectioner touchesEndAtPoint:tapPoint];
    }
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if([_selectioner respondsToSelector:@selector(trunkedGestureRecognizerShouldBegin:)] && ![_selectioner trunkedGestureRecognizerShouldBegin:gestureRecognizer]) {
        return NO;
    }
    CGPoint location = [gestureRecognizer locationInView:_interactView];
    BOOL shouldBegin = NO;
    if (_selectEnable && gestureRecognizer == _panGesture) {
        if([_selectioner respondsToSelector:@selector(panShouldBeginSelectionAtPoint:)]) {
            shouldBegin = [_selectioner panShouldBeginSelectionAtPoint:location];
        }
    } else if (_selectEnable && gestureRecognizer == _longPressGesture) {
        shouldBegin = YES;
    }
    if(shouldBegin && [_selectioner respondsToSelector:@selector(selectionerGestureRecognizerShouldBegin:point:)]) {
        shouldBegin = [_selectioner selectionerGestureRecognizerShouldBegin:gestureRecognizer point:location];
    }
    return shouldBegin;
}

- (BOOL)labelGestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if(_selectEnable && (gestureRecognizer == _panGesture || gestureRecognizer == _longPressGesture)) {
        return YES;
    }
    if(![gestureRecognizer isKindOfClass:[UITapGestureRecognizer class]]) {
        return YES;
    }
    if([self.recognizerDelegate respondsToSelector:@selector(rendererPointInside:)]) {
        CGPoint tapPoint = [gestureRecognizer locationInView:_interactView];
        return [self.recognizerDelegate rendererPointInside:tapPoint];
    }
    return YES;
}

@end
