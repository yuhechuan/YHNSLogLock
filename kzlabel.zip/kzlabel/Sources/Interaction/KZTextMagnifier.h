//
//  KZTextMagnifier.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import <UIKit/UIKit.h>
#import "KZTextHelper.h"
/**
A magnifier view which can be displayed in `KZTextEffectWindow`.

@discussion Use `magnifierWithType:` to create instance.
Typically, you should not use this class directly.
*/
@interface KZTextMagnifier : UIView

/// Create a mangifier with the specified type. @param type The magnifier type.
+ (instancetype)magnifierWithType:(KZTextMagnifierType)type;

@property (nonatomic, readonly) KZTextMagnifierType type;  ///< Type of magnifier
@property (nonatomic, readonly) CGSize fitsSize;            ///< The 'best' size for magnifier view.
@property (nonatomic, readonly) CGSize snapshotSize;       ///< The 'best' snapshot image size for magnifier.
@property (nonatomic, strong) UIImage *snapshot; ///< The image in magnifier (readwrite).

@property (nonatomic, weak) UIView *hostView;   ///< The coordinate based view.
@property (nonatomic) CGPoint hostCaptureCenter;          ///< The snapshot capture center in `hostView`.
@property (nonatomic) CGPoint hostPopoverCenter;          ///< The popover center in `hostView`.
@property (nonatomic) BOOL hostVerticalForm;              ///< The host view is vertical form.
@property (nonatomic) BOOL captureDisabled;               ///< A hint for `KZTextEffectWindow` to disable capture.
@property (nonatomic) BOOL captureFadeAnimation;          ///< Show fade animation when the snapshot image changed.

@end
