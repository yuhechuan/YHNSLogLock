//
//  KZTextMenuManager.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/9.
//

#import <UIKit/UIKit.h>
#import "KZLabelProtocol.h"
#import "KZTextHelper.h"

@class KZLabel;

@interface KZTextMenuManager : NSObject

@property (nonatomic, weak) id <KZLabelMenuDelegate> menuDelegate;
@property (nonatomic, weak) KZLabel *label;
@property (nonatomic, assign) KZTextMenuType textMenuType;
@property (nonatomic, assign) UIEdgeInsets pointInsideInset;
@property (nonatomic, copy) void(^didHideMenuControllerBlock)(void);
@property (nonatomic, copy) BOOL(^isSelectingBlock)(void);

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender;

- (void)showMenuFromView:(UIView *)targetView
               unionRect:(CGRect)unionRect
           originalRects:(NSArray *)originalRects;
- (void)hideMenu:(BOOL)animated;
- (void)hideMenuWithoutNotifi:(BOOL)animated;
- (BOOL)isMenuVisible;




@end
