//
//  KZTextEffectWindow.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import <UIKit/UIKit.h>
#import "KZTextMagnifier.h"

@interface KZTextEffectWindow : UIWindow

/// Returns the shared instance (returns nil in App Extension).
+ (instancetype)sharedWindow;

/// Show the magnifier in this window with a 'popup' animation. @param magnifier A magnifier.
- (void)showMagnifier:(KZTextMagnifier *)magnifier;
/// Update the magnifier content and position. @param magnifier A magnifier.
- (void)moveMagnifier:(KZTextMagnifier *)magnifier;
/// Remove the magnifier from this window with a 'shrink' animation. @param magnifier A magnifier.
- (void)hideMagnifier:(KZTextMagnifier *)magnifier;


@end

