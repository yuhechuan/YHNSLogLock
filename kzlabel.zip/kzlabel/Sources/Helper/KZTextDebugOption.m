//
//  KZTextDebugOption.m
//  KZLabel
//
//  Created by yuhechuan on 2023/11/14.
//

#import "KZTextDebugOption.h"

@implementation KZTextDebugOption

- (instancetype)init {
    if(self = [super init]) {
        _baselineColor = [[UIColor redColor] colorWithAlphaComponent:0.5];
        _lineFragmentBorderColor = [[UIColor redColor] colorWithAlphaComponent:0.200];
        _lineFragmentUsedBorderColor = [UIColor colorWithRed:0.000 green:0.463 blue:1.000 alpha:0.200];
        _glyphBorderColor = [UIColor colorWithRed:1.000 green:0.524 blue:0.000 alpha:0.200];
    }
    return self;
}

@end
