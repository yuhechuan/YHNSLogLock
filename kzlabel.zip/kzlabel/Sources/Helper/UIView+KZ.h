//
//  UIView+KZ.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/8.
//

#import <UIKit/UIKit.h>

@interface UIView (KZ)

- (CGPoint)kz_convertPoint:(CGPoint)point toViewOrWindow:(UIView *)view;
- (CGPoint)kz_convertPoint:(CGPoint)point fromViewOrWindow:(UIView *)view;
- (CGRect)kz_convertRect:(CGRect)rect toViewOrWindow:(UIView *)view;
- (CGRect)kz_convertRect:(CGRect)rect fromViewOrWindow:(UIView *)view;

@end
