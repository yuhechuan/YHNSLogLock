//
//  KZLabelProtocol.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/18.
//

#ifndef KZLabelProtocol_h
#define KZLabelProtocol_h

@class KZLabel;
@class YPMenuItem;
@class YPMenuController;
@class KZCustomMenuBackInfo;
@class KZTextDebugOption;

@protocol KZLabelDelegate <NSObject>

@optional

/// 长按即将 出现选择view时回调, 返回YES 正常出现  返回NO 终止选择
- (BOOL)label:(KZLabel *)label shouldBeginSelectingAtPoint:(CGPoint)point range:(NSRange)range;
/**
 * 当遇到特殊的 unicode 码是会回调, 注意 再换行时也会进行回调  并且只在  NSLineBreakByCharWrapping 模式下生效
 * 如果不进行任何改变 可以 返回 shouldUseAction
 * 可以根据需要返回不同 的Action 来控制 换行 等
 */
- (NSControlCharacterAction)layoutManager:(NSLayoutManager *)layoutManager
                          shouldUseAction:(NSControlCharacterAction)action
                         controlCharacter:(NSString *)controlCharacter
                                charIndex:(NSUInteger)charIndex;
/**
 * 布局完成之后的回调
 */
- (void)didLayoutWithTextCalculateSize:(CGSize)size;
/**
 * 渲染debug线时回调  可以配置颜色
 * DEBUG 模式下才会生效
 */
- (void)willRendererDebugOption:(KZTextDebugOption *)option;

@end

@protocol KZLabelMenuDelegate <NSObject>

@required
/// UIMenuController   优先级比较低  只有 kzmenuItemsForLabel为实现时才 出系统
/// YPMenuItem 或者 UIMenuItem
- (NSArray *)menuItemsForLabel:(KZLabel *)label;

@optional

/// 会优先用次方法  如果没有实现会 遍历 menuItemsForLabel 返回的数组
- (BOOL)canPerfomSelector:(SEL)aSelector;

/// 当选中内容发生变化时 回调
- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent;

/// 当选中内容发生变化时 回调
- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent selectRange:(NSRange)selectRange;

/// 当选中内容发生变化时 询问是否需要 展示Menu
- (BOOL)label:(KZLabel *)label shouldShowMenuForRange:(NSRange)range selectContent:(NSAttributedString *)selectContent;

/// 获取自定义的 菜单控制器 如果 没有或者未 实现 会用  [YPMenuController sharedMenuController] 单例
- (YPMenuController *)labelForCustomMenuController:(KZLabel *)label;

/// 当 menu 将要显示时 给外面一个自定义的机会
- (void)label:(KZLabel *)label customMenuShowForSelectRect:(CGRect)selectRect menuShowRect:(CGRect)menuShowRect  completionHandler:(void (^)(KZCustomMenuBackInfo *menuBackInfo))completionHandler;

@end

@protocol KZLabelAutoDetectDelegate <NSObject>

@optional

- (BOOL)shouldEffectEmojiDetectAttributedString:(NSAttributedString *)attributedString
                                          range:(NSRange)range;
- (BOOL)shouldEffectLinkDetectAttributedString:(NSAttributedString *)attributedString
                                          range:(NSRange)range;
- (BOOL)shouldEffectPhoneDetectAttributedString:(NSAttributedString *)attributedString
                                          range:(NSRange)range;

- (UIImage *)emojiImageForDetectAttributedString:(NSAttributedString *)attributedString
                                       emojiDict:(NSDictionary *)emojiDict
                                        emojiStr:(NSString *)emojiStr
                                           range:(NSRange)range;

- (CGSize)emojiImageSiseForDetectAttributedString:(NSAttributedString *)attributedString
                                       emojiDict:(NSDictionary *)emojiDict
                                        emojiStr:(NSString *)emojiStr
                                            range:(NSRange)range
                                   emojiImageSise:(CGSize)emojiImageSise
                                       emojiImage:(UIImage *)emojiImage;
@end


#endif /* KZLabelProtocol_h */
