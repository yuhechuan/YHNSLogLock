//
//  NSMutableAttributedString+KZ.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import <UIKit/UIKit.h>
#import "KZTextAttributes.h"

@interface NSAttributedString (KZ)

@property (nonatomic, strong, readonly) UIFont *kzFont;

@property (nonatomic, strong, readonly) UIColor *kzColor;

@property (nonatomic, strong, readonly) UIColor *kzBackgroundColor;

@property (nonatomic, assign, readonly) NSUnderlineStyle kzUnderlineStyle;

@property (nonatomic, strong, readonly) UIColor *kzUnderlineColor;

@property (nonatomic, strong, readonly) NSParagraphStyle *kzParagraphStyle;

@property (nonatomic, assign, readonly) CGFloat kzLineSpacing;

@property (nonatomic, assign, readonly) CGFloat kzMinimumLineHeight;

@property (nonatomic, assign, readonly) CGFloat kzMaximumLineHeight;

@property (nonatomic, assign, readonly) NSTextAlignment kzAlignment;

@property (nonatomic, assign, readonly) NSLineBreakMode kzLineBreakMode;

@property (nonatomic, assign, readonly) CGFloat kzFirstLineHeadIndent;

@property (nonatomic, assign, readonly) CGFloat kzHeadIndent;

@property (nonatomic, assign, readonly) CGFloat kzTailIndent;

@property (nonatomic, assign, readonly) CGFloat kzParagraphSpacing;

@property (nonatomic, assign, readonly) CGFloat kzParagraphSpacingBefore;

@property (nonatomic, strong, readonly) NSShadow *kzShadow;

@property (nonatomic, strong, readonly) KZTextLink *kzLink;

@property (nonatomic, strong, readonly) KZTextBorder *kzBorder;

@property (nonatomic, strong, readonly) KZTextQuote *kzQuote;

//@property (nonatomic, strong, readonly) KZTextAttachment *kzAttachment;
/**
 calculate size
 @param containerSize     文字容器大小
 */
- (CGSize)boundingSizeWithContainerSize:(CGSize)containerSize;
/**
 Height
 @param containerWidth     文字容器宽度
 */
- (CGFloat)boundingHeightWithContainerWidth:(CGFloat)containerWidth
                           numberOfLines:(NSInteger)numberOfLines;
/**
 calculate size
 @param containerSize     文字容器大小
 @param optionsBlock       配置block  如果不设置 会以 字符串为准
  如果是计算带 自动检测的 文本 请 给 detectConfig 赋值
 */
- (CGSize)boundingSiseWithContainerSize:(CGSize)containerSize optionsBlock:(KZTextAttributesBlock)optionsBlock;

/**
 calculate Display Line count
 @param containerSize     文字容器大小
 @warning  当存在自定义 富文本时 次方法 算的行数 会不对
 */
- (NSInteger)getSystemDisplayLineWithContainerSize:(CGSize)containerSize;
/**
 calculate Display Line count
 @param containerSize     文字容器大小
 */
- (NSInteger)getComstomDisplayLineWithContainerSize:(CGSize)containerSize;
/**
 calculate Display Line count
 @param containerSize     文字容器大小
 @param optionsBlock       配置block  如果不设置 会以 字符串为准
 如果是计算带 自动检测的 文本 请 给 detectConfig 赋值
 */
- (NSInteger)getComstomDisplayLineWithContainerSize:(CGSize)containerSize optionsBlock:(KZTextAttributesBlock)optionsBlock;

@end


@interface NSMutableAttributedString (KZ)

#pragma mark -- General Properties
//font
@property (nonatomic, strong, readwrite) UIFont *kzFont;
- (void)kzSetFont:(UIFont *)font range:(NSRange)range;
//color
@property (nonatomic, strong, readwrite) UIColor *kzColor;
- (void)kzSetColor:(UIColor *)color range:(NSRange)range;
//backgroundColor
@property (nonatomic, strong, readwrite) UIColor *kzBackgroundColor;
- (void)kzSetBackgroundColor:(UIColor *)backgroundColor range:(NSRange)range;
//underlineStyle
@property (nonatomic, assign, readwrite) NSUnderlineStyle kzUnderlineStyle;
-(void)kzSetUnderlineStyle:(NSUnderlineStyle)underlineStyle range:(NSRange)range;
//underlineColor
@property (nonatomic, strong, readwrite) UIColor *kzUnderlineColor;
- (void)kzSetUnderlineColor:(UIColor *)underlineColor range:(NSRange)range;

//shadow
@property (nonatomic, strong, readwrite) NSShadow *kzShadow;
- (void)kzSetShadow:(NSShadow *)shadow range:(NSRange)range;

//link
@property (nonatomic, strong, readwrite) KZTextLink *kzLink;
- (void)kzSetLink:(KZTextLink *)link range:(NSRange)range;
//border
@property (nonatomic, strong, readwrite) KZTextBorder *kzBorder;
- (void)kzSetBorder:(KZTextBorder *)border range:(NSRange)range;
//quote
@property (nonatomic, strong, readwrite) KZTextQuote *kzQuote;
- (void)kzSetQuote:(KZTextQuote *)quote range:(NSRange)range;

////Attachment
//@property (nonatomic, strong, readwrite) KZTextAttachment *kzAttachment;
//- (void)kzSetAttachment:(KZTextAttachment *)attachment range:(NSRange)range;

#pragma mark -- Paragraph Style Properties
//lineSpacing
@property (nonatomic, assign, readwrite) CGFloat kzLineSpacing;
- (void)kzSetLineSpacing:(CGFloat)lineSpacing range:(NSRange)range;
//minimumLineHeight
@property (nonatomic, assign, readwrite) CGFloat kzMinimumLineHeight;
- (void)kzSetMinimumLineHeight:(CGFloat)minimumLineHeight range:(NSRange)range;
//maximumLineHeight
@property (nonatomic, assign, readwrite) CGFloat kzMaximumLineHeight;
- (void)kzSetMaximumLineHeight:(CGFloat)maximumLineHeight range:(NSRange)range;
//alignment
@property (nonatomic, assign, readwrite) NSTextAlignment kzAlignment;
- (void)kzSetAlignment:(NSTextAlignment)alignment range:(NSRange)range;
//NSLineBreakMode
@property (nonatomic, assign, readwrite) NSLineBreakMode kzLineBreakMode;
- (void)kzSetLineBreakMode:(NSLineBreakMode)lineBreakMode range:(NSRange)range;
//firstLineHeadIndent
@property (nonatomic, assign, readwrite) CGFloat kzFirstLineHeadIndent;
- (void)kzSetFirstLineHeadIndent:(CGFloat)firstLineHeadIndent range:(NSRange)range;
//headIndent
@property (nonatomic, assign, readwrite) CGFloat kzHeadIndent;
- (void)kzSetHeadIndent:(CGFloat)headIndent range:(NSRange)range;
//tailIndent
@property (nonatomic, assign, readwrite) CGFloat kzTailIndent;
- (void)kzSetTailIndent:(CGFloat)tailIndent range:(NSRange)range;
// paragraphStyle
@property (nonatomic, assign, readwrite) NSParagraphStyle *kzParagraphStyle;
- (void)kzSetParagraphStyle:(NSParagraphStyle *)paragraphStyle range:(NSRange)range;

//paragraphSpacing
@property (nonatomic, assign, readwrite) CGFloat kzParagraphSpacing;
- (void)kzSetParagraphSpacing:(CGFloat)paragraphSpacing range:(NSRange)range;
//paragraphSpacingBefore
@property (nonatomic, assign, readwrite) CGFloat kzParagraphSpacingBefore;
- (void)kzSetParagraphSpacingBefore:(CGFloat)paragraphSpacingBefore range:(NSRange)range;


#pragma mark -- Link
/**
 Config link
 @param linkColor         文字的颜色
 @param clickAction     click action call back
 */
- (void)configLinkColor:(UIColor *)linkColor
            clickAction:(KZAttributedActionBlock)clickAction;
/**
 Config link
 @param linkColor         文字的颜色
 @param range    设置的范围
 @param clickAction     click action call back
 */
- (void)configLinkColor:(UIColor *)linkColor
                  range:(NSRange)range
            clickAction:(KZAttributedActionBlock)clickAction;
/**
 Config link
 @param highlightColor     按下之后文字的颜色
 @param highlightBgColor    按下之后背景高亮的颜色
 @param clickAction         click action call back
 */
- (void)configHighLightColor:(UIColor *)highlightColor
            highlightBgColor:(UIColor *)highlightBgColor
                 clickAction:(KZAttributedActionBlock)clickAction;
/**
 Config link
 @param highlightColor     按下之后文字的颜色
 @param highlightBgColor    按下之后背景高亮的颜色
 @param range    设置的范围
 @param clickAction         click action call back
 */
- (void)configHighLightColor:(UIColor *)highlightColor
            highlightBgColor:(UIColor *)highlightBgColor
                       range:(NSRange)range
                 clickAction:(KZAttributedActionBlock)clickAction;



#pragma mark --Quote
/**
 Config quote
 @param quoteColor     quote color
 @param quoteWidth     quote width
 @param quoteLeft     quote left
 */
- (void)configKzQuoteWithQuoteColor:(UIColor *)quoteColor
                         quoteWidth:(CGFloat)quoteWidth
                          quoteLeft:(CGFloat)quoteLeft;
/**
 Config quote
 @param quoteColor     quote color
 @param quoteWidth     quote width
 @param quoteLeft     quote left
 @param range    设置的范围
 */
- (void)configKzQuoteWithQuoteColor:(UIColor *)quoteColor
                         quoteWidth:(CGFloat)quoteWidth
                          quoteLeft:(CGFloat)quoteLeft
                              range:(NSRange)range;
#pragma mark --Border
/**
 Config border
 @param borderStyle     border style
 @param borderColor     border color
 @param borderWidth     border width
 @param conerRadius     conerRadius
 @param fillColor       fillColor
 */
- (void)configKzBorderWithBorderStyle:(KZBorderStyle)borderStyle
                          borderColor:(UIColor *)borderColor
                          borderWidth:(CGFloat)borderWidth
                          conerRadius:(NSInteger)conerRadius
                            fillColor:(UIColor *)fillColor
                               insets:(UIEdgeInsets)insets;
/**
 Config border
 @param borderStyle     border style
 @param borderColor     border color
 @param borderWidth     border width
 @param conerRadius     conerRadius
 @param fillColor       fillColor
 @param range    设置的范围
 */
- (void)configKzBorderWithBorderStyle:(KZBorderStyle)borderStyle
                          borderColor:(UIColor *)borderColor
                          borderWidth:(CGFloat)borderWidth
                          conerRadius:(NSInteger)conerRadius
                            fillColor:(UIColor *)fillColor
                               insets:(UIEdgeInsets)insets
                                range:(NSRange)range;

/**
 Config border UnderLine
 @param underLineStyle     border underLine style
 @param underlineColor     border underline Color
 @param underlineWidth     underlineWidth
 @param dashPaintedLength     dashPaintedLength
 @param dashNotPaintedLength    dashNotPaintedLength
 */
- (void)configUnderLineStyle:(KZBorderUnderLineStyle)underLineStyle
              underlineColor:(UIColor *)underlineColor
              underlineWidth:(CGFloat)underlineWidth
           dashPaintedLength:(CGFloat)dashPaintedLength
        dashNotPaintedLength:(CGFloat)dashNotPaintedLength;
/**
 Config border UnderLine
 @param underLineStyle     border underLine style
 @param underlineColor     border underline Color
 @param underlineWidth     underlineWidth
 @param dashPaintedLength     dashPaintedLength
 @param dashNotPaintedLength    dashNotPaintedLength
 @param range    设置的范围
 */
- (void)configUnderLineStyle:(KZBorderUnderLineStyle)underLineStyle
              underlineColor:(UIColor *)underlineColor
              underlineWidth:(CGFloat)underlineWidth
           dashPaintedLength:(CGFloat)dashPaintedLength
        dashNotPaintedLength:(CGFloat)dashNotPaintedLength
                       range:(NSRange)range;
                    
/**
 Config Normal bottom  border UnderLine
 @param underlineColor     border underline Color
 @param underlineWidth     underlineWidth
 */
- (void)configNormalUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth;
/**
 Config  border   Normal bottom UnderLine
 @param underlineColor     border underline Color
 @param underlineWidth     underlineWidth
 @param range    设置的范围
 */
- (void)configNormalUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth
                             range:(NSRange)range;
/**
 Config  border  center UnderLine
 @param underlineColor     border underline Color
 @param underlineWidth     underlineWidth
 */
- (void)configCenterUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth;
/**
 Config  border  center UnderLine
 @param underlineColor     border underline Color
 @param underlineWidth     underlineWidth
 @param range    设置的范围
 */
- (void)configCenterUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth
                             range:(NSRange)range;

#pragma mark --Attachment

/**
 Config attachment
 @param content                         Support view / layer / image.
 @param attachmentSize          The content size.
 return attachment's attributed string
 */
+ (NSMutableAttributedString *)configKzAttachmentStringContent:(id)content
                                                attachmentSize:(CGSize)attachmentSize
                                                   alignToFont:(UIFont *)alignToFont;
/**
 Config attachment
 
 @param content                 Support view / layer / image.
 @param attachmentSize          The content size.
 @param alignToFont                 The content will align to the font.
 @param aligment                       Alignment.
 @param clickAction             Click action call back.
 return attachment's attributed string
 */
+ (NSMutableAttributedString *)configKzAttachmentStringContent:(id)content
                                                attachmentSize:(CGSize)attachmentSize
                                                   alignToFont:(UIFont *)alignToFont
                                                      aligment:(KZTextVerticalAlignment)aligment
                                                   clickAction:(KZAttributedAlignmentActionBlock)clickAction;


                                              
/**
 Config Emoji
 
 @param image                  content
 @param imageSize          The content size.
 @param alignToFont      alignToFont
 @param emojiString      emojiString
 @param aligment             aligment
 return attachment's attributed string
 */
+ (NSMutableAttributedString *)configKzEmojiStringImage:(UIImage *)image
                                              imageSize:(CGSize)imageSize
                                            alignToFont:(UIFont *)alignToFont
                                            emojiString:(NSString *)emojiString
                                               aligment:(KZTextVerticalAlignment)aligment;
/**
 Config Emoji
 
 @param image                  content
 @param imageSize          The content size.
 @param alignToFont      alignToFont
 @param emojiString      emojiString
 @param aligment             aligment
 @param clickAction      clickAction
 return attachment's attributed string
 */
+ (NSMutableAttributedString *)configKzEmojiStringImage:(UIImage *)image
                                              imageSize:(CGSize)imageSize
                                            alignToFont:(UIFont *)alignToFont
                                            emojiString:(NSString *)emojiString
                                               aligment:(KZTextVerticalAlignment)aligment
                                            clickAction:(KZAttributedAlignmentActionBlock)clickAction;

/**
 split String
 
 @param barrierLine  按照几行进行切割
 @param containerSize          The content size.
 @param font      字体
 @param lineSpacing  行间距
 @param numberOfLines    展示行数
 @param splitString      待切割字符串
 
 return 切割后的数组
 */
+ (NSArray <NSString *>*)splitStringBarrierLine:(int)barrierLine
                                  containerSize:(CGSize)containerSize
                                           font:(UIFont *)font
                                    lineSpacing:(CGFloat)lineSpacing
                                  numberOfLines:(NSUInteger)numberOfLines
                                    splitString:(NSString *)splitString;
/**
 split String
 
 @param barrierLine  按照几行进行切割
 @param containerSize          The content size.
 @param numberOfLines    展示行数
 @param attributedText      待切割的属性字符串
 
 return 切割后的数组
 */
+ (NSArray <NSAttributedString *>*)splitStringBarrierLine:(int)barrierLine
                                            containerSize:(CGSize)containerSize
                                            numberOfLines:(NSUInteger)numberOfLines
                                           attributedText:(NSAttributedString *)attributedText;

@end
