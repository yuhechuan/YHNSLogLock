//
//  KZTextDebugOption.h
//  KZLabel
//
//  Created by yuhechuan on 2023/11/14.
//

#import <UIKit/UIKit.h>

@interface KZTextDebugOption : NSObject

@property (nonatomic, strong) UIColor *baselineColor;      ///< baseline color
@property (nonatomic, strong) UIColor *lineFragmentBorderColor;  ///< LineFragment bounds border color
@property (nonatomic, strong) UIColor *lineFragmentFillColor;    ///< LineFragment bounds fill color
@property (nonatomic, strong) UIColor *lineFragmentUsedBorderColor;  ///< LineFragment used bounds border color
@property (nonatomic, strong) UIColor *lineFragmentUsedFillColor;    ///< LineFragment used bounds fill color
@property (nonatomic, strong) UIColor *glyphBorderColor; ///< Glyph bounds border color
@property (nonatomic, strong) UIColor *glyphFillColor;   ///< Glyph bounds fill color

@end
