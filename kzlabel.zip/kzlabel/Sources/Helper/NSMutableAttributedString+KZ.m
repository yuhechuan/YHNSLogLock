//
//  NSMutableAttributedString+KZ.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/2.
//

#import "NSMutableAttributedString+KZ.h"
#import <CoreText/CoreText.h>
#import "KZAutoDetector.h"
#import "KZLayoutManager.h"
#import "KZTextKitComponents.h"
#import "KZContextRef.h"

@implementation NSAttributedString (KZ)

//font
- (UIFont *)kzFont {
   return [self kz_fontAtIndex:0];
}
- (UIFont *)kz_fontAtIndex:(NSUInteger)index {
   return [self kz_attribute:NSFontAttributeName atIndex:index];
}

//color
- (UIColor *)kzColor {
    return [self kz_colorAtIndex:0];
}
- (UIColor *)kz_colorAtIndex:(NSUInteger)index {
    UIColor *color = [self kz_attribute:NSForegroundColorAttributeName atIndex:index];
    return color;
}

//backgroundColor
- (UIColor *)kzBackgroundColor {
    return [self kz_backgroundColorAtIndex:0];
}
- (UIColor *)kz_backgroundColorAtIndex:(NSUInteger)index {
    return [self kz_attribute:NSBackgroundColorAttributeName atIndex:0];
}

//underlineStyle
-(NSUnderlineStyle)kzUnderlineStyle {
    return [self kz_underlineStyleAtIndex:0];
}
- (NSUnderlineStyle)kz_underlineStyleAtIndex:(NSUInteger)index {
    NSNumber *style = [self kz_attribute:NSUnderlineStyleAttributeName atIndex:index];
    return style.integerValue;
}

//underlineColor
-(UIColor *)kzUnderlineColor {
    return [self kz_underlineColorAtIndex:0];
}
- (UIColor *)kz_underlineColorAtIndex:(NSUInteger)index {
    UIColor *color = [self kz_attribute:NSUnderlineColorAttributeName atIndex:index];
    return color;
}

//link
-(KZTextLink *)kzLink {
   return [self kz_attribute:KZTextLinkAttributedStringKey atIndex:0];
}

//border
-(KZTextBorder *)kzBorder {
    return [self kz_attribute:KZTextBorderAttributedStringKey atIndex:0];
}

//quote
-(KZTextQuote *)kzQuote {
    return [self kz_attribute:KZTextQuoteAttributedStringKey atIndex:0];
}

//attachment
- (KZTextAttachment *)kzAttachment {
    KZTextAttachment *at = [self kz_attribute:NSAttachmentAttributeName atIndex:0];
    if([at isMemberOfClass:[KZTextAttachment class]]) {
        return at;
    }
    return nil;
}

//shadow
- (NSShadow *)kzShadow {
    return [self kz_attribute:NSShadowAttributeName atIndex:0];
}

#pragma mark -- Getter ParagraphStyle Property

//paragraphStyle
- (NSParagraphStyle *)kzParagraphStyle {
    return [self kz_paragraphStyleAtIndex:0];
}
- (NSParagraphStyle *)kz_paragraphStyleAtIndex:(NSUInteger)index {
    NSParagraphStyle *style = [self kz_attribute:NSParagraphStyleAttributeName atIndex:index];
    return style;
}

#define ParagraphStyleGetting(attribute) \
NSParagraphStyle *style = self.kzParagraphStyle; \
if (!style) style = [NSParagraphStyle defaultParagraphStyle]; \
return style.attribute;

-(CGFloat)kzLineSpacing {
    ParagraphStyleGetting(lineSpacing);
}
- (NSLineBreakMode)kzLineBreakMode {
    ParagraphStyleGetting(lineBreakMode);
}
- (NSTextAlignment)kzAlignment{
    ParagraphStyleGetting(alignment);
}
- (CGFloat)kzMinimumLineHeight {
    ParagraphStyleGetting(minimumLineHeight);
}
- (CGFloat)kzMaximumLineHeight {
    ParagraphStyleGetting(maximumLineHeight);
}

- (CGFloat)kzFirstLineHeadIndent {
    ParagraphStyleGetting(firstLineHeadIndent);
}

- (CGFloat)kzHeadIndent {
    ParagraphStyleGetting(headIndent);
}
- (CGFloat)kzTailIndent{
    ParagraphStyleGetting(tailIndent);
}
- (CGFloat)kzParagraphSpacing {
    ParagraphStyleGetting(paragraphSpacing);
}
- (CGFloat)kzParagraphSpacingBefore {
    ParagraphStyleGetting(paragraphSpacingBefore);
}
#pragma mark -- Basic

- (id)kz_attribute:(NSString *)attributeName atIndex:(NSUInteger)index {
    if (!attributeName || index > self.length || self.length == 0){
        return nil;
    }
    if (self.length > 0 && index == self.length){
        index--;
    }
    return [self attribute:attributeName atIndex:index effectiveRange:NULL];
}

- (CGSize)boundingSizeWithContainerSize:(CGSize)containerSize {
    return [self boundingSiseWithContainerSize:containerSize optionsBlock:^(KZTextAttributes *attributes) {
        attributes.numberOfLines = 0;
    }];
}

- (CGFloat)boundingHeightWithContainerWidth:(CGFloat)containerWidth
                              numberOfLines:(NSInteger)numberOfLines {
    return [self boundingSiseWithContainerSize:CGSizeMake(containerWidth, CGFLOAT_MAX) optionsBlock:^(KZTextAttributes *attributes) {
        attributes.numberOfLines = numberOfLines;
    }].height;
}

- (CGSize)boundingSiseWithContainerSize:(CGSize)containerSize optionsBlock:(KZTextAttributesBlock)optionsBlock {
    if (self.length < 1) {
        return CGSizeZero;
    }
    if (containerSize.width > KZTextContainerMaxSize.width) {
        containerSize.width = KZTextContainerMaxSize.width;
    }
    if (containerSize.height > KZTextContainerMaxSize.height) {
        containerSize.height = KZTextContainerMaxSize.height;
    }
    KZTextAttributes *attributes = [[KZTextAttributes alloc]init];
    if(optionsBlock) {
        optionsBlock(attributes);
    }
    NSAttributedString *attributedText = attributes.attributedText ? attributes.attributedText : self;
    if(attributes.detectConfig) {
        attributedText = [KZAutoDetector autoDetectWithAttributedString:attributedText detectConfig:attributes.detectConfig];
    }
    attributes.attributedText = attributedText;
    attributes.truncationAttributedText = KZTextTruncationAttributedTextWithToken(attributes.attributedText, attributes.truncationAttributedText);
    
    CGRect frame = UIEdgeInsetsInsetRect((CGRect){.size = containerSize}, attributes.textContainerInset);    
    KZTextKitComponents *kitComponents = [[KZTextKitComponents alloc]init];
    CGSize calculatedSize = [kitComponents calculateSizeForConstraintSize:frame.size attributes:attributes];
    return calculatedSize;
}


- (NSInteger)getSystemDisplayLineWithContainerSize:(CGSize)containerSize {
    if (self.length < 1) {
        return 0;
    }
    if (containerSize.width > KZTextContainerMaxSize.width) {
        containerSize.width = KZTextContainerMaxSize.width;
    }
    if (containerSize.height > KZTextContainerMaxSize.height) {
        containerSize.height = KZTextContainerMaxSize.height;
    }

    //create ctframe
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)self);
    CGMutablePathRef allPath = CGPathCreateMutable();
    CGPathAddRect(allPath, NULL, CGRectMake(0 , 0, containerSize.width, containerSize.height));
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), allPath, NULL);
    CFRelease(allPath);
    CFRelease(setterRef);
    if (!frameRef) return 0;

    //get ctlines
    CFArrayRef lineCFArray = CTFrameGetLines(frameRef);
    NSInteger lineCount = CFArrayGetCount(lineCFArray);
    CFRelease(frameRef);
    return lineCount;
}



- (NSInteger)getComstomDisplayLineWithContainerSize:(CGSize)containerSize {
    return [self getComstomDisplayLineWithContainerSize:containerSize optionsBlock:^(KZTextAttributes *attributes) {
        attributes.numberOfLines = 0;
    }];
}

- (NSInteger)getComstomDisplayLineWithContainerSize:(CGSize)containerSize optionsBlock:(KZTextAttributesBlock)optionsBlock {
    if (self.length < 1) {
        return 0;
    }
    if (containerSize.width > KZTextContainerMaxSize.width) {
        containerSize.width = KZTextContainerMaxSize.width;
    }
    if (containerSize.height > KZTextContainerMaxSize.height) {
        containerSize.height = KZTextContainerMaxSize.height;
    }
    KZTextAttributes *attributes = [[KZTextAttributes alloc]init];
    if(optionsBlock) {
        optionsBlock(attributes);
    }
    NSAttributedString *attributedText = attributes.attributedText ? attributes.attributedText : self;
    if(attributes.detectConfig) {
        attributedText = [KZAutoDetector autoDetectWithAttributedString:attributedText detectConfig:attributes.detectConfig];
    }
    attributes.attributedText = attributedText;
    attributes.truncationAttributedText = KZTextTruncationAttributedTextWithToken(attributes.attributedText, attributes.truncationAttributedText);
    
    CGRect frame = UIEdgeInsetsInsetRect((CGRect){.size = containerSize}, attributes.textContainerInset);
    
    KZContextRef *contextRef = [[KZContextRef alloc]initWithAttributes:attributes containerSize:frame.size];
    return [contextRef.layoutManager displayLineForGlyphRange:NSMakeRange(0, self.length)];
}

@end


@implementation NSMutableAttributedString (KZ)


#pragma mark -- Mutable Setter General
//font
- (void)setKzFont:(UIFont *)kzFont {
    [self kzSetFont:kzFont range:NSMakeRange(0, self.length)];
}

- (void)kzSetFont:(UIFont *)font range:(NSRange)range {
    //In iOS7 and later, UIFont is toll-free bridged to CTFontRef.
    [self kz_configAttribute:NSFontAttributeName value:font range:range];
}

//color
- (void)setKzColor:(UIColor *)kzColor {
    [self kzSetColor:kzColor range:NSMakeRange(0, self.length)];
}
- (void)kzSetColor:(UIColor *)color range:(NSRange)range {
    [self kz_configAttribute:NSForegroundColorAttributeName value:color range:range];
}

//backgroundColor
- (void)setKzBackgroundColor:(UIColor *)kzBackgroundColor {
    [self kzSetBackgroundColor:kzBackgroundColor range:NSMakeRange(0, self.length)];
}
- (void)kzSetBackgroundColor:(UIColor *)backgroundColor range:(NSRange)range {
    [self kz_configAttribute:NSBackgroundColorAttributeName value:backgroundColor range:range];
}

//underlineStyle
- (void)setKzUnderlineStyle:(NSUnderlineStyle)kzUnderlineStyle {
    [self kzSetUnderlineStyle:kzUnderlineStyle range:NSMakeRange(0, self.length)];
}

- (void)kzSetUnderlineStyle:(NSUnderlineStyle)underlineStyle range:(NSRange)range {
    if (underlineStyle == 0x00) {
        return;
    }
    [self kz_configAttribute:NSUnderlineStyleAttributeName value:@(underlineStyle) range:range];
}

//underlineColor
- (void)setKzUnderlineColor:(UIColor *)kzUnderlineColor {
    [self kzSetUnderlineColor:kzUnderlineColor range:NSMakeRange(0, self.length)];
}

- (void)kzSetUnderlineColor:(UIColor *)underlineColor range:(NSRange)range {
    [self kz_configAttribute:NSUnderlineColorAttributeName value:underlineColor range:range];
}

//link
- (void)setKzLink:(KZTextLink *)kzLink {
    [self kzSetLink:kzLink range:NSMakeRange(0, self.length)];
}
- (void)kzSetLink:(KZTextLink *)link range:(NSRange)range {
    [self kz_configAttribute:KZTextLinkAttributedStringKey value:link range:range];
}

//border
- (void)setKzBorder:(KZTextBorder *)kzBorder {
    [self kzSetBorder:kzBorder range:NSMakeRange(0, self.length)];
}
- (void)kzSetBorder:(KZTextBorder *)border range:(NSRange)range {
    [self kz_configAttribute:KZTextBorderAttributedStringKey value:border range:range];
}

//quote
- (void)setKzQuote:(KZTextQuote *)kzQuote {
    [self kzSetQuote:kzQuote range:NSMakeRange(0, self.length)];
}
- (void)kzSetQuote:(KZTextQuote *)quote range:(NSRange)range {
    [self kz_configAttribute:KZTextQuoteAttributedStringKey value:quote range:range];
}

//attachment
-(void)setKzAttachment:(KZTextAttachment *)kzAttachment {
    [self kzSetAttachment:kzAttachment range:NSMakeRange(0, self.length)];
}
- (void)kzSetAttachment:(KZTextAttachment *)attachment range:(NSRange)range {
    [self kz_configAttribute:NSAttachmentAttributeName value:attachment range:range];
}

//shadow
- (void)setKzShadow:(NSShadow *)kzShadow {
    [self kzSetShadow:kzShadow range:NSMakeRange(0, self.length)];
}
- (void)kzSetShadow:(NSShadow *)shadow range:(NSRange)range  {
    [self kz_configAttribute:NSShadowAttributeName value:shadow range:range];
}

#pragma mark -- Mutable Setter ParagraphStyle Property

//paragraphStyle
- (void)setKzParagraphStyle:(NSParagraphStyle *)kzParagraphStyle {
    [self kzSetParagraphStyle:kzParagraphStyle range:NSMakeRange(0, self.length)];
}
- (void)kzSetParagraphStyle:(NSParagraphStyle *)paragraphStyle range:(NSRange)range {
   //NSParagraphStyle are supported on CoreText and UIKit.
    [self kz_configAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:range];
}

#define ParagraphStyleSetting(_property_name) \
[self enumerateAttribute:NSParagraphStyleAttributeName \
inRange:range \
options:kNilOptions \
usingBlock: ^(NSParagraphStyle *value, NSRange subRange, BOOL *stop) { \
    NSMutableParagraphStyle *style = nil; \
    if (value) { \
        if (CFGetTypeID((__bridge CFTypeRef)(value)) == CTParagraphStyleGetTypeID()) { \
            value = [self kz_styleWithCTStyle:(__bridge CTParagraphStyleRef)(value)]; \
        } \
        if (value._property_name == _property_name) return; \
        if ([value isKindOfClass:[NSMutableParagraphStyle class]]) { \
            style = (id)value; \
        } else { \
            style = value.mutableCopy; \
        } \
    } else { \
        if ([NSParagraphStyle defaultParagraphStyle]._property_name == _property_name) return; \
        style = [NSParagraphStyle defaultParagraphStyle].mutableCopy; \
    } \
    style._property_name = _property_name; \
    [self kzSetParagraphStyle:style range:subRange]; \
}];

//lineSpacing
- (void)setKzLineSpacing:(CGFloat)kzLineSpacing {
    [self kzSetLineSpacing:kzLineSpacing range:NSMakeRange(0, self.length)];
}

- (void)kzSetLineSpacing:(CGFloat)lineSpacing range:(NSRange)range {
    ParagraphStyleSetting(lineSpacing);
}
//lineBreakMode
- (void)setKzLineBreakMode:(NSLineBreakMode)kzLineBreakMode {
    [self kzSetLineBreakMode:kzLineBreakMode range:NSMakeRange(0, self.length)];
}

- (void)kzSetLineBreakMode:(NSLineBreakMode)lineBreakMode range:(NSRange)range {
    ParagraphStyleSetting(lineBreakMode);
}

//minimumLineHeight
- (void)setKzMinimumLineHeight:(CGFloat)kzMinimumLineHeight {
    [self kzSetMinimumLineHeight:kzMinimumLineHeight range:NSMakeRange(0, self.length)];
}
- (void)kzSetMinimumLineHeight:(CGFloat)minimumLineHeight range:(NSRange)range {
    ParagraphStyleSetting(minimumLineHeight);
}

//maximumLineHeight
- (void)setKzMaximumLineHeight:(CGFloat)kzMaximumLineHeight {
    [self kzSetMaximumLineHeight:kzMaximumLineHeight range:NSMakeRange(0, self.length)];
}
- (void)kzSetMaximumLineHeight:(CGFloat)maximumLineHeight range:(NSRange)range {
    ParagraphStyleSetting(maximumLineHeight);
}
//alignment
- (void)setKzAlignment:(NSTextAlignment)kzAlignment {
    [self kzSetAlignment:kzAlignment range:NSMakeRange(0, self.length)];
}
- (void)kzSetAlignment:(NSTextAlignment)alignment range:(NSRange)range {
    ParagraphStyleSetting(alignment);
}
//firstLineHeadIndent
- (void)setKzFirstLineHeadIndent:(CGFloat)kzFirstLineHeadIndent {
    [self kzSetFirstLineHeadIndent:kzFirstLineHeadIndent range:NSMakeRange(0, self.length)];
}
- (void)kzSetFirstLineHeadIndent:(CGFloat)firstLineHeadIndent range:(NSRange)range {
    ParagraphStyleSetting(firstLineHeadIndent);
}
//headIndent
- (void)setKzHeadIndent:(CGFloat)kzHeadIndent {
    [self kzSetHeadIndent:kzHeadIndent range:NSMakeRange(0, self.length)];
}
- (void)kzSetHeadIndent:(CGFloat)headIndent range:(NSRange)range {
    ParagraphStyleSetting(headIndent);
}

//tailIndent
- (void)setKzTailIndent:(CGFloat)kzTailIndent {
    [self kzSetTailIndent:kzTailIndent range:NSMakeRange(0, self.length)];
}
- (void)kzSetTailIndent:(CGFloat)tailIndent range:(NSRange)range {
    ParagraphStyleSetting(tailIndent);
}
//paragraphSpacing
- (void)setKzParagraphSpacing:(CGFloat)kzParagraphSpacing {
    [self kzSetParagraphSpacing:kzParagraphSpacing range:NSMakeRange(0, self.length)];
}
- (void)kzSetParagraphSpacing:(CGFloat)paragraphSpacing range:(NSRange)range {
    ParagraphStyleSetting(paragraphSpacing);
}
//paragraphSpacingBefore
- (void)setKzParagraphSpacingBefore:(CGFloat)kzParagraphSpacingBefore {
    [self kzSetParagraphSpacingBefore:kzParagraphSpacingBefore range:NSMakeRange(0, self.length)];
}
- (void)kzSetParagraphSpacingBefore:(CGFloat)paragraphSpacingBefore range:(NSRange)range {
    ParagraphStyleSetting(paragraphSpacingBefore);
}

- (NSParagraphStyle *)kz_styleWithCTStyle:(CTParagraphStyleRef)CTStyle {
    if (CTStyle == NULL) return [NSParagraphStyle defaultParagraphStyle];
    
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    CGFloat lineSpacing;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierLineSpacing, sizeof(CGFloat), &lineSpacing)) {
        style.lineSpacing = lineSpacing;
    }
#pragma clang diagnostic pop
    
    CGFloat paragraphSpacing;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierParagraphSpacing, sizeof(CGFloat), &paragraphSpacing)) {
        style.paragraphSpacing = paragraphSpacing;
    }
    
    CTTextAlignment alignment;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierAlignment, sizeof(CTTextAlignment), &alignment)) {
        style.alignment = NSTextAlignmentFromCTTextAlignment(alignment);
    }
    
    CGFloat firstLineHeadIndent;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierFirstLineHeadIndent, sizeof(CGFloat), &firstLineHeadIndent)) {
        style.firstLineHeadIndent = firstLineHeadIndent;
    }
    
    CGFloat headIndent;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierHeadIndent, sizeof(CGFloat), &headIndent)) {
        style.headIndent = headIndent;
    }
    
    CGFloat tailIndent;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierTailIndent, sizeof(CGFloat), &tailIndent)) {
        style.tailIndent = tailIndent;
    }
    
    CTLineBreakMode lineBreakMode;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierLineBreakMode, sizeof(CTLineBreakMode), &lineBreakMode)) {
        style.lineBreakMode = (NSLineBreakMode)lineBreakMode;
    }
    
    CGFloat minimumLineHeight;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierMinimumLineHeight, sizeof(CGFloat), &minimumLineHeight)) {
        style.minimumLineHeight = minimumLineHeight;
    }
    
    CGFloat maximumLineHeight;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierMaximumLineHeight, sizeof(CGFloat), &maximumLineHeight)) {
        style.maximumLineHeight = maximumLineHeight;
    }
    
    CTWritingDirection baseWritingDirection;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierBaseWritingDirection, sizeof(CTWritingDirection), &baseWritingDirection)) {
        style.baseWritingDirection = (NSWritingDirection)baseWritingDirection;
    }
    
    CGFloat lineHeightMultiple;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierLineHeightMultiple, sizeof(CGFloat), &lineHeightMultiple)) {
        style.lineHeightMultiple = lineHeightMultiple;
    }
    
    CGFloat paragraphSpacingBefore;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierParagraphSpacingBefore, sizeof(CGFloat), &paragraphSpacingBefore)) {
        style.paragraphSpacingBefore = paragraphSpacingBefore;
    }
    
    return style;
}

- (void)kz_configAttribute:(NSString *)name value:(id)value range:(NSRange)range {
    if (!name || [NSNull isEqual:name] || !value || [NSNull isEqual:value]) {
        return;
    }
    if (range.location + range.length > self.length) {
        return;
    }
    [self addAttribute:name value:value range:range];
}

#pragma mark -- custom Method

- (void)configLinkColor:(UIColor *)linkColor
            clickAction:(KZAttributedActionBlock)clickAction {
    [self configLinkColor:linkColor
                    range:NSMakeRange(0, self.length)
              clickAction:clickAction];
}

- (void)configLinkColor:(UIColor *)linkColor
                  range:(NSRange)range
            clickAction:(KZAttributedActionBlock)clickAction {
    KZTextLink *link = [[KZTextLink alloc] init];
    link.linkTextColor = linkColor;
    link.clickAction = clickAction;
    [self kzSetLink:link range:range];
}

- (void)configHighLightColor:(UIColor *)highlightColor
            highlightBgColor:(UIColor *)highlightBgColor
                 clickAction:(KZAttributedActionBlock)clickAction {
    [self configHighLightColor:highlightColor
              highlightBgColor:highlightBgColor
                         range:NSMakeRange(0, self.length)
                   clickAction:clickAction];
}

- (void)configHighLightColor:(UIColor *)highlightColor
            highlightBgColor:(UIColor *)highlightBgColor
                       range:(NSRange)range
                 clickAction:(KZAttributedActionBlock)clickAction {
    KZTextLink *link = [[KZTextLink alloc] init];
    link.highlightColor = highlightColor;
    link.clickAction = clickAction;
    link.highlightBackViewColor = highlightBgColor;
    [self kzSetLink:link range:range];
}

- (void)configKzQuoteWithQuoteColor:(UIColor *)quoteColor
                       quoteWidth:(CGFloat)quoteWidth
                        quoteLeft:(CGFloat)quoteLeft {
    [self configKzQuoteWithQuoteColor:quoteColor
                         quoteWidth:quoteWidth
                          quoteLeft:quoteLeft
                              range:NSMakeRange(0, self.length)];
    
}

- (void)configKzQuoteWithQuoteColor:(UIColor *)quoteColor
                       quoteWidth:(CGFloat)quoteWidth
                        quoteLeft:(CGFloat)quoteLeft
                            range:(NSRange)range {
    KZTextQuote *quote = [[KZTextQuote alloc]init];
    quote.quoteColor = quoteColor;
    quote.quoteWidth = quoteWidth;
    quote.quoteLeft = quoteLeft;
    [self kzSetQuote:quote range:range];
}

- (void)configKzBorderWithBorderStyle:(KZBorderStyle)borderStyle
                        borderColor:(UIColor *)borderColor
                        borderWidth:(CGFloat)borderWidth
                        conerRadius:(NSInteger)conerRadius
                          fillColor:(UIColor *)fillColor
                             insets:(UIEdgeInsets)insets {
    [self configKzBorderWithBorderStyle:borderStyle
                          borderColor:borderColor
                          borderWidth:borderWidth
                          conerRadius:conerRadius
                            fillColor:fillColor
                               insets:insets
                                range:NSMakeRange(0, self.length)];
    
}

- (void)configKzBorderWithBorderStyle:(KZBorderStyle)borderStyle
                        borderColor:(UIColor *)borderColor
                        borderWidth:(CGFloat)borderWidth
                        conerRadius:(NSInteger)conerRadius
                          fillColor:(UIColor *)fillColor
                             insets:(UIEdgeInsets)insets
                              range:(NSRange)range {
    KZTextBorder *border = [[KZTextBorder alloc]init];
    border.borderStyle = borderStyle;
    border.borderColor = borderColor;
    border.borderWidth = borderWidth;
    border.cornerRadius = conerRadius;
    border.fillColor = fillColor;
    border.insets = insets;
    [self kzSetBorder:border range:range];
}

- (void)configUnderLineStyle:(KZBorderUnderLineStyle)underLineStyle
              underlineColor:(UIColor *)underlineColor
              underlineWidth:(CGFloat)underlineWidth
           dashPaintedLength:(CGFloat)dashPaintedLength
        dashNotPaintedLength:(CGFloat)dashNotPaintedLength {
    [self configUnderLineStyle:underLineStyle
                underlineColor:underlineColor
                underlineWidth:underlineWidth
             dashPaintedLength:dashPaintedLength
          dashNotPaintedLength:dashNotPaintedLength
                         range:NSMakeRange(0, self.length)];
}

- (void)configUnderLineStyle:(KZBorderUnderLineStyle)underLineStyle
              underlineColor:(UIColor *)underlineColor
              underlineWidth:(CGFloat)underlineWidth
           dashPaintedLength:(CGFloat)dashPaintedLength
        dashNotPaintedLength:(CGFloat)dashNotPaintedLength
                       range:(NSRange)range {
    KZTextBorder *border = [[KZTextBorder alloc]init];
    border.borderStyle = KZBorderNormal;
    border.underlineStyle = underLineStyle;
    border.underlineColor = underlineColor;
    border.underlineWidth = underlineWidth;
    border.dashPaintedLength = dashPaintedLength;
    border.dashNotPaintedLength = dashNotPaintedLength;
    [self kzSetBorder:border range:range];
}

- (void)configNormalUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth {
    [self configNormalUnderlineColor:underlineColor
                      underlineWidth:underlineWidth
                               range:NSMakeRange(0, self.length)];
}

- (void)configNormalUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth
                             range:(NSRange)range {
    KZTextBorder *border = [[KZTextBorder alloc]init];
    border.borderStyle = KZBorderNormal;
    border.underlineStyle = KZBorderUnderLineNormal;
    border.underlineColor = underlineColor;
    border.underlineWidth = underlineWidth;
    [self kzSetBorder:border range:range];
}

- (void)configCenterUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth {
    [self configCenterUnderlineColor:underlineColor
                      underlineWidth:underlineWidth
                               range:NSMakeRange(0, self.length)];
}

- (void)configCenterUnderlineColor:(UIColor *)underlineColor
                    underlineWidth:(CGFloat)underlineWidth
                             range:(NSRange)range {
    KZTextBorder *border = [[KZTextBorder alloc]init];
    border.borderStyle = KZBorderNormal;
    border.underlineStyle = KZBorderUnderLineCenterNormal;
    border.underlineColor = underlineColor;
    border.underlineWidth = underlineWidth;
    [self kzSetBorder:border range:range];
}


+ (NSMutableAttributedString *)configKzAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                                 alignToFont:(UIFont *)alignToFont {
    return [self configKzEmojiStringImage:content
                              imageSize:attachmentSize
                            alignToFont:alignToFont
                            emojiString:nil
                               aligment:KZTextVerticalAlignmentCenter
                            clickAction:nil];
}

+ (NSMutableAttributedString *)configKzAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                                 alignToFont:(UIFont *)alignToFont
                                                    aligment:(KZTextVerticalAlignment)aligment
                                                 clickAction:(KZAttributedAlignmentActionBlock)clickAction {
    return [self configKzEmojiStringImage:content
                              imageSize:attachmentSize
                            alignToFont:alignToFont
                            emojiString:nil
                               aligment:aligment
                            clickAction:clickAction];
}


+ (NSMutableAttributedString *)configKzEmojiStringImage:(UIImage *)image
                                            imageSize:(CGSize)imageSize
                                          alignToFont:(UIFont *)alignToFont
                                          emojiString:(NSString *)emojiString
                                             aligment:(KZTextVerticalAlignment)aligment {
    return [self configKzEmojiStringImage:image
                              imageSize:imageSize
                            alignToFont:alignToFont
                            emojiString:emojiString
                               aligment:aligment
                            clickAction:nil];
}

+ (NSMutableAttributedString *)configKzEmojiStringImage:(UIImage *)image
                                            imageSize:(CGSize)imageSize
                                          alignToFont:(UIFont *)alignToFont
                                          emojiString:(NSString *)emojiString
                                             aligment:(KZTextVerticalAlignment)aligment
                                          clickAction:(KZAttributedAlignmentActionBlock)clickAction {
    NSMutableAttributedString *attachmentAttrStr = [[NSMutableAttributedString alloc] initWithString:KZAttachmentPlaceholder];
    KZTextAttachment *attachment = [[KZTextAttachment alloc]init];
    attachment.contentSize = imageSize;
    attachment.content = image;
    attachment.representString = emojiString;
    attachment.aligment = aligment;
    attachment.clickAction = clickAction;
    attachment.alignToFont = alignToFont;
    attachmentAttrStr.kzAttachment = attachment;
    return attachmentAttrStr;
}


+ (NSArray <NSString *>*)splitStringBarrierLine:(int)barrierLine
                                            containerSize:(CGSize)containerSize
                                                     font:(UIFont *)font
                                              lineSpacing:(CGFloat)lineSpacing
                                            numberOfLines:(NSUInteger)numberOfLines
                                              splitString:(NSString *)splitString {
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc]initWithString:splitString];
    [attributedText addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, attributedText.length)];
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineSpacing = lineSpacing;
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraph range:NSMakeRange(0, attributedText.length)];
    return [self _splitStringBarrierLine:barrierLine
                          containerSize:containerSize
                          numberOfLines:numberOfLines
                         attributedText:attributedText
                                    type:0];
}

+ (NSArray <NSAttributedString *>*)splitStringBarrierLine:(int)barrierLine
                                            containerSize:(CGSize)containerSize
                                            numberOfLines:(NSUInteger)numberOfLines
                                           attributedText:(NSAttributedString *)attributedText {
    return [self _splitStringBarrierLine:barrierLine
                          containerSize:containerSize
                          numberOfLines:numberOfLines
                         attributedText:attributedText
                                    type:1];
}

+ (NSArray *)_splitStringBarrierLine:(int)barrierLine
                       containerSize:(CGSize)containerSize
                       numberOfLines:(NSUInteger)numberOfLines
                      attributedText:(NSAttributedString *)attributedText
                                type:(int)type {
    NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
    NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:containerSize];
    textContainer.maximumNumberOfLines = numberOfLines;
    [layoutManager addTextContainer:textContainer];

    NSTextStorage *textStorage = attributedText ? [[NSTextStorage alloc] initWithAttributedString:attributedText] : [[NSTextStorage alloc] init];
    [textStorage addLayoutManager:layoutManager];
    [layoutManager ensureLayoutForTextContainer:textContainer];
    NSMutableArray *rangeList = [NSMutableArray array];
    __block NSRange range = NSMakeRange(0, 0);
    __block int i = 0;
    [layoutManager enumerateLineFragmentsForGlyphRange:NSMakeRange(0, attributedText.length) usingBlock:^(CGRect rect, CGRect usedRect, NSTextContainer * _Nonnull textContainer, NSRange glyphRange, BOOL * _Nonnull stop) {
        if (i % barrierLine == 0) {
            NSAttributedString *subText = [attributedText attributedSubstringFromRange:range];
            if (type == 0) {
                [rangeList addObject:subText.string];
            } else {
                [rangeList addObject:subText];
            }
            range = NSMakeRange(range.location + range.length, 0);
        }
        range = NSUnionRange(range, glyphRange);
        i++;
    }];
    if (range.length > 0 ) {
        NSAttributedString *subText = [attributedText attributedSubstringFromRange:range];
        if (type == 0) {
            [rangeList addObject:subText.string];
        } else {
            [rangeList addObject:subText];
        }
    }
    return rangeList.copy;
}

@end
