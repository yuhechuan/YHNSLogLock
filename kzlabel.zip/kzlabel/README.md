
![Build Status](https://img.shields.io/badge/build-passing-green.svg)
![Cocopods](https://img.shields.io/badge/Cocopods-support-green.svg)
[![Pod License](https://img.shields.io/badge/license-MIT-lightgrey.svg)](https://www.apache.org/licenses/LICENSE-2.0.html)
![iOS Version](https://img.shields.io/badge/iOS-10.0%20or%20later-yellowgreen.svg)

## 介绍
在iOS 7之后，文字渲染框架的层级主要如下所示：
![架构](https://git.kanzhun-inc.com/bosszhipin/kzlabel/-/raw/e9953c25c3508dcfb13bc47e9139298b88776f83/image/TextKit.png)
> TextKit 框架是对Core Text的封装，是iOS7以上才可以使用的框架，是文字排版和渲染引擎。
  为了让富文本框架更加稳定 适配iOS系统 所以选用  TextKit作为渲染引擎, 这样的好处是,不用维护Core Text 复杂的底层接口来适配不同的系统


## Features
- [x] 和UILabel 一样基于 TextKit作为底层渲染器 
- [x] 图文混排、链接点击、图片点击
- [x] emoji、链接（网址、电话、邮箱）自动检测
- [x] 文字选择、自定义UIMenuItem 系统UIMenuItem, 支持 放大镜(方形 和 圆形)
- [x] 自定义文字边框
- [x] 链接的颜色、点击高亮颜色、点击背景高亮颜色等颜色高度订制
- [x] 独立的富文本size计算方法
- [x] 图片作为mark的 文本
- [x] 渐变layer作为mark的 文本
- [x] 异步绘制
- [x] NSMutableAttributedString 扩展，提高开发效率


## 接入
pod 'KZLabel'

## 简单用法介绍
`KZLabel`的核心是通过`TextKit`自定义富文本，然后交由`KZLabel`来做显示。我们要实现各种自定义样式，就需要通过`NSMutableAttributedString+KZ.h`这个扩展来创建各种富文本对象；而`NSMutableAttributedString+KZ.h`类中实现高亮链接，文字背景颜色，点击背景颜色，图片都是通过`KZTextAttributes.h`类里面的`KZTextLink、KZTextBorder、KZTextQuote、KZTextAttachment`来实现自定义。

* ### 链接
根据实际应用，选择以下合适的方式：  


方式一：创建KZTextLink对象方法

```objective-c

NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:@"我们来写一个最复杂的连接:"];

KZTextLink *link = [[KZTextLink alloc]init];
link.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
link.highlightColor = [UIColor yellowColor];
link.highlightBackViewColor = [UIColor redColor];
link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
    NSLog(@"Text Link Click");
};

NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"Text Link"];
one.font = [UIFont boldSystemFontOfSize:30];
one.link = link;

[text appendAttributedString:one];

```
方式二：NSMutableAttributedString+KZ.h 扩展里的方法

```objective-c

1. 部分文字高亮展示 并支持点击

NSMutableAttributedString *allString = [[NSMutableAttributedString alloc] initWithString:@"我们来写一个最复杂的连接"];
NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"Text Link"];

[one configLinkColor:[UIColor redColor] clickAction:^(NSAttributedString *attributedString, NSRange range) {
    NSLog(@"Text Link Click");
}]
[text appendAttributedString:one];

2. 按下之后 高亮文字  和 高亮背景


NSMutableAttributedString *allString = [[NSMutableAttributedString alloc] initWithString:@"我们来写一个最复杂的连接"];
NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"Text Link"];

[one configHighLightColor:[UIColor redColor] tapBackViewColor:[UIColor yellowColor] clickAction:^(NSAttributedString *attributedString, NSRange range) {
    NSLog(@"Text Link Click");
}];
[text appendAttributedString:one];


```

* ### 边框样式
同链接，使用创建KZTextAttributes对象方法 或者 使用NSMutableAttributedString+KZ.h 扩展里的方法。

* ### 配置图片 和 Emoji
```objective-c
/**
 Config attachment
 
 @param content                 Support view / layer / image.
 @param attachmentSize          The content size.
 @param alignToFont                 The content will align to the font.
 @param aligment                       Alignment.
 @param clickAction             Click action call back.
 return attachment's attributed string
 */
+ (NSMutableAttributedString *)configAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                                 alignToFont:(UIFont *)alignToFont
                                                    aligment:(KZTextVerticalAlignment)aligment
                                                 clickAction:(KZAttributedAlignmentActionBlock)clickAction;
/**
 Config Emoji
 
 @param image                  content
 @param imageSize          The content size.
 @param alignToFont      alignToFont
 @param emojiString      emojiString
 @param aligment             aligment
 @param clickAction      clickAction
 return attachment's attributed string
 */
+ (NSMutableAttributedString *)configEmojiStringImage:(UIImage *)image
                                            imageSize:(CGSize)imageSize
                                          alignToFont:(UIFont *)alignToFont
                                          emojiString:(NSString *)emojiString
                                             aligment:(KZTextVerticalAlignment)aligment
                                          clickAction:(KZAttributedAlignmentActionBlock)clickAction;

```

* ### 自动检测
根据实际应用，选择以下合适的方式：  

通过KZLabel类
```objective-c

/**
 Setting with detecting config
 
 @param detectType       The detect type
 @param emojiDict         The emoji dictionary which key is string and value is iamge name.
 @param emojiSize        Emoji size. If CGSizeZero, use the emoji image size.
 @param emojiBundle      Emoji bundle. If nil, use main bundle.
 @param linkColor        The link color.
 @param underlineStyle   The link underline style.
 @param underlineColor   The link underline color, default is nil which same as link color.
 */
- (void)configAutoDetectWithDetectType:(KZAutoDetectCheckType)detectType
                              emojiDict:(NSDictionary *)emojiDict
                             emojiSize:(CGSize)emojiSize
                           emojiBundle:(NSBundle *)emojiBundle
                             linkColor:(UIColor *)linkColor
                        underlineStyle:(NSUnderlineStyle)underlineStyle
                        underlineColor:(UIColor *)underlineColor;

/**
 Setting with detecting config
 
 @param config       The detect config.
 */
- (void)configAutoDetectWithConfig:(KZAutoDetectConfig *)config;
/**
 Setting with detecting config
 
 @param configBlock     The detect config block.
 */
- (void)configAutoDetectWithConfigBlock:(KZTextAutoDetectConfigBlock)configBlock;


```

* ### 自定义截断
```objective-c
文字截断:
KZLabel *label = [[KZLabel alloc]init];

NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"...更多"];
truncationAttributedText.font = [UIFont systemFontOfSize:18];
truncationAttributedText.color = [[UIColor blueColor] colorWithAlphaComponent:0.5];
label.truncationAttributedText =truncationAttributedText;

__weak __typeof(self)weakSelf = self;
label.truncationAction = ^{
    NSLog(@"Truncation 点击");
};

图标截断:
KZLabel *label = [[KZLabel alloc]init];

UIImage *image = [UIImage imageNamed:@"dribbble64_imageio"];
__weak __typeof(self)weakSelf = self;
[label configTruncationWithContent:image contentSize:CGSizeMake(font.lineHeight, font.lineHeight) clickAction:^{
    NSLog(@"Truncation 点击");
}];

```

* ### 获取文本Size
根据实际应用，选择以下合适的方式：  

方式一：通过KZLabel类
```objective-c

/**
 Get current label object content size.
 @param constraintWidth The constraint width.
 */
- (CGSize)calculateSizeForConstraintWidth:(CGFloat)constraintWidth;
/**
 Get current label object content size.
 @param constraintSize The constraint size.
 */
- (CGSize)calculateSizeForConstraintSize:(CGSize)constraintSize;

```

方式二：通过NSMutableAttributedString+KZ.h类
```objective-c

/**
 calculate size
 @param containerSize     文字容器大小
 */
- (CGSize)boundingSizeWithContainerSize:(CGSize)containerSize;
/**
 calculate size
 @param containerSize     文字容器大小
 @param optionsBlock       配置block  如果不设置 会以 字符串为准
 */
- (CGSize)boundingSiseWithContainerSize:(CGSize)containerSize optionsBlock:(KZTextAttributesBlock)optionsBlock;

```


* ### KZLabel Properties
YPSeniorLabel类里的属性均有详细注释，重点讲解以下几个：

```objective-c
/**
 * Label 的事件是否高于手势响应 默认是YES  label或者父视图存在手势时,  Label Action高于手势响应      设置为NO 手势响应优先于 Label Action
 */
@property (nonatomic, assign) BOOL cancelsGestureWhenLabelAction;
/**
 *  给外部一个机会 来自定义 渲染
 *  key 是字符串
 *  如果key 是以下几个的话会覆盖掉  原始的渲染类 非特殊情况不建议这么做
 *  KZTextTrunctionAttributedStringKey:
 *  KZTextBodyAttributedStringKey:
 *  KZTextLinkAttributedStringKey:
 *  KZTextBorderAttributedStringKey:
 *  KZTextQuoteAttributedStringKey:
 *  NSAttachmentAttributeName:
 *  class 必须是遵循  <KZTextRenderer> 协议的类  如果不是的话不会加入渲染 引擎
 */
@property (nonatomic, copy) NSDictionary <NSString *, Class>*extendRendererMap;
/**
 |     text    |
 |     text    |
 Default value: 0.0  The layout padding at the beginning and end of the line fragment rects insetting the layout width available for the contents.
 This value is utilized by NSLayoutManager for determining the layout width.
 */
@property (nonatomic, assign) CGFloat lineFragmentPadding;
/**
 * a mark image for kzlabel 只有用 allocWithType:KZLabelTypeImageMark 生效
 * 设置此属性会导致 KZLabel 退化成 UIlabel
 */
@property (nonatomic, strong) UIImage *markImage;
/**
 * a mark gradientLayer for kzlabel 只有用 allocWithType:KZLabelTypeGradientMark 生效
 * 设置此属性会导致 KZLabel 退化成 UIlabel
 * 若要适配暗黑 请使用此属性
 */
@property (nonatomic, strong) CAGradientLayer *gradientLayer;
/**
 * a mark gradientLayer for kzlabel 只有用 allocWithType:KZLabelTypeGradientMark 生效
 * 设置此属性会导致 KZLabel 退化成 UIlabel
 * 如果存在 gradientLayer 设置 此属性无效
 */
@property (nonatomic, copy) NSArray <UIColor *>*gradientColors;

/**
 An array of UIBezierPath representing the exclusion paths inside the receiver's bounding rect.
 The default value is empty.
 */
@property (nonatomic, copy) NSArray<UIBezierPath *> *exclusionPaths;

```


* ### NSMutableAttributedString+KZ.h
此扩展里有许多便捷方法，提高开发效率。例如：

```objective-c
NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:@"Boss直聘"];
//点语法设置 字体
test.font = [UIFont systemFontOfSize:26];
//点语法设置 颜色
test.color = COLOR_333333;
//段落属性
test.lineSpacing = 4;

```

* ### 扩展功能
一、异步渲染

```objective-c
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeAsync];

```
二、本地图片mark

```objective-c
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeImageMark];
    label.markImage = [UIImage imageNamed:@"text_bg3.jpeg"];
```
三、渐变mark

方式1：通过gradientColors属性
```objective-c
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeGradientMark];
    label.gradientColors = @[[UIColor blueColor],[UIColor greenColor]];
    
```
方式2：通过gradientLayer属性
```objective-c
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeGradientMark];
    CAGradientLayer *layer = [[CAGradientLayer alloc]init];
    layer.startPoint = CGPointMake(0, 0.5);
    layer.endPoint = CGPointMake(1, 0.5);
    layer.locations = @[ @(0), @(1.0f) ];
    layer.colors = @[(__bridge id)[UIColor redColor].CGColor, (__bridge id)[UIColor blueColor].CGColor];
    label.gradientLayer = layer;
    
```

* ### 选择
支持长按选择 、支持自定义`YPMenuItem`只需要遵循`KZLabel`里面的协议即可、支持放大镜。具体用法请参考demo。

* ### 总结
以上为简单介绍，详细用法请参考demo、查阅KZLabel里的各种属性。

## Licenses
All source code is licensed under the [MIT License](https://git.kanzhun-inc.com/bosszhipin/kzlabel).
