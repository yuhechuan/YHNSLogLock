//
//  KZAttachmentViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/16.
//

#import "KZAttachmentViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIImageView+YPWebImage.h"
#import "UIView+KZExample.h"
#import "NSBundle+KZExample.h"
#import "YPAnimatedImageView.h"

@interface KZAttachmentViewController ()<UIGestureRecognizerDelegate>

@property (nonatomic, strong) UIView *dotView;
@property (nonatomic, strong) KZLabel *label;

@end

@implementation KZAttachmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
     ///[self setUpUI1];
    [self setUpUI1];
    UITapGestureRecognizer *tap =[[ UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick)];
    [self.view addGestureRecognizer:tap];
}


- (void)tapClick {
    NSLog(@"tapClick");
}

- (void)setUpUI {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.layer.borderWidth = 0.5;
    label.layer.borderColor = [UIColor colorWithRed:0.000 green:0.463 blue:1.000 alpha:1.000].CGColor;
    label.frame = CGRectMake(0, 0, 260, 350);
    label.center = CGPointMake(CGRectGetWidth(self.view.frame) / 2, CGRectGetHeight(self.view.frame) / 2);
    [self.view addSubview:label];
    
    UIFont *font = [UIFont systemFontOfSize:16];
    NSMutableAttributedString *text = [NSMutableAttributedString new];
    
    {
        NSString *title = @"这是一个顶部对齐的UISwitch Attachment: ";
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:title attributes:nil]];
    
        KZTextAttachment *at = [[KZTextAttachment alloc]init];
        at.aligment = KZTextVerticalAlignmentTop;
        at.AsyncFetchAttachContent = ^id(CGSize contentSize) {
            UISwitch *switcher = [UISwitch new];
            [switcher sizeToFit];
            switcher.on = YES;
            return switcher;
        };
        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:at] mutableCopy];
        [text appendAttributedString:attachText];
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n" attributes:nil]];
    }
    
    {
        NSString *title = @"这是一个中间对齐的UIIamge Attachment:";
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:title attributes:nil]];
        
        UIImage *image = [UIImage imageNamed:@"dribbble64_imageio"];
        KZTextAttachment *at = [[KZTextAttachment alloc]init];
        at.content = image;
        at.aligment = KZTextVerticalAlignmentCenter;
        at.contentSize = CGSizeMake(32, 32);
        at.clickAction = ^(KZTextAttachment *attachment, NSRange range) {
            NSLog(@"点击事件");
        };
        
        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:at] mutableCopy];
        [text appendAttributedString:attachText];
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n" attributes:nil]];
    }
    
    
    {

        NSString *title = @"这是一个底部对齐的CALayer Attachment:";
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:title attributes:nil]];
        
     
        
        KZTextAttachment *at = [[KZTextAttachment alloc]init];
       // at.content = layer;
        at.aligment = KZTextVerticalAlignmentBottom;
        at.AsyncFetchAttachContent = ^id(CGSize contentSize) {
            CALayer *layer = [[CALayer alloc]init];
            layer.frame = CGRectMake(0, 0, 32, 32);
            layer.backgroundColor = [UIColor blueColor].CGColor;
            layer.cornerRadius = 8;
            return layer;
        };

        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:at] mutableCopy];
        [text appendAttributedString:attachText];
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n" attributes:nil]];
    }
    
    
    {
        NSString *title = @"这是一个底部对齐的,加载远端图片Attachment:";
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:title attributes:nil]];
    
        KZTextAttachment *at = [[KZTextAttachment alloc]init];
        // at.content = imageView;
        at.aligment = KZTextVerticalAlignmentBottom;
        at.AsyncFetchAttachContent = ^id(CGSize contentSize) {
            UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
            [imageView yp_setImageWithURL:[NSURL URLWithString:@"https://upload-images.jianshu.io/upload_images/1646251-230ff15b31132057.png"]];
            return imageView;
        };

        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:at] mutableCopy];
        [text appendAttributedString:attachText];
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n" attributes:nil]];
    }
    
    {
        NSString *title = @"这是一个加载动图的Attachment:";
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:title attributes:nil]];
        
        NSArray *names = @[@"001", @"022", @"019",@"056",@"085"];
        for (NSString *name in names) {
            NSString *path = [[NSBundle mainBundle] pathForScaledResource:name ofType:@"gif" inDirectory:@"EmoticonQQ.bundle"];
            NSData *data = [NSData dataWithContentsOfFile:path];
            YPImage *image = [YPImage imageWithData:data scale:2];
            
            YPAnimatedImageView *imageView = [[YPAnimatedImageView alloc] initWithImage:image];
            
            KZTextAttachment *attach = [[KZTextAttachment alloc]init];
            attach.content = imageView;
            
            NSMutableAttributedString *attachText = [[NSAttributedString attributedStringWithAttachment:attach] mutableCopy];
            [text appendAttributedString:attachText];
        }
      
        KZTextAttachment *attach = [[KZTextAttachment alloc]init];
        /// attach.content = imageView;
        attach.aligment = KZTextVerticalAlignmentBottom;
        attach.contentSize = CGSizeMake(120, 120);
        attach.AsyncFetchAttachContent = ^id(CGSize contentSize) {
            YPImage *image = [YPImage imageNamed:@"test1@2x.gif"];
            YPAnimatedImageView *imageView = [[YPAnimatedImageView alloc] initWithImage:image];
            return imageView;
        };

        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:attach] mutableCopy];
        [text appendAttributedString:attachText];
        [text appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n" attributes:nil]];
    }
    
    text.kzFont = font;
    label.attributedText = text;
    self.label = label;
    
    UIView *dot = [self newDotView];
    dot.center = CGPointMake(label.width, label.height);
    dot.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin;
    [label addSubview:dot];
    
    _dotView = dot;
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
    pan.delegate = self;
    [self.view addGestureRecognizer:pan];
}

#pragma mark - Action

- (void)panAction:(UIPanGestureRecognizer *)pan {
    if (pan.state == UIGestureRecognizerStateChanged) {
        CGPoint location = [pan locationInView:self.view];
        CGPoint labelOrigin = _label.frame.origin;
        CGSize labelMinSize = CGSizeMake(30, 30);
        
        CGFloat width = location.x - labelOrigin.x;
        CGFloat height = location.y - labelOrigin.y;
        
        if (width < labelMinSize.width ||
            height < labelMinSize.height) {
            return;
        }
        _label.size = CGSizeMake(width, height);
        _label.center = CGPointMake(CGRectGetWidth(self.view.frame) / 2, CGRectGetHeight(self.view.frame) / 2);
    }
}

- (UIView *)newDotView {
    UIView *view = [UIView new];
    view.size = CGSizeMake(50, 50);
    
    UIView *dot = [UIView new];
    dot.size = CGSizeMake(10, 10);
    dot.backgroundColor = [UIColor colorWithRed:0.000 green:0.463 blue:1.000 alpha:1.000];
    dot.clipsToBounds = YES;
    dot.layer.cornerRadius = dot.height / 2;
    dot.center = CGPointMake(view.width / 2, view.height / 2);
    [view addSubview:dot];
    
    return view;
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    CGPoint location = [gestureRecognizer locationInView:self.view];
    CGRect dotViewFrame = [_dotView convertRect:_dotView.bounds toView:self.view];
    return CGRectContainsPoint(dotViewFrame, location);
}


- (void)setUpUI1 {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.frame = CGRectMake(50, 100, 100, 350);
    label.clipsToBounds = YES;
    label.backgroundColor = [[UIColor blueColor] colorWithAlphaComponent:0.1];
    NSString *title = @"这是一个中间对齐的UIIamge Attachment:";
    NSMutableAttributedString *text = [NSMutableAttributedString new];
    [text appendAttributedString:[[NSAttributedString alloc] initWithString:title attributes:nil]];
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 150, 150)];
    imageView.image = [UIImage imageNamed:@"dribbble64_imageio"];
    imageView.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.5];
    KZTextAttachment *iconAttachment = [[KZTextAttachment alloc]init];
    iconAttachment.content = imageView;
    iconAttachment.contentMode =  UIViewContentModeScaleAspectFit;
    NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:iconAttachment] mutableCopy];
    [text appendAttributedString:attachText];
    
    [self.view addSubview:label];
    label.attributedText = text;
    [label sizeToFit];
}

@end
