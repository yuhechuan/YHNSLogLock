//
//  KZAttributesViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/13.
//

#import "KZAttributesViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZTextDemoHelper.h"
#import "KZTextDebugOption.h"

@interface KZAttributesViewController ()<KZLabelDelegate>

@property (nonatomic, strong) KZLabel *label;

@end

@implementation KZAttributesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    
    [self setUpUI];
}

- (void)setUpUI {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.delegate = self;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(0, kz_appGetNavHeight(), self.view.bounds.size.width, self.view.bounds.size.height - kz_appGetNavHeight());
    [self.view addSubview:label];
    
    NSMutableAttributedString *text = [NSMutableAttributedString new];
    [text appendAttributedString:[self padding]];
    [text appendAttributedString:[self padding]];
    [text appendAttributedString:[self padding]];
    [text appendAttributedString:[self padding]];
    [text appendAttributedString:[self padding]];

    {
        NSShadow *shadow = [NSShadow new];
        shadow.shadowColor = [UIColor colorWithWhite:0.000 alpha:0.490];
        shadow.shadowOffset = CGSizeMake(0, 1);
        shadow.shadowBlurRadius = 5;
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Shadow" attributes:@{
                                                                                 NSFontAttributeName: [UIFont boldSystemFontOfSize:30],
                                                                                 NSForegroundColorAttributeName: [UIColor whiteColor],
                                                                                 NSShadowAttributeName: shadow
                                                                                 }];
        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }

    {
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.borderColor = [UIColor colorWithRed:1.000 green:0.029 blue:0.651 alpha:1.000];
        border.borderWidth = 3;
        border.insets = UIEdgeInsetsMake(0, -4, 0, -4);
        border.fillColor = [UIColor colorWithRed:1.000 green:0.795 blue:0.014 alpha:1.000];
        border.cornerRadius = 3;
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Text Border" attributes:@{
                                                                                     NSFontAttributeName: [UIFont boldSystemFontOfSize:30],
                                                                                     NSForegroundColorAttributeName: [UIColor colorWithRed:1.000 green:0.029 blue:0.651 alpha:1.000],
                                                                                     KZTextBorderAttributedStringKey: border
                                                                                 }];

        [text appendAttributedString:[self padding]];
        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
    }
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor blackColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterNormal;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Strikethrough"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
    }
    
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor redColor];
        boder.underlineWidth = 2.0;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Underline"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
    }

    {
        KZTextLink *link = [[KZTextLink alloc]init];
        link.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
        link.highlightColor = [UIColor yellowColor];
        link.highlightBackViewColor = [UIColor redColor];
        link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
            NSLog(@"Text Link Click");
        };

        NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"Text Link"];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzLink = link;
        
        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];

    }
    [text kzSetAlignment:NSTextAlignmentCenter range:NSMakeRange(0, text.length)];
    
    {
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
        paragraphStyle.headIndent = 23;
        paragraphStyle.firstLineHeadIndent = 23;
        paragraphStyle.tailIndent = -19;
        
        KZTextQuote *quote = [KZTextQuote new];
        quote.quoteWidth = 4;
        quote.quoteColor =  [UIColor lightGrayColor];
        quote.quoteLeft = 11;
        quote.insets = UIEdgeInsetsMake(-8, 0, -8, 0);
        
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.fillColor = [[UIColor blueColor] colorWithAlphaComponent:0.1];
        border.insets = UIEdgeInsetsMake(-8, -8, -8, 19);
        border.borderStyle = KZBorderBlockTiled;
        
        NSString *quoteText = @"『《我的阿勒泰》是作者十年来散文创作的合集。分为阿勒泰文字、阿勒泰角落和九篇雪三辑。这是一部描写疆北阿勒泰地区生活和风情的原生态散文集。充满生机活泼、新鲜动人的元素。记录作者在疆北阿勒泰地区生活的点滴，包括人与事的记忆。作者在十年前以天才的触觉和笔调初现文坛并引起震惊。作品风格清新、明快，质地纯粹，原生态地再现了疆北风物，带着非常活泼的生机。』";
        NSDictionary *dict = @{NSFontAttributeName: [UIFont preferredFontForTextStyle:UIFontTextStyleCallout],
                               NSParagraphStyleAttributeName: paragraphStyle,
                               KZTextQuoteAttributedStringKey: quote,
                               KZTextBorderAttributedStringKey:border
        };
        NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:quoteText
                                                                                attributes:dict];
        KZTextLink *link = [[KZTextLink alloc]init];
        link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
            NSURL *URL = [NSURL URLWithString:@"https://book.douban.com/subject/4884218/"];
            [UIApplication.sharedApplication openURL:URL options:@{} completionHandler:nil];
        };
        link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
        NSRange bookRange = [quoteText rangeOfString:@"《我的阿勒泰》"];
        [one kzSetLink:link range:bookRange];
        
        [text appendAttributedString:one];
        
        [text appendAttributedString:[self padding]];
    }
    
    
    label.attributedText = text;
    self.label = label;
}

- (NSAttributedString *)padding {
    NSMutableAttributedString *pad = [[NSMutableAttributedString alloc] initWithString:@"\n\n" attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:4]}];
    return pad;
}

- (void)willRendererDebugOption:(KZTextDebugOption *)option {
    option.baselineColor = [UIColor blueColor];
}

@end
