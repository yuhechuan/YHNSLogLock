//
//  KZTextRangeController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/9/11.
//

#import "KZTextRangeController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIView+KZExample.h"

@interface KZTextRangeController ()

@end

@implementation KZTextRangeController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self test1];
}

- (void)test1 {
    KZLabel *label = [KZLabel new];
    label.frame = CGRectMake(100, 200, 100, 20);
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    
    NSString *all = @"20000w";
    NSString *sub1 = @"20000";
    NSRange range1 = [all rangeOfString:sub1];
    
    NSString *sub2 = @"w";
    NSRange range2 = [all rangeOfString:sub2];
    
    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:all];
    [test addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:24] range:range1];
    [test addAttribute:NSForegroundColorAttributeName value:[UIColor greenColor] range:range1];
    [test addAttribute:@"KZMDBoldAttributeName" value:@"KZMDBoldAttributeName" range:range1];
    
    [test addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:range2];
    [test addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:range2];
    [test addAttribute:@"KZMDBoldAttributeName" value:@"KZMDBoldAttributeName" range:range2];
    
    
    label.attributedText = test;
    [self.view addSubview:label];
}

- (void)tap {
    NSLog(@"手势");
}

- (void)test {
    
    UIPanGestureRecognizer *tap = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
    [self.view addGestureRecognizer:tap];
    
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 3;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.frame = CGRectMake(20, 200, 255, 500);
    label.cancelsGestureWhenLabelAction = NO;
    [self.view addSubview:label];
    
    NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"...更多"];
    truncationAttributedText.kzFont = [UIFont systemFontOfSize:28];
    truncationAttributedText.kzColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
    label.truncationAttributedText =truncationAttributedText;
    
    NSString *all = @"爱新觉罗·衎乞力马扎罗·頔丽热巴绘制了带有圆角和箭头的气泡形状实例，并设置其属性，然后将其添加到视图层级中即";
    NSString *sub1 = @"级中即";
    NSRange range1 = [all rangeOfString:sub1];
    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:all];
    test.kzFont = [UIFont systemFontOfSize:28];
    test.kzColor =  [UIColor colorWithRed:20/ 255.0 green:20/ 255.0 blue:20/ 255.0  alpha:1.000];
    // test.minimumLineHeight = 40;
    test.kzLineSpacing = 0;
    KZTextBorder *border = [[KZTextBorder alloc]init];
    //border.insets = UIEdgeInsetsMake(-5, 0, -5, 0);
    border.fillColor =  [UIColor colorWithRed:21/ 255.0 green:179/ 255.0 blue:179/ 255.0  alpha:0.12];
    border.underlineStyle = KZBorderUnderLineDash;
    border.underlineWidth = 1;
    border.underlineColor = [UIColor colorWithRed:21/ 255.0 green:179/ 255.0 blue:179/ 255.0  alpha:1];
    border.dashPaintedLength = 2.0;
    border.dashNotPaintedLength = 2.0;
    
    [test kzSetBorder:border range:range1];
    
    KZTextLink *link = [[KZTextLink alloc]init];
    link.clickAction = ^(NSAttributedString *attrStr, NSRange textRange) {
        NSArray *rects = [label textRectsAtTextRange:textRange];
        for (NSValue *r in rects) {
            UIView *view = [[UIView alloc]initWithFrame:[r CGRectValue]];
            view.backgroundColor = [[UIColor redColor]colorWithAlphaComponent:0.3];
            [label addSubview:view];
        }
    };
    [test kzSetLink:link range:range1];
    label.attributedText = test;
    [label sizeToFit];
}

@end
