//
//  KZFeaturesTestViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/25.
//

#import "KZFeaturesTestViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZTextDemoHelper.h"
#import "UIView+KZExample.h"


/// Magnifier type
typedef NS_ENUM(int, KZFeaturesTestType) {
    KZFeaturesTestTypeText = 0,
    KZFeaturesTestTypeFontSize,
    KZFeaturesTestTypeLineSpacing,
    KZFeaturesTestTypeLineHeightMultiple,
};


@interface KZFeaturesTestCellModel :NSObject

@property (nonatomic, copy) NSString *title;
@property(nonatomic) float minimumValue;
@property(nonatomic) float maximumValue;
@property (nonatomic, assign) KZFeaturesTestType testType;

@end

@implementation KZFeaturesTestCellModel

@end

@interface KZFeaturesTestCell :UITableViewCell

@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, copy) void(^sliderChangeValueAction)(KZFeaturesTestCellModel *model, float value);
@property (nonatomic, strong) KZFeaturesTestCellModel *cellModel;



- (void)refreshCell:(KZFeaturesTestCellModel *)cellModel;

@end

@implementation KZFeaturesTestCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self) {
        [self.contentView addSubview:self.slider];
        [self.contentView addSubview:self.title];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.slider.frame =  CGRectMake(0, 10, self.width, 40);
    self.title.frame = CGRectMake(0, CGRectGetMaxY(self.slider.frame) -15, self.width, 30);
}

- (void)refreshCell:(KZFeaturesTestCellModel *)cellModel {
    self.cellModel = cellModel;
    self.title.text = cellModel.title;
    self.slider.minimumValue = cellModel.minimumValue;
    self.slider.maximumValue =  cellModel.maximumValue;
}

- (void)sliderChangeValue:(UISlider *)slider {
    if(self.sliderChangeValueAction) {
        self.sliderChangeValueAction(self.cellModel, slider.value);
    }
}

- (UISlider *)slider {
    if(!_slider) {
        _slider = [[UISlider alloc]init];
        [_slider addTarget:self action:@selector(sliderChangeValue:) forControlEvents:UIControlEventValueChanged];
    }
    return _slider;
}

- (UILabel *)title {
    if(!_title) {
        _title = [[UILabel alloc]init];
        _title.textAlignment = NSTextAlignmentCenter;
        _title.numberOfLines = 0;
        _title.textColor = [UIColor colorWithRed:51/ 255.0 green:51/ 255.0 blue:51/ 255.0 alpha:1];
        _title.font = [UIFont systemFontOfSize:14];
    }
    return _title;
}

@end

#define ParagraphStyleAttriSet(_attri_) \
NSMutableParagraphStyle *paragraphStyle = self.paragraphStyle.mutableCopy; \
paragraphStyle. _attri_ = _attri_; \
self.paragraphStyle = paragraphStyle;

@interface KZFeaturesTestViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) KZLabel *label;
@property (nonatomic, strong) UILabel *valueLabel;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataList;
@property (nonatomic) NSMutableDictionary *attributes;
@property (nonatomic) NSParagraphStyle *paragraphStyle;
@property (nonatomic) NSInteger maxNumberOfLines;
@property (nonatomic) NSMutableAttributedString *text;

@end

@implementation KZFeaturesTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUp];
    [self loadData];
}

- (void)setUp {
    [self.tableView registerClass:[KZFeaturesTestCell class] forCellReuseIdentifier:NSStringFromClass([KZFeaturesTestCell class])];
    self.attributes = [@{NSFontAttributeName : [UIFont systemFontOfSize:18]} mutableCopy];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.hyphenationFactor = 1;
    paragraphStyle.lineSpacing = 0;
    paragraphStyle.paragraphSpacing = 0;
    self.paragraphStyle = paragraphStyle;
    self.maxNumberOfLines = 0;
    [self updateText:0];
}

- (void)loadData {
    
    NSArray *types = @[@(KZFeaturesTestTypeText),
                      @(KZFeaturesTestTypeFontSize),
                      @(KZFeaturesTestTypeLineSpacing),
                      @(KZFeaturesTestTypeLineHeightMultiple)];
    
    for (NSNumber *type in types) {
        KZFeaturesTestCellModel *cellM = [KZFeaturesTestCellModel new];
        cellM.testType = [type intValue];
        switch (cellM.testType) {
            case KZFeaturesTestTypeText:{
                cellM.title = @"text";
                cellM.minimumValue = 0;
                cellM.maximumValue = 6;
                break;
            }
            case KZFeaturesTestTypeFontSize:{
                cellM.title = @"font size";
                cellM.minimumValue = 10;
                cellM.maximumValue = 30;
                break;
            }
            case KZFeaturesTestTypeLineSpacing:{
                cellM.title = @"line spacing";
                cellM.minimumValue = 0;
                cellM.maximumValue = 60;
                break;
            }
            case KZFeaturesTestTypeLineHeightMultiple:{
                cellM.title = @"lineHeightMultiple";
                cellM.minimumValue = 0.5;
                cellM.maximumValue = 3;
                break;
            }
            default:
                break;
        }
        [self.dataList addObject:cellM];
    }
    [self.tableView reloadData];
}

- (void)refreshTextattributes {
    NSMutableDictionary *attributes = self.attributes.mutableCopy;
    attributes[NSParagraphStyleAttributeName] = self.paragraphStyle;
    [self.text addAttributes:attributes range:NSMakeRange(0, self.text.length)];
    self.label.attributedText = self.text;
}

- (void)updateText:(int)index {
    NSMutableDictionary *attributes = self.attributes.mutableCopy;
    attributes[NSParagraphStyleAttributeName] = self.paragraphStyle;
    self.text = [[NSMutableAttributedString alloc] initWithString:[self textOfIndex:index] attributes:self.attributes];
    self.label.attributedText = self.text;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KZFeaturesTestCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([KZFeaturesTestCell class]) forIndexPath:indexPath];
    [cell refreshCell:self.dataList[indexPath.row]];
    __weak __typeof(self)weakSelf = self;
    cell.sliderChangeValueAction = ^(KZFeaturesTestCellModel *model, float value) {
        [weakSelf sliderChangeValue:model value:value];
    };
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}

- (void)sliderChangeValue:(KZFeaturesTestCellModel *)model value:(float)value {
    switch (model.testType) {
        case KZFeaturesTestTypeText:{
            [self updateText:(int)value];
            break;
        }
        case KZFeaturesTestTypeFontSize:{
            CGFloat size = value;
            self.attributes[NSFontAttributeName] = [UIFont systemFontOfSize:size];
            break;
        }
        case KZFeaturesTestTypeLineSpacing:{
            CGFloat lineSpacing = value;
            ParagraphStyleAttriSet(lineSpacing);
            break;
        }
        case KZFeaturesTestTypeLineHeightMultiple:{
            float lineHeightMultiple = value;
            ParagraphStyleAttriSet(lineHeightMultiple);
            break;
        }
        default:
            break;
    }
    
    if(model.testType != KZFeaturesTestTypeText) {
        [self refreshTextattributes];
    }
}

- (KZLabel *)label {
    if(!_label) {
        CGFloat width  = KZTextScreenSize().width / 2.0;
        CGFloat y = kz_appGetNavHeight();
        CGFloat height  = KZTextScreenSize().height - y;
        _label = [[KZLabel alloc]initWithFrame:CGRectMake(0, y, width, height)];
        _label.backgroundColor = [[UIColor orangeColor] colorWithAlphaComponent:0.5];
        _label.textVerticalAlignment = KZTextVerticalAlignmentTop;
        _label.numberOfLines = 0;
        _label.textContainerInset = UIEdgeInsetsMake(20, 0, 20, 0);
        _label.lineBreakMode = NSLineBreakByCharWrapping;
        [self.view addSubview:_label];
    }
    return _label;
}


- (UITableView *)tableView {
    if (!_tableView) {
        CGFloat width  = KZTextScreenSize().width / 2.0;
        CGFloat y = kz_appGetNavHeight();
        CGFloat height  = KZTextScreenSize().height - y;
        CGFloat x = width;

        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(x, y , width, height) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.backgroundColor = UIColor.whiteColor;
        _tableView.contentInset = UIEdgeInsetsMake(0, 0, 34, 0);
        _tableView.scrollIndicatorInsets = UIEdgeInsetsMake(0, 0, 34, 0);
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (NSMutableArray *)dataList {
    if(!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}


- (NSString *)textOfIndex:(NSInteger)index {
    switch (index % 7) {
        case 0:
            return @""
            "The withdrawn and mysterious pilot of Evangelion Unit-00 🤖, Rei Ayanami, is a clone made from the salvaged remains of Yui and is plagued by a sense of negative self-worth stemming from the realization that she is an expendable asset 🤔. \nShe at one time despised Shinji for his lack of trust in his father Gendo 😎, with whom Rei is very close. However, after Shinji and Rei successfully defeat the Angel Ramiel, she takes a friendly liking to him. Towards the end of the series it is revealed that she is one of many clones, whose use is to replace the currently existing Rei if she is killed.";
        case 1:
            return @""
            "iCloud 能将你的 GarageBand 创作进度在你所有的 iOS 设备间保持更新。它还可以让你在 iPad、iPhone 或 iPod touch 上开始勾勒一首歌的灵感，然后用 iCloud Drive 将音轨导入 Mac 做进一步创作，再将完成的作品共享到你的任何设备。你还可以导入 Logic Pro 项目的便携版本，接着创作其他音轨。当你重新在 Logic Pro 打开该项目时，所有原始音轨以及在 GarageBand 中另外添加的音轨，都将同时显示出来。";
        case 2:
            return @""
            "iCloud 能将你的 GarageBand 创作进度在你所有的 iOS 设备间保持更新。\n它还可以让你在 iPad、iPhone 或 iPod touch 上开始勾勒一首歌的灵感，然后用 iCloud Drive 将音轨导入 Mac 做进一步创作，再将完成的作品共享到你的任何设备。你还可以导入 Logic Pro 项目的便携版本，接着创作其他音轨。当你重新在 Logic Pro 打开该项目时，所有原始音轨以及在 GarageBand 中另外添加的音轨，都将同时显示出来。";
        case 3:
            return @""
            "iCloud 🤗能将你的 GarageBand 创作进度在你所有的 iOS 设备间保持更新🤗。\n它还可以让你在 iPad、iPhone 或 iPod touch 上开始勾勒一首歌的灵感，然后用 iCloud Drive 将音轨导入 Mac 做进一步创作，再将完成的作品共享到你的任何设备。你还可以导入 Logic Pro 项目的便携版本，接着创作其他音轨。\n\n当你重新在 Logic Pro 打开该项目时，所有原始音轨以及在 GarageBand 中另外添加的音轨，都将同时显示出来。Hello world";
        case 4:
            return @""
            "2012年12月。エヴァ：Qの公開後🤗、僕は EVA 壊れました。 Hello world 所謂、鬱状態となりました。 ６年間、自分の魂を削って再びエヴァを作っていた事への、当然の報いでした。明けた2013年。その一年間は精神的な負の波が何度も揺れ戻してくる年でした。自分が代表を務め、自分が作品 work を背負っているスタジオにただの１度も近づく事が出来ませんでした。\n他者や世間との関係性がおかしくなり、まるで回復しない疲労困憊も手伝って、ズブズブと精神的な不安定感に取り込まれていきました。その間、様々な方々に迷惑をかけました。が、妻や友人らの御蔭で、この世に留まる事が出来、宮崎駿氏に頼まれた声の仕事がアニメ制作へのしがみつき行為として機能した事や、友人らが僕のアニメファンの源になっていた作品の新作をその時期に作っていてくれた御蔭で、アニメーションから心が離れずにすみました。友人が続けている戦隊シリーズも、特撮ファンとしての心の支えになっていました。The series contains numerous allusions to the Kojiki and the Nihongi, the sacred texts of Shinto. The Shinto vision of the primordial cosmos is referenced in the series, and the mythical lances of the Shinto deities Izanagi and Izanami are used as weapons in battles between Evangelions and Angels.[63] Elements of the Judeo-Christian tradition also feature prominently throughout the series, including references to Adam, Lilith, Eve, the Lance of Longinus,[64]";
        case 5:
            return @""
            "중국조선어에 관한 망🤗라적인 언어 I don't know what the text means. 규범은 동북3성조선어문사업협의소조가 1977년에 작성한 ‘조선말규범집’이 처음이다. 이 규 This will test Korean and English mix layout 범집에는 표준발음법, 맞춤법, 띄어쓰기, 문장부호에 관한 규범이 수록되었다. ‘조선말규범집’은 어휘에 관한 규범을 덧붙이고, 일부를 가필 수정한 개정판이 1984년에 만들어졌다.[1]\n 중국조선말은 1949년 중화인민공화국 건국 이래, 조선민주주의인민공화국(이하 북조선)의 언어에 규범의 토대를 두어 온 경위로, 중국조선말의 언어 규범은 모두 북조선의 규범(조선말규범집 등)과  hello 거의 동일하며, 1992년 한중수교 이후에는 대한민국으로부터 진출한 기업이나 한국어 교육 기관의 영향력이 커짐에 따라 남한식 한국어의 사용이 확대되고 있다.";
        case 6:
            return @""
            "للغة العربية هي🤗 أكثر اللغات تحدثاً ونطقاً ضمن مجموعة اللغات hello world السامية، وإحدى أكثر اللغات انتشاراً في العالم، يتحدثها أكثر من 422 مليون نسمة،[2](1) ويتوزع متحدثوها في الوطن العربي، بالإضافة إلى العديد من المناطق الأخرى المجاورة كالأحواز وتركيا وتشاد ومالي والسنغال وإرتيريا و إثيوبيا و جنوب السودان و إيران. اللغة العربية ذات أهمية قصوى لدى المسلمين، فهي لغة مقدسة (لغة القرآن)، ولا تتم الصلاة (وعبادات أخرى) في الإسلام إلا بإتقان بعض من كلماتها.[4][5] العربية هي أيضاً لغة شعائرية رئيسية لدى عدد من الكنائس المسيحية في الوطن العربي، كما كتبت بها كثير من أهم الأعمال الدينية والفكرية اليهودية في العصور الوسطى. وأثّر انتشار الإسلام، وتأسيسه دولاً، ";
        default:return @"";
    }
}



@end
