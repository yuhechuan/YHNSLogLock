//
//  KZBigTextListController.m
//  KZLabel
//
//  Created by yuhechuan on 2024/8/13.
//

#import "KZBigTextListController.h"
#import "KZDemoText.h"
#import "KZLabel.h"
#import "UIView+KZExample.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZNavigationController.h"
#import "UIViewController+NavigationItem.h"
#import "UIColor+KZExtension.h"

typedef NS_ENUM(int, KZTextBigItemType) {
    KZTextBigItemTypeNormal = 0,
    KZTextBigItemTypeTop =    1, ///< Top alignment.
    KZTextBigItemTypeCenter = 2, ///< Center alignment.
    KZTextBigItemTypeBottom = 3, ///< Bottom alignment.
};


CGFloat _marginLeft = 70;
CGFloat _marginRight = 15;
CGFloat _marginBottom = 20;
CGFloat _msgPadding = 10;
CGFloat _headWH = 40;

@interface KZTextBigItemModel : NSObject

@property (nonatomic, copy) NSAttributedString *attributedText;
@property (nonatomic, copy) NSAttributedString *originAttributedText;
@property (nonatomic, assign) KZTextBigItemType itemType;

@end

@implementation KZTextBigItemModel

@end

@interface KZTextBigExampleCell : UITableViewCell

- (void)setAyncText:(KZTextBigItemModel *)bigModel;

@end


@implementation KZTextBigExampleCell {
    KZLabel *_uiLabel;
    UIImageView *_bgImageView;
    UIImageView *_headImageView;
    KZTextBigItemModel *_bigModel;
    UIView *_msgView;

}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
 
    _uiLabel = [KZLabel new];
    _uiLabel.font = [UIFont systemFontOfSize:14];
    _uiLabel.numberOfLines = 0;
    _uiLabel.textColor = HEXColor(@"#333333");
    _uiLabel.selectable = YES;
    
    _bgImageView = [[UIImageView alloc]init];
    _bgImageView.clipsToBounds = YES;
    _bgImageView.userInteractionEnabled = YES;
    
    _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, _headWH, _headWH)];
    _headImageView.layer.cornerRadius = 6;
    _headImageView.clipsToBounds = YES;
    _headImageView.image = [UIImage imageNamed:@"head.jpg"];
    
    _msgView = [UIView new];
    [_bgImageView addSubview:_uiLabel];
    [_msgView addSubview:_bgImageView];
    [_msgView addSubview:_headImageView];
    [_msgView sendSubviewToBack:_bgImageView];
    [_msgView bringSubviewToFront:_headImageView];
    
    [self.contentView addSubview:_msgView];
    self.contentView.backgroundColor = [UIColor clearColor];
    self.backgroundColor = [UIColor clearColor];

    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (!_bigModel) {
        return;
    }
    _msgView.frame = CGRectMake(_marginLeft, 0, self.width - _marginLeft, self.height);
    _headImageView.top = 0;
    if (_bigModel.itemType == KZTextBigItemTypeTop) {
        _bgImageView.frame = CGRectMake(0, 0, _msgView.width - _headImageView.height - _marginRight - _marginRight / 2.0, _msgView.height);
        _headImageView.left = CGRectGetMaxX(_bgImageView.frame) + _marginRight / 2.0;
        _uiLabel.frame = CGRectMake(_msgPadding, _msgPadding, _bgImageView.width - _msgPadding*2 , _bgImageView.height - _msgPadding);
    } else if (_bigModel.itemType == KZTextBigItemTypeCenter) {
        _bgImageView.frame = CGRectMake(0, 0, _msgView.width - _headImageView.height - _marginRight - _marginRight / 2.0, _msgView.height);
        _uiLabel.frame = CGRectMake(_msgPadding, 0, _bgImageView.width - _msgPadding*2 , _bgImageView.height);
    } else if (_bigModel.itemType == KZTextBigItemTypeBottom) {
        _bgImageView.frame = CGRectMake(0, 0, _msgView.width - _headImageView.height - _marginRight - _marginRight / 2.0, _msgView.height - _marginBottom);
        _uiLabel.frame = CGRectMake(_msgPadding, 0, _bgImageView.width - _msgPadding*2 , _bgImageView.height - _msgPadding);
    } else {
        _bgImageView.frame = CGRectMake(0, 0, _msgView.width - _headImageView.height - _marginRight - _marginRight / 2.0, _msgView.height - _marginBottom);
        _headImageView.left = CGRectGetMaxX(_bgImageView.frame) + _marginRight / 2.0;
        _uiLabel.frame = CGRectMake(_msgPadding, _msgPadding, _bgImageView.width - _msgPadding*2 , _bgImageView.height - _msgPadding *2);
    }
}

- (void)setAyncText:(KZTextBigItemModel *)bigModel {
    _bigModel = bigModel;
    _uiLabel.attributedText = bigModel.attributedText;
    _headImageView.hidden = YES;
    NSString *bubble = @"bubble_blue_normal@3x.png";
    if (bigModel.itemType == KZTextBigItemTypeTop) {
        bubble = @"bubble_blue_top@3x.png";
        _headImageView.hidden = NO;
    } else if (bigModel.itemType == KZTextBigItemTypeCenter) {
        bubble = @"bubble_blue_center@3x.png";
    } else if (bigModel.itemType == KZTextBigItemTypeBottom) {
        bubble = @"bubble_blue_bottom@3x.png";
    } else {
        _headImageView.hidden = NO;
    }
    UIImage *bubbleImg = [UIImage imageNamed:bubble];
    _bgImageView.image = [bubbleImg resizableImageWithCapInsets:UIEdgeInsetsMake(10, 10, 10, 10) resizingMode:UIImageResizingModeStretch];
}


@end


@interface KZBigTextListController ()

@property (nonatomic, strong) NSMutableArray *dataList;

@end

@implementation KZBigTextListController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 20, 0);
    self.tableView.backgroundColor = HEXColor(@"#F5F5F6");
    self.tableView.tableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 30)];
    [self.tableView registerClass:[KZTextBigExampleCell class] forCellReuseIdentifier:NSStringFromClass([KZTextBigExampleCell class])];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self loadBigText];
}

- (void)loadBigText {
    
    NSString *text1 = @"然后可以看到，这个文件夹下是按照日期来分类的，可以都删掉，也可以选择把日期较老的部分删掉。";
    NSString *text2 = @"这部分是编译项目时产生的索引缓存文件，文件夹时按照单个项目来区分的，可以将这里的内容全部清空，下次编译有需要的项目时会再次生成。";
    NSString *text3 = @"当进行真机调试时，需要先下载这个机器系统对应的支持文件，通过数据线连接时会自动生成对应的调试信息。当你调试了多个真机设备，这个文件夹就会越堆越大，其实只需要保留你常用的真机支持文件即可。";
    NSString *text4 = [self textString];
    
    NSArray *list = @[text1, text2, text3, text4];
    CGFloat width = [UIScreen mainScreen].bounds.size.width - _marginLeft - _msgPadding *2 - _marginRight / 2.0 - _headWH - _marginRight;
    for (NSString *t in list) {
        if (t.length < 1000) {
            KZTextBigItemModel *m = [[KZTextBigItemModel alloc]init];
            m.attributedText = [[NSAttributedString alloc]initWithString:t];
            [self.dataList addObject:m];
        } else {
            NSAttributedString *originAttributedText = [[NSAttributedString alloc]initWithString:t];
            NSArray *subList = [NSMutableAttributedString splitStringBarrierLine:10
                                                                   containerSize:CGSizeMake(width, 50000)
                                                                            font:[UIFont systemFontOfSize:14]
                                                                     lineSpacing:0
                                                                   numberOfLines:0
                                                                     splitString:t];
            for (int i = 0; i < subList.count; i ++) {
                NSAttributedString *subText = [[NSAttributedString alloc]initWithString:subList[i]];
                KZTextBigItemModel *m = [[KZTextBigItemModel alloc]init];
                m.attributedText = subText;
                m.originAttributedText = originAttributedText;
                if (i == 0) {
                    m.itemType = KZTextBigItemTypeTop;
                } else if (i == subList.count - 1) {
                    m.itemType = KZTextBigItemTypeBottom;
                } else {
                    m.itemType = KZTextBigItemTypeCenter;
                }
                [self.dataList addObject:m];
            }
        }
    }
    [self.tableView reloadData];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    KZTextBigItemModel *bigModel = self.dataList[indexPath.row];
    NSAttributedString *attText = bigModel.attributedText;
    CGFloat width = [UIScreen mainScreen].bounds.size.width - _marginLeft - _msgPadding *2 - _marginRight / 2.0 - _headWH - _marginRight;
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, width, 10)];
    label.font = [UIFont systemFontOfSize:14];
    label.numberOfLines = 0;
    label.attributedText = attText;
    [label sizeToFit];
    CGFloat height = label.height;
    if (bigModel.itemType == KZTextBigItemTypeTop) {
        height += 10;
    } else if (bigModel.itemType == KZTextBigItemTypeCenter) {
    } else if (bigModel.itemType == KZTextBigItemTypeBottom) {
        height += 30;
    } else {
        height += 40;
    }
    return height;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KZTextBigExampleCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([KZTextBigExampleCell class]) forIndexPath:indexPath];
    KZTextBigItemModel *m = self.dataList[indexPath.row];
    [cell setAyncText:m];
    return cell;
}

- (NSMutableArray *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}


- (NSString *)textString {
    return [KZDemoText bigTextDemo];
}


@end
