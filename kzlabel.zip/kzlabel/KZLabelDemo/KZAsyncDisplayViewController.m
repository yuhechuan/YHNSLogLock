//
//  KZAsyncDisplayViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/17.
//

#import "KZAsyncDisplayViewController.h"
#import "KZLabel.h"
#import "UIView+KZExample.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZNavigationController.h"
#import "UIViewController+NavigationItem.h"

@interface KZTextAsyncExampleCell : UITableViewCell
@property (nonatomic, assign) BOOL async;
- (void)setAyncText:(NSAttributedString *)text;
@end


@implementation KZTextAsyncExampleCell {
    UILabel *_uiLabel;
    KZLabel *_kzLabel;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    _uiLabel = [UILabel new];
    _uiLabel.font = [UIFont systemFontOfSize:8];
    _uiLabel.numberOfLines = 0;
    _uiLabel.size = CGSizeMake(KZTextScreenSize().width, 34);
    
    _kzLabel = [[KZLabel alloc]init];
    _kzLabel.seniorDrawsAsynchronously = YES;
    _kzLabel.font = _uiLabel.font;
    _kzLabel.numberOfLines = _uiLabel.numberOfLines;
    _kzLabel.size = _uiLabel.size;
    _kzLabel.hidden = YES;
    
    [self.contentView addSubview:_uiLabel];
    [self.contentView addSubview:_kzLabel];
    return self;
}

- (void)setAsync:(BOOL)async {
    if (_async == async) return;
    _async = async;
    _uiLabel.hidden = async;
    _kzLabel.hidden = !async;
}

- (void)setAyncText:(id)text {
    if (_async) {
        _kzLabel.attributedText = text;
    } else {
        _uiLabel.attributedText = text;
    }
}

@end


@interface KZAsyncDisplayViewController ()

@property (nonatomic, copy) NSArray<NSAttributedString *> *strings;
@property (nonatomic, assign) BOOL async;

@end

@implementation KZAsyncDisplayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.tableView registerClass:[KZTextAsyncExampleCell class] forCellReuseIdentifier:NSStringFromClass([KZTextAsyncExampleCell class])];
    
    NSMutableArray *strings = [NSMutableArray new];
    for (int i = 0; i < 300; i++) {
        NSString *str = [NSString stringWithFormat:@"%d Async Display Test ✺◟(∗❛ัᴗ❛ั∗)◞✺ ✺◟(∗❛ัᴗ❛ั∗)◞✺ 😀😖😐😣😡🚖🚌🚋🎊💖💗💛💙🏨🏦🏫 Async Display Test ✺◟(∗❛ัᴗ❛ั∗)◞✺ ✺◟(∗❛ัᴗ❛ั∗)◞✺ 😀😖😐😣😡🚖🚌🚋🎊💖💗💛💙🏨🏦🏫",i];
        
        NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:str];
        text.kzFont = [UIFont systemFontOfSize:10];
        [strings addObject:text];
    }
    self.strings = strings;
    [self.tableView reloadData];
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.async = !weakSelf.async;
        [weakSelf.tableView reloadData];
    }];
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _strings.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 34;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KZTextAsyncExampleCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([KZTextAsyncExampleCell class]) forIndexPath:indexPath];
    cell.async = _async;
    [cell setAyncText:_strings[indexPath.row]];
    return cell;
}

@end
