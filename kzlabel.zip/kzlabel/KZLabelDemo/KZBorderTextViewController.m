//
//  KZBorderTextViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZBorderTextViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZTextDemoHelper.h"

@interface KZBorderTextViewController ()

@property (nonatomic, strong) KZLabel *label;


@end

@implementation KZBorderTextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    [self setUpUI];
}

- (void)setUpUI1 {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.backgroundColor = [UIColor whiteColor];
    label.frame = CGRectMake(100, kz_appGetNavHeight(), 80, self.view.bounds.size.height);
    label.textContainerInset = UIEdgeInsetsMake(0, 20, 0, 20);
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    [self.view addSubview:label];
    
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc]initWithString:@"😀😖😀😖😀😖"];
    att.kzLineSpacing = 5;
    KZTextBorder *boder = [KZTextBorder new];
    boder.underlineColor = [UIColor redColor];
    boder.underlineWidth = 1.0;
    boder.underlineStyle = KZBorderUnderLineCenterNormal;
    
    att.kzColor = [UIColor whiteColor];
    att.kzFont = [UIFont boldSystemFontOfSize:20];
    att.kzBorder = boder;
    label.attributedText = att;
    [label sizeToFit];
}

- (void)setUpUI {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.backgroundColor = [UIColor whiteColor];
    label.frame = CGRectMake(0, kz_appGetNavHeight(), self.view.bounds.size.width, self.view.bounds.size.height);
    label.textContainerInset = UIEdgeInsetsMake(0, 20, 0, 20);

    [self.view addSubview:label];
    
    NSMutableAttributedString *text = [NSMutableAttributedString new];

    {
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];

        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.borderColor = [UIColor colorWithRed:1.000 green:0.029 blue:0.651 alpha:1.000];
        border.borderWidth = 2;
        border.insets = UIEdgeInsetsMake(0, -4, 0, -4);
        border.fillColor = [UIColor colorWithRed:1.000 green:0.795 blue:0.014 alpha:1.000];
        border.cornerRadius = 3;
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Text Border" attributes:@{
                                                                                     NSFontAttributeName: [UIFont boldSystemFontOfSize:20],
                                                                                     NSForegroundColorAttributeName: [UIColor colorWithRed:1.000 green:0.029 blue:0.651 alpha:1.000],
                                                                                     KZTextBorderAttributedStringKey: border
                                                                                 }];

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor blackColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterNormal;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        boder.insets = UIEdgeInsetsMake(0, -5, 0, -5);
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"实线删除线"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:20];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor blackColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterDash;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"虚线删除线"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:20];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor redColor];
        boder.underlineWidth = 5.0;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        boder.underlineOffset = 3;
        boder.underLineLevel = KZBorderUnderLineLevelBottom;

        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"下划线"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:20];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor redColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineDash;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"虚线下划线"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:20];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    
    
    {
        [text appendAttributedString:[self padding]];

        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.borderStyle = KZBorderBlockAround;
        border.fillColor =  [UIColor colorWithRed:214/255.0 green:214/255.0 blue:214/255.0 alpha:1];
        border.cornerRadius = 3;
        border.insets = UIEdgeInsetsMake(-10, -10, -10, -10);
        
        NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"int main(int argc, char * argv[]) {\u2028\tint val = 1;\u2028\tint result = val + 66666;\u2028}"];

        NSMutableParagraphStyle *st = [NSMutableParagraphStyle new];
        st.lineSpacing = 6;
        
        one.kzFont =  [UIFont systemFontOfSize:17];
        one.kzColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
        one.kzBorder = border;
        one.kzParagraphStyle = st;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    
    {
        [text appendAttributedString:[self padding]];

        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.borderStyle = KZBorderBlockTiled;
        border.fillColor =  [UIColor colorWithRed:214/255.0 green:214/255.0 blue:214/255.0 alpha:1];
        border.cornerRadius = 3;
        border.insets = UIEdgeInsetsMake(-10, -10, -10, -10);
        
        NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"int main(int argc, char * argv[]) {\u2028\tint val = 1;\u2028\tint result = val + 66666;\u2028}"];

        NSMutableParagraphStyle *st = [NSMutableParagraphStyle new];
        st.lineSpacing = 6;
        
        one.kzFont =  [UIFont systemFontOfSize:17];
        one.kzColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
        one.kzBorder = border;
        one.kzParagraphStyle = st;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }
    

    label.attributedText = text;
    self.label = label;
}

- (NSAttributedString *)padding {
    NSMutableAttributedString *pad = [[NSMutableAttributedString alloc] initWithString:@"\n\n\n\n" attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:4]}];
    return pad;
}



@end
