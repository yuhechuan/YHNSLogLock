//
//  KZGestureClashViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/19.
//

#import "KZGestureClashViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIViewController+NavigationItem.h"
#import "UIImageView+YPWebImage.h"
#import "UIView+KZExample.h"
#import "NSBundle+KZExample.h"
#import "YPAnimatedImageView.h"

@interface KZGestureClashViewController ()

@property (nonatomic, strong) KZLabel *label;

@end

@implementation KZGestureClashViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUp];
}

- (void)setUp {
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    
    NSString *text  =@"@远恒之义：Apple 一直秉承制造所有人都能顺畅使用产品的理念，为迎接本周四的全球无障碍宣传日（每年五月第三个星期四），展示了一套为认知能力、视力、听力与肢体活动能力而设计的软件辅助功能。这些功能将于今年晚些时候推出，预计会在秋季的 iOS 17 正式版系统中上线。\n针对有认知障碍的用户，Apple 推出 Assistive Access，把电话、信息、相机、照片与音乐等 App 整合为一个单独的 App";
    
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc]initWithString:text];
    
    {
        YPImage *image = [YPImage imageNamed:@"test1@2x.gif"];
        YPAnimatedImageView *imageView = [[YPAnimatedImageView alloc] initWithImage:image];
        KZTextAttachment *attach = [[KZTextAttachment alloc]init];
        attach.content = imageView;
        attach.aligment = KZTextVerticalAlignmentBottom;
        attach.contentSize = CGSizeMake(120, 120);
        attach.clickAction = ^(KZTextAttachment *attachment, NSRange range) {
            NSLog(@"Text Attachment Click");
        };

        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:attach] mutableCopy];
        [attributedText appendAttributedString:attachText];
    }
    
    NSString *last = @"对于有语言能力障碍的用户，通过 Live Speech 新功能，他们可以在 iPhone 上打电话时键盘输入文字，当前设备会将文字转成语音并朗读出来。此外，对于面临失语风险的用户，他们可使用 iPhone 录制 15 分钟的音频，通过机器学习的 Personal Voice 技术，创建与自己嗓音相似的 AI 语音，后续就能使用此语音进行文字朗读。\n面对失明或低视力用户，iPhone 内置的放大器将新增 Point and Speak 功能，结合相机与激光雷达扫描，视障用户在使用微波炉等家用电器时，iPhone 能识别在按键区移动的手指，朗读出手指指向按键上的功能文字。";
   
    [attributedText appendAttributedString:[[NSAttributedString alloc]initWithString:last]];
    
    {
        NSRange range = [text rangeOfString:@"每年五月第三个星期四"];
        KZTextLink *link = [KZTextLink new];
        link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
        link.highlightColor = [UIColor yellowColor];
        link.highlightBackViewColor = [UIColor redColor];
        link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
            NSLog(@"Text Link Click");
        };
        [attributedText kzSetLink:link range:range];
    }
    

    UIFont *font = [UIFont systemFontOfSize:16];
    attributedText.kzFont = font;
    
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 12;
    
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = [self kzLabelFrame];
    [self.view addSubview:label];
 
    
    NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"...查看更多"];
    truncationAttributedText.kzColor = [[UIColor redColor] colorWithAlphaComponent:0.5];
    label.truncationAttributedText = truncationAttributedText;
    label.truncationAction = ^{
        NSLog(@"Text TruncationAction Click");
    };
    label.attributedText = attributedText;
    
    UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    [self.view addGestureRecognizer:ges];
}

- (CGRect)kzLabelFrame {
    return CGRectMake(20,  150, self.view.bounds.size.width - 40,  self.view.bounds.size.height - 300);;
}

- (void)tapAction:(UITapGestureRecognizer *)recognizer {
    NSLog(@"UITapGestureRecognizer Click");
}



@end
