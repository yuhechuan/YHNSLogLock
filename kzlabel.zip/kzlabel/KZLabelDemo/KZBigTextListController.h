//
//  KZBigTextListController.h
//  KZLabel
//
//  Created by yuhechuan on 2024/8/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZBigTextListController : UITableViewController

@end

NS_ASSUME_NONNULL_END
