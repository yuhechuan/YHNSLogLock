//
//  KZTruncatingViewController.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZTruncatingViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
