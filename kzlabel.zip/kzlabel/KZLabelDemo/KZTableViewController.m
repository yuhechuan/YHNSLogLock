//
//  KZTableViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/10/25.
//

#import "KZTableViewController.h"
#import "KZTextDemoHelper.h"
#import "KZLabelCell.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"

@interface KZTableViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataList;

@end

@implementation KZTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[KZLabelCell class] forCellReuseIdentifier:NSStringFromClass([KZLabelCell class])];
    [self.dataList addObject:[self create1]];
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KZLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([KZLabelCell class]) forIndexPath:indexPath];
    NSAttributedString *t  = self.dataList[indexPath.row];
    [cell refreshContent:t];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 150;
}

- (UITableView *)tableView {
    if (!_tableView) {
        CGFloat IphoneXBottom = kz_IsIphoneX() ? 34: 0;
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kz_appGetNavHeight(), [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - kz_appGetNavHeight()) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = UIColor.whiteColor;
        _tableView.contentInset = UIEdgeInsetsMake(0, 0, IphoneXBottom, 0);
        _tableView.scrollIndicatorInsets = UIEdgeInsetsMake(0, 0, IphoneXBottom, 0);
    }
    return _tableView;
}

- (NSAttributedString *)create1 {
    NSString *title = @"@玉河川 @周鹏祖 @徐建东 @张庆龙 @李强 @李亚平 @杨茂盛 @汪亚东";
    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:title];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.headIndent = 3;
    paragraphStyle.firstLineHeadIndent = 3;
    paragraphStyle.tailIndent = -3;
    [test addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, test.length)];
    
    NSArray *list  = @[@"@玉河川",@"@周鹏祖",@"@徐建东",@"@张庆龙",@"@李强",@"@李亚平",@"@杨茂盛",@"@汪亚东"];
    for (NSString *sub in list) {
        NSRange range = [title rangeOfString:sub];
        KZTextBorder *b = [[KZTextBorder alloc]init];
        b.borderStyle = KZBorderNormal;
        b.cornerRadius = 11;
        b.fillColor = [UIColor blueColor];
        b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
        b.avoidLineBreak = YES;
        [test addAttribute:KZTextBorderAttributedStringKey value:b range:range];
        [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    }
    test.kzFont = [UIFont systemFontOfSize:18];
    return test;
}

- (NSMutableArray *)dataList {
    if(!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

@end
