//
//  KZParagraphStyleViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/8/4.
//

#import "KZParagraphStyleViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZTextDemoHelper.h"

@interface KZParagraphStyleViewController ()<KZLabelDelegate>

@end

@implementation KZParagraphStyleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUpUI1];
}



- (void)setUpUI1 {
    KZLabel *label = [[KZLabel alloc]init];
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.numberOfLines = 0;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, 100, self.view.bounds.size.width - 40, self.view.bounds.size.height - 200);
    [self.view addSubview:label];
    
    NSString *separator = @"\u2029";
    NSAttributedString *separatorAttr = [[NSAttributedString alloc] initWithString:separator attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:0.01]}];
    
    
    NSString *s1 = @"\u2022主标题";
    NSString *s2 = @"\u0970副标题";
    NSString *s3 = @"\u0970副标题";

    NSMutableAttributedString *text1 = [[NSMutableAttributedString alloc]initWithString:s1 attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:20]}];
    
    NSMutableAttributedString *text2 = [[NSMutableAttributedString alloc]initWithString:s2];
    [text2 addAttributes:[self unorderedSublistAttributes] range:NSMakeRange(0, text2.length)];
    
    NSMutableAttributedString *text3 = [[NSMutableAttributedString alloc]initWithString:s3];
    [text3 addAttributes:[self unorderedSublistAttributes] range:NSMakeRange(0, text3.length)];
    
    [text1 appendAttributedString:separatorAttr];
    [text1 appendAttributedString:text2];

    [text1 appendAttributedString:separatorAttr];
    
    [text1 appendAttributedString:text3];
    label.attributedText = text1;
}

- (void)setUpUI2  {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.backgroundColor = [UIColor clearColor];
    label.frame = CGRectMake(0, kz_appGetNavHeight() + 20, self.view.bounds.size.width, self.view.bounds.size.height);

    [self.view addSubview:label];
    
    NSMutableAttributedString *text = [NSMutableAttributedString new];

    {
     
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor redColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterNormal;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"大"];
        one.kzFont = [UIFont boldSystemFontOfSize:20];
        one.kzBorder = boder;

        [text appendAttributedString:one];
    
    }
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor blueColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterNormal;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"小"];
        one.kzFont = [UIFont boldSystemFontOfSize:13];
        one.kzBorder = boder;

        [text appendAttributedString:one];
    
    }
    label.attributedText = text;
    
}

- (void)setUpUI3 {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.textVerticalAlignment = KZTextVerticalAlignmentCenter;
    label.backgroundColor = [[UIColor orangeColor] colorWithAlphaComponent:0.5];
    label.frame = CGRectMake(0, kz_appGetNavHeight() + 20, self.view.bounds.size.width, self.view.bounds.size.height);

    [self.view addSubview:label];
    
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.minimumLineHeight = 40;
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:@"测试一下" attributes:@{
        NSParagraphStyleAttributeName : style,
        NSFontAttributeName : [UIFont systemFontOfSize:16],
        NSStrikethroughStyleAttributeName: @(NSUnderlineStyleSingle),
    }];;
    
    label.attributedText = text;
    
    [label sizeToFit];
}

- (void)setUpUI4 {
    UILabel *label = [[UILabel alloc]init];
    label.numberOfLines = 0;
    label.backgroundColor = [[UIColor orangeColor] colorWithAlphaComponent:0.5];
    label.frame = CGRectMake(0, kz_appGetNavHeight() + 100, self.view.bounds.size.width, self.view.bounds.size.height);

    [self.view addSubview:label];
    
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.minimumLineHeight = 40;
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:@"测试一下abcd" attributes:@{
        NSParagraphStyleAttributeName : style,
        NSFontAttributeName : [UIFont systemFontOfSize:16],
        NSStrikethroughStyleAttributeName: @(5),
        NSStrikethroughColorAttributeName: [UIColor redColor],
    }];;

    
    label.attributedText = text;
    
    [label sizeToFit];
}

/// 无序子列表
- (NSDictionary *)unorderedSublistAttributes {
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.firstLineHeadIndent = 20;
    style.headIndent = 20;
    style.paragraphSpacingBefore = 0;
    style.lineBreakMode = NSLineBreakByCharWrapping;
    return @{
        NSParagraphStyleAttributeName : style,
        NSFontAttributeName : [UIFont systemFontOfSize:20]
    };
}

- (NSAttributedString *)padding {
    NSMutableAttributedString *pad = [[NSMutableAttributedString alloc] initWithString:@"\n" attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:18]}];
    return pad;
}


@end
