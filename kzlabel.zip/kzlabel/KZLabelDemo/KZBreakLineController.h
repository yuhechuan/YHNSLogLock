//
//  KZBreakLineController.h
//  KZLabel
//
//  Created by yuhechuan on 2023/9/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZBreakLineController : UIViewController

@end

NS_ASSUME_NONNULL_END
