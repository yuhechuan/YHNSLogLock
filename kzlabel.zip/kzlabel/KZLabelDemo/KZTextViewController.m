//
//  KZTextViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/8/29.
//

#import "KZTextViewController.h"
#import "KZContextRef.h"
#import "KZTextAttributes.h"
#import "NSMutableAttributedString+KZ.h"
#import "KZTextRendererEngine.h"

@interface KZTextLayoutManager : NSLayoutManager

@end

@implementation KZTextLayoutManager

- (void)drawBackgroundForGlyphRange:(NSRange)glyphsToShow atPoint:(CGPoint)origin {
    [super drawBackgroundForGlyphRange:glyphsToShow atPoint:origin];

}
- (void)drawGlyphsForGlyphRange:(NSRange)glyphsToShow atPoint:(CGPoint)origin {
    [super drawGlyphsForGlyphRange:glyphsToShow atPoint:origin];
}


@end

@interface KZTextViewController ()

@property (nonatomic, strong) KZTextRendererEngine *rendererEngine;

@end

@implementation KZTextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUp];
}

- (void)setUp {
    CGRect rect = CGRectMake(20, 100, self.view.bounds.size.width - 40, 500);
    CGSize size =  CGSizeMake(self.view.bounds.size.width - 40, 500);
    KZTextAttributes *attributes = [self textAttributesForRenderer] ;
    KZContextRef *ref = [self.rendererEngine readContextRefForTextAttributes:attributes containerSize:size];
    UITextView *textView = [[UITextView alloc] initWithFrame:rect textContainer:ref.textContainer];
    textView.tintColor = [[UIColor redColor] colorWithAlphaComponent:0.2];
    textView.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    textView.scrollEnabled = NO;
    textView.editable = NO;
    textView.selectable = NO;
    textView.textContainerInset = UIEdgeInsetsZero;
    [self.view addSubview:textView];
}

- (NSMutableAttributedString *)test1 {
    NSMutableAttributedString *text = [NSMutableAttributedString new];
    
    {
        NSShadow *shadow = [NSShadow new];
        shadow.shadowColor = [UIColor colorWithWhite:0.000 alpha:0.490];
        shadow.shadowOffset = CGSizeMake(0, 1);
        shadow.shadowBlurRadius = 5;
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Shadow" attributes:@{
                                                                                 NSFontAttributeName: [UIFont boldSystemFontOfSize:30],
                                                                                 NSForegroundColorAttributeName: [UIColor whiteColor],
                                                                                 NSShadowAttributeName: shadow
                                                                                 }];
        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
    }

    {
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.borderColor = [UIColor colorWithRed:1.000 green:0.029 blue:0.651 alpha:1.000];
        border.borderWidth = 3;
        border.insets = UIEdgeInsetsMake(0, -4, 0, -4);
        border.fillColor = [UIColor colorWithRed:1.000 green:0.795 blue:0.014 alpha:1.000];
        border.cornerRadius = 3;
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Text Border" attributes:@{
                                                                                     NSFontAttributeName: [UIFont boldSystemFontOfSize:30],
                                                                                     NSForegroundColorAttributeName: [UIColor colorWithRed:1.000 green:0.029 blue:0.651 alpha:1.000],
                                                                                     KZTextBorderAttributedStringKey: border
                                                                                 }];

        [text appendAttributedString:[self padding]];
        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
    }
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor blackColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterNormal;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Strikethrough"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
    }
    
    
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor redColor];
        boder.underlineWidth = 2.0;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Underline"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzBorder = boder;

        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
    }

    {
        KZTextLink *link = [[KZTextLink alloc]init];
        link.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
        link.highlightColor = [UIColor yellowColor];
        link.highlightBackViewColor = [UIColor redColor];
        link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
            NSLog(@"Text Link Click");
        };

        NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:@"Text Link"];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzLink = link;
        
        [text appendAttributedString:one];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];
        [text appendAttributedString:[self padding]];

    }
    [text kzSetAlignment:NSTextAlignmentCenter range:NSMakeRange(0, text.length)];
    
    {
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
        paragraphStyle.headIndent = 15;
        paragraphStyle.firstLineHeadIndent = 15;
        KZTextQuote *quote = [KZTextQuote new];
        quote.quoteWidth = 4;
        quote.quoteColor =  [UIColor lightGrayColor];
        quote.quoteLeft = 11;
        
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.fillColor = [[UIColor blueColor] colorWithAlphaComponent:0.1];
        border.insets = UIEdgeInsetsMake(0, 0, 0, 0);
        border.borderStyle = KZBorderBlockTiled;
        
        NSString *quoteText = @"『《我的阿勒泰》是作者十年来散文创作的合集。分为阿勒泰文字、阿勒泰角落和九篇雪三辑。这是一部描写疆北阿勒泰地区生活和风情的原生态散文集。充满生机活泼、新鲜动人的元素。记录作者在疆北阿勒泰地区生活的点滴，包括人与事的记忆。作者在十年前以天才的触觉和笔调初现文坛并引起震惊。作品风格清新、明快，质地纯粹，原生态地再现了疆北风物，带着非常活泼的生机。』";
        NSDictionary *dict = @{NSFontAttributeName: [UIFont preferredFontForTextStyle:UIFontTextStyleCallout],
                               NSParagraphStyleAttributeName: paragraphStyle,
                               KZTextQuoteAttributedStringKey: quote,
                               KZTextBorderAttributedStringKey:border
        };
        NSMutableAttributedString *one = [[NSMutableAttributedString alloc] initWithString:quoteText
                                                                                attributes:dict];
        KZTextLink *link = [[KZTextLink alloc]init];
        link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
            NSURL *URL = [NSURL URLWithString:@"https://book.douban.com/subject/4884218/"];
            [UIApplication.sharedApplication openURL:URL options:@{} completionHandler:nil];
        };
        link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
        NSRange bookRange = [quoteText rangeOfString:@"《我的阿勒泰》"];
        [one kzSetLink:link range:bookRange];
        
        [text appendAttributedString:one];
        
        [text appendAttributedString:[self padding]];
    }
    return text;
}

- (NSAttributedString *)test2 {
    NSString *str = @"从后来的结果来看，李斯在荀子那里学到了帝王之术，但没有学到治国之道。李斯曾问荀子：“秦四世有胜，兵强海内，威行诸侯。”意思是秦朝四代的胜利战果，都不是靠仁义来取胜的，而是根据有利于自己的利益做事罢了。可以看出，李斯一开始就对儒家的仁义不屑一顾。荀子回答：“皆前行素修也,所谓仁义之兵也。今女不求之于本";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    text.kzFont = [UIFont systemFontOfSize:20];
    return text;
}

- (NSMutableAttributedString *)test3 {
    NSMutableAttributedString *text = [NSMutableAttributedString new];
    {
        KZTextBorder *boder = [KZTextBorder new];
        boder.underlineColor = [UIColor blackColor];
        boder.underlineWidth = 2.0;
        boder.underlineStyle = KZBorderUnderLineCenterNormal;
        boder.fillColor = [UIColor colorWithWhite:0.000 alpha:0.220];
        boder.cornerRadius = 3;
        
        NSMutableAttributedString *one =
        [[NSMutableAttributedString alloc] initWithString:@"Strikethrough"];
        one.kzColor = [UIColor whiteColor];
        one.kzFont = [UIFont boldSystemFontOfSize:30];
        one.kzBorder = boder;

        [text appendAttributedString:one];
    }
    return text;
}


- (NSAttributedString *)padding {
    NSMutableAttributedString *pad = [[NSMutableAttributedString alloc] initWithString:@"\n\n" attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:4]}];
    return pad;
}


- (KZTextAttributes *)textAttributesForRenderer {
    KZTextAttributes *attributes = [[KZTextAttributes alloc]init];
    attributes.attributedText = [self test1];
    attributes.numberOfLines = 0;
    return attributes;
}

- (KZTextRendererEngine *)rendererEngine {
    if(!_rendererEngine) {
        _rendererEngine = [[KZTextRendererEngine alloc]init];
    }
    return _rendererEngine;
}

@end
