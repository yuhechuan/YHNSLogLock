//
//  KZSelectionViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/17.
//

#import "KZSelectionViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "YPMenuItem.h"
#import "KZTextDemoHelper.h"
#import "UIView+KZExample.h"
#import "UIColor+KZExtension.h"
#import "YPMenuController.h"

@interface KZSelectionViewController ()<KZLabelMenuDelegate>

@property (nonatomic, strong) KZLabel *label;


@end

@implementation KZSelectionViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [KZTextDemoHelper popGestureClose:self];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [KZTextDemoHelper popGestureOpen:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    YPMenuStyleConfig *config = [[YPMenuStyleConfig alloc] init];
    config.menuType = YPMenuControllerCustom;
    config.barContentHeight = 45;
    [YPMenuController sharedMenuController].styleConfig = config;
    
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    scrollView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:scrollView];
    scrollView.contentSize = CGSizeMake(scrollView.width, self.view.height *2);
    scrollView.scrollEnabled = YES;
    scrollView.bounces = YES;
    scrollView.alwaysBounceVertical = YES;
    
    [self setUpLabels:scrollView];
}

- (void)setUpLabels:(UIScrollView *)scrollView {
    // Do any additional setup after loading the view.
//    NSString *text = @"1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色，大片裸露的黄土地述说着贫瘠但充满希望的生活。窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着，心里却想着赶紧逃离这里，到外面的寒冷里去。她第一次与男人以这样的方式独处，显得紧张，不知所措。与她同坐在炕边的男人，倒是显得轻松自然。她感觉这个男的一直盯着她看。她在心里骂他，看啥看，有啥看的，再看扣了你的眼珠子。男人见侗月花不看自己，就开始问这，问哪的，她一直保持沉默，啥话似乎都没有听进去。男人见她只是低头，看她她不理睬，问她她不答话。心想不会得病哑巴了吧。两个青年男女这样干坐着也不是事。只见男人下了坑边，走向门口，打开门出去了。侗月花想她才15岁呀，父亲竟然早早托了人给她寻婆家。今天晌午，还没到做中午饭时间，父亲就让她把灶膛的火加旺，让她打扮一下自己，不要跑出去了。说一会来个人，父亲让侗月花好好看看，如果相中了，这事就定下来了。侗月花脑子一片空白，她一点思想准备都没有。她还觉得自己是孩子，整天还和村里的小伙子打架骂嘴，和伙伴们忙着帮持家，还想着多认识几个字，想着上进呢。哪想到自己这么早就要被卖出去。父亲不容她发表任何意见，就大声骂她，让她在窑洞里等着。";
    
    CGFloat x = 20;
    CGFloat width = self.view.bounds.size.width - 40;
    CGFloat y =  kz_appGetNavHeight();
    KZLabel *label = [self createKzLabelWithFrame:CGRectMake( x + 100 , y, width, 0)];
    label.text = @"1963年初冬";
    label.useWordSelect = NO;
    [label sizeToFit];
    label.left = (self.view.bounds.size.width - label.width) / 2.0;
    [scrollView addSubview:label];
  
    
    KZLabel *label1 = [self createKzLabelWithFrame:CGRectMake( x , CGRectGetMaxY(label.frame) + 30, width, 0)];
    label1.text = @"显得紧张不知所措";
    label1.useWordSelect = NO;
    label1.tintColor = [UIColor blueColor];
    [label1 sizeToFit];
    label1.left = (self.view.bounds.size.width - label1.width) / 2.0;
    [scrollView addSubview:label1];
    
    
    KZLabel *label2 = [self createKzLabelWithFrame:CGRectMake( x , CGRectGetMaxY(label1.frame) + 30, width, 0)];
    label2.text = @"窑洞内与坑连接的灶台";
    label2.canShowMagnifier = NO;
    label2.useWordSelect = NO;
    label2.tintColor = [UIColor greenColor];
    [label2 sizeToFit];
    label2.left = (self.view.bounds.size.width - label2.width) / 2.0;
    [scrollView addSubview:label2];
    
    
    KZLabel *label3 = [self createKzLabelWithFrame:CGRectMake( x , CGRectGetMaxY(label2.frame) + 30, width, 500)];
    label3.text = @"1.男人见侗月花不看自己，就开始问这\n2.问哪的，她一直保持沉默，啥话似乎都没有听进去。\n3.男人见她只是低头，看她她不理睬，问她她不答话。心想不会得病哑巴了吧。\n4.两个青年男女这样干坐着也不是事。只见男人下了坑边，走向门口，打开门出去了。\n5.侗月花想她才15岁呀，父亲竟然早早托了人给她寻婆家。\n6.今天晌午，还没到做中午饭时间，父亲就让她把灶膛的火加旺，让她打扮一下自己，不要跑出去了。\n7.说一会来个人，父亲让侗月花好好看看，如果相中了，这事就定下来了。\n8.侗月花脑子一片空白，她一点思想准备都没有。\n9.她还觉得自己是孩子，整天还和村里的小伙子打架骂嘴，和伙伴们忙着帮持家，还想着多认识几个字，想着上进呢。\n10.哪想到自己这么早就要被卖出去。父亲不容她发表任何意见，就大声骂她，让她在窑洞里等着。1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色，大片裸露的黄土地述说着贫瘠但充满希望的生活。窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着，心里却想着赶紧逃离这里，到外面的寒冷里去。她第一次与男人以这样的方式独处，显得紧张，不知所措。与她同坐在炕边的男人，倒是显得轻松自然。她感觉这个男的一直盯着她看。她在心里骂他，看啥看，有啥看的，再看扣了你的眼珠子。男人见侗月花不看自己，就开始问这，问哪的，她一直保持沉默，啥话似乎都没有听进去。男人见她只是低头，看她她不理睬，问她她不答话。心想不会得病哑巴了吧。两个青年男女这样干坐着也不是事。只见男人下了坑边，走向门口，打开门出去了。侗月花想她才15岁呀，父亲竟然早早托了人给她寻婆家。今天晌午，还没到做中午饭时间，父亲就让她把灶膛的火加旺，让她打扮一下自己，不要跑出去了。说一会来个人，父亲让侗月花好好看看，如果相中了，这事就定下来了。侗月花脑子一片空白，她一点思想准备都没有。她还觉得自己是孩子，整天还和村里的小伙子打架骂嘴，和伙伴们忙着帮持家，还想着多认识几个字，想着上进呢。哪想到自己这么早就要被卖出去。父亲不容她发表任何意见，就大声骂她，让她在窑洞里等着。";
    label3.tintColor = [UIColor cyanColor];
    label3.magnifierType = KZTextMagnifierTypeCaret;
    label3.truncationAttributedText = [self getTruncationAttrStr];
    label3.truncationAction = ^{
        NSLog(@"");
    };
    [scrollView addSubview:label3];
    
    self.label = label3;
    [self setUpLabels1:scrollView view:label3];
}

/**
 * 获取折叠展开的点击文字
 */
- (NSAttributedString *)getTruncationAttrStr {
    NSString *unfoldString = @"...查看全部";
    NSMutableAttributedString *mutaAttr = [[NSMutableAttributedString alloc] initWithString:unfoldString attributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize:20],
        NSForegroundColorAttributeName: HEXColor(@"#333333")
    }];
    [mutaAttr addAttributes:@{NSForegroundColorAttributeName: HEXColor(@"#0D9EA3")} range:NSMakeRange(3, unfoldString.length - 3)];
    return [mutaAttr copy];
}

- (void)setUpLabels1:(UIScrollView *)scrollView view:(UIView *)view {
    // Do any additional setup after loading the view.
//    NSString *text = @"1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色，大片裸露的黄土地述说着贫瘠但充满希望的生活。窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着，心里却想着赶紧逃离这里，到外面的寒冷里去。她第一次与男人以这样的方式独处，显得紧张，不知所措。与她同坐在炕边的男人，倒是显得轻松自然。她感觉这个男的一直盯着她看。她在心里骂他，看啥看，有啥看的，再看扣了你的眼珠子。男人见侗月花不看自己，就开始问这，问哪的，她一直保持沉默，啥话似乎都没有听进去。男人见她只是低头，看她她不理睬，问她她不答话。心想不会得病哑巴了吧。两个青年男女这样干坐着也不是事。只见男人下了坑边，走向门口，打开门出去了。侗月花想她才15岁呀，父亲竟然早早托了人给她寻婆家。今天晌午，还没到做中午饭时间，父亲就让她把灶膛的火加旺，让她打扮一下自己，不要跑出去了。说一会来个人，父亲让侗月花好好看看，如果相中了，这事就定下来了。侗月花脑子一片空白，她一点思想准备都没有。她还觉得自己是孩子，整天还和村里的小伙子打架骂嘴，和伙伴们忙着帮持家，还想着多认识几个字，想着上进呢。哪想到自己这么早就要被卖出去。父亲不容她发表任何意见，就大声骂她，让她在窑洞里等着。";
    
    CGFloat x = 20;
    CGFloat width = self.view.bounds.size.width - 40;
    CGFloat y =  CGRectGetMaxY(view.frame) + 20;
    KZLabel *label = [self createKzLabelWithFrame:CGRectMake( x + 100 , y, width, 0)];
    label.text = @"她第一次与男人以这样的方式独处，显得紧张，不知所措。与她同坐在炕边的男人倒是显得轻松自然。她感觉这个男的一直盯着她看。";
    label.useWordSelect = NO;
    [label sizeToFit];
    label.left = (self.view.bounds.size.width - label.width) / 2.0;
    [scrollView addSubview:label];
  
    
    KZLabel *label1 = [self createKzLabelWithFrame:CGRectMake( x , CGRectGetMaxY(label.frame) + 30, width, 0)];
    label1.text = @"她还觉得自己是孩子";
    label1.useWordSelect = NO;
    label1.tintColor = [UIColor blueColor];
    [label1 sizeToFit];
    label1.left = (self.view.bounds.size.width - label1.width) / 2.0;
    [scrollView addSubview:label1];
    
    
    KZLabel *label2 = [self createKzLabelWithFrame:CGRectMake( x , CGRectGetMaxY(label1.frame) + 30, width, 0)];
    label2.text = @"窑洞";
    label2.canShowMagnifier = NO;
    label2.useWordSelect = NO;
    label2.tintColor = [UIColor greenColor];
    [label2 sizeToFit];
    label2.left = (self.view.bounds.size.width - label2.width) / 2.0;
    [scrollView addSubview:label2];
    
    
    KZLabel *label3 = [self createKzLabelWithFrame:CGRectMake( x , CGRectGetMaxY(label2.frame) + 30, width, 150)];
    label3.text = @"侗月花想她才15岁呀，父亲竟然早早托了人给她寻婆家。今天晌午，还没到做中午饭时间，父亲就让她把灶膛的火加旺，让她打扮一下自己，不要跑出去了。说一会来个人，父亲让侗月花好好看看，如果相中了，这事就定下来了。侗月花脑子一片空白，她一点思想准备都没有。她还觉得自己是孩子，整天还和村里的小伙子打架骂嘴，和伙伴们忙着帮持家，还想着多认识几个字，想着上进呢。哪想到自己这么早就要被卖出去。父亲不容她发表任何意见，就大声骂她，让她在窑洞里等着。";
    label3.tintColor = [UIColor cyanColor];
    label3.magnifierType = KZTextMagnifierTypeCaret;
    label3.useWordSelect = NO;
    [scrollView addSubview:label3];
    
    
    UIImage *image = [UIImage imageNamed:@"dribbble64_imageio"];
    [label3 configTruncationWithContent:image contentSize:CGSizeMake(label3.font.lineHeight, label3.font.lineHeight) clickAction:^{
        [label3 sizeToFit];
        NSLog(@"Truncation 点击");
    }];
    label3.forbidSelectableWhenTruncated = YES;

}

- (KZLabel *)createKzLabelWithFrame:(CGRect)frame {
    KZLabel *label = [[KZLabel alloc]init];
    label.menuDelegate = self;
    label.numberOfLines = 0;
    label.textColor = HEXColor(@"#333333");
    label.font = [UIFont systemFontOfSize:20];
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.selectable = YES;
    label.tintColor = [UIColor redColor];
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = frame;
    return label;
}


//- (NSArray *)menuItemsForLabel:(KZLabel *)label {
//    SEL action1 = NSSelectorFromString(@"menuHighLightAction:");
//    NSString *itemTitle1 = @"高亮显示";
//    YPMenuItem *item1 = [[YPMenuItem alloc] initSystemWithAction:action1
//                                                           title:itemTitle1];
//    
//    SEL action2 = NSSelectorFromString(@"menuCopyAction:");
//    NSString *itemTitle2 = @"复制链接";
//    YPMenuItem *item2 = [[YPMenuItem alloc] initSystemWithAction:action2
//                                                           title:itemTitle2];
//    return @[item1, item2];
//}

- (NSArray *)menuItemsForLabel:(KZLabel *)label {
    
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn1.frame = CGRectMake(0, 0, 80, 45);
    [btn1 setTitle:@"复制" forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(customViewTypeAction1:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn2.frame = CGRectMake(0, 0, 80, 45);
    [btn2 setTitle:@"搜索" forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(customViewTypeAction2:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn3.frame = CGRectMake(0, 0, 80, 45);
    [btn3 setTitle:@"全选" forState:UIControlStateNormal];
    [btn3 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn3 addTarget:self action:@selector(customViewTypeAction3:) forControlEvents:UIControlEventTouchUpInside];
    
    YPMenuItem *item = [[YPMenuItem alloc] initWithCustomView:btn1];
    YPMenuItem *item1 = [[YPMenuItem alloc] initWithCustomView:btn2];
    YPMenuItem *item2 = [[YPMenuItem alloc] initWithCustomView:btn3];
    return  @[item,item1,item2];
}

- (void)customViewTypeAction1:(id)act {
    [[YPMenuController sharedMenuController] menuInvisibleWithAnimated:YES];
}

- (void)customViewTypeAction2:(id)act {
    [[YPMenuController sharedMenuController] menuInvisibleWithAnimated:YES];
}

- (void)customViewTypeAction3:(id)act {
    [self.label setSelectedRange:NSMakeRange(0, self.label.text.length) showMenuController:YES];
}


- (void)menuHighLightAction:(id)act {
    
}

- (void)menuCopyAction:(id)act {
    
}

- (BOOL)label:(KZLabel *)label shouldShowMenuForRange:(NSRange)range selectContent:(NSAttributedString *)selectContent {
    NSLog(@"shouldShowMenuForRange");
    NSString *str = [selectContent.string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (str.length == 0) {
        return NO;
    }
    return YES;
}

- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent {
    NSLog(@"didChangeSelectContent:%@", selectContent);
    self.label = label;
}

- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent selectRange:(NSRange)selectRange {
    NSLog(@"didChangeSelectContent:%@ selectRange:[location:%ld],[length:%ld]", selectContent, selectRange.location, selectRange.length);
    self.label = label;
    
}


@end
