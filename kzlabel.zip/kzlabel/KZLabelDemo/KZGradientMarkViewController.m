//
//  KZGradientMarkViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZGradientMarkViewController.h"
#import "KZLabel.h"
#import "UIColor+KZExtension.h"

@interface KZGradientMarkViewController ()

@property (nonatomic, strong) KZLabel *label1;
@property (nonatomic, strong) KZLabel *label2;

@end

@implementation KZGradientMarkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addLabel1];
    [self addLabel2];
}

- (void)addLabel1 {
    NSString *text = @"1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色，大片裸露的黄土地述说着贫瘠但充满希望的生活。";
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeGradientMark];
    label.numberOfLines = 0;
    label.frame = CGRectMake(20,  100, self.view.bounds.size.width - 40,  self.view.bounds.size.height - 250);
    UIFont *font = [UIFont systemFontOfSize:20];
    label.font = font;
    label.text = text;
    label.gradientColors = @[[UIColor blueColor],[UIColor greenColor]];;
    
    [label sizeToFit];
    [self.view addSubview:label];
    self.label1 = label;
}

- (void)addLabel2 {
    NSString *text = @"窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着，心里却想着赶紧逃离这里，到外面的寒冷里去。她第一次与男人以这样的方式独处，显得紧张，不知所措。与她同坐在炕边的男人，倒是显得轻松自然。";
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeGradientMark];
    label.numberOfLines = 0;
    label.frame = CGRectMake(20, CGRectGetMaxY(self.label1.frame) + 20, self.view.bounds.size.width - 40,  self.view.bounds.size.height - 250);
    UIFont *font = [UIFont systemFontOfSize:20];
    label.font = font;
    label.text = text;
    
    CAGradientLayer *layer = [[CAGradientLayer alloc]init];
    layer.startPoint = CGPointMake(0, 0.5);
    layer.endPoint = CGPointMake(1, 0.5);
    layer.locations = @[ @(0), @(1.0f) ];
    layer.colors = @[(__bridge id)[UIColor redColor].CGColor, (__bridge id)[UIColor blueColor].CGColor];
    
    label.gradientLayer = layer;
    
    [label sizeToFit];
    [self.view addSubview:label];
    self.label2 = label;
}


@end
