//
//  KZTruncatingViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/16.
//

#import "KZTruncatingViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIView+KZExample.h"

@interface KZTruncatingViewController ()

@property (nonatomic, strong) KZLabel *label;
@property (nonatomic, strong) KZLabel *label1;
@property (nonatomic, strong) KZLabel *label2;
@property (nonatomic, strong) KZLabel *label3;

@end

@implementation KZTruncatingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    [self setUpUI1];
}

- (void)setUpUI1 {
    KZLabel *label = [[KZLabel alloc]init];
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.numberOfLines = 2;
    label.lineBreakMode = NSLineBreakByCharWrapping;
    label.frame = CGRectMake(20, 100, self.view.bounds.size.width - 40, 260);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    
    NSString *str = @"The range of glyphs that would need to be displayed in order to draw all glyphs that fall (even partially) within the given bounding rectangle. The range returned can include glyphs that don’t fall inside or intersect bounds, although the first and last glyphs in the range always do. At most this method returns the glyph range for the whole container。";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    text.kzFont = [UIFont systemFontOfSize:20];
    
    NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"...更多"];
    truncationAttributedText.kzFont = [UIFont systemFontOfSize:18];
    truncationAttributedText.kzColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
    label.truncationAttributedText =truncationAttributedText;
    __weak __typeof(self)weakSelf = self;
    label.truncationAction = ^{
        weakSelf.label.numberOfLines = 0;
    };
    label.attributedText = text;
    [label sizeToFit];
    self.label = label;
    [self setUpUI2:label];
}


- (void)setUpUI2:(KZLabel *)l  {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 3;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.truncationActionExpendInset = UIEdgeInsetsMake(-10, -10, -10, -10);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(l.frame) +20, self.view.bounds.size.width - 40,  150);
    [self.view addSubview:label];
    
    NSString *str = @"Set up the bridge: Depending on the platform you're working with (e.g., Android, iOS, React Native), you'll need to set up a bridge that enables communication between the native code and your JavaScript code. ";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    UIFont *font = [UIFont systemFontOfSize:20];
    text.kzFont = font;
    UIImage *image = [UIImage imageNamed:@"dribbble64_imageio"];
    __weak __typeof(self)weakSelf = self;
    KZTextAttachment *truncation = [[KZTextAttachment alloc]init];
    truncation.content = image;
    truncation.contentSize = CGSizeMake(font.lineHeight, font.lineHeight);
    truncation.clickAction = ^(KZTextAttachment *attachment, NSRange range) {
        weakSelf.label1.numberOfLines = 0;
    };
    NSAttributedString *attachText = [[NSAttributedString attributedStringWithAttachment:truncation] mutableCopy];
   
    label.additionalTruncationAttributedText = attachText;
    NSMutableAttributedString *start = [[NSMutableAttributedString alloc]initWithString:@"..."];
    label.truncationAttributedText = start;
    
    label.attributedText = text;
    self.label1 = label;
    [self setUpUI3:label];
}

- (void)setUpUI3:(KZLabel *)l {
    KZLabel *label = [[KZLabel alloc]init];
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.numberOfLines = 1;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(l.frame) +20, self.view.bounds.size.width - 40, 50);
    [self.view addSubview:label];
    
    NSString *str = @"从后来的结果来看，李斯在荀子\n那里学到了帝王之术，但没有学到治国之道。李斯曾问荀子：“秦四世有胜，兵强海内，威行诸侯。”意思是秦朝四代的胜利战果，都不是靠仁义，而是根据有利于自己的利益做事罢了。";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    text.kzFont = [UIFont systemFontOfSize:20];
    
    NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"..."];
    truncationAttributedText.kzFont = [UIFont systemFontOfSize:18];
    truncationAttributedText.kzColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
    label.truncationAttributedText = truncationAttributedText;
    __weak __typeof(self)weakSelf = self;
    label.truncationAction = ^{
        weakSelf.label2.numberOfLines = 0;
    };
    label.attributedText = text;
    self.label2 = label;
    [self setUpUI4:label];
}


- (void)setUpUI4:(KZLabel *)l {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 2;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.truncationActionExpendInset = UIEdgeInsetsMake(-10, -10, -10, -10);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(l.frame) + 20, self.view.bounds.size.width - 40,  60);
    [self.view addSubview:label];
    
    NSString *str = @"从后来的结果来看";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    UIFont *font = [UIFont systemFontOfSize:20];
    text.kzFont = font;
    UIImage *image = [UIImage imageNamed:@"dribbble64_imageio"];
    __weak __typeof(self)weakSelf = self;
    KZTextAttachment *truncation = [[KZTextAttachment alloc]init];
    truncation.content = image;
    truncation.contentSize = CGSizeMake(32, 32);
    truncation.alignToFont = font;
    truncation.clickAction = ^(KZTextAttachment *attachment, NSRange range) {
        weakSelf.label3.numberOfLines = 0;
    };
    NSAttributedString *attachText = [[NSAttributedString attributedStringWithAttachment:truncation] mutableCopy];
    label.additionalTruncationAttributedText = attachText;
    NSMutableAttributedString *start = [[NSMutableAttributedString alloc]initWithString:@"..."];
    label.truncationAttributedText = start;
    
    label.attributedText = text;
    self.label3 = label;

    [self setUpUI5:label];
}

- (void)setUpUI5:(KZLabel *)l  {
    KZLabel *label = [[KZLabel alloc]init];
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.numberOfLines = 2;
    label.lineBreakMode = NSLineBreakByCharWrapping;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(l.frame) + 20 , self.view.bounds.size.width - 40, 150);
    [self.view addSubview:label];
    
    NSString *str = @"从后来的结果来看，李斯在荀子那里学到了帝王之术，但没有学到治国之道。李斯曾问荀子：“秦四世有胜，兵强海内，威行诸侯。”意思是秦朝四代的胜利战果，都不是靠仁义，而是根据有利于自己的利益做事罢了。";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    text.kzFont = [UIFont systemFontOfSize:20];
    
    NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"...更多"];
    truncationAttributedText.kzFont = [UIFont systemFontOfSize:18];
    truncationAttributedText.kzColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
//    label.truncationAttributedText =truncationAttributedText;
//    __weak __typeof(self)weakSelf = self;
//    label.truncationAction = ^{
//        weakSelf.label.numberOfLines = 0;
//    };
    label.attributedText = text;
    [label sizeToFit];
}

@end
