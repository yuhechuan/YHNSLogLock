//
//  KZImageMarkViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/23.
//

#import "KZImageMarkViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"

@interface KZImageMarkViewController ()

@property (nonatomic, strong) KZLabel *label1;
@property (nonatomic, strong) KZLabel *label2;

@end

@implementation KZImageMarkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addLabel1];
    [self addLabel2];
}

- (void)addLabel1 {
    NSString *text = @"1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色";
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeImageMark];
    label.numberOfLines = 0;
    label.frame = CGRectMake(20,  100, self.view.bounds.size.width - 40,  self.view.bounds.size.height - 250);
    UIFont *font = [UIFont systemFontOfSize:28];
    label.font = font;
    label.text = text;
    label.markImage = [UIImage imageNamed:@"text_bg4.jpg"];
    [label sizeToFit];
    [self.view addSubview:label];
    self.label1 = label;
}

- (void)addLabel2 {
    NSString *text = @"窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着。";
    KZLabel *label = [KZLabel allocWithType:KZLabelTypeImageMark];
    label.numberOfLines = 0;
    label.frame = CGRectMake(20, CGRectGetMaxY(self.label1.frame) + 20, self.view.bounds.size.width - 40,  self.view.bounds.size.height - 250);
    UIFont *font = [UIFont systemFontOfSize:28];
    label.font = font;
    label.text = text;
    label.markImage = [UIImage imageNamed:@"text_bg3.jpeg"];
    [label sizeToFit];
    [self.view addSubview:label];
    self.label2 = label;
}


@end
