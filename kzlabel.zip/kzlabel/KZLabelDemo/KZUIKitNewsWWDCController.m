//
//  KZUIKitNewsWWDCController.m
//  KZLabel
//
//  Created by yuhechuan on 2024/6/20.
//

#import "KZUIKitNewsWWDCController.h"

/**
 *UITextInput 
 *https://www.cnblogs.com/ChouDanDan/p/5051912.html
 */

@interface KZSelectionView : UIView <UITextInput, UITextSelectionDisplayInteractionDelegate>

@end

@implementation KZSelectionView

@synthesize selectedTextRange;
@synthesize markedTextRange;
@synthesize markedTextStyle;
@synthesize beginningOfDocument;
@synthesize endOfDocument;
@synthesize inputDelegate;
@synthesize tokenizer;
@synthesize hasText;


- (void)textSelectionDisplayInteraction {
    if (@available(iOS 17.0, *)) {
        UITextSelectionDisplayInteraction *interaction = [[UITextSelectionDisplayInteraction alloc]initWithTextInput:self delegate:self];
        [self addInteraction:interaction];
    } else {
        // Fallback on earlier versions
    }
}

/* Methods for manipulating text. */
- (nullable NSString *)textInRange:(UITextRange *)range {
    return nil;
}
- (void)replaceRange:(UITextRange *)range withText:(NSString *)text {
    
}

- (void)setMarkedText:(nullable NSString *)markedText selectedRange:(NSRange)selectedRange {
    
}
- (void)unmarkText {
    
}

/* Methods for creating ranges and positions. */
- (nullable UITextRange *)textRangeFromPosition:(UITextPosition *)fromPosition toPosition:(UITextPosition *)toPosition {
    return nil;
}
- (nullable UITextPosition *)positionFromPosition:(UITextPosition *)position offset:(NSInteger)offset {
    return nil;
}
- (nullable UITextPosition *)positionFromPosition:(UITextPosition *)position inDirection:(UITextLayoutDirection)direction offset:(NSInteger)offset {
    return nil;
}

/* Simple evaluation of positions */
- (NSComparisonResult)comparePosition:(UITextPosition *)position toPosition:(UITextPosition *)other {
    return NSOrderedSame;
}
- (NSInteger)offsetFromPosition:(UITextPosition *)from toPosition:(UITextPosition *)toPosition {
    return 0;
}

/* Layout questions. */
- (nullable UITextPosition *)positionWithinRange:(UITextRange *)range farthestInDirection:(UITextLayoutDirection)direction {
    return  nil;
    
}
- (nullable UITextRange *)characterRangeByExtendingPosition:(UITextPosition *)position inDirection:(UITextLayoutDirection)direction {
    return nil;
}

/* Writing direction */
- (NSWritingDirection)baseWritingDirectionForPosition:(UITextPosition *)position inDirection:(UITextStorageDirection)direction {
    return NSWritingDirectionLeftToRight;
}
- (void)setBaseWritingDirection:(NSWritingDirection)writingDirection forRange:(UITextRange *)range {
}

/* Geometry used to provide, for example, a correction rect. */
- (CGRect)firstRectForRange:(UITextRange *)range {
    return CGRectZero;
}
- (CGRect)caretRectForPosition:(UITextPosition *)position {
    return CGRectZero;
}
- (NSArray<UITextSelectionRect *> *)selectionRectsForRange:(UITextRange *)range {
    return @[];
}
/* Hit testing. */
- (nullable UITextPosition *)closestPositionToPoint:(CGPoint)point {
    return nil;
}
- (nullable UITextPosition *)closestPositionToPoint:(CGPoint)point withinRange:(UITextRange *)range {
    return nil;
}
- (nullable UITextRange *)characterRangeAtPoint:(CGPoint)point {
    return nil;
}

- (void)insertText:(NSString *)text {
}
- (void)deleteBackward {
    
}

@end


@interface KZUIKitNewsWWDCController ()

@end

@implementation KZUIKitNewsWWDCController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    KZSelectionView *selection = [[KZSelectionView alloc]initWithFrame:CGRectMake(50, 100, self.view.bounds.size.width - 100, 200)];
    selection.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:selection];
}

@end
