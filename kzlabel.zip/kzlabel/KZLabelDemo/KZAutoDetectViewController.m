//
//  KZAutoDetectViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/19.
//

#import "KZAutoDetectViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "NSBundle+KZExample.h"
#import "YPMenuItem.h"
#import "YPAnimatedImageView.h"
#import "UIViewController+NavigationItem.h"
#import "YPMenuController.h"

@interface KZAutoDetectViewController ()<KZLabelMenuDelegate,KZLabelAutoDetectDelegate>

@property (nonatomic, copy) NSString *selectContent;
@property (nonatomic, strong) KZLabel *label;
@property (nonatomic, strong) NSBundle *emjoBundle;

@end

@implementation KZAutoDetectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UITapGestureRecognizer *tap =[[ UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick)];
    [self.view addGestureRecognizer:tap];
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    
    YPMenuStyleConfig *config = [[YPMenuStyleConfig alloc] init];
    [YPMenuController sharedMenuController].styleConfig = config;
    [self setUp];
}

- (void)tapClick {
}

- (void)setUp {
    NSString *text = @"😀😖😐😣@东坡肘子: [001]随着疫情得到控制，[002]越来😀😖😐😣越多的线下活动👩‍❤️‍👨👩‍❤️‍💋‍👨💏👨‍❤️‍💋‍👨得以顺利举办。😀😖😐😣18612764897作者用了三篇博文总结了[003] 2023 年 Deep Dish Swift 😀👩‍❤️‍👨😖😐😣会议的演讲内容。446751836@qq.com 第一天的演讲涵盖了独立开发😀😖😐😣者的讲座、订阅模型、CI/CD 自动化和 ASO。第二天的演👩‍❤️‍👨👩‍❤️‍💋‍👨💏👨‍❤️‍💋‍👨讲涵盖了公司销售、Swift 算法、😀😖👩‍❤️‍👨👩‍❤️‍💋‍👨💏👨‍❤️‍💋‍👨😐😣";
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc]initWithString:text];
    KZLabel *label = [[KZLabel alloc]init];
    label.frame = [self kzLabelFrame];
    label.numberOfLines = 0;
    label.selectable = YES;
    label.menuDelegate = self;
    label.magnifierType = KZTextMagnifierTypeCaret;
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.textContainerInset = UIEdgeInsetsMake(30, 30, 30, 30);
    label.lineBreakMode = NSLineBreakByCharWrapping;
    label.autoDetectDelegate = self;
    
    UIFont *font = [UIFont systemFontOfSize:20];
    attributedText.kzFont = font;
    label.attributedText = attributedText;
    
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"EmoticonQQ" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSArray *emojiPaths = [NSBundle pathsForResourcesOfType:@"gif" inDirectory:bundlePath];
    NSMutableDictionary *emojiDic = [NSMutableDictionary dictionary];
    for (NSString *path in emojiPaths) {
        NSString *name = [path lastPathComponent];
        NSArray *sublist = [name componentsSeparatedByString:@"@"];
        NSString *key = [NSString stringWithFormat:@"[%@]",sublist.firstObject];
        emojiDic[key] = name;
    }
    self.emjoBundle = bundle;
    
    [label configAutoDetectWithDetectType:KZAutoDetectCheckTypeAll
                                emojiDict:emojiDic
                                emojiSize:CGSizeMake(font.lineHeight, font.lineHeight)
                              emojiBundle:bundle
                                linkColor:[UIColor blueColor]
                           underlineStyle:NSUnderlineStyleNone
                           underlineColor:nil];
    
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    self.label = label;
}

- (void)setUp1 {
    NSString *text = @"👩‍❤️‍👨👩‍❤️‍💋‍👨💏👨‍❤️‍💋‍👨";
    NSString *text1 = @"👩‍❤️‍👨";
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc]initWithString:text];
    KZLabel *label = [[KZLabel alloc]init];
    label.frame = [self kzLabelFrame];
    label.numberOfLines = 0;
    label.selectable = YES;
    label.menuDelegate = self;
    label.magnifierType = KZTextMagnifierTypeCaret;
    label.textVerticalAlignment = KZTextVerticalAlignmentCenter;
    label.lineBreakMode = NSLineBreakByCharWrapping;
    label.autoDetectDelegate = self;
    
    UIFont *font = [UIFont systemFontOfSize:20];
    attributedText.kzFont = font;
    label.attributedText = attributedText;
    
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    self.label = label;
}



- (CGRect)kzLabelFrame {
    return CGRectMake(20,  110, self.view.bounds.size.width - 40,  self.view.bounds.size.height - 200);;
}

- (NSArray *)menuItemsForLabel:(KZLabel *)label {
    SEL action1 = NSSelectorFromString(@"selectAll:");
    NSString *itemTitle1 = @"选择全部";
    YPMenuItem *item1 = [[YPMenuItem alloc] initSystemWithAction:action1
                                                           title:itemTitle1];
    item1.autoDismissBeforeAction = YES;
    
    SEL action2 = NSSelectorFromString(@"copyAction:");
    NSString *itemTitle2 = @"复制";
    YPMenuItem *item2 = [[YPMenuItem alloc] initSystemWithAction:action2
                                                           title:itemTitle2];
    return @[item1, item2];
}

- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent selectRange:(NSRange)selectRange {
    self.selectContent  =selectContent;
    NSLog(@"location:%lu length:%lu selectContent:%@", (unsigned long)selectRange.location, (unsigned long)selectRange.length, selectContent);
}

- (void)copyAction:(id)sender {
    NSString *str = [self.label.attributedText attributedSubstringFromRange:self.label.selectedRange].string;
    if (![str isEqualToString:self.selectContent]) {
        NSLog(@"有问题, range: %@  select: %@", str, self.selectContent);
    }
    NSLog(@"%@", self.selectContent);
}

- (void)selectAll:(id)sender {
    [self.label setSelectedRange:NSMakeRange(0, self.label.attributedText.length) showMenuController:YES];
    self.selectContent = self.label.attributedText.string;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"");
}

- (UIImage *)emojiImageForDetectAttributedString:(NSAttributedString *)attributedString
                                       emojiDict:(NSDictionary *)emojiDict
                                        emojiStr:(NSString *)emojiStr
                                           range:(NSRange)range {
    NSString *imageName = [emojiDict objectForKey:emojiStr];
    YPImage *image = [YPImage imageNamed:imageName inBundle:self.emjoBundle];
    return image;

}

- (CGSize)emojiImageSiseForDetectAttributedString:(NSAttributedString *)attributedString
                                       emojiDict:(NSDictionary *)emojiDict
                                        emojiStr:(NSString *)emojiStr
                                            range:(NSRange)range
                                   emojiImageSise:(CGSize)emojiImageSise
                                       emojiImage:(UIImage *)emojiImage {
    return CGSizeMake(30, 30);
}


@end
