//
//  KZBigTextController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/11/7.
//

#import "KZBigTextController.h"
#import "KZTextDemoHelper.h"
#import "UIView+KZExample.h"
#import "KZLabel.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "NSBundle+KZExample.h"
#import "YPMenuItem.h"
#import "YPAnimatedImageView.h"
#import "YPMenuController.h"
#import "KZDemoText.h"

@interface KZBigTextController ()<KZLabelMenuDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;

@end

@implementation KZBigTextController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0,kz_appGetNavHeight(), self.view.width, self.view.height - kz_appGetNavHeight())];
    self.scrollView = scrollView;
    [self.view addSubview:scrollView];
    YPMenuStyleConfig *config = [[YPMenuStyleConfig alloc] init];
    config.menuType = YPMenuControllerCustom;
    config.barContentHeight = 45;
    [YPMenuController sharedMenuController].styleConfig = config;
    
    [self setUpUI];
}

- (void)setUpUI {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.selectable = YES;
    label.canShowMagnifier = NO;
    label.menuDelegate = self;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(0, 0, self.view.bounds.size.width, 30000);
    label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    [self.scrollView addSubview:label];

    label.text = [KZDemoText emojiString];
    [self.scrollView setContentSize:CGSizeMake(self.view.bounds.size.width, label.height)];
}

- (void)setUpUI1:(KZLabel *)l {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(0, CGRectGetMaxY(l.frame), self.view.bounds.size.width, 20000);
    [self.scrollView addSubview:label];
    [self.scrollView setContentSize:CGSizeMake(self.view.bounds.size.width, 20000)];

    NSString *text = [self textString];
    [KZTextDemoHelper cacuTimer:^{
        label.text = text;
    }];
}


- (void)setUpUI4 {
    CFAbsoluteTime startTime =CFAbsoluteTimeGetCurrent();
    
    NSString *text = [self textSting1];
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc]initWithString:text];
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.selectable = YES;
    label.maxBigLimitLength = 100;
    
    UIFont *font = [UIFont systemFontOfSize:20];
    attributedText.kzFont = font;
    label.attributedText = attributedText;
    
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"EmoticonQQ" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSArray *emojiPaths = [NSBundle pathsForResourcesOfType:@"gif" inDirectory:bundlePath];
    NSMutableDictionary *emojiDic = [NSMutableDictionary dictionary];
    for (NSString *path in emojiPaths) {
        NSString *name = [path lastPathComponent];
        NSArray *sublist = [name componentsSeparatedByString:@"@"];
        NSString *key = [NSString stringWithFormat:@"[%@]",sublist.firstObject];
        emojiDic[key] = name;
    }
    
    [label configAutoDetectWithDetectType:KZAutoDetectCheckTypeAll
                                emojiDict:emojiDic
                                emojiSize:CGSizeMake(font.lineHeight, font.lineHeight)
                              emojiBundle:bundle
                                linkColor:[UIColor blueColor]
                           underlineStyle:NSUnderlineStyleNone
                           underlineColor:nil];
    
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(0, 0, self.view.bounds.size.width, 10000);
    [self.scrollView addSubview:label];
    [self.scrollView setContentSize:CGSizeMake(self.view.bounds.size.width, 10000)];
    
    CFAbsoluteTime linkTime = (CFAbsoluteTimeGetCurrent() - startTime);

    NSLog(@">初始化使用的时间cost time = %f ms", linkTime);
}

- (void)setUpUI2 {
    NSAttributedString *attributedText = [[NSAttributedString alloc]initWithString:[self textString]];
    CGRect usedRect =
    [attributedText boundingRectWithSize:CGSizeMake(self.view.bounds.size.width, 10000)
                                 options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingTruncatesLastVisibleLine
                                             context:nil];
    NSLog(@"%f",usedRect.size.width);
}

- (void)setUpUI3 {
    NSAttributedString *attributedText = [[NSAttributedString alloc]initWithString:[self textString]];
    CGSize usedRect = [attributedText boundingSizeWithContainerSize:CGSizeMake(self.view.bounds.size.width, 10000)];
    NSLog(@"%f",usedRect.width);
}

- (NSString *)textString2 {
    return @"《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。《认知觉醒》一书就大脑、\n潜意识、元认知、专注力、\n学习力、行动力、情绪力，\n阐述了普通人对于觉知的重要性。\n在生活上给我很大的启发，首先第一点就是，\n无论是读书还是阅读，\n改变才是最终目标，\n哪怕只有很小一点的灵感，\n请摄取他，改变自己。第二点，\n学习并非需要学习别人的知识体系，\n每个人其实并不相同，\n其实更应该扩充的是自己的认知体系，\n将优秀者的好习惯，\n优秀品质关联自身，\n对自己解释世界做一个更好的扩充，\n也就是“无关联，不学习”，\n关联自己才是最重要的。\n最后一点，\n要明白无论是读书还是学习，\n哪怕看完，\n学完忘记了，\n其实都是很正常的现象，\n放平心态，\n只要你持续学习，\n持续扩充自己的知识体系，\n终究是会明白你遗漏的知识，\n遗忘并不可耻。";
}


- (NSString *)textSting1 {
    return @"@东坡肘子: [001]随着疫情得到控制，[002]越来越多的线下活动得以顺利举办。18612764897作者用了三篇博文总结了[003] 2023 年 Deep Dish Swift 会议的演讲内容。446751836@qq.com 第一天的演讲涵盖了独立开发者的讲座、订阅模型、CI/CD 自动化和 ASO。第二天的演讲涵盖了公司销售、Swift 算法、模块化架构、导师制、Swift Playgrounds 和SwiftUI 导航。[011] (https://mp.weixin.qq.com/)第三天的演讲涵盖了服务器端 Swift 和 GraphQL、使用 Swift 创建演示文稿、实时活动、代码风格和 DocC 文档。[015] 这次会议涵盖了广泛的 Swift 开发相关主题，使与会者从各个角度深入了解 Swift 语言。纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~<test p=123>**自定义 test Text**<new n=000>~~自定义 new~~</new></test> ![foo](/url 'title') [我是链接](www.baidu.com '链接标题')**加粗**\n - 无序列表\n- 无序列表2\n```\n代码块阿斯顿发生大法师发生的发生的发生的发生大发\n```\n纯文本abc\n\n***xyz***正常文本 **加粗**~~shabchuxian~~ 结尾啦阿萨德哈佛卡收到回复立卡收到回复卢卡斯大护法阿石创V型怎么吃v阿手打发哈王力宏法律思考大护法个阿斯利康地方阿斯利康发生了快递费啊s'l";
}

- (NSString *)textString {
    return [KZDemoText bigTextDemo];
}


- (NSArray *)menuItemsForLabel:(KZLabel *)label {
    
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn1.frame = CGRectMake(0, 0, 80, 45);
    [btn1 setTitle:@"复制" forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(customViewTypeAction1:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn2.frame = CGRectMake(0, 0, 80, 45);
    [btn2 setTitle:@"搜索" forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(customViewTypeAction2:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn3.frame = CGRectMake(0, 0, 80, 45);
    [btn3 setTitle:@"全选" forState:UIControlStateNormal];
    [btn3 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn3 addTarget:self action:@selector(customViewTypeAction3:) forControlEvents:UIControlEventTouchUpInside];
    
    YPMenuItem *item = [[YPMenuItem alloc] initWithCustomView:btn1];
    YPMenuItem *item1 = [[YPMenuItem alloc] initWithCustomView:btn2];
    YPMenuItem *item2 = [[YPMenuItem alloc] initWithCustomView:btn3];
    return  @[item,item1,item2];
}

- (void)customViewTypeAction1:(id)act {
    [[YPMenuController sharedMenuController] menuInvisibleWithAnimated:YES];
}

- (void)customViewTypeAction2:(id)act {
    [[YPMenuController sharedMenuController] menuInvisibleWithAnimated:YES];
}

- (void)customViewTypeAction3:(id)act {
    [[YPMenuController sharedMenuController] menuInvisibleWithAnimated:YES];
}

- (void)menuHighLightAction:(id)act {
    
}

- (void)menuCopyAction:(id)act {
    
}

- (BOOL)label:(KZLabel *)label shouldShowMenuForRange:(NSRange)range selectContent:(NSAttributedString *)selectContent {
    NSLog(@"shouldShowMenuForRange");
    NSString *str = [selectContent.string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (str.length == 0) {
        return NO;
    }
    return YES;
}

- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent {
    NSLog(@"didChangeSelectContent:%@", selectContent);
}

- (void)label:(KZLabel *)label didChangeSelectContent:(NSString *)selectContent selectRange:(NSRange)selectRange {
    NSLog(@"didChangeSelectContent:%@ selectRange:[location:%ld],[length:%ld]", selectContent, selectRange.location, selectRange.length);
    
}





@end
