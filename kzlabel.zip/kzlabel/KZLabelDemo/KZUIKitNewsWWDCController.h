//
//  KZUIKitNewsWWDCController.h
//  KZLabel
//
//  Created by yuhechuan on 2024/6/20.
//

#import <UIKit/UIKit.h>

@interface KZUIKitNewsWWDCController : UIViewController

@end
