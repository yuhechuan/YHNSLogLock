//
//  KZSeniorLabelBugViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/22.
//

#import "KZSeniorLabelBugViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIView+KZExample.h"

@interface KZSeniorLabelBugViewController ()

@property (nonatomic, strong) KZLabel *label1;
@property (nonatomic, strong) KZLabel *label2;
@property (nonatomic, strong) UILabel *label3;

@end

@implementation KZSeniorLabelBugViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label2.enbleDebugOption = switcher.on;
    }];
    [self setUpUI1];
    [self setUpUI2];
   // [self setUpUI3];
    // [self setUpUI4];
}


- (void)setUpUI1 {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 4;
    label.textColor = [UIColor orangeColor];
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, 100, self.view.bounds.size.width - 40, 250);
    [self.view addSubview:label];
    
    NSString *str = @"CGAffineTransform 仿射变化引起的字体异常Bug";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];
    UIFont *customFont = [UIFont systemFontOfSize:18];
    
    CGFloat angle = 10;
    CGAffineTransform matrix = CGAffineTransformMake(1, 0, tanf(angle * (CGFloat)M_PI / 180), 1, 0, 0);//设置反射。倾斜角度。
    UIFontDescriptorSymbolicTraits fontTraits = 0;
    fontTraits |= customFont.fontDescriptor.symbolicTraits;
    if (!fontTraits) {
        fontTraits |= UIFontDescriptorClassSansSerif;
    }
    UIFontDescriptor *syntheticDesc = [customFont.fontDescriptor fontDescriptorWithSymbolicTraits:fontTraits];
    syntheticDesc = [syntheticDesc fontDescriptorWithMatrix:matrix];
    UIFont *font = [UIFont fontWithDescriptor:syntheticDesc size:syntheticDesc.pointSize];
    text.kzFont = font;
    label.attributedText = text;
    [label sizeToFit];
    self.label1 = label;
}


- (void)setUpUI2 {
    KZLabel *label = [[KZLabel alloc]init];
    
    NSString *str = @"1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色，大片裸露的黄土地述说着贫瘠但充满希望的生活。窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着，心里却想着赶紧逃离这里，到外面的寒冷里去。她第一次与男人以这样的方式独处，显得紧张，不知所措。";
    UIFont *customFont = [UIFont systemFontOfSize:24];
    label.numberOfLines = 0;
    label.textColor = [UIColor orangeColor];
    label.font = customFont;
    label.text = str;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(self.label1.frame) + 20, self.view.bounds.size.width - 40, 0);
    [self.view addSubview:label];
    [label sizeToFit];
    self.label2 = label;
}

- (void)setUpUI3 {
    UILabel *label = [[UILabel alloc]init];
    
    NSString *str = @"1963年初冬，西部山区一个小村，村里村外到处都是枯黄的颜色，大片裸露的黄土地述说着贫瘠但充满希望的生活。窑洞内，与坑连接的灶台，火烧得正旺，窑洞内暖和如春。侗月花低着头拘谨的坐着，心里却想着赶紧逃离这里，到外面的寒冷里去。她第一次与男人以这样的方式独处，显得紧张，不知所措。";
    UIFont *customFont = [UIFont systemFontOfSize:24];
    label.numberOfLines = 0;
   // label.textVerticalAlignment = KZTextVerticalAlignmentTop;
    label.textColor = [UIColor orangeColor];
    label.font = customFont;
    label.text = str;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(self.label1.frame) + 20, self.view.bounds.size.width - 40, 0);
    [self.view addSubview:label];
    [label sizeToFit];
    self.label3 = label;
}


- (void)setUpUI4 {
    KZLabel *label = [[KZLabel alloc]init];
    
    NSString *str = @"1963年初冬，西部山区一个小村，\u2029村里村外到处都是枯黄的颜色，\u2029大片裸露的黄土地述说着贫瘠但充满希望的生活。";
    UIFont *customFont = [UIFont systemFontOfSize:18];
    label.numberOfLines = 0;
    label.textColor = [UIColor orangeColor];
    label.font = customFont;
    label.text = str;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, CGRectGetMaxY(self.label2.frame) + 20, self.view.bounds.size.width - 40, 0);
    [self.view addSubview:label];
    [label sizeToFit];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [UIView animateWithDuration:0.25 animations:^{
        self.label2.height = 100;
    }];
}


@end
