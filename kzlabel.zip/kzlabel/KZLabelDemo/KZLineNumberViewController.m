//
//  KZLineNumberViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2024/5/30.
//

#import "KZLineNumberViewController.h"

@interface KZLineNumberViewController ()<UITextViewDelegate>

@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, assign) NSRange visibleCharacterRange;


@end

@implementation KZLineNumberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString *text = @"1\n2\n3\n4\n5\n6\n7";
    
    CGSize size = CGSizeMake(300, 100);
    CGFloat x = (self.view.bounds.size.width - size.width) / 2.0;
    CGRect rect = CGRectMake(x, 100, 300, 500);
    UIFont *font = [UIFont systemFontOfSize:16];
    UITextView *textView = [[UITextView alloc]initWithFrame:rect];
    textView.font = font;
    textView.textColor = [UIColor blueColor];
    textView.text = text;
    textView.textContainer.maximumNumberOfLines = 6;
    textView.backgroundColor = [UIColor grayColor];
    textView.delegate = self;
    [self.view addSubview:textView];
    self.textView = textView;
    [self textViewDidChange:self.textView];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"之前:%@", self.textView.text);
    NSRange visibleGlyphRange = [self.textView.layoutManager glyphRangeForBoundingRect:(CGRect){ .size = self.textView.textContainer.size }
                                                         inTextContainer:self.textView.textContainer];
    NSRange visibleCharacterRange = [self.textView.layoutManager characterRangeForGlyphRange:visibleGlyphRange actualGlyphRange:NULL];
    NSString *result = [self.textView.text substringWithRange:visibleCharacterRange];
    NSLog(@"之后:%@", result);
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if (range.location + 1 == self.visibleCharacterRange.length && ([text isEqualToString:@"\n"] || [text isEqualToString:@"\r"])) {
        return NO;
    }
    if (range.location + 1 > self.visibleCharacterRange.length) {
        return NO;
    }
   
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView {
    NSRange visibleGlyphRange = [self.textView.layoutManager glyphRangeForBoundingRect:(CGRect){ .size = self.textView.textContainer.size }
                                                         inTextContainer:self.textView.textContainer];
    NSRange visibleCharacterRange = [self.textView.layoutManager characterRangeForGlyphRange:visibleGlyphRange actualGlyphRange:NULL];
    self.visibleCharacterRange = visibleCharacterRange;
}


@end
