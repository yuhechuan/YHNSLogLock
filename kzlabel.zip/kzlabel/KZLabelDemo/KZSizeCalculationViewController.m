//
//  KZSizeCalculationViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/5/17.
//

#import "KZSizeCalculationViewController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIViewController+NavigationItem.h"
#import "UIImageView+YPWebImage.h"
#import "UIView+KZExample.h"
#import "NSBundle+KZExample.h"
#import "YPAnimatedImageView.h"

@interface KZSizeCalculationViewController ()<KZLabelDelegate>

@property (nonatomic, assign) BOOL isSizeThatFits;
@property (nonatomic, strong) KZLabel *label;
@property (nonatomic, copy) NSString *alertMessge;

@end

@implementation KZSizeCalculationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUp4];
}

- (void)setUp4 {
    NSString *text1 = @"此外，新增动态计算功能，轻松支持同比、环比及加减乘除等运算需求！";
    NSMutableParagraphStyle *style1 = [[NSMutableParagraphStyle alloc]init];
    style1.tailIndent = 0;
    
    NSMutableAttributedString *atrr1 = [[NSMutableAttributedString alloc]initWithString:text1 attributes:@{NSParagraphStyleAttributeName: style1}];
    
    
    NSString *text2 = @"曼城意外折戟，热刺强势晋级！北京时间10月31日凌晨，英格兰联赛杯第4轮的较量上演了一场引人瞩目的对决。";
    NSMutableParagraphStyle *style2 = [[NSMutableParagraphStyle alloc]init];
    style2.tailIndent = 0;
    
    NSMutableAttributedString *atrr2 = [[NSMutableAttributedString alloc]initWithString:text2 attributes:@{NSParagraphStyleAttributeName: style2}];
    
    NSMutableParagraphStyle *style = [NSMutableParagraphStyle new];
    style.tailIndent = 3;
    
    [atrr2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, atrr2.length)];
    
    [self check_yuhechuan:atrr1];
    [self check_yuhechuan:atrr2];
}

- (void)check_yuhechuan:(NSAttributedString *)attributedText {
    NSLog(@"");
    [attributedText enumerateAttribute:NSParagraphStyleAttributeName inRange:NSMakeRange(0, attributedText.length) options:0 usingBlock:^(NSParagraphStyle *value, NSRange range, BOOL * _Nonnull stop) {
        NSLog(@"");
    }];
}

- (void)setUp3 {
    NSString *text = @"此外，新增动态计算功能，轻松支持同比、环比及加减乘除等运算需求！";
    NSMutableAttributedString *atrr = [[NSMutableAttributedString alloc]initWithString:text];
    atrr.kzMinimumLineHeight = 22;
    atrr.kzFont =  [UIFont systemFontOfSize:14];
    atrr.kzLineSpacing = 2;
    KZLabel *label = [[KZLabel alloc]init];
    label.frame = CGRectMake(50, 150, 0, 0);
    label.textContainerInset = UIEdgeInsetsMake(1, 3, 1, 3);
    label.numberOfLines = 0;
    label.textColor = [UIColor blueColor];
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    label.attributedText = atrr;
    
    [self.view addSubview:label];
    
    CGSize size = [label calculateSizeForConstraintWidth:238];
    label.height = size.height;
    label.width = 238;
    self.label = label;
}

- (void)setUp1 {
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
    
    NSString *text  =@"@远恒之义：Apple 一直秉承制造所有人都能顺畅使用产品的理念，为迎接本周四的全球无障碍宣传日（每年五月第三个星期四），展示了一套为认知能力、视力、听力与肢体活动能力而设计的软件辅助功能。这些功能将于今年晚些时候推出，预计会在秋季的 iOS 17 正式版系统中上线。\n针对有认知障碍的用户，Apple 推出 Assistive Access，把电话、信息、相机、照片与音乐等 App 整合为一个单独的 App，并提炼出这些常用 App 的基本功能，以减轻用他们的认知负担。这相当于是系统层级的长辈模式，简化原本复杂的交互逻辑，突出放大文字按钮操作。";
    KZLabel *label = [[KZLabel alloc]init];
    label.frame = CGRectMake(20, 150, self.view.width - 40, 100);
    label.numberOfLines = 0;
    label.delegate = self;
    label.font = [UIFont systemFontOfSize:17];
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    label.containerSize = CGSizeMake(200, CGFLOAT_MAX);
    label.text = text;
    [self.view addSubview:label];
    self.label = label;
}


- (void)setUp {
    
    __weak __typeof(self)weakSelf = self;
    [self addRightTitleNavigationItemTitle:@"检测" action:^{
        [weakSelf showAlert:weakSelf.alertMessge];
    }];
    
    NSString *text  =@"@远恒之义：Apple 一直秉承制造所有人都能顺畅使用产品的理念，为迎接本周四的全球无障碍宣传日（每年五月第三个星期四），展示了一套为认知能力、视力、听力与肢体活动能力而设计的软件辅助功能。这些功能将于今年晚些时候推出，预计会在秋季的 iOS 17 正式版系统中上线。\n针对有认知障碍的用户，Apple 推出 Assistive Access，把电话、信息、相机、照片与音乐等 App 整合为一个单独的 App，并提炼出这些常用 App 的基本功能，以减轻用他们的认知负担。这相当于是系统层级的长辈模式，简化原本复杂的交互逻辑，突出放大文字按钮操作。";
    
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc]initWithString:text];
    
    {
        NSArray *names = @[@"001", @"022", @"019",@"056",@"085"];
        for (NSString *name in names) {
            NSString *path = [[NSBundle mainBundle] pathForScaledResource:name ofType:@"gif" inDirectory:@"EmoticonQQ.bundle"];
            NSData *data = [NSData dataWithContentsOfFile:path];
            YPImage *image = [YPImage imageWithData:data scale:2];
            
            YPAnimatedImageView *imageView = [[YPAnimatedImageView alloc] initWithImage:image];
            
            KZTextAttachment *attach = [[KZTextAttachment alloc]init];
            attach.content = imageView;
            
            NSMutableAttributedString *attachText = [[NSAttributedString attributedStringWithAttachment:attach] mutableCopy];
            [attributedText appendAttributedString:attachText];
        }
        YPImage *image = [YPImage imageNamed:@"test1@2x.gif"];
        YPAnimatedImageView *imageView = [[YPAnimatedImageView alloc] initWithImage:image];
        KZTextAttachment *attach = [[KZTextAttachment alloc]init];
        attach.content = imageView;
        attach.aligment = KZTextVerticalAlignmentBottom;
        attach.contentSize = CGSizeMake(120, 120);

        NSMutableAttributedString *attachText = [[NSMutableAttributedString attributedStringWithAttachment:attach] mutableCopy];
        [attributedText appendAttributedString:attachText];
    }
    
    NSString *last = @"对于有语言能力障碍的用户，通过 Live Speech 新功能，他们可以在 iPhone 上打电话时键盘输入文字，当前设备会将文字转成语音并朗读出来。此外，对于面临失语风险的用户，他们可使用 iPhone 录制 15 分钟的音频，通过机器学习的 Personal Voice 技术，创建与自己嗓音相似的 AI 语音，后续就能使用此语音进行文字朗读。\n面对失明或低视力用户，iPhone 内置的放大器将新增 Point and Speak 功能，结合相机与激光雷达扫描，视障用户在使用微波炉等家用电器时，iPhone 能识别在按键区移动的手指，朗读出手指指向按键上的功能文字。";
   
    [attributedText appendAttributedString:[[NSAttributedString alloc]initWithString:last]];
    
    {
        KZTextQuote *quote = [KZTextQuote new];
        quote.quoteWidth = 4;
        quote.quoteColor =  [UIColor lightGrayColor];
        quote.quoteLeft = 0;
        attributedText.kzQuote = quote;
    }
    
    {
        NSRange range = [text rangeOfString:@"每年五月第三个星期四"];
        KZTextLink *link = [KZTextLink new];
        link.avoidLineBreak = YES;
        link.linkTextColor = [UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000];
        link.highlightColor = [UIColor yellowColor];
        link.highlightBackViewColor = [UIColor redColor];
        link.clickAction = ^(NSAttributedString *attributedString, NSRange range) {
            NSLog(@"Text Link Click");
        };
        [attributedText kzSetLink:link range:range];
    }
    
    {
        NSRange range = [text rangeOfString:@"iOS 17"];
        KZTextBorder *boder = [KZTextBorder new];
        boder.borderColor = [UIColor redColor];
        boder.borderWidth = 1.0;
        [attributedText kzSetBorder:boder range:range];
        
        NSRange range1 = [text rangeOfString:@"Apple"];
        KZTextBorder *boder1 = [KZTextBorder new];
        boder1.underlineColor = [UIColor redColor];
        boder1.underlineWidth = 1.0;
        [attributedText kzSetBorder:boder1 range:range1];
        
        NSRange range2 = [text rangeOfString:@"迎接本周四"];
        KZTextBorder *boder2 = [KZTextBorder new];
        boder2.underlineColor = [UIColor redColor];
        boder2.underlineWidth = 1.0;
        boder2.underlineStyle = KZBorderUnderLineCenterNormal;
        [attributedText kzSetBorder:boder2 range:range2];
    }
    
    

    UIFont *font = [UIFont systemFontOfSize:16];
    attributedText.kzFont = font;

    
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 16;
    label.textContainerInset = UIEdgeInsetsMake(0, 15, 0, 0);
    
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = [self kzLabelFrame];
    [self.view addSubview:label];
 
    
    UIImage *image = [UIImage imageNamed:@"dribbble64_imageio"];
    [label configTruncationWithContent:image contentSize:CGSizeMake(font.lineHeight, font.lineHeight) clickAction:^{
        NSLog(@"Truncation 点击");
    }];
    
    label.attributedText = attributedText;
    [label sizeToFit];
    
    self.label = label;
    
    CGSize labelSize = label.size;
    
    CGSize fitsSize = CGSizeMake([self kzLabelFrame].size.width, CGFLOAT_MAX);
    CGSize textSize = [attributedText boundingSiseWithContainerSize:fitsSize optionsBlock:^(KZTextAttributes *attributes) {
        attributes.lineBreakMode = label.lineBreakMode;
        attributes.numberOfLines = label.numberOfLines;
        attributes.exclusionPaths = label.exclusionPaths;
        attributes.truncationAttributedText = label.truncationAttributedText;
        attributes.textVerticalAlignment = label.textVerticalAlignment;
        attributes.textContainerInset = label.textContainerInset;
        attributes.exclusionPaths = label.exclusionPaths;
        attributes.extendRendererMap = label.extendRendererMap;
        attributes.textContainerInset = label.textContainerInset;
    }];
    
    NSString *str1 = [NSString stringWithFormat:@"sizeThatFits: width:%.f  height:%.f",labelSize.width, labelSize.height];
    NSString *str2 = [NSString stringWithFormat:@"自己计算: width:%.f   height:%.f",textSize.width, textSize.height];
    NSString *ret = CGSizeEqualToSize(textSize, labelSize) ? @"相等" : @"不等";
    NSString *str3 = [NSString stringWithFormat:@"两个Size是否相等: %@", ret];
    
    NSMutableString *message = [[NSMutableString alloc]init];
    [message appendString:str1];
    [message appendString:@"\n"];
    [message appendString:str2];
    [message appendString:@"\n"];
    [message appendString:str3];
    self.alertMessge = message;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)showAlert:(NSString *)message1 {
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"提示信息" message:message1 preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * okAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDestructive handler:nil];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}

//- (void)setIsSizeThatFits:(BOOL)isSizeThatFits {
//    _isSizeThatFits = isSizeThatFits;
//    if(isSizeThatFits) {
//        [self.label sizeToFit];
//    } else {
//        self.label.frame = [self kzLabelFrame];
//    }
//}

- (CGRect)kzLabelFrame {
    CGFloat X = 20;
    return CGRectMake(X,  100, self.view.bounds.size.width - 2 *X,  self.view.bounds.size.height - 200);;
}


- (void)didLayoutWithTextCalculateSize:(CGSize)size {
    self.label.frame = CGRectMake(20, 150, size.width, size.height);
}

@end
