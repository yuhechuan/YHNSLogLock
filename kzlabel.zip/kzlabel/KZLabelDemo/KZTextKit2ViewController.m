//
//  KZTextKit2ViewController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/6/14.
//

#import "KZTextKit2ViewController.h"


@interface KZTextLayoutFragment : NSTextLayoutFragment
@end
@implementation KZTextLayoutFragment

- (CGRect)renderingSurfaceBounds {
    return CGRectZero;
}

- (void)drawAtPoint:(CGPoint)point inContext:(CGContextRef)context {
    CGContextSaveGState(context);
    // 在这儿可以开始 渲染
    CGContextRestoreGState(context);
}

@end


@interface KZTestView : UIView
@end
@implementation KZTestView

- (void)animate {
    [UIView animateWithDuration:1.0 animations:^{
        self.alpha = 0.0;
        self.transform = CGAffineTransformRotate(CGAffineTransformIdentity, M_PI);
    } completion:^(BOOL finished) {
        [self reset];
    }];
}

- (void)reset {
    [UIView animateWithDuration:1.0 animations:^{
        self.alpha = 1.0;
        self.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        [self animate];
    }];
}

@end

@interface KZTextAttachmentViewProvider : NSTextAttachmentViewProvider
@end
@implementation KZTextAttachmentViewProvider

- (void)loadView {
    
    KZTestView *tview = [[KZTestView alloc]init];
    self.view = tview;
    self.view.backgroundColor = [UIColor orangeColor];
    [tview animate];
}

- (CGRect)attachmentBoundsForAttributes:(NSDictionary<NSAttributedStringKey,id> *)attributes location:(id<NSTextLocation>)location textContainer:(NSTextContainer *)textContainer proposedLineFragment:(CGRect)proposedLineFragment position:(CGPoint)position {
    return CGRectZero;
}

@end


@interface KZTextKit2ViewController ()

@end

@implementation KZTextKit2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UITextView *textView = [[UITextView alloc]initWithFrame:CGRectMake(20, 100, self.view.bounds.size.width - 40, 300)];
    textView.backgroundColor = [[UIColor yellowColor]colorWithAlphaComponent:0.3];
 
    [self.view addSubview:textView];
    [NSTextAttachment registerTextAttachmentViewProviderClass:[KZTextAttachmentViewProvider class] forFileType:@"public.data"];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc]initWithString:@"测试附件"];
    NSTextAttachment *attach = [[NSTextAttachment alloc]initWithData:nil ofType:@"public.data"];
    NSAttributedString *att = [NSAttributedString attributedStringWithAttachment:attach];
    [str appendAttributedString:att];
    textView.attributedText = str;
    
}



@end
