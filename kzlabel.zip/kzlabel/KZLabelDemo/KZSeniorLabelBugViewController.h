//
//  KZSeniorLabelBugViewController.h
//  KZLabel
//
//  Created by yuhechuan on 2023/5/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZSeniorLabelBugViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
