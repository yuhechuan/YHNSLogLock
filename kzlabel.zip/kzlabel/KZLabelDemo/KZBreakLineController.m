//
//  KZBreakLineController.m
//  KZLabel
//
//  Created by yuhechuan on 2023/9/11.
//

#import "KZBreakLineController.h"
#import "KZLabel.h"
#import "NSMutableAttributedString+KZ.h"
#import "UIView+KZExample.h"

@interface KZBreakLineController ()<KZLabelDelegate>

@property (nonatomic, strong) KZLabel *label;


@end

@implementation KZBreakLineController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    __weak __typeof(self)weakSelf = self;
    [self addRightSwitchNavigationItem:^(UISwitch * _Nonnull switcher) {
        weakSelf.label.enbleDebugOption = switcher.on;
    }];
//    KZLabel *l = [self setUpUI5];
//    [self setUpUI10:l];
    
    NSString *text = @"检测到您填写的「公司简称」与「公司名称」无明显相关关系，建议上传商标授权函或品牌加盟协议等证明材料，提高信息审核通过率";
    NSRange range1 = [text rangeOfString:@"公司简称"];
    NSRange range2 = [text rangeOfString:@"公司名称"];
    NSRange range3 = [text rangeOfString:@"商标授权函"];
    NSRange range4 = [text rangeOfString:@"品牌加盟协议"];
    [self setUpUI12];
}

- (void)setUpUI {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.frame = CGRectMake(20, 150, [UIScreen mainScreen].bounds.size.width - 40, 500);
    label.cancelsGestureWhenLabelAction = YES;
    label.avoidLineBreak = YES;
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    NSString *textAll = @"男人见侗月花不看自己，就开始问这.问哪的，她一直保持沉默，啥话似乎都没有听进去。男人见她只是低头，看她她不理睬，问她她不答话。心想不会得病哑巴了吧。.两个青年男女这样干坐着也不是事。只见男人下了坑边，走向门口，打开门出去了。.侗月花想她才15岁呀，父亲竟然早早托了人给她寻婆家。.今天晌午，还没到做中午饭时间，父亲就让她把灶膛的火加旺，让她打扮一下自己，不要跑出去了。.说一会来个人，父亲让侗月花好好看看，如果相中了，这事就定下来了。8.侗月花脑子一片空白，她一点思想准备都没有。9.她还觉得自己是孩子，整天还和村里的小伙子打架骂嘴，和伙伴们忙着帮持家，还想着多认识几个字，想着上进呢。10.哪想到自己这么早就要被卖出去。父亲不容她发表任何意见，就大声骂她，让她在窑洞里等着。";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:textAll];
    text.kzFont = [UIFont systemFontOfSize:20];
    [self.view addSubview:label];
    
    NSString *sub1 = @"男人见侗";
    NSString *sub2 = @"不理睬";
    NSString *sub3 = @"两个青年";
    NSString *sub4 = @"走向门";
    NSString *sub5 = @"打扮一下";
    NSString *sub6 = @"如果相中了，";
    NSString *sub7 = @"忙着帮持家";
    NSString *sub8 = @"哪想到自己";
    
    NSString *sub9 = @"这事就定下来了";
    NSString *sub10 = @"和伙伴们";

    NSRange range1 = [textAll rangeOfString:sub1];
    NSRange range2 = [textAll rangeOfString:sub2];
    NSRange range3 = [textAll rangeOfString:sub3];
    NSRange range4 = [textAll rangeOfString:sub4];
    NSRange range5 = [textAll rangeOfString:sub5];
    NSRange range6 = [textAll rangeOfString:sub6];
    NSRange range7 = [textAll rangeOfString:sub7];
    NSRange range8 = [textAll rangeOfString:sub8];
    
    NSRange range9 = [textAll rangeOfString:sub9];
    NSRange range10 = [textAll rangeOfString:sub10];
    
    NSMutableArray *list = [NSMutableArray array];
    [list addObject:[NSValue valueWithRange:range1]];
    [list addObject:[NSValue valueWithRange:range2]];
    [list addObject:[NSValue valueWithRange:range3]];
    [list addObject:[NSValue valueWithRange:range4]];
    [list addObject:[NSValue valueWithRange:range5]];
    [list addObject:[NSValue valueWithRange:range6]];
    [list addObject:[NSValue valueWithRange:range7]];
    [list addObject:[NSValue valueWithRange:range8]];
    
    NSMutableArray *list1 = [NSMutableArray array];
    [list1 addObject:[NSValue valueWithRange:range9]];
    [list1 addObject:[NSValue valueWithRange:range10]];

    
    for (NSValue *v in list) {
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.fillColor = [[UIColor blueColor] colorWithAlphaComponent:0.1];
        border.avoidLineBreak = YES;
        [text kzSetBorder:border range:v.rangeValue];
    }
    for (NSValue *v in list1) {
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.fillColor = [[UIColor yellowColor] colorWithAlphaComponent:0.1];
        border.avoidLineBreak = YES;
        [text kzSetBorder:border range:v.rangeValue];
    }
    
    label.attributedText = text;
}



- (KZLabel *)setUpUI5 {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByCharWrapping;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, 150, 250, 100);
    label.font = [UIFont systemFontOfSize:17];
    label.textContainerInset = UIEdgeInsetsMake(1, 3, 1, 3);
    label.lineBreakControlCharacter = @"\u200b";
    label.avoidLineBreak = YES;
    [self.view addSubview:label];
    
    NSString *title = @"\u200b@张龙庆 :&amp;&amp;;&amp;::&amp;838288335283sfjkf; \u200b@张笼庆 &nbsp;3883838:&amp;:&amp;&amp;&amp;;&amp;;&amp;;&amp;;&amp;;;’dmd";
//    NSString *title = @"@周游  @玉河川  @赵巨鹏 @周鹏祖 列表接口qa已部署哈";

    NSString *name = @"@张龙庆";
    NSString *name1 = @"@张笼庆";

    NSRange range = [title rangeOfString:name];
    NSRange range1 = [title rangeOfString:name1];

    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:title];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineSpacing = 2;
    paragraphStyle.minimumLineHeight = 22;
    [test addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, test.length)];
    
    KZTextBorder *b = [[KZTextBorder alloc]init];
    b.borderStyle = KZBorderNormal;
    b.cornerRadius = 11;
    b.fillColor = [UIColor blueColor];
    b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
    b.avoidLineBreak = YES;
    b.range = range;
    
    KZTextBorder *b1 = [[KZTextBorder alloc]init];
    b1.borderStyle = KZBorderNormal;
    b1.cornerRadius = 11;
    b1.fillColor = [UIColor blueColor];
    b1.insets = UIEdgeInsetsMake(0, -3, 0, -3);
    b1.avoidLineBreak = YES;
    b1.range = range1;
    [test addAttribute:KZTextBorderAttributedStringKey value:b range:range];
    [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];

    [test addAttribute:KZTextBorderAttributedStringKey value:b1 range:range1];
    [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range1];
    label.attributedText = test;
    [label sizeToFit];
    return label;
}

- (void)setUpUI61:(KZLabel *)l {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.delegate = self;
    label.frame = CGRectMake(20, 150, self.view.bounds.size.width - 100, 100);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    
    NSString *title = @" @玉河川 发动机上课 @周鹏祖";
    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:title];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.headIndent = 3;
    paragraphStyle.firstLineHeadIndent = 3;
    paragraphStyle.tailIndent = -3;
    paragraphStyle.lineSpacing = 5;
    [test addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, test.length)];
    
    NSArray *list  = @[@"@玉河川",@"@周鹏祖"];
    for (NSString *sub in list) {
        NSRange range = [title rangeOfString:sub];
        KZTextBorder *b = [[KZTextBorder alloc]init];
        b.borderStyle = KZBorderNormal;
        b.cornerRadius = 11;
        b.fillColor = [UIColor blueColor];
        b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
        [test addAttribute:KZTextBorderAttributedStringKey value:b range:range];
        [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    }
    test.kzFont = [UIFont systemFontOfSize:18];
    label.attributedText = test;
    [label sizeToFit];
    if(l) {
        label.top = CGRectGetMaxY(l.frame) + 10;
        [self setUpUI6:label];
    }
}

- (void)setUpUI6:(KZLabel *)l {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.delegate = self;
    label.frame = CGRectMake(20, 150, self.view.bounds.size.width - 100, 100);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    
    NSString *title = @" @玉河川 发动机上课 @周鹏祖 上课的房间号 @徐建东 刷卡机电话费";
    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:title];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.headIndent = 3;
    paragraphStyle.firstLineHeadIndent = 3;
    paragraphStyle.tailIndent = -3;
    paragraphStyle.lineSpacing = 5;
    [test addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, test.length)];
    
    NSArray *list  = @[@"@玉河川",@"@周鹏祖",@"@徐建东"];
    for (NSString *sub in list) {
        NSRange range = [title rangeOfString:sub];
        KZTextBorder *b = [[KZTextBorder alloc]init];
        b.borderStyle = KZBorderNormal;
        b.cornerRadius = 11;
        b.fillColor = [UIColor blueColor];
        b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
        [test addAttribute:KZTextBorderAttributedStringKey value:b range:range];
        [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    }
    test.kzFont = [UIFont systemFontOfSize:18];
    label.attributedText = test;
    [label sizeToFit];
    if(l) {
        label.top = CGRectGetMaxY(l.frame) + 10;
        [self setUpUI7:label];
    }
}

- (void)setUpUI7:(KZLabel *)l  {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    label.frame = CGRectMake(20, 150, 250, 100);
    label.font = [UIFont systemFontOfSize:17];
    label.textContainerInset = UIEdgeInsetsMake(1, 3, 1, 3);
    [self.view addSubview:label];
    
    NSString *title = @"•  @张亚东  舒服的时光 蛇口街道 @周鹏祖 数控刀具反馈圣诞节发货";
    NSMutableAttributedString *test = [[NSMutableAttributedString alloc] initWithString:title];
    NSString *name = @"@张亚东";
    NSRange range = [title rangeOfString:name];
    
    NSString *name1 = @"\u2022";
    NSRange range1 = [title rangeOfString:name1];
    
    NSString *name2 = @"@周鹏祖";
    NSRange range2 = [title rangeOfString:name2];
    
    
    KZTextBorder *b = [[KZTextBorder alloc]init];
    b.borderStyle = KZBorderNormal;
    b.cornerRadius = 11;
    b.fillColor = [UIColor blueColor];
    b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
    b.avoidLineBreak = YES;
    
    [test addAttribute:KZTextBorderAttributedStringKey value:b range:range];
    [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    
    KZTextBorder *b1 = [[KZTextBorder alloc]init];
    b1.borderStyle = KZBorderNormal;
    b1.cornerRadius = 11;
    b1.fillColor = [UIColor blueColor];
    b1.insets = UIEdgeInsetsMake(0, -3, 0, -3);
    b1.avoidLineBreak = YES;
    
    [test addAttribute:KZTextBorderAttributedStringKey value:b1 range:range2];
    [test addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range2];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    [test addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:28], NSParagraphStyleAttributeName:paragraphStyle} range:range1];
    
    test.kzLineSpacing = 2;
    test.kzMinimumLineHeight = 22;
    label.attributedText = test;
    if(l) {
        label.top = CGRectGetMaxY(l.frame) + 10;
    }
}


- (void)setUpUI8 {
    KZLabel *label = [[KZLabel alloc]init];
    label.numberOfLines = 0;
    label.avoidLineBreak = YES;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.textContainerInset = UIEdgeInsetsMake(1, 3, 1, 3);
    label.lineBreakControlCharacter = @"\u200b";
    label.maxBigLimitLength = 50;
    label.delegate = self;
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    label.frame = CGRectMake(20, 100, [UIScreen mainScreen].bounds.size.width - 40, 500);
    [self.view addSubview:label];
    
    NSString *str = @"Set up the Depending bridge: Depending \u200b@周鹏祖 on the platform you're working with (e.g., Android, iOS, React Native), you'll \u200b@玉河川 need to set up a bridge that enables communication \u200b@李强 between the native code and your JavaScript code. This exception is raised if supportedInterfaceOrientations returns 0, or if preferredInterfaceOrientationForPresentation returns an orientation that is not supported.Calling this will result in either application:didRegisterForRemoteNotificationsWithDeviceToken: or application:didFailToRegisterForRemoteNotificationsWithError: to be called on the application delegate. Note: these callbacks will be made only if the application has successfully registered for user notifications with registerUserNotificationSettings or if it is enabled for Background App Refresh.\u200b@张龙庆";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:str];

    NSArray *list  = @[@"@周鹏祖",@"@玉河川",@"@李强",@"@张龙庆"];
    for (NSString *sub in list) {
        NSRange range = [str rangeOfString:sub];
        KZTextBorder *b = [[KZTextBorder alloc]init];
        b.borderStyle = KZBorderNormal;
        b.cornerRadius = 11;
        b.avoidLineBreak = YES;
        b.fillColor = [UIColor blueColor];
        b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
        b.range = range;
        [text addAttribute:KZTextBorderAttributedStringKey value:b range:range];
        [text addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    }
    text.kzFont = [UIFont systemFontOfSize:20];
    label.attributedText = text;
    [label sizeToFit];
}


- (void)setUpUI9 {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.frame = CGRectMake(20, 150, [UIScreen mainScreen].bounds.size.width - 40, 500);
    label.cancelsGestureWhenLabelAction = YES;
    label.avoidLineBreak = NO;
    label.lineBreakMode = NSLineBreakByCharWrapping;
    label.textContainerInset = UIEdgeInsetsMake(1, 3, 1, 3);
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    NSString *textAll = @" Allows NSLayoutManagerDelegate to 男人见侗 customize the line fragment geometry 不理睬 before committing to the layout cache. \u200b两个青年 The implementation of this \u200b走向门 method should 打扮一下 make sure \u200b如果相中了 that the modified fragments \u200b忙着帮持家 are still valid 哪想到自己 inside the text container coordinate. \u200b这事就定下来了 When it returns YES, \u200b和伙伴们 the layout manager uses the modified rects. Otherwise, it ignores the rects returned from this method.";
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:textAll];
    text.kzFont = [UIFont systemFontOfSize:20];
    [self.view addSubview:label];
    
    NSString *sub1 = @"男人见侗";
    NSString *sub2 = @"不理睬";
    NSString *sub3 = @"两个青年";
    NSString *sub4 = @"走向门";
    NSString *sub5 = @"打扮一下";
    NSString *sub6 = @"如果相中了";
    NSString *sub7 = @"忙着帮持家";
    NSString *sub8 = @"哪想到自己";
    
    NSString *sub9 = @"这事就定下来了";
    NSString *sub10 = @"和伙伴们";

    NSRange range1 = [textAll rangeOfString:sub1];
    NSRange range2 = [textAll rangeOfString:sub2];
    NSRange range3 = [textAll rangeOfString:sub3];
    NSRange range4 = [textAll rangeOfString:sub4];
    NSRange range5 = [textAll rangeOfString:sub5];
    NSRange range6 = [textAll rangeOfString:sub6];
    NSRange range7 = [textAll rangeOfString:sub7];
    NSRange range8 = [textAll rangeOfString:sub8];
    
    NSRange range9 = [textAll rangeOfString:sub9];
    NSRange range10 = [textAll rangeOfString:sub10];
    
    NSMutableArray *list = [NSMutableArray array];
    [list addObject:[NSValue valueWithRange:range1]];
    [list addObject:[NSValue valueWithRange:range2]];
    [list addObject:[NSValue valueWithRange:range3]];
    [list addObject:[NSValue valueWithRange:range4]];
    [list addObject:[NSValue valueWithRange:range5]];
    [list addObject:[NSValue valueWithRange:range6]];
    [list addObject:[NSValue valueWithRange:range7]];
    [list addObject:[NSValue valueWithRange:range8]];
    
    NSMutableArray *list1 = [NSMutableArray array];
    [list1 addObject:[NSValue valueWithRange:range9]];
    [list1 addObject:[NSValue valueWithRange:range10]];

    
    for (NSValue *v in list) {
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.fillColor = [[UIColor blueColor] colorWithAlphaComponent:0.1];
        [text kzSetBorder:border range:v.rangeValue];
    }
    for (NSValue *v in list1) {
        KZTextBorder *border = [[KZTextBorder alloc]init];
        border.fillColor = [[UIColor yellowColor] colorWithAlphaComponent:0.1];
        [text kzSetBorder:border range:v.rangeValue];
    }
    
    label.attributedText = text;
}

- (void)setUpUI10:(KZLabel *)top {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.delegate = self;
    label.textContainerInset = UIEdgeInsetsMake(1, 3, 1, 3);
    NSMutableAttributedString *truncationAttributedText = [[NSMutableAttributedString alloc]initWithString:@"...更多"];
    truncationAttributedText.kzFont = [UIFont systemFontOfSize:18];
    truncationAttributedText.kzColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
    label.truncationAttributedText =truncationAttributedText;
    
    label.frame = CGRectMake(20, CGRectGetMaxY(top.frame) + 20, 282, 300);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 220, 68)];
    imageView.image = [UIImage imageNamed:@"BossHi-bug.png"];
    
    KZTextAttachment *iconAttachment = [[KZTextAttachment alloc]init];
    iconAttachment.content = imageView;
    iconAttachment.contentMode = UIViewContentModeScaleAspectFill;
    NSMutableAttributedString *test = [[NSMutableAttributedString attributedStringWithAttachment:iconAttachment] mutableCopy];
    
    NSString *title = @"臣\n哥，用户邮件裂图原因定位，新版编辑器兼容问题, 预计今晚热修 \u200b @陈臣01 \u2060撒尽快发货";
    NSMutableAttributedString *test1 = [[NSMutableAttributedString alloc] initWithString:title];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.headIndent = 3;
    paragraphStyle.firstLineHeadIndent = 3;
    paragraphStyle.tailIndent = -3;
    [test1 addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, test.length)];
    
    NSArray *list  = @[@"@陈臣01"];
    for (NSString *sub in list) {
        NSRange range = [title rangeOfString:sub];
        KZTextBorder *b = [[KZTextBorder alloc]init];
        b.borderStyle = KZBorderNormal;
        b.cornerRadius = 11;
        b.fillColor = [UIColor blueColor];
        b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
        [test1 addAttribute:KZTextBorderAttributedStringKey value:b range:range];
        [test1 addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    }
    
    [test appendAttributedString:test1];
    test.kzLineSpacing = 5;
    test.kzMinimumLineHeight = 22;
    test.kzFont = [UIFont systemFontOfSize:18];
    label.attributedText = test;
}

- (void)setUpUI12 {
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(20, 100, self.view.frame.size.width - 40, 500)];
    [self.view addSubview:label];
    label.numberOfLines = 0;
    label.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    CGFloat lineHeight = 19;
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.maximumLineHeight = lineHeight;
    paragraphStyle.minimumLineHeight = lineHeight;
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:paragraphStyle forKey:NSParagraphStyleAttributeName];
    CGFloat baselineOffset = (lineHeight - label.font.lineHeight) / 4;
    [attributes setObject:@(baselineOffset) forKey:NSBaselineOffsetAttributeName];
    NSString *title = @"注意事项:\n1.您确认填写的公司简称不存在侵犯他人包括商标权等在内的在先权利，否则贵司应承担由此而产生的侵权或不正当竞争等法律风险\n2.若您填写的公司简称与公司名称无明显相关关系，可能会导致信息被驳回。建议上传能够证明贵公司有使用此公司简称权利的材料（例如商标授权函或品牌加盟协议等），点击上传 ";
    label.attributedText = [[NSAttributedString alloc] initWithString:title attributes:attributes];
    [label sizeToFit];
}

- (void)setUpUI11 {
    KZLabel *label = [KZLabel new];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    label.delegate = self;
    label.textContainerInset = UIEdgeInsetsMake(10, 10, 10, 10);
    label.textVerticalAlignment = KZTextVerticalAlignmentBottom;
    
    label.frame = CGRectMake(20, 100, 280, 400);
    label.backgroundColor = [UIColor colorWithWhite:0.933 alpha:1.000];
    [self.view addSubview:label];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 130, 300)];
    imageView.image = [UIImage imageNamed:@"yuhechuan.png"];
    
    KZTextAttachment *iconAttachment = [[KZTextAttachment alloc]init];
    iconAttachment.content = imageView;
    iconAttachment.contentMode = UIViewContentModeScaleAspectFill;
    iconAttachment.aligment = KZTextVerticalAlignmentBottom;
    NSMutableAttributedString *test = [[NSMutableAttributedString attributedStringWithAttachment:iconAttachment] mutableCopy];
    
    NSString *title = @"\u200b @玉河川 \u2060需要模型改吗 现状不太对";
    NSMutableAttributedString *test1 = [[NSMutableAttributedString alloc]initWithString:title];
    NSArray *list  = @[@"@玉河川"];
    for (NSString *sub in list) {
        NSRange range = [title rangeOfString:sub];
        KZTextBorder *b = [[KZTextBorder alloc]init];
        b.borderStyle = KZBorderNormal;
        b.cornerRadius = 11;
        b.avoidLineBreak = YES;
        b.fillColor = [UIColor blueColor];
        b.insets = UIEdgeInsetsMake(0, -3, 0, -3);
        b.range = range;
        [test1 addAttribute:KZTextBorderAttributedStringKey value:b range:range];
        [test1 addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    }
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.headIndent = 3;
    paragraphStyle.firstLineHeadIndent = 3;
    paragraphStyle.tailIndent = -3;
    [test1 addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, test.length)];
    
    [test appendAttributedString:test1];
    test.kzFont = [UIFont systemFontOfSize:18];
    test.kzLineSpacing = 5;
    test.kzMinimumLineHeight = 22;
    label.attributedText = test;
    self.label = label;
}


@end
