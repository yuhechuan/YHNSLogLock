//
//  BZLineHeightHelper.h
//  KZStudy
//
//  Created by yuhechuan on 2024/10/22.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BZLineHeightHelper : NSObject

+ (void)testLineHeight:(UIView *)bgView;

@end
