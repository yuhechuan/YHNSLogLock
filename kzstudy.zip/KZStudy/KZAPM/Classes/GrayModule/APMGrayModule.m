//
//  APMGrayModule.m
//  KZAPM
//
//  Created by doit on 2020/2/20.
//

#import "APMGrayModule.h"
#import "AFHTTPSessionManager.h"
#import "APMUtilities.h"

//rd环境boss-api.weizhipin.com
static NSString * const APM_Gray_Request_Path = @"https://api.zhipin.com/api/zpApm/ios/gray/release/check";

@interface APMGrayModule ()

@property (nonatomic, strong) AFHTTPSessionManager *netSession;

@property (nonatomic, strong) dispatch_queue_t uploadQueue;

@end

@implementation APMGrayModule

+ (instancetype)shareModule {
    static APMGrayModule *center = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        center = [[APMGrayModule alloc] init];
    });
    return center;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        //forbid proxy
        configuration.connectionProxyDictionary = @{};
        self.netSession = [[AFHTTPSessionManager alloc] initWithSessionConfiguration:configuration];
        
        self.uploadQueue = dispatch_queue_create("com.LYPDoit.KZAPM.APMGrayModule.upload", DISPATCH_QUEUE_SERIAL);

    }
    return self;
}

- (void)enableWithAppKey:(NSString *)appKey
                  vector:(NSString *)vector
                  userID:(int64_t)userID
              customHint:(_Nullable APMGrayCustomBlock)customHint
{
    dispatch_async(self.uploadQueue, ^{
        if (!appKey || !vector) return;

        if ([self hasShowAlert] || [self testFlightVersion]) return;
        NSString *encrypt = APM_AESEncryptStringToBase64([NSString stringWithFormat:@"%lld", userID], appKey, vector);
        NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
        NSDictionary *params = @{@"appKey" : appKey,
                                 @"version" : APM_SafeString(version),
                                 @"u" : APM_SafeString(encrypt)};
        [self.netSession POST:APM_Gray_Request_Path parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            if (responseObject && [responseObject isKindOfClass:NSDictionary.class]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSDictionary *data = responseObject[@"zpData"];
                    if (data) {
                        BOOL update = [data[@"update"] boolValue];
                        if (update) {
                            [self setPreVersionRecordTime];
                            if (customHint) {
                                customHint(data[@"title"], data[@"content"], data[@"url"]);
                            }else{
                                [self analysePreVersionResponseInfo:data[@"title"] dialogContent:data[@"content"] flightURL:data[@"url"]];
                            }
                        }
                    }
                });
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"[APM] gray request faild, detail: %@", error);
        }];
    });
}

- (void)analysePreVersionResponseInfo:(NSString *)dialogTitle
                        dialogContent:(NSString *)dialogContent
                            flightURL:(NSString *)flightURL
{
    if (!flightURL) return;
    if (dialogTitle.length < 1) {
        dialogTitle = @"温馨提示";
    }
    //content
    if (!dialogContent) {
        dialogContent = @"邀请你体验抢先内测版,更多新版本功能抢先体验";
    }
    //go to gray version
    [self showAlertWithTitle:dialogTitle message:dialogContent okDescribe:@"立即体验" clcikOk:^{
        NSString *decodeUrl = [self urlDecodedString:flightURL];
        if (![self openURLByApplication:decodeUrl]) {
            NSLog(@"[AMP] Could not open the flight url!");
        }
     }];

      //go to no official version
//   [self showAlertWithTitle:dialogTitle message:dialogContent okDescribe:@"立即更新" clcikOk:^{
//       NSString *markurl= [NSString stringWithFormat:@"itms-apps://itunes.apple.com/app/id%@",self.appID];
//       [self openURLByApplication:markurl];
//   }];
}

- (BOOL)openURLByApplication:(NSString *)urlString {
    if (!urlString) return NO;
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return NO;
    if ([UIApplication.sharedApplication canOpenURL:url]) {
        /// UIApplicationOpenURLOptionUniversalLinksOnly YES 只能应用间跳转，NO无法跳转应用时会使用safari打开
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:url options:@{UIApplicationOpenURLOptionUniversalLinksOnly : @NO} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:url];
        }
        return YES;
    }
    return NO;
}

- (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
                okDescribe:(NSString *)okDescribe
                   clcikOk:(void (^)(void))clcikOk
{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:okDescribe style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (clcikOk) {
            clcikOk();
        }
    }];
    [alertVC addAction:okAction];

    UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"暂不" style:UIAlertActionStyleCancel handler:nil];
    [alertVC addAction:actionCancel];

    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertVC animated:YES completion:nil];
}

// detect current whether is testflight version
- (BOOL)testFlightVersion {
    if (![NSBundle.mainBundle respondsToSelector:@selector(appStoreReceiptURL)]) {
        return NO;
    }
    return [[[[NSBundle mainBundle] appStoreReceiptURL] lastPathComponent] isEqualToString:@"sandboxReceipt"];
}

- (void)setPreVersionRecordTime {
    NSString * dateStr = [self dataStringForDate:[NSDate date] format:@"yyyy-MM-dd"];
    [[NSUserDefaults standardUserDefaults] setObject:dateStr forKey:@"kPreVersionRecordTime"];
}

- (BOOL)hasShowAlert {
    NSString * preDateStr =  [[NSUserDefaults standardUserDefaults] objectForKey:@"kPreVersionRecordTime"];
    NSString * currDateStr = [self dataStringForDate:[NSDate date] format:@"yyyy-MM-dd"];
    return [preDateStr isEqualToString:currDateStr];
}

- (NSString *)dataStringForDate:(NSDate *)data format:(NSString *)format {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    return [formatter stringFromDate:[NSDate date]];
}

- (NSString*)urlDecodedString:(NSString *)url {
    NSString *decodedCFString = [url stringByRemovingPercentEncoding];
    // We need to replace "+" with " " because the CF method above doesn't do it
    if (decodedCFString) {
        NSString *decodedString = [[NSString alloc] initWithString:decodedCFString];
        if (decodedString) {
            decodedString = [decodedString stringByReplacingOccurrencesOfString:@"+" withString:@" "];
            decodedString = [decodedString stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
            return decodedString;
        }
    }
    return @"";
}

@end
