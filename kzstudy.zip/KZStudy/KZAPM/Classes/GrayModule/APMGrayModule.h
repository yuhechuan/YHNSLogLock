//
//  APMGrayModule.h
//  KZAPM
//
//  Created by doit on 2020/2/20.
//

#import <Foundation/Foundation.h>

typedef void(^APMGrayCustomBlock)(NSString * _Nullable title,
                                  NSString * _Nullable content,
                                  NSString * _Nullable url);

NS_ASSUME_NONNULL_BEGIN

@interface APMGrayModule : NSObject

+ (instancetype)shareModule;

- (void)enableWithAppKey:(NSString *)appKey
                  vector:(NSString *)vector
                  userID:(int64_t)userID
              customHint:(_Nullable APMGrayCustomBlock)customHint;
@end

NS_ASSUME_NONNULL_END
