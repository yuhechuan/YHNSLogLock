//
//  KZAMP.m
//  KZAPM
//
//  Created by doit on 2020/2/15.
//

#import "KZAMP.h"

static BOOL _g_start_log = NO;
static BOOL _g_start_gray = NO;
static BOOL _g_start_onlineParams = NO;

@implementation KZAMP

#pragma mark -- Log module

void KZAPM_logEnable(APMLogEnableType enableType, NSString *appKey, NSString *vector, int64_t userID, APMExceptionUpload excUpload)
{
    KZAPM_logEnableCustom(enableType, appKey, vector, userID, excUpload, nil, nil);
}

void KZAPM_logEnableWithDBMonitor(APMLogEnableType enableType,
                                  NSString *appKey,
                                  NSString *vector,
                                  int64_t userID,
                                  APMExceptionUpload excUpload,
                                  APMDBDamagedBlock dbInfoMonitor)
{
    KZAPM_logEnableCustom(enableType, appKey, vector, userID, excUpload, dbInfoMonitor, nil);
}

void KZAPM_logEnableCustom(APMLogEnableType enableType,
                           NSString *appKey,
                           NSString *vector,
                           int64_t userID,
                           APMExceptionUpload excUpload,
                           APMDBDamagedBlock dbInfoMonitor,
                           APMLogReportResult reportResult)
{
    if (!appKey || !vector) {
        NSLog(@"[APM] Log module missing necessary parameters!");
        return;
    }
    _g_start_log = YES;
    if (dbInfoMonitor) {
        [APMLogModule shareModule].dbDamagedNotifyBlock = ^(int code) {
            dbInfoMonitor(code);
        };
    }
   
    [[APMLogModule shareModule] enableWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload repportResult:reportResult];
}

void KZAPM_logImmediateExcEnable(APMLogEnableType enableType,
                                 NSString *appKey,
                                 NSString *vector,
                                 int64_t userID,
                                 APMExceptionUpload excUpload,
                                 APMImmediateUpload excUploadResult)
{
    if (!appKey || !vector) {
        NSLog(@"[APM] Log module missing necessary parameters!");
        return;
    }
    _g_start_log = YES;
    [[APMLogModule shareModule] enableInImmediateExcWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload excUploadResult:excUploadResult];
}

void KZAPM_logDebugEnable(APMLogEnableType enableType,
                          NSString *appKey,
                          NSString *vector,
                          int64_t userID,
                          APMExceptionUpload excUpload)
{
    if (!appKey || !vector) {
        NSLog(@"[APM] Log module missing necessary parameters!");
        return;
    }
    _g_start_log = YES;
    [[APMLogModule shareModule] enableDebugWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload];
}

void KZAPM_updateLogUserID(int64_t userID) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] updateUserID:userID];
}

void KZAPM_updateDeviceID(NSString *deviceID) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] updateDeviceID:deviceID];
}

void KZAPM_triggerExceptionAction(NSString *reportID, NSString *downloadUrl){
    if (!_g_start_log) return;
    [[APMLogModule shareModule] triggerExceptionWithReportID:reportID downloadUrl:downloadUrl];
}

void KZAPM_triggerAction(NSString *action, NSString *subType, NSString *content) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] triggerAction:action subType:subType content:content];
}

void KZAPM_triggerCustomAction(NSString *action, NSString *subType, NSDictionary *customDic) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] triggerCustomAction:action subType:subType params:customDic];
}

void KZAPM_triggerImmediateAction(NSString *action,
                                  NSString * _Nullable subType,
                                  NSString *content,
                                  APMImmediateUpload uploadResult)
{
    if (!_g_start_log) return;
    [[APMLogModule shareModule] triggerImmediatelyAction:action subType:subType content:content uploadResult:uploadResult];
}

void KZAPM_updateObjcExceptionOwnership(void) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] updateObjcExceptionOwnership];
}

void KZAPM_updateUnixSignalOwnership(void) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] updateUnixSignalOwnership];
}

void KZAPM_updateUserMark(NSString *userMark) {
    if (!_g_start_log) return;
    [[APMLogModule shareModule] updateUserMark:userMark];
}

KZPRebootLastTerminateReasonType KZAPM_getLastTerminateReason(void) {
    if (!_g_start_log) return KZPRebootLastTerminateReasonUnknow;
    return [APMLogModule shareModule].reasonType;
}

NSString *KZAPM_getLastTerminateReasonDescription(void) {
    if (!_g_start_log) return @"Unknown";
    return [APMLogModule shareModule].reasonTypeDescription;
}

#pragma mark -- Gray module

void KZAPM_grayEnable(NSString *appKey, NSString *vector, int64_t userID){
    KZAPM_grayEnableWithCustom(appKey, vector, userID, nil);
}

void KZAPM_grayEnableWithCustom(NSString *appKey, NSString *vector, int64_t userID, APMGrayCustomBlock custom){
    if (!appKey || !vector) {
       NSLog(@"[APM] Gray module missing necessary parameters!");
       return;
    }
    _g_start_gray = YES;
    [[APMGrayModule shareModule] enableWithAppKey:appKey vector:vector userID:userID customHint:custom];
}


#pragma mark -- Online params module
void KZAPM_OnlineParamsEnable(NSString *appKey,
                              NSString *vector,
                              int64_t userID) {
    if (!appKey || !vector) {
       NSLog(@"[APM] Online params module missing necessary parameters!");
       return;
    }
    _g_start_onlineParams = YES;
    [KZAPM_OPModule enableWithAppKey:appKey vector:vector userID:userID];
}
//update user id
void KZAPM_updateOnlineParamsUserID(int64_t userID) {
    if (!_g_start_onlineParams) return;
    [KZAPM_OPModule updateUserID:userID];
}

void KZAPM_asyncAllValues(APMOParamQueryBlock queryBlock) {
    if (!_g_start_onlineParams) return;
    [KZAPM_OPModule asyncAllValuesWithQueryBlock:queryBlock];
}

void KZAPM_asyncValueForKey(NSString *paramKey,
                            APMOValueType valueType,
                            APMOParamQueryBlock queryBlock)
{
    if (!_g_start_onlineParams) return;
    [KZAPM_OPModule asyncValueForKey:paramKey valueType:valueType queryBlock:queryBlock];
}

@end
