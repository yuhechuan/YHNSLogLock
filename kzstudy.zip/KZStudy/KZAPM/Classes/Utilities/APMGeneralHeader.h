//
//  APMGeneralHeader.h
//  KZAPM
//
//  Created by doit on 2020/4/17.
//

#ifndef APMGeneralHeader_h
#define APMGeneralHeader_h

/**  General APM log keys **/
#define APM_LOG_USER_MARK       @"userMark"

#define APM_LOG_DEVICEID        @"deviceID"


#endif /* APMGeneralHeader_h */
