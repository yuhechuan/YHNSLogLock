//
//  APMUtilities.h
//  KZAPM
//
//  Created by doit on 2020/2/18.
//

#import <Foundation/Foundation.h>
#import "APMGeneralHeader.h"


/**
 subType:Launch \ MainThread \ EnterForground
 */
FOUNDATION_EXTERN NSString * const APM_Freeze_Action;
/**
 subType:NSException \ Signal \ Mach
 */
FOUNDATION_EXTERN NSString * const APM_Crash_Action;

FOUNDATION_EXTERN NSString * const APM_Launch_Action;

FOUNDATION_EXTERN NSString * const APM_Active_Action;


static inline NSString * APM_SafeString(NSString * value) {
    if (!value) return @"";
    return value;
}

static inline NSString * APM_SafeStringReplace(NSString *value, NSString *replace) {
    if (!value) {
        if (replace) {
            return replace;
        }else{
            return @"";
        }
    }
    return value;
}

@interface APMUtilities : NSObject

extern
BOOL APM_IsSDKActionName(NSString * actionName);

extern
NSString * APM_FormatObjectToJsonString(id object);

extern
id APM_FormatJsonStringToObject(NSString *jsonString);

extern
NSString  * APM_AESEncryptStringToBase64(NSString *string, NSString *key, NSString *vector);

@end

