//
//  APMUtilities.m
//  KZAPM
//
//  Created by doit on 2020/2/18.
//

#import "APMUtilities.h"
#import <CommonCrypto/CommonCrypto.h>
#import <CommonCrypto/CommonDigest.h>

NSString * const APM_Freeze_Action = @"APMFreeze";

NSString * const APM_Crash_Action = @"APMCrash";

NSString * const APM_Launch_Action = @"APMLaunch";

NSString * const APM_Active_Action = @"APMActive";


@implementation APMUtilities

BOOL APM_IsSDKActionName(NSString * actionName) {
    if (!actionName) {
        return NO;
    }
    if (actionName == APM_Freeze_Action ||
        actionName == APM_Crash_Action ||
        actionName == APM_Launch_Action ||
        actionName == APM_Active_Action) {
        return YES;
    }
    return NO;
}

NSString *APM_FormatObjectToJsonString(id object) {
    if (!object) return nil;
    NSString *jsonString = nil;
    if ([NSJSONSerialization isValidJSONObject:object]) {
        NSData *pJsonData = [NSJSONSerialization dataWithJSONObject:object options:NSJSONWritingPrettyPrinted error:nil];
        if (pJsonData) {
            NSString *pStr = [[NSString alloc] initWithData:pJsonData encoding:NSUTF8StringEncoding];
            if (pStr) jsonString = pStr;
        }
    }else{
        NSLog(@"[APM] Custom params is invalid json object!");
    }
    return jsonString;
}

id APM_FormatJsonStringToObject(NSString *jsonString) {
    if (!jsonString) return nil;
    
    id obj = nil;
    NSData *jsd = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    if (jsd) {
        obj = [NSJSONSerialization JSONObjectWithData:jsd options:NSJSONReadingMutableContainers error:nil];
    }
    return obj;
}

#pragma mark - AES

NSString *APM_AESEncryptStringToBase64(NSString *string,
                                       NSString *key,
                                       NSString *vector)
{
    if (!string || !key) return nil;
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    NSData *result = AES128_Operation(kCCEncrypt, key, data, vector);
    if (result) {
        return [result base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    }
    return nil;
    //    //tranform to hex format
    //    if(result && result.length > 0)
    //    {
    //        Byte *datas = (Byte *)[result bytes];
    //        NSMutableString *outPut = [NSMutableString stringWithCapacity:result.length];
    //        for(int i = 0 ; i < result.length ; i++)
    //        {
    //            [outPut appendFormat:@"%02x",datas[i]];
    //        }
    //        return outPut;
    //    }
    //    return nil;
}

//NSString *APM_AESDecryptStringFromBase64(NSString *string,
//                                         NSString *key,
//                                         NSString *vector)
//{
//    if (!string || !key) return nil;
//
//    //转换为2进制Data
//    //    NSMutableData *data = [NSMutableData dataWithCapacity:string.length / 2];
//    //    unsigned char whole_byte;
//    //    char byte_chars[3] = {'\0','\0','\0'};
//    //    int i;
//    //    for (i=0; i < [string length] / 2; i++) {
//    //        byte_chars[0] = [string characterAtIndex:i*2];
//    //        byte_chars[1] = [string characterAtIndex:i*2+1];
//    //        whole_byte = strtol(byte_chars, NULL, 16);
//    //        [data appendBytes:&whole_byte length:1];
//    //    }
//    NSData *data = [[NSData alloc] initWithBase64EncodedString:string options:NSDataBase64DecodingIgnoreUnknownCharacters];
//    NSData *result = AES128_Operation(kCCDecrypt, key, data, vector);
//    if(result) {
//        return [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
//    }
//    return nil;
//}

static NSData *AES128_Operation(CCOperation operate,
                                NSString *key,
                                NSData *contentData,
                                NSString *vector)
{
    if (!key || !contentData) return nil;
    
    char keyPtr[kCCKeySizeAES128+1];
    memset(keyPtr, 0, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    char ivPtr[kCCKeySizeAES128+1];
    memset(ivPtr, 0, sizeof(ivPtr));
    if (vector) {
        [vector getCString:ivPtr maxLength:sizeof(ivPtr) encoding:NSUTF8StringEncoding];
    }
    
    NSUInteger dataLength = [contentData length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    if (!buffer) return nil;
    size_t numBytes = 0;
    CCCryptorStatus cryptStatus = CCCrypt(operate,
                                          kCCAlgorithmAES,
                                          kCCOptionPKCS7Padding,
                                          keyPtr,
                                          kCCBlockSizeAES128,
                                          ivPtr,
                                          [contentData bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytes);
    NSData *resultData = nil;
    if (cryptStatus == kCCSuccess) {
        resultData = [NSData dataWithBytes:buffer length:numBytes];
    }
    free(buffer);
    return resultData;
}


@end
