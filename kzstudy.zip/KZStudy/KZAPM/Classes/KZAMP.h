//
//  KZAMP.h
//  KZAPM
//
//  Created by doit on 2020/2/15.
//

#import <Foundation/Foundation.h>
#import "APMLogModule.h"
#import "APMGrayModule.h"
#import "APMOnlineParamsModule.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZAMP : NSObject

#ifdef __cplusplus
extern "C" {
#endif

#pragma mark -- Log module
//Log entrance
extern
void KZAPM_logEnable(APMLogEnableType enableType,
                     NSString *appKey,
                     NSString *vector,
                     int64_t userID,
                     APMExceptionUpload excUpload);

extern
void KZAPM_logEnableWithDBMonitor(APMLogEnableType enableType,
                                  NSString *appKey,
                                  NSString *vector,
                                  int64_t userID,
                                  APMExceptionUpload excUpload,
                                  APMDBDamagedBlock dbInfoMonitor);
extern
void KZAPM_logEnableCustom(APMLogEnableType enableType,
                           NSString *appKey,
                           NSString *vector,
                           int64_t userID,
                           APMExceptionUpload excUpload,
                           APMDBDamagedBlock _Nullable dbInfoMonitor,
                           APMLogReportResult _Nullable reportResult);
//Immediate log entrance
extern
void KZAPM_logImmediateExcEnable(APMLogEnableType enableType,
                                 NSString *appKey,
                                 NSString *vector,
                                 int64_t userID,
                                 APMExceptionUpload excUpload,
                                 APMImmediateUpload excUploadResult);
//debug log entrance
extern
void KZAPM_logDebugEnable(APMLogEnableType enableType,
                          NSString *appKey,
                          NSString *vector,
                          int64_t userID,
                          APMExceptionUpload excUpload);

//update user id
extern
void KZAPM_updateLogUserID(int64_t userID);

//update device id
extern
void KZAPM_updateDeviceID(NSString *deviceID);
    
//trigger common action
extern
void KZAPM_triggerAction(NSString *action,
                         NSString * _Nullable subType,
                         NSString *content);
    
//trigger custom action
void KZAPM_triggerCustomAction(NSString *action,
                               NSString * _Nullable subType,
                               NSDictionary *customDic);


//trigger immediate action
extern
void KZAPM_triggerImmediateAction(NSString *action,
                                  NSString * _Nullable subType,
                                  NSString *content,
                                  APMImmediateUpload _Nullable uploadResult);

//trigger exception action
extern
void KZAPM_triggerExceptionAction(NSString *reportID,
                                  NSString *downloadUrl);
    
//update objc exception ownership
extern
void KZAPM_updateObjcExceptionOwnership(void);
    
//update unix signal ownership
extern
void KZAPM_updateUnixSignalOwnership(void);
    
//update user mark.
extern
void KZAPM_updateUserMark(NSString *userMark);

//get last terminate reason.
extern
KZPRebootLastTerminateReasonType KZAPM_getLastTerminateReason(void);
    
//get last terminate reason description.
extern
NSString *KZAPM_getLastTerminateReasonDescription(void);

#pragma mark -- Gray module
//Gray entrance
extern
void KZAPM_grayEnable(NSString *appKey,
                      NSString *vector,
                      int64_t userID);

//Gray entrance with custom block
extern
void KZAPM_grayEnableWithCustom(NSString *appKey,
                                NSString *vector,
                                int64_t userID,
                                APMGrayCustomBlock _Nullable custom);
    
#pragma mark -- Online params module
extern
void KZAPM_OnlineParamsEnable(NSString *appKey,
                              NSString *vector,
                              int64_t userID);
//update user id
extern
void KZAPM_updateOnlineParamsUserID(int64_t userID);

//query all values for current version

extern
void KZAPM_asyncAllValues(APMOParamQueryBlock queryBlock);
  
//query for param key
extern
void KZAPM_asyncValueForKey(NSString *paramKey,
                            APMOValueType valueType,
                            APMOParamQueryBlock queryBlock);
    
#ifdef __cplusplus
}  // extern "C"
#endif

@end

NS_ASSUME_NONNULL_END
