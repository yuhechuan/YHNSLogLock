//
//  APMOnlineParamsModule.m
//  KZAPM
//
//  Created by doit on 2021/1/18.
//

#import "APMOnlineParamsModule.h"
#import "AFHTTPSessionManager.h"
#import "APMUtilities.h"

#define  APM_OP_Request_Path  @"https://api.zhipin.com/api/zpApm/online/config/check";

@interface APMOnlineParamsModule ()

@property (nonatomic, strong) AFHTTPSessionManager *netSession;

@property (nonatomic, strong) dispatch_queue_t handleQueue;

@property (nonatomic, strong) NSMutableDictionary *paramsCache;

@property (nonatomic, strong) NSString *appKey;

@property (nonatomic, strong) NSString *vector;

@property (nonatomic, assign) int64_t userID;

@property (nonatomic, strong) dispatch_semaphore_t signal;

@property (nonatomic, strong) NSString *requestURL;

@end

@implementation APMOnlineParamsModule

#pragma mark -- Init
+ (instancetype)shareInstance {
    static APMOnlineParamsModule *online = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        online = [[APMOnlineParamsModule alloc] init];
    });
    return  online;
}


- (instancetype)init
{
    self = [super init];
    if (self) {
        self.requestURL = APM_OP_Request_Path;
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        //forbid proxy
        configuration.connectionProxyDictionary = @{};
        self.netSession = [[AFHTTPSessionManager alloc] initWithSessionConfiguration:configuration];
        
        self.handleQueue = dispatch_queue_create("com.LYPDoit.KZAPM.OnlineParamsModule.upload", DISPATCH_QUEUE_SERIAL);
        self.paramsCache = [[NSMutableDictionary alloc] init];
        self.signal = dispatch_semaphore_create(1);
    }
    return self;
}

- (void)enableWithAppKey:(NSString *)appKey
                  vector:(NSString *)vector
                  userID:(int64_t)userID {
    if (self.appKey || !appKey || !vector) {
        return;
    }
    
    dispatch_sync(self.handleQueue, ^{
        self.appKey = appKey;
        self.vector = vector;
        self.userID = userID;
    });
}

- (void)_enableWithAppKey:(NSString *)appKey
                   vector:(NSString *)vector
                   userID:(int64_t)userID
                      url:(NSString *)url {
    if (self.appKey || !appKey || !vector) {
        return;
    }
    
    dispatch_sync(self.handleQueue, ^{
        self.requestURL = url;
        self.appKey = appKey;
        self.vector = vector;
        self.userID = userID;
    });
}

#pragma mark -- Update
- (void)updateUserID:(int64_t)userID {
    if (!self.appKey) return;
    dispatch_async(self.handleQueue, ^{
        self.userID = userID;
    });
}

#pragma mark -- Async query
- (void)asyncAllValuesWithQueryBlock:(APMOParamQueryBlock)queryBlock {
    if (!self.appKey) return;
    [self _requestValueForKey:nil valueType:APMOValueDictionary queryBlock:queryBlock];
}

- (void)asyncValueForKey:(NSString *)paramKey
               valueType:(APMOValueType)valueType
              queryBlock:(APMOParamQueryBlock)queryBlock
{
    if (!self.appKey) return;
    dispatch_async(self.handleQueue, ^{
        //invalid key
        if (!paramKey){
            if (queryBlock) queryBlock(nil);
            return;
        }
        //value in cache
        id memObj = [self _memoryForParamKey:paramKey];
        if (!memObj) {
            //value not exist, request by net
            [self _requestValueForKey:paramKey valueType:valueType queryBlock:queryBlock];
            
        }else if (![memObj isKindOfClass:[self valueTypeToClass:valueType]]){
            //value type not match
            if (queryBlock) queryBlock(nil);
            
        }else{
            if (queryBlock) queryBlock(memObj);
        }
    });
}

#pragma mark -- Sync query
- (nullable id)valueForKey:(NSString *)paramKey
                 valueType:(APMOValueType)valueType
{
    return [self _objectForParamKey:paramKey valueType:valueType];
}

- (NSDictionary *)dictForParamKey:(NSString *)paramKey {
    return [self _objectForParamKey:paramKey valueType:APMOValueDictionary];
}

- (nullable NSArray *)arrayForParamKey:(NSString *)paramKey {
    return [self _objectForParamKey:paramKey valueType:APMOValueArray];
}

- (nullable NSString *)stringForParamKey:(NSString *)paramKey {
    return [self _objectForParamKey:paramKey valueType:APMOValueString];
}

- (int64_t)intForParamKey:(NSString *)paramKey {
    NSNumber *re = [self _objectForParamKey:paramKey valueType:APMOValueNumber];
    if (re) {
        return re.longLongValue;
    }else{
        return 0;
    }
}

- (double)doubleForParamKey:(NSString *)paramKey {
    NSNumber *re = [self _objectForParamKey:paramKey valueType:APMOValueNumber];
    if (re) {
        return re.doubleValue;
    }else{
        return 0.0;
    }
}

- (BOOL)boolForParamKey:(NSString *)paramKey {
    NSNumber *re = [self _objectForParamKey:paramKey valueType:APMOValueNumber];
    if (re) {
        return re.boolValue;
    }else{
        return NO;
    }
}

#pragma mark -- Private
//verify the value type
- (Class)valueTypeToClass:(APMOValueType)valueType {
    switch (valueType) {
        case APMOValueDictionary:
            return NSDictionary.class;
        case APMOValueArray:
            return NSArray.class;
        case APMOValueNumber:
            return NSNumber.class;
        case APMOValueString:
            return NSString.class;
    }
    return Nil;
}

- (id)_memoryForParamKey:(NSString *)paramKey {
    if (!self.appKey || !paramKey) return nil;

    id object = nil;
    dispatch_semaphore_wait(self.signal, DISPATCH_TIME_FOREVER);
    object = self.paramsCache[paramKey];
    dispatch_semaphore_signal(self.signal);
    return  object;
}

- (id)_objectForParamKey:(NSString *)paramKey valueType:(APMOValueType)valueType{
    if (!paramKey) return nil;
    id memObj = [self _memoryForParamKey:paramKey];
  
    if (!memObj) {
        //value not exist
        [self _requestValueForKey:paramKey valueType:valueType queryBlock:nil];
        return nil;
        
    }else if (![memObj isKindOfClass:[self valueTypeToClass:valueType]]){
        //value type not match
        return nil;
    }
    return memObj;
    
}

// get all values when paramKey is nil.
- (void)_requestValueForKey:(NSString *)paramKey
                  valueType:(APMOValueType)valueType
                 queryBlock:(APMOParamQueryBlock)queryBlock
{
    dispatch_async(self.handleQueue, ^{
        if (!self.appKey) return;
        NSString *encrypt = APM_AESEncryptStringToBase64([NSString stringWithFormat:@"%lld", self.userID], self.appKey, self.vector);
        NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
        NSMutableDictionary *params = @{@"appKey" : self.appKey,
                                 @"version" : APM_SafeString(version),
                                 @"userId" : APM_SafeString(encrypt)}.mutableCopy;
        if (paramKey) {
            params[@"paramKey"] = APM_SafeString(paramKey);
        }
        [self.netSession POST:self.requestURL parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            dispatch_async(self.handleQueue, ^{
                NSArray *datas = nil;
                if (responseObject && [responseObject isKindOfClass:NSDictionary.class]) {
                    id codenum = responseObject[@"code"];
                    if (codenum && [codenum intValue] == 0) {
                        datas = responseObject[@"zpData"];
                    }
                }
                [self successForKey:paramKey datas:datas valueType:valueType queryBlock:queryBlock];
            });
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_async(self.handleQueue, ^{
                if (queryBlock) queryBlock(nil);
            });
            NSLog(@"[APM] Online params request faild, detail: %@", error);
        }];
    });
}

- (void)successForKey:(NSString *)paramKey
                datas:(NSArray *)datas
            valueType:(APMOValueType)valueType
           queryBlock:(APMOParamQueryBlock)queryBlock
{
    if (datas && [datas isKindOfClass:NSArray.class]) {
        id memObj = nil;
        dispatch_semaphore_wait(self.signal, DISPATCH_TIME_FOREVER);
        for (NSDictionary *opDic in datas) {
            if (opDic && [opDic isKindOfClass:NSDictionary.class]) {
                NSString *key = opDic[@"paramKey"];
                id value = opDic[@"value"];
                if (key && value) {
                    self.paramsCache[key] = value;
                }
            }
        }
        if (paramKey){
            memObj = self.paramsCache[paramKey];
        }else{
            memObj = self.paramsCache.copy;
        }
        dispatch_semaphore_signal(self.signal);
        
        if (queryBlock) {
            if (memObj && ![memObj isKindOfClass:[self valueTypeToClass:valueType]]){
                //value type not match
                memObj = nil;
            }
            queryBlock(memObj);
        }
    }else{
        if (queryBlock) queryBlock(nil);
    }
}

@end
