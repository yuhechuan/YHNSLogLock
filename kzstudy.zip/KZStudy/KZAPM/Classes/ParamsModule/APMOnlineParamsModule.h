//
//  APMOnlineParamsModule.h
//  KZAPM
//
//  Created by doit on 2021/1/18.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

#define KZAPM_OPModule ([APMOnlineParamsModule shareInstance])

typedef NS_ENUM(NSInteger, APMOValueType) {
    APMOValueDictionary,
    APMOValueArray,
    APMOValueNumber,
    APMOValueString
};

typedef void(^APMOParamQueryBlock)(id _Nullable result);

@interface APMOnlineParamsModule : NSObject

#pragma mark -- Init
+ (instancetype)shareInstance;

- (void)enableWithAppKey:(NSString *)appKey
                  vector:(NSString *)vector
                  userID:(int64_t)userID;

#pragma mark -- Update
- (void)updateUserID:(int64_t)userID;

#pragma mark -- Async query
//query all values for current version form net
- (void)asyncAllValuesWithQueryBlock:(APMOParamQueryBlock)queryBlock;

//query for param key in memory or network
- (void)asyncValueForKey:(NSString *)paramKey
               valueType:(APMOValueType)valueType
              queryBlock:(APMOParamQueryBlock)queryBlock;


#pragma mark -- Sync query in memory cache and async reqeust when not in cache

- (nullable id)valueForKey:(NSString *)paramKey
                 valueType:(APMOValueType)valueType;

- (nullable NSDictionary *)dictForParamKey:(NSString *)paramKey;

- (nullable NSArray *)arrayForParamKey:(NSString *)paramKey;

- (nullable NSString *)stringForParamKey:(NSString *)paramKey;

- (int64_t)intForParamKey:(NSString *)paramKey;

- (double)doubleForParamKey:(NSString *)paramKey;

- (BOOL)boolForParamKey:(NSString *)paramKey;

#pragma mark -- test

- (void)_enableWithAppKey:(NSString *)appKey
                   vector:(NSString *)vector
                   userID:(int64_t)userID
                      url:(NSString *)url;


@end

NS_ASSUME_NONNULL_END
