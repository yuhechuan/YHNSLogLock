//
//  APMLogModule.m
//  KZAPM
//
//  Created by doit on 2020/2/15.
//

#import "APMLogModule.h"
#import "KZPGeneralMacros.h"
#import "APMUtilities.h"
#import "APMUploadAssembler.h"
#import "KZPerformanceWolf.h"
#import "AFHTTPSessionManager.h"
#import "APMLogElement.h"
#import "KZPSystemEnvInfoAssistor.h"
#import <MetricKit/MetricKit.h>

static NSString * const APM_Upload_URL = @"https://api.zhipin.com/api/zpApm/actionLog/common.json";

static NSString * const APM_Upload_URL_Debug = @"https://boss-api.weizhipin.com/api/zpApm/actionLog/common.json";

#define APM_TIMER_DELAY_INTERVAL  3

#define APM_UPLOAD_INTERVAL   10

#define APM_MAX_CACHE_COUNT 15

#define APM_MAX_FAILED_CACHE_COUNT 160

#define APM_ACTIVE_SEND_INTERVAL  60

@interface APMLogModule ()<MXMetricManagerSubscriber>

@property (nonatomic, strong) dispatch_queue_t uploadQueue;

@property (nonatomic, strong) AFHTTPSessionManager *uploadSession;

@property (nonatomic, strong) NSMutableArray *logCaches;

@property (nonatomic, strong) NSMutableArray *failedCaches;

@property (nonatomic, strong) NSString *appKey;

@property (nonatomic, strong) NSString *vector;

@property (nonatomic, assign) int64_t userID;

@property (nonatomic, strong) NSString *userMark;

@property (nonatomic, assign) APMLogEnableType enableType;

@property (nonatomic, strong) dispatch_source_t timer;

@property (nonatomic, strong) NSMutableDictionary *exceptionCache;

@property (nonatomic, copy) APMExceptionUpload excUpload;

@property (nonatomic, copy) APMImmediateUpload excUploadResult;

@property (nonatomic, copy) APMLogReportResult reportResult;

@property (nonatomic, strong) NSMutableArray *immediateExcCaches;

@property (nonatomic, strong) NSError *immediateExcError;

@property (nonatomic, assign) BOOL isDebug;

@property (nonatomic, assign) BOOL appBackgroundStatus;

@property (nonatomic, assign) CFTimeInterval lastLogPoint;

@property (nonatomic, strong) NSString *systemInfoCache;

@property (nonatomic, strong) NSString *deviceID;

@property (nonatomic, strong) APMLogDBManager *dbManager;

@end

@implementation APMLogModule

#pragma mark -- Initialize module
+ (instancetype)shareModule {
    static APMLogModule *center = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        center = [[APMLogModule alloc] init];
    });
    return center;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.uploadQueue = dispatch_queue_create("com.LYPDoit.KZAPM.APMLogModule.upload", DISPATCH_QUEUE_SERIAL);
        //db
        self.dbManager = [[APMLogDBManager alloc] init];
        __weak typeof(self) weakSelf = self;
        self.dbManager.dbDamaged = ^(int code) {
            if (weakSelf.dbDamagedNotifyBlock) {
                weakSelf.dbDamagedNotifyBlock(code);
            }
        };
        
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        //forbid proxy
        configuration.connectionProxyDictionary = @{};
        self.uploadSession = [[AFHTTPSessionManager alloc] initWithSessionConfiguration:configuration];
        
        self.uploadSession.requestSerializer = [AFHTTPRequestSerializer serializer];
        [self.uploadSession.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        self.uploadSession.responseSerializer.acceptableContentTypes = [NSSet
           setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/plain", nil];
        self.uploadSession.completionQueue = self.uploadQueue;
        
        self.logCaches = [[NSMutableArray alloc] init];
        self.failedCaches = [[NSMutableArray alloc] init];
        self.exceptionCache = [[NSMutableDictionary alloc] init];
        self.immediateExcCaches = [[NSMutableArray alloc] init];
        self.lastLogPoint = 0;
        self.appBackgroundStatus = NO;
        _reasonType = KZPRebootLastTerminateReasonUnknow;
        _reasonTypeDescription = @"Unknow";
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(didEnterBackground)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(willResignActive)
                                                     name:UIApplicationWillResignActiveNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(didBecomeActive)
                                                     name:UIApplicationDidBecomeActiveNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(willEnterForeground)
                                                     name:UIApplicationWillEnterForegroundNotification
                                                   object:nil];
        
        if (@available(iOS 13.0, *)) {
            [[MXMetricManager sharedManager]addSubscriber:self];
        } else {
            // Fallback on earlier versions
        }

    }
    return self;
}

- (void)enableWithLogType:(APMLogEnableType)enableType
                   appKey:(NSString *)appKey
                   vector:(NSString *)vector
                   userID:(int64_t)userID
                excUpload:(APMExceptionUpload)excUpload
{
    [self _enableWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload isDebug:NO excUploadResult:nil reportResult:nil];
}

- (void)enableWithLogType:(APMLogEnableType)enableType
                   appKey:(NSString *)appKey
                   vector:(NSString *)vector
                   userID:(int64_t)userID
                excUpload:(APMExceptionUpload)excUpload
            repportResult:(APMLogReportResult)repportResult
{
    [self _enableWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload isDebug:NO excUploadResult:nil reportResult:repportResult];
}

- (void)enableInImmediateExcWithLogType:(APMLogEnableType)enableType
                                 appKey:(NSString *)appKey
                                 vector:(NSString *)vector
                                 userID:(int64_t)userID
                              excUpload:(APMExceptionUpload)excUpload
                        excUploadResult:(APMImmediateUpload)excUploadResult
{
    [self _enableWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload isDebug:NO excUploadResult:excUploadResult reportResult:nil];
}

- (void)enableDebugWithLogType:(APMLogEnableType)enableType
                        appKey:(NSString *)appKey
                        vector:(NSString *)vector
                        userID:(int64_t)userID
                     excUpload:(APMExceptionUpload)excUpload
{
    [self _enableWithLogType:enableType appKey:appKey vector:vector userID:userID excUpload:excUpload isDebug:YES excUploadResult:nil reportResult:nil];
}


- (void)_enableWithLogType:(APMLogEnableType)enableType
                    appKey:(NSString *)appKey
                    vector:(NSString *)vector
                    userID:(int64_t)userID
                 excUpload:(APMExceptionUpload)excUpload
                   isDebug:(BOOL)isDebug
           excUploadResult:(APMImmediateUpload)excUploadResult
             reportResult:(APMLogReportResult)reportResult
{
    if (!appKey || !vector) {
        NSLog(@"[APM]: Please confirm whether the start parameters are valid!");
        return;
    }
    if (self.appKey) {
        return;
    }
    
    //start
    self.appKey = appKey;
    self.userID = userID;
    self.vector = vector;
    self.enableType = enableType;
    self.excUpload = excUpload;
    self.isDebug = isDebug;
    self.excUploadResult = excUploadResult;
    self.reportResult = reportResult;
    
    //reload system
    [self reloadSystemInfo];
    
    //start db
    __weak typeof(self) weakSelf = self;
    self.dbManager.dbDamaged = ^(int code) {
        if (weakSelf.dbDamagedNotifyBlock) {
            weakSelf.dbDamagedNotifyBlock(code);
        }
    };
    [self.dbManager startupDBManager];

    //timer
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, self.uploadQueue);
    dispatch_source_set_timer(self.timer, dispatch_walltime(NULL, APM_TIMER_DELAY_INTERVAL * NSEC_PER_SEC), APM_UPLOAD_INTERVAL * NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(self.timer, ^{
        if (!self.appBackgroundStatus) {
            CFTimeInterval curTime = CACurrentMediaTime();
            if (curTime - self.lastLogPoint >= APM_ACTIVE_SEND_INTERVAL) {
                self.lastLogPoint = curTime;
                NSString *time = [NSString stringWithFormat:@"%.0f", NSDate.date.timeIntervalSince1970*1000];
                NSDictionary *contentDic = [APMNormalElement contentDicWithContent:@"Active"];
                [self _triggerAction:APM_Active_Action subType:nil contentDic:contentDic ocurrDate:time];
            }
        }
        if (self.logCaches.count > 0) {
            NSArray *eles = [NSArray arrayWithArray:self.logCaches];
            [self.logCaches removeAllObjects];
            [self executeUploadWithUploadArr:eles];
        }
    });
    dispatch_resume(self.timer);
    
    //last terminal
    if (enableType & APMLogEnableFreeze && enableType & APMLogEnableCrash) {
        [[KZPRebootMonitor shareMonitor] startMonitor];
        _reasonType = [KZPRebootMonitor shareMonitor].reasonType;
        _reasonTypeDescription = [KZPRebootMonitor shareMonitor].reasonDescription;
    }
    
    //exception
    [self exceptionInitializeWithType:enableType];

    //others
    dispatch_async(self.uploadQueue, ^{
        //upload in db
        if (self.enableType & APMLogEnableCustom) {
            NSArray *elements = [self.dbManager getAllElementCachesInDB];
            if (elements && elements.count > 0) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), self.uploadQueue, ^{
                    [self executeUploadWithUploadArr:elements];
                });
            }
        }
        //log start action
        [self triggerCustomAction:APM_Launch_Action
                          subType:nil
                           params:@{@"p3" : @(self.reasonType)}];
    });
}


- (void)updateAppKey:(NSString *)appKey
              vector:(NSString *)vector
{
    dispatch_async(self.uploadQueue, ^{
        self.appKey = appKey;
        self.vector = vector;
    });
}

- (void)updateUserID:(int64_t)userID
{
    if (!self.appKey) return;
    dispatch_async(self.uploadQueue, ^{
        self.userID = userID;
    });
}

- (void)updateDeviceID:(NSString *)deviceID {
    if (!self.appKey) return;
    dispatch_async(self.uploadQueue, ^{
        self.deviceID = deviceID;
        [self reloadSystemInfo];
    });
}

- (void)didEnterBackground {
    self.appBackgroundStatus = YES;
}

- (void)willResignActive {
    self.appBackgroundStatus = YES;
}

- (void)didBecomeActive {
    self.appBackgroundStatus = NO;
}

- (void)willEnterForeground {
    self.appBackgroundStatus = NO;
}

- (void)updateUserMark:(NSString *)userMark {
    if (!self.appKey) return;
    dispatch_async(self.uploadQueue, ^{
        self.userMark = userMark;
        [self reloadSystemInfo];
    });
}

- (void)updateObjcExceptionOwnership {
    if (!self.appKey) return;
    [KZPCrashObjcException updateOjbcExceptionOwnership];
}

- (void)updateUnixSignalOwnership {
    if (!self.appKey) return;
    [KZPCrashUnixSignal recaptureSignalOwnership];
}

#pragma mark -- Exception action module
- (void)exceptionInitializeWithType:(APMLogEnableType)enableType {
    KZPerformanceType type = KZPerformanceNone;
    if (enableType & APMLogEnableFreeze) {
        type |= KZPerformanceFreeze;
    }
    
    if (enableType & APMLogEnableCrash) {
        type |= KZPerformanceCrash;
    }
    if (type == KZPerformanceNone) {
        return;
    }
    kzp_startMonitor(type);
    if (self.excUploadResult) {
        [[KZPerformanceDataCenter shareDataCenter] autoImmediateUploadUsingBlock:^(KZPDataType dataType, NSData * _Nonnull uploadData, NSString * _Nonnull filePath, NSString * _Nonnull reportID) {
            dispatch_async(self.uploadQueue, ^{
                [self reportExceptionData:uploadData dataType:dataType filePath:filePath reportID:reportID];
            });
        } startupDatas:^(NSArray<KZPUploadExceptionData *> * _Nonnull excDatas) {
            dispatch_async(self.uploadQueue, ^{
                for (KZPUploadExceptionData *data in excDatas) {
                    [self.immediateExcCaches addObject:data.reportID];
                    [self reportExceptionData:data.uploadData dataType:data.dataType filePath:data.filePath reportID:data.reportID];
                }
            });
        }];
    }else{
        [[KZPerformanceDataCenter shareDataCenter] autoUploadUsingBlock:^(KZPDataType dataType, NSData * _Nonnull uploadData, NSString *filePath, NSString * _Nonnull reportID) {
            dispatch_async(self.uploadQueue, ^{
                [self reportExceptionData:uploadData dataType:dataType filePath:filePath reportID:reportID];
            });
        }];
    }
}

- (void)reportExceptionData:(NSData *)exceptionData
                   dataType:(KZPDataType)dataType
                   filePath:(NSString *)filePath
                   reportID:(NSString *)reportID
{
    //Warning : current only collect freeze and crash!
    if (dataType != KZPDataTypeCrash && dataType != KZPDataTypeFreezing) {
        return;
    }

    if (!exceptionData) return;
       
    NSDictionary *excDic = [NSJSONSerialization JSONObjectWithData:exceptionData options:NSJSONReadingMutableContainers error:nil];
    if (!excDic) return;
    
    APMExceptionElement *ele = [[APMExceptionElement alloc] init];
    ele.pageBacktrace = excDic[KZP_SYSTEM_ENV][KZP_SYSTEM_PAGE_BACKTRACE];
    ele.occurDate = excDic[KZP_SYSTEM_ENV][KZP_SYSTEM_TIMESTAMP];
    //filter freeze relate system classs.
    if (dataType == KZPDataTypeFreezing && ele.pageBacktrace) {
        NSArray *pages = [ele.pageBacktrace componentsSeparatedByString:@"-->"];
        if (pages.count >= 2) {
            NSUInteger lastIndex = pages.count - 2;
            NSString *lastVC = pages[lastIndex];
            if ([lastVC hasPrefix:@"UI"] ||
                [lastVC hasPrefix:@"_UI"] ||
                [lastVC isEqualToString:@"KZAlert"]) {
                return;
            }
        }
    }
    //action
    if (dataType == KZPDataTypeFreezing) {
        ele.action = APM_Freeze_Action;

    }else if (dataType == KZPDataTypeCrash) {
        ele.action = APM_Crash_Action;
    }
    if (!ele.action) return;
    
    //details
    NSString *type = excDic[KZP_EXCEPTION_TYPE];
    NSDictionary *excInfoDic = excDic[KZP_EXCEPTION_INFO];
    if (!excInfoDic) return;
    if ([type isEqualToString:@"Crash"]) {
        ele.subType = excInfoDic[KZP_CRASH_TYPE];
        ele.title = excInfoDic[KZP_CRASH_REASON];
        ele.describe = excInfoDic[KZP_CRASH_DESC];
        ele.crashMarkSlide = [excInfoDic[KZP_CRASH_MARK_SLIDE] longValue];
        ele.crashMarkImage = excInfoDic[KZP_CRASH_MARK_IMAGE];

        
    }else if ([type isEqualToString:@"Freeze"]) {
        ele.subType = excInfoDic[KZP_FREEZE_TYPE];
        ele.title = ele.subType;
        double interval = [excInfoDic[KZP_FREEZE_INTERVAL] doubleValue];
        ele.describe = [NSString stringWithFormat:@"Freeze Interval: %f\n\n", interval];
        ele.freezeDuration = interval;
    }

    //post format data
    if (self.excUpload) {
        if (self.exceptionCache.count > APM_MAX_FAILED_CACHE_COUNT) {
            [self.exceptionCache removeAllObjects];
        }
        self.exceptionCache[reportID] = ele;
        self.excUpload(reportID ,exceptionData);
    }else{
        NSDictionary *contentDic = [ele contentDicWithDownloadUrl:@"The exception json was not uploaded!"];
        [self _triggerAction:ele.action subType:ele.subType contentDic:contentDic ocurrDate:ele.occurDate];
        [[KZPerformanceDataCenter shareDataCenter] deleteCacheWithDataType:dataType reportID:reportID];
    }
}


#pragma mark -- Trigger cache actions

- (void)triggerExceptionWithReportID:(NSString *)reportID downloadUrl:(NSString *)downloadUrl {
    if (!reportID || !self.appKey) return;
    dispatch_async(self.uploadQueue, ^{
        APMExceptionElement *ele = self.exceptionCache[reportID];
        if (!ele) return;
        [self.exceptionCache removeObjectForKey:reportID];
        if (!downloadUrl) return;
        //upload
        NSDictionary *contentDic = [ele contentDicWithDownloadUrl:downloadUrl];
        if (self.excUploadResult && [self.immediateExcCaches containsObject:reportID]) {
            [self _triggerImmediatelyAction:ele.action subType:ele.subType contentDic:contentDic uploadResult:nil reportID:reportID ocurrDate:ele.occurDate];
        }else{
            [self _triggerAction:ele.action subType:ele.subType contentDic:contentDic ocurrDate:ele.occurDate];
        }
        if (ele.action == APM_Freeze_Action) {
            [[KZPerformanceDataCenter shareDataCenter] deleteCacheWithDataType:KZPDataTypeFreezing reportID:reportID];
            
        }else if (ele.action == APM_Crash_Action) {
            [[KZPerformanceDataCenter shareDataCenter] deleteCacheWithDataType:KZPDataTypeCrash reportID:reportID];
        }
    });
}

- (void)triggerAction:(NSString *)action subType:(NSString *)subType content:(NSString *)content {
    if (!action || !self.appKey) return;
    NSString *time = [NSString stringWithFormat:@"%.0f", NSDate.date.timeIntervalSince1970*1000];
    dispatch_async(self.uploadQueue, ^{
        NSDictionary *contentDic = [APMNormalElement contentDicWithContent:content];
        [self _triggerAction:action subType:subType contentDic:contentDic ocurrDate:time];
    });
}

- (void)triggerCustomAction:(NSString *)action
                    subType:(NSString *)subType
                     params:(NSDictionary *)params {
    if (!params || !self.appKey || params.count < 1) return;
    NSString *time = [NSString stringWithFormat:@"%.0f", NSDate.date.timeIntervalSince1970*1000];
    dispatch_async(self.uploadQueue, ^{
        NSDictionary *contentDic = [APMCustomElement contentDicWithCustomDic:params];
        [self _triggerAction:action subType:subType contentDic:contentDic ocurrDate:time];
    });
}

//must be called in uploadQueue.
- (void)_triggerAction:(NSString *)action
               subType:(NSString *)subType
            contentDic:(NSDictionary *)contentDic
             ocurrDate:(NSString *)ocurrDate
{
    if (!action || !self.appKey) return;
    NSString *userID = [NSString stringWithFormat:@"%lld", self.userID];
    NSString *eleUUID = [NSUUID UUID].UUIDString;
    APMUploadAssembler *ele =
    [APMUploadAssembler createWithUUID:eleUUID action:action
                            contentDic:contentDic userId:userID
                                appKey:self.appKey vector:self.vector
                               subType:subType occurDate:ocurrDate systemInfo:self.systemInfoCache];
    //add cache
    [self.logCaches addObject:ele];
    [self.dbManager insertElementToCache:ele];
    if (self.logCaches.count > APM_MAX_CACHE_COUNT) {
        NSArray *eles = [NSArray arrayWithArray:self.logCaches];
        [self.logCaches removeAllObjects];
        [self executeUploadWithUploadArr:eles];
    }
}

//must be called in uploadQueue.
- (void)executeUploadWithUploadArr:(NSArray *)uploadArr {
    //upload
    NSMutableArray *paramsArr = [[NSMutableArray alloc] init];
    for (APMUploadAssembler *ele in uploadArr) {
        [paramsArr addObject:[ele elementParams]];
    }
    NSDictionary *params = APM_AssambleUploadSetsParameters(paramsArr);
    if (!params) return;
    NSString *requestPath = self.isDebug ? APM_Upload_URL_Debug : APM_Upload_URL;
    [self.uploadSession POST:requestPath parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (self.reportResult) {
            self.reportResult(YES, nil);
        }
        [self handleUploadSuccessWithUploadArr:uploadArr];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (self.reportResult) {
            self.reportResult(NO, error);
        }
        [self handleUploadFailedWithUploadArr:uploadArr];
    }];
}

- (void)handleUploadSuccessWithUploadArr:(NSArray *)uploadArr {
    //clear cache for upload id
    for (APMUploadAssembler *ele in uploadArr) {
        [self.dbManager deleteCacheForReportID:ele.uuid];
    }
    //upload faild
    if (self.failedCaches.count > 0) {
        NSArray *eles = [NSArray arrayWithArray:self.failedCaches];
        [self.failedCaches removeAllObjects];
        [self executeUploadWithUploadArr:eles];
    }
}

- (void)handleUploadFailedWithUploadArr:(NSArray *)uploadArr {
    [self.failedCaches addObjectsFromArray:uploadArr];
    if (self.failedCaches.count > APM_MAX_FAILED_CACHE_COUNT) {
        NSArray *revers = self.failedCaches.reverseObjectEnumerator.allObjects;
        NSInteger loc = lrintf(APM_MAX_FAILED_CACHE_COUNT/2);
        NSArray *removes = [revers subarrayWithRange:NSMakeRange(loc, revers.count - loc)];
        for (APMUploadAssembler *ele in removes) {
            [self.dbManager deleteCacheForReportID:ele.uuid];
            [self.failedCaches removeObject:ele];
        }
    }
}

#pragma mark -- Trigger immediate actions

- (void)triggerImmediatelyAction:(NSString *)action
                         subType:(NSString *)subType
                         content:(NSString *)content
                    uploadResult:(APMImmediateUpload)uploadResult
{
    if (!action || !self.appKey) return;
    NSString *ocurrDate = [NSString stringWithFormat:@"%.0f", NSDate.date.timeIntervalSince1970*1000];
    dispatch_async(self.uploadQueue, ^{
        NSDictionary *contentDic = [APMNormalElement contentDicWithContent:content];
        [self _triggerImmediatelyAction:action subType:subType contentDic:contentDic uploadResult:uploadResult reportID:nil ocurrDate:ocurrDate];
    });
}

- (void)_triggerImmediatelyAction:(NSString *)action
                          subType:(NSString *)subType
                       contentDic:(NSDictionary *)contentDic
                     uploadResult:(APMImmediateUpload)uploadResult
                         reportID:(NSString *)reportID
                        ocurrDate:(NSString *)ocurrDate
{
    if (!action || !self.appKey) return;
    
    NSString *userID = [NSString stringWithFormat:@"%lld", self.userID];
    NSString *eleUUID = [NSUUID UUID].UUIDString;
    APMUploadAssembler *ele =
    [APMUploadAssembler createWithUUID:eleUUID action:action
                            contentDic:contentDic userId:userID
                                appKey:self.appKey vector:self.vector
                               subType:subType occurDate:ocurrDate systemInfo:self.systemInfoCache];
    NSArray *paramsArr = [NSArray arrayWithObject:[ele elementParams]];
    NSDictionary *params = APM_AssambleUploadSetsParameters(paramsArr);
    if (!params) return;
    NSString *requestPath = self.isDebug ? APM_Upload_URL_Debug : APM_Upload_URL;
    [self.uploadSession POST:requestPath parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [self handleImmediatelyUploadResult:nil uploadResult:uploadResult reportID:reportID];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
       [self handleImmediatelyUploadResult:error uploadResult:uploadResult reportID:reportID];
    }];
}

- (void)handleImmediatelyUploadResult:(NSError *)error
                         uploadResult:(APMImmediateUpload)uploadResult
                             reportID:(NSString *)reportID
{
    if (self.excUploadResult && reportID && self.immediateExcCaches.count > 0) {
        if (error) {
            self.immediateExcError = error;
        }
        [self.immediateExcCaches removeObject:reportID];
        if (self.immediateExcCaches.count < 1 && self.excUploadResult) {
            self.excUploadResult(self.immediateExcError ? NO : YES, nil);
        }
    }
    if (uploadResult) {
        uploadResult(error ? NO : YES, nil);
    }
}


#pragma mark -- Private
- (void)reloadSystemInfo {
    dispatch_async(self.uploadQueue, ^{
        NSMutableDictionary *systemDic = [NSMutableDictionary dictionaryWithDictionary:kzp_systemInfo()];
        if (self.deviceID) {
            systemDic[APM_LOG_DEVICEID] = self.deviceID;
        }
        if (self.userMark) {
            systemDic[APM_LOG_USER_MARK] = self.userMark;
        }
        self.systemInfoCache = APM_FormatObjectToJsonString(systemDic);
    });
}

#pragma mark - Metrics
- (void)didReceiveMetricPayloads:(NSArray<MXMetricPayload *> * _Nonnull)payloads
API_AVAILABLE(ios(13.0))
{
    NSMutableString* result = [[NSMutableString alloc]initWithString:@"["];
    
    NSUInteger total = payloads.count;
    if(total>10){
        total = 10;
        
        NSString* s = [NSString stringWithFormat:@"%d",(int)payloads.count];
        [self triggerAction:@"APM_METRIC_PAYLOAD" subType:@"toobig" content:s];
    }
    [payloads enumerateObjectsUsingBlock:^(MXMetricPayload * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
       
        NSData* data = [obj JSONRepresentation];
        NSString* s = [[NSString alloc]initWithUTF8String:data.bytes];
        if(s!=nil){
            [result appendString: s ];
        }
        if(idx+1<total){
            [result appendString:@","];
        }else
        {
            *stop = YES;
        }
    }];
    
    [result appendString:@"]"];
    
    [self triggerAction:@"APM_METRIC_PAYLOAD" subType:@"" content:result];
}

- (void)didReceiveDiagnosticPayloads:(NSArray* _Nonnull)payloads
{
    NSMutableString* result = [[NSMutableString alloc]initWithString:@"["];
    
    NSUInteger total = payloads.count;
    if(total>10){
        total = 10;
        
        NSString* s = [NSString stringWithFormat:@"%d",(int)payloads.count];
        [self triggerAction:@"APM_METRIC_DIAGNOSTIC" subType:@"toobig" content:s];
    }
    if (@available(iOS 14.0, *)) {
        [payloads enumerateObjectsUsingBlock:^(MXDiagnosticPayload * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            NSData* data = [obj JSONRepresentation];
            NSString* s = [[NSString alloc]initWithUTF8String:data.bytes];
            if(s!=nil){
                [result appendString: s ];
            }
            if(idx+1<total){
                [result appendString:@","];
            }else{
                *stop = YES;
            }
        }];
    }
    
    [result appendString:@"]"];
    
    [self triggerAction:@"APM_METRIC_DIAGNOSTIC" subType:@"" content:result];
}
@end
