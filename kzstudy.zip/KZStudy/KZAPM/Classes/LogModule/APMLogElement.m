//
//  APMLogElement.m
//  KZAPM
//
//  Created by doit on 2020/9/17.
//

#import "APMLogElement.h"
#import "APMUtilities.h"


/**  APMNormalElement  **/
#define APM_GENERAL_CONTENT     @"content"

@implementation APMNormalElement

+ (NSDictionary *)contentDicWithContent:(NSString *)content {
    NSDictionary *contentDic = @{
        APM_GENERAL_CONTENT : APM_SafeString(content),
    };
    return @{@"p3" : APM_SafeString(APM_FormatObjectToJsonString(contentDic))};
}
@end

@implementation APMCustomElement

+ (NSDictionary *)contentDicWithCustomDic:(NSDictionary *)customDic {
    if (!customDic || customDic.count < 1) return @{};
    NSMutableDictionary *contentDic = [[NSMutableDictionary alloc] init];
    for (NSString *key in customDic.allKeys) {
        id value = customDic[key];
        if ([value isKindOfClass:NSString.class]) {
            contentDic[key] = value;
            
        }else if ([value isKindOfClass:NSDictionary.class] || [value isKindOfClass:NSArray.class]) {
            NSString *jsr = APM_FormatObjectToJsonString(value);
            contentDic[key] = APM_SafeString(jsr);
            
        }else if ([value isKindOfClass:NSNumber.class]) {
            contentDic[key] = [(NSNumber *)value stringValue];
        }
    }
    return contentDic;
}

@end

/**  APMExceptionElement  **/
#define APM_EXC_TITLE           @"title"
#define APM_EXC_DESCRIBE        @"describe"
#define APM_EXC_JSONURL         @"jsonURL"
#define APM_EXC_PAGETRACE       @"pageTrace"
#define APM_EXC_MARKSLIDE       @"markSlide"
#define APM_EXC_MARKIMAGE       @"markImage"
#define APM_EXC_FREEZEDUR       @"freezeDuration"

@implementation APMExceptionElement

- (NSDictionary *)contentDicWithDownloadUrl:(NSString *)downloadUrl {
    NSDictionary *contentDic = @{
        APM_EXC_TITLE : APM_SafeString(self.title),
        APM_EXC_DESCRIBE : APM_SafeString(self.describe),
        APM_EXC_JSONURL : APM_SafeString(downloadUrl),
        APM_EXC_PAGETRACE : APM_SafeString(self.pageBacktrace),
        APM_EXC_MARKSLIDE : @(self.crashMarkSlide),
        APM_EXC_MARKIMAGE : APM_SafeString(self.crashMarkImage),
        APM_EXC_FREEZEDUR : @(self.freezeDuration)
    };
    return @{@"p3" : APM_SafeString(APM_FormatObjectToJsonString(contentDic))};
}
@end
