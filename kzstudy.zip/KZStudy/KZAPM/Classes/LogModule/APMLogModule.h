//
//  APMLogModule.h
//  KZAPM
//
//  Created by doit on 2020/2/15.
//

#import <Foundation/Foundation.h>
#import "KZPRebootMonitor.h"
#import "APMLogDBManager.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(NSUInteger, APMLogEnableType) {
    APMLogEnableNone = 0,
    APMLogEnableAll = 0xFFFFFFFF,
    APMLogEnableCustom = 1 << 0,
    APMLogEnableCrash = 1 << 1,
    APMLogEnableFreeze = 1 << 2,
};

typedef void(^APMExceptionUpload)(NSString *reportID ,NSData *excData);

typedef void(^APMImmediateUpload)(BOOL result, NSError * _Nullable error);

typedef void(^APMLogReportResult)(BOOL result, NSError * _Nullable error);

@interface APMLogModule : NSObject

+ (instancetype)shareModule;

#pragma mark -- Enable
//enable
- (void)enableWithLogType:(APMLogEnableType)enableType
                   appKey:(NSString *)appKey
                   vector:(NSString *)vector
                   userID:(int64_t)userID
                excUpload:(APMExceptionUpload)excUpload;

- (void)enableWithLogType:(APMLogEnableType)enableType
                   appKey:(NSString *)appKey
                   vector:(NSString *)vector
                   userID:(int64_t)userID
                excUpload:(APMExceptionUpload)excUpload
            repportResult:(APMLogReportResult)repportResult;

- (void)enableInImmediateExcWithLogType:(APMLogEnableType)enableType
                                 appKey:(NSString *)appKey
                                 vector:(NSString *)vector
                                 userID:(int64_t)userID
                              excUpload:(APMExceptionUpload)excUpload
                        excUploadResult:(APMImmediateUpload)excUploadResult;

- (void)enableDebugWithLogType:(APMLogEnableType)enableType
                        appKey:(NSString *)appKey
                        vector:(NSString *)vector
                        userID:(int64_t)userID
                     excUpload:(APMExceptionUpload)excUpload;

#pragma mark -- Info
@property (nonatomic, assign, readonly) KZPRebootLastTerminateReasonType reasonType;

@property (nonatomic, strong, readonly) NSString *reasonTypeDescription;

@property(nonatomic, copy) APMDBDamagedBlock dbDamagedNotifyBlock;

#pragma mark -- Trigger
//trigger common action
- (void)triggerAction:(NSString *)action
              subType:(nullable NSString *)subType
              content:(nullable NSString *)content;

/**
 trigger custom common action
 @param action      action name.
 @param subType     subtype name.
 @param params      custom params.
 The `params` takes a string as the key,
 the key must start with the letter p and end with a number and the number is greater than or equal to 3;
 value must be a valid JSON object.
 */
- (void)triggerCustomAction:(NSString *)action
                    subType:(nullable NSString *)subType
                     params:(NSDictionary *)params;

//trigger exeption action
- (void)triggerExceptionWithReportID:(NSString *)reportID
                         downloadUrl:(NSString *)downloadUrl;

//trigger immediately action
- (void)triggerImmediatelyAction:(NSString *)action
                         subType:(nullable NSString *)subType
                         content:(NSString *)content
                    uploadResult:(_Nullable APMImmediateUpload)uploadResult;

#pragma mark - Update

- (void)updateAppKey:(NSString *)appKey
              vector:(NSString *)vector;

- (void)updateUserID:(int64_t)userID;

- (void)updateDeviceID:(NSString *)deviceID;

- (void)updateUserMark:(NSString *)userMark;

- (void)updateObjcExceptionOwnership;

- (void)updateUnixSignalOwnership;

@end

NS_ASSUME_NONNULL_END
