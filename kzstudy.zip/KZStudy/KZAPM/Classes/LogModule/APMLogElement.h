//
//  APMLogElement.h
//  KZAPM
//
//  Created by doit on 2020/9/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface APMNormalElement : NSObject

+ (NSDictionary *)contentDicWithContent:(NSString *)content;

@end


@interface APMCustomElement : NSObject

+ (NSDictionary *)contentDicWithCustomDic:(NSDictionary *)customDic;

@end


@interface APMExceptionElement : NSObject

@property (nonatomic, strong) NSString *action;

@property (nonatomic, strong) NSString *subType;

@property (nonatomic, strong) NSString *title;

@property (nonatomic, strong) NSString *describe;

@property (nonatomic, strong) NSString *occurDate;

@property (nonatomic, strong) NSString *pageBacktrace;

@property (nonatomic, strong) NSString *crashMarkImage;

@property (nonatomic, assign) long crashMarkSlide;

@property (nonatomic, assign) CFTimeInterval freezeDuration;

- (NSDictionary *)contentDicWithDownloadUrl:(NSString *)downloadUrl;

@end

NS_ASSUME_NONNULL_END
