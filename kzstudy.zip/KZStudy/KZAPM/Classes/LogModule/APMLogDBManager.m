//
//  APMLogDBManager.m
//  KZAPM
//
//  Created by doit on 2021/1/25.
//

#import "APMLogDBManager.h"
#import "FMDatabaseQueue.h"
#import "FMDatabase.h"
#import "APMUploadAssembler.h"
#import "APMUtilities.h"
#if FMDB_SQLITE_STANDALONE
#import <sqlite3/sqlite3.h>
#else
#import <sqlite3.h>
#endif
#define APM_DB_TOKEN_KEY    @"_apm_log_cipher_key"

@interface APMLogDBManager ()

@property (nonatomic, strong) dispatch_queue_t operationQueue;

@property (nonatomic, strong) FMDatabaseQueue *dbQueue;

@property (nonatomic, assign) int failedCount;

@end

@implementation APMLogDBManager

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.failedCount = 0;
        self.operationQueue = dispatch_queue_create("com.LYPDoit.KZAPM.APMLogDBManager.dbOperate", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}

- (void)startupDBManager {
    [self createDBQueueWithDBPath:[self getDBPath]];
}

#pragma mark -- Public

- (NSMutableArray *)getAllElementCachesInDB {
    NSMutableArray *dataArray = [[NSMutableArray alloc] init];
    dispatch_sync(self.operationQueue, ^{
        if (![self isValidDB]) return;

        __block int errorCode = SQLITE_OK;
        [self.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
            NSString *querySql = @"select * from uploadDataTable";
            FMResultSet *rs = [db executeQuery:querySql];
            NSError *error = nil;
        
            while([rs nextWithError:&error])
            {
                NSString *uuid = [rs stringForColumnIndex:0];
                NSString *action = [rs stringForColumnIndex:1];
                NSString *content = [rs stringForColumnIndex:2];
                NSString *commonInfo = [rs stringForColumnIndex:3];
                NSString *systemInfo = [rs stringForColumnIndex:4];
                APMUploadAssembler *ele = [APMUploadAssembler createWithUUID:uuid action:action content:content commonInfo:commonInfo systemInfo:systemInfo];
                [dataArray addObject:ele];
            }
            if (error) {
                errorCode = [self getErrorCode:db];
            }
        }];
        if ([self isDBDamagedForErrorCode:errorCode]) {
            [self fixDamaged];
        }
    });
    return dataArray;
}

- (void)insertElementToCache:(APMUploadAssembler *)element {
    NSString *insertSql = [NSString stringWithFormat:@"insert into uploadDataTable (id,action,content,commoninfo,systeminfo) values (?,?,?,?,?);"];
    
    NSArray *values = @[APM_SafeString(element.uuid),
                        APM_SafeString(element.action),
                        APM_SafeString(element.content),
                        APM_SafeString(element.commonInfo),
                        APM_SafeString(element.systemInfo)];
    dispatch_async(self.operationQueue, ^{
        [self executeSql:insertSql values:values];
    });
}

- (void)deleteCacheForReportID:(NSString *)reportID {
    NSString *deleteSql = [NSString stringWithFormat:@"delete from uploadDataTable where id = '%@';", reportID];
    dispatch_async(self.operationQueue, ^{
        [self executeSql:deleteSql values:nil];
    });
}

#pragma mark -- Private

- (NSString *)getDBPath {
    NSString *cachePath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) firstObject];
    NSString *folderPath = [cachePath stringByAppendingPathComponent:@"com.LYPDoit.KZAPM.DataCache"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:folderPath]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    return [folderPath stringByAppendingPathComponent:@"ampDB_1.sqlite3"];
}

- (BOOL)isValidDB {
    if (self.dbQueue) {
        return YES;
    }else{
        return NO;
    }
}

- (void)createDBQueueWithDBPath:(NSString *)dbPath {
    if (self.dbQueue) return;
    if (self.failedCount > 3) {
        return;
    }
    self.dbQueue = [[FMDatabaseQueue alloc] initWithPath:dbPath];
    if (self.dbQueue) {
        [self.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
            [db setKey:APM_DB_TOKEN_KEY];
        }];
        NSString *createTableSql = @"create table if not exists uploadDataTable (id text primary key, action text, content text, commoninfo text, systeminfo text);";
        [self executeSql:createTableSql values:nil];
    }
}

- (BOOL)executeSql:(NSString *)sqlString values:(NSArray *)values{
    if (![self isValidDB]) return NO;
    __block BOOL result = NO;
    __block int errorCode = SQLITE_OK;
    [self.dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
        NSError *error = nil;
        result = [db executeUpdate:sqlString values:values error:&error];
        if (error) {
            errorCode = [self getErrorCode:db];
        }
    }];
    if ([self isDBDamagedForErrorCode:errorCode]) {
        [self fixDamaged];
    }
    return result;
}

- (void)fixDamaged {
    [self.dbQueue close];
    self.dbQueue = nil;
    NSString *dbPath = [self getDBPath];
    if (![[NSFileManager defaultManager] removeItemAtPath:dbPath error:nil]) {
        return;
    }
    [self createDBQueueWithDBPath:dbPath];
}

- (int)getErrorCode:(FMDatabase *)aDb
{
    if ([aDb hadError]) {
        int errorCode = [aDb lastErrorCode];
        NSString *errorMsg = [aDb lastErrorMessage];
        NSLog(@"[APM] DB error code: %d, message: %@", errorCode, errorMsg);
        return errorCode;
    }
    return SQLITE_OK;
}

- (BOOL)isDBDamagedForErrorCode:(int)errorCode {
    if(errorCode == SQLITE_CORRUPT || errorCode == SQLITE_NOTADB) {
        self.failedCount++;
        if (self.dbDamaged) {
            self.dbDamaged(errorCode);
        }
        return YES;
    }
    self.failedCount = 0;
    return NO;
}

@end

