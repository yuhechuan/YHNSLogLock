//
//  APMUploadAssembler.h
//  KZAPM
//
//  Created by doit on 2020/2/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface APMUploadAssembler : NSObject

@property (nonatomic, strong, readonly) NSString *uuid;

@property (nonatomic, strong, readonly) NSString *action;

@property (nonatomic, strong, readonly) NSString *content;

@property (nonatomic, strong, readonly) NSString *commonInfo;

@property (nonatomic, strong, readonly) NSString *systemInfo;

+ (APMUploadAssembler *)createWithUUID:(NSString *)uuid
                                action:(NSString *)action
                               content:(NSString *)content
                            commonInfo:(NSString *)commonInfo
                            systemInfo:(NSString *)systemInfo;


+ (APMUploadAssembler *)createWithUUID:(NSString *)uuid
                                action:(NSString *)action
                            contentDic:(NSDictionary *)contentDic
                                userId:(NSString *)userId
                                appKey:(NSString *)appKey
                                vector:(NSString *)vector
                               subType:(NSString *)subType
                             occurDate:(NSString *)occurDate
                            systemInfo:(NSString *)systemInfo;


- (NSDictionary *)elementParams;

extern
NSDictionary *APM_AssambleUploadSetsParameters(NSArray *uploadDatas);

@end

NS_ASSUME_NONNULL_END
