//
//  APMLogDBManager.h
//  KZAPM
//
//  Created by doit on 2021/1/25.
//

#import <Foundation/Foundation.h>
@class APMUploadAssembler;

NS_ASSUME_NONNULL_BEGIN

typedef void(^APMDBDamagedBlock)(int code);

@interface APMLogDBManager : NSObject

@property(nonatomic, copy) APMDBDamagedBlock dbDamaged;

- (void)startupDBManager;

- (void)insertElementToCache:(APMUploadAssembler *)element;

- (void)deleteCacheForReportID:(NSString *)reportID;

- (NSMutableArray *)getAllElementCachesInDB;

@end

NS_ASSUME_NONNULL_END
