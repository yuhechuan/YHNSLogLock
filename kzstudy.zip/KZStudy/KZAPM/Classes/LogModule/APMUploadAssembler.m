//
//  APMUploadAssembler.m
//  KZAPM
//
//  Created by doit on 2020/2/19.
//

#import "APMUploadAssembler.h"
#import "APMUtilities.h"

@implementation APMUploadAssembler

+ (APMUploadAssembler *)createWithUUID:(NSString *)uuid
                                action:(NSString *)action
                               content:(NSString *)content
                            commonInfo:(NSString *)commonInfo
                            systemInfo:(NSString *)systemInfo
{
    APMUploadAssembler *ele = [[APMUploadAssembler alloc] init];
    ele->_uuid = uuid;
    ele->_action = action;
    ele->_content = APM_SafeString(content);
    ele->_commonInfo = APM_SafeString(commonInfo);
    ele->_systemInfo = APM_SafeString(systemInfo);
    return ele;
}

+ (APMUploadAssembler *)createWithUUID:(NSString *)uuid
                                action:(NSString *)action
                            contentDic:(NSDictionary *)contentDic
                                userId:(NSString *)userId
                                appKey:(NSString *)appKey
                                vector:(NSString *)vector
                               subType:(NSString *)subType
                             occurDate:(NSString *)occurDate
                            systemInfo:(NSString *)systemInfo
{
    APMUploadAssembler *ele = [[APMUploadAssembler alloc] init];
    ele->_uuid = uuid;
    ele->_action = action;
    ele->_content = APM_SafeString(APM_FormatObjectToJsonString(contentDic));
    ele->_commonInfo = APM_SafeString(assambleConmmonInfo(userId, appKey, vector, subType, occurDate));
    ele->_systemInfo = APM_SafeString(systemInfo);
    return ele;
}

- (NSDictionary *)elementParams {
    NSMutableDictionary *parasDic = [[NSMutableDictionary alloc] init];
    NSDictionary *cd = APM_FormatJsonStringToObject(self.content);
    if (cd && [cd isKindOfClass:NSDictionary.class]) {
        [parasDic addEntriesFromDictionary:cd];
    }
    parasDic[@"action"] = APM_SafeString(self.action);
    parasDic[@"p"] =  APM_SafeString(self.commonInfo);
    parasDic[@"p2"] =  APM_SafeString(self.systemInfo);

    return parasDic;
}

static NSString *assambleConmmonInfo(NSString *userId, NSString *appKey,
                                     NSString *vector, NSString *subType,
                                     NSString *occurDate)
{
    if (!appKey) return @"";
    //p json string
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *time = occurDate;
    if (!time) {
        time  = [NSString stringWithFormat:@"%.0f", NSDate.date.timeIntervalSince1970*1000];
    }
    NSString *encry = APM_AESEncryptStringToBase64(userId, appKey, vector);
    NSDictionary *p = @{@"appKey" : appKey,
                        @"userId" : APM_SafeString(encry),
                          @"time" : @([time longLongValue]),
                       @"version" : APM_SafeString(version),
                          @"type" : APM_SafeString(subType)
                        };
    NSString *describe = APM_FormatObjectToJsonString(p);
    if (!describe) {
        describe = @"";
        NSLog(@"[KZPerformance]: Report failed because of `p` is invalid!");
    }
    return describe;
}


NSDictionary *APM_AssambleUploadSetsParameters(NSArray *uploadDatas) {
    if (!uploadDatas || uploadDatas.count < 1) {
        return nil;
    }
    NSString *postJson = APM_FormatObjectToJsonString(uploadDatas);
    if (!postJson) return nil;
    NSDictionary *param = @{@"ba" : postJson};
    return param;
}



@end
