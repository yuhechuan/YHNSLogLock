//
//  UIResponder+Router.m
//  KZStudy
//
//  Created by yuhechuan on 2023/9/27.
//

#import "UIResponder+Router.h"

@implementation UIResponder (Router)

- (void)routerEventWithName:(NSString *)eventName {
    [self routerEventWithName:eventName userInfo:nil];
}

- (void)routerEventWithName:(NSString *)eventName
                   userInfo:(NSDictionary *)userInfo {
    [self routerEventWithName:eventName userInfo:userInfo resultBlock:nil];
}

- (void)routerEventWithName:(NSString *)eventName
                   userInfo:(NSDictionary *)userInfo
                resultBlock:(void(^)(id responseSender))resultBlock {
    [[self nextResponder] routerEventWithName:eventName userInfo:userInfo resultBlock:resultBlock];
}

@end
