//
//  UIResponder+Router.h
//  KZStudy
//
//  Created by yuhechuan on 2023/9/27.
//

#import <UIKit/UIKit.h>

@interface UIResponder (Router)

- (void)routerEventWithName:(NSString *)eventName;

- (void)routerEventWithName:(NSString *)eventName
                   userInfo:(NSDictionary *)userInfo;

- (void)routerEventWithName:(NSString *)eventName
                   userInfo:(NSDictionary *)userInfo
                resultBlock:(void(^)(id responseSender))resultBlock;
@end
