//
//  BZBaseResponderProxy.m
//  KZStudy
//
//  Created by yuhechuan on 2023/9/27.
//

#import "BZBaseResponderProxy.h"

@implementation BZBaseResponderProxy

@end
