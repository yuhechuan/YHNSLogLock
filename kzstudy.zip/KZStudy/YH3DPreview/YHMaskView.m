//
//  YHMaskView.m
//  KZStudy
//
//  Created by yuhechuan on 2022/9/23.
//

#import "YHMaskView.h"

@interface YHMaskView ()<CALayerDelegate>

@property (nonatomic, strong) UIImageView *gradient;
@property (nonatomic, strong) UILabel *title;

@end

@implementation YHMaskView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addTagGradientColor];
        self.layer.delegate = self;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.gradient.frame = self.bounds;
    self.title.frame = self.gradient.bounds;
}

- (void)addTagGradientColor {
    self.title.text = @"小码哥,专注于高级ios开发工程师的培养小码哥";
    self.title.numberOfLines = 1;
    [ self.title sizeToFit];
    self.gradient.layer.mask = self.title.layer;
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.title.frame.size.width, self.title.frame.size.height);
}

- (UIImageView *)gradient {
    if (!_gradient) {
        _gradient = [[UIImageView alloc]init];
        _gradient.image = [UIImage imageNamed:@"bb_position_grade_mask@2x.png"];
        [self addSubview:_gradient];
    }
    return _gradient;
}

- (UILabel *)title {
    if (!_title) {
        _title = [[UILabel alloc]init];
        [self addSubview:_title];
    }
    return _title;
}

- (void)displayLayer:(CALayer *)layer {
    
}

- (void)drawLayer:(CALayer *)layer inContext:(CGContextRef)ctx {
    
}



@end
