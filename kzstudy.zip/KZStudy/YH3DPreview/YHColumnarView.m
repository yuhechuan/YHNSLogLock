//
//  YHColumnarView.m
//  KZStudy
//
//  Created by yuhechuan on 2022/7/20.
//

#import "YHColumnarView.h"

@interface YHColumnarView ()

@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat width;

@end

@implementation YHColumnarView

- (instancetype)initWithFrame:(CGRect)frame {
    CGRect rf = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.height + [YHColumnarView repairOffset]);
    if (self = [super initWithFrame:rf]) {
        _width = frame.size.width;
        _height = frame.size.height;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

//- (void)drawRect:(CGRect)rect {
//    // Drawing code
//
//    CGContextRef context = UIGraphicsGetCurrentContext();
//
//    CGContextSetFillColorWithColor(context, [UIColor redColor].CGColor);
//    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
//
//    /// 修复1.0 的高度
//    CGFloat radius = _width / 2.0;
//    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(radius, radius + [YHColumnarView repairOffset]) radius:radius startAngle:0 endAngle:M_PI clockwise:NO];
//
//    [path addLineToPoint:CGPointMake(0, _height)];
//    [path addLineToPoint:CGPointMake(_width, _height)];
//    [path fill];
//
//    CGContextAddPath(context, path.CGPath);
//
//    CGContextStrokePath(context);
//    CGContextClosePath(context);
//}

- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [[UIColor redColor] set];
    
    /// 修复1.0 的高度
    CGFloat radius = _width / 2.0;
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(radius, radius + [YHColumnarView repairOffset]) radius:radius startAngle:0 endAngle:M_PI clockwise:NO];
    
    [path addLineToPoint:CGPointMake(0, _height)];
    [path addLineToPoint:CGPointMake(_width, _height)];
    [path closePath];
    [path fill];
}

+ (CGFloat)repairOffset {
    return 1.0;
}


@end
