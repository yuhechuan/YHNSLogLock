//
//  YHHighTextView.m
//  KZStudy
//
//  Created by yuhechuan on 2022/8/28.
//

#import "YHHighTextView.h"

@interface BBGradientLabelInfo : NSObject

@property (nonatomic, copy) NSString *text;
@property (nonatomic, assign) NSInteger numberOfLines;
@property (nonatomic, strong) UIFont *font;
@property (nonatomic, copy) NSArray <UIColor *>*colors;

@end

@implementation BBGradientLabelInfo

- (instancetype)init {
    if (self = [super init]) {
        _numberOfLines = 1;
        _font = nil;
        _colors = @[];
    }
    return self;
}

@end


@interface YHHighTextView ()

@property (nonatomic, strong) CAGradientLayer *gradientLayer;
@property (nonatomic, strong) UILabel *title;


@end

@implementation YHHighTextView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addTagGradientColor];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.gradientLayer.frame = self.bounds;
    self.title.frame = self.gradientLayer.bounds;
}

- (void)addTagGradientColor {
    self.title.text = @"小码哥,专注于高级ios开发工程师的培养小码哥,专注于高级ios开发工程师的培养小码哥,专注于高级ios开发工程师的培养小码哥,专注于高级ios开发工程师的培养";
    self.title.numberOfLines = 1;
    [ self.title sizeToFit];
    self.gradientLayer.mask = self.title.layer;
}

- (CAGradientLayer *)gradientLayer {
    if (!_gradientLayer) {
        _gradientLayer = [CAGradientLayer layer];
        _gradientLayer.startPoint = CGPointMake(0, 0.5);
        _gradientLayer.endPoint = CGPointMake(1, 0.5);
        _gradientLayer.locations = @[ @(0), @(1.0f) ];
        [self.layer insertSublayer:_gradientLayer atIndex:0];
    }
    return _gradientLayer;
}

- (UILabel *)title {
    if (!_title) {
        _title = [[UILabel alloc]init];
        [self addSubview:_title];
    }
    return _title;
}

@end
