//
//  BZTextLineHeightCategroy.h
//  KZStudy
//
//  Created by yuhechuan on 2024/11/6.
//

#import <UIKit/UIKit.h>
#import "YPSeniorLabel.h"

@interface UILabel (lineHeight)

@property (nonatomic, assign) CGFloat lineHeight;

@end

@interface YPSeniorLabel (lineHeight)

@property (nonatomic, assign) CGFloat lineHeight;

@end


@interface NSAttributedString (lineHeight)

@property (nonatomic, assign, readonly) CGFloat lineHeight;

@end

@interface NSMutableAttributedString (lineHeight)

@property (nonatomic, assign) CGFloat lineHeight;

@end

