//
//  BZTextLineHeightCategroy.m
//  KZStudy
//
//  Created by yuhechuan on 2024/11/6.
//

#import "BZTextLineHeightCategroy.h"
#import <objc/runtime.h>
#import "NSMutableAttributedString+YP.h"
#import "FlexUtils.h"
#import "UIFont+Extension.h"

static void bzlhSwizzleClass(Class clas, SEL originalSEL, SEL swizzledSEL) {
    Method originalMethod = class_getInstanceMethod(clas, originalSEL);
    Method swizzledMethod = class_getInstanceMethod(clas, swizzledSEL);
    BOOL didAddMethod = class_addMethod(clas, originalSEL, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
    if (didAddMethod) {
        class_replaceMethod(clas, swizzledSEL, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
    } else {
        method_exchangeImplementations(originalMethod, swizzledMethod);
    }
}

@implementation UILabel (lineHeight)

+ (void)initialize {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [UILabel swizzlelineHeightMethod];
    });
}

+ (void)swizzlelineHeightMethod {
    /// setText:
    bzlhSwizzleClass(UILabel.class, @selector(setText:), @selector(lh_setText:));
    /// setAttributedText:
    bzlhSwizzleClass(UILabel.class, @selector(setAttributedText:), @selector(lh_setAttributedText:));
}

- (void)lh_setText:(NSString *)text {
    if (self.lineHeight > 0) {
        self.attributedText = [[NSAttributedString alloc]initWithString:text];
    } else {
        [self lh_setText:text];
    }
}

- (void)lh_setAttributedText:(NSAttributedString *)attributedText {
    if (self.lineHeight > 0) {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]init];
        attributedString.lineHeight = self.lineHeight;
        attributedText = attributedString.copy;
    }
    [self lh_setAttributedText:attributedText];
}

- (void)setLineHeight:(CGFloat)lineHeight {
    if (lineHeight == self.lineHeight) {
        return;
    }
    objc_setAssociatedObject(self, @selector(setLineHeight:), @(lineHeight), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    NSAttributedString *attributedText = self.attributedText;
    self.attributedText = attributedText;
}

- (CGFloat)lineHeight {
    NSNumber *result = objc_getAssociatedObject(self, @selector(setLineHeight:));
    return [result floatValue];
}

FLEXSET(bzlhFont)
{
    UIFont *font = [self bzFontWithFontNameString:sValue];
    if(font == nil){
        return;
    }
    self.font = font;
}

- (UIFont *)bzFontWithFontNameString:(NSString *)fontNameString {
    UIFont *font = nil;
    NSArray* ary = [fontNameString componentsSeparatedByString:@"|"];
    
    if (ary.count == 0) {
        return nil;
    }
    
    if(ary.count==1){
        CGFloat fontSize = [ary.firstObject floatValue]<0.1?14.0f:[ary.firstObject floatValue];
        return [UIFont systemFontOfSize:fontSize];
    }
    
    NSString* fontName = ary.firstObject;
    CGFloat fontSize = [ary[1] floatValue];
    
    if ([fontName containsString:@"Medium"]) {
        font = [UIFont PSCMediumFontSize:fontSize];
    } else if ([fontName containsString:@"Regular"]) {
        font = [UIFont PSCFontSize:fontSize];
    } else if ([fontName containsString:@"Semibold"]) {
        font = [UIFont PSCBoldFontSize:fontSize];
    } else if ([fontName containsString:@"Light"]) {
        font = [UIFont PSCLightFontSize:fontSize];
    } else if ([fontName containsString:@"Kanzhun"])  {
        font = [UIFont KZRegularFontSize:fontSize];
    } else {
        font = [UIFont systemFontOfSize:fontSize];
    }
    
    if (ary.count >= 3) {
        CGFloat lineHeight = [ary[2] floatValue];
        if (lineHeight > 0) {
            self.lineHeight = lineHeight;
        }
    }
    return font;
}


@end


@implementation YPSeniorLabel (lineHeight)

- (void)setLineHeight:(CGFloat)lineHeight {
    objc_setAssociatedObject(self, @selector(setLineHeight:), @(lineHeight), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (CGFloat)lineHeight {
    NSNumber *result = objc_getAssociatedObject(self, @selector(setLineHeight:));
    return [result floatValue];
}

- (void)setLineHeightFont:(UIFont *)lineHeightFont {
    objc_setAssociatedObject(self, @selector(setLineHeightFont:), lineHeightFont, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIFont *)lineHeightFont {
    id result = objc_getAssociatedObject(self, @selector(setLineHeightFont:));
    if ([result isKindOfClass:UIFont.class]) {
        return (UIFont *)result;
    }
    return nil;
}


@end


@implementation NSAttributedString (lineHeight)

- (CGFloat)lineHeight {
    return self.minimumLineHeight;
}

@end

@implementation NSMutableAttributedString (lineHeight)

- (void)setLineHeight:(CGFloat)lineHeight {
    __block int fontCount = 0;
    __block UIFont *font = nil;
    [self enumerateAttribute:NSFontAttributeName inRange:NSMakeRange(0, self.length) options:0 usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
        fontCount ++;
        font = value;
        if (fontCount >= 2) {
            *stop = YES;
        }
    }];
    if (fontCount >= 2) {
        return;
    }
    self.minimumLineHeight = lineHeight;
    self.maximumLineHeight = lineHeight;
    CGFloat baselineOffset = (lineHeight - font.lineHeight) / 2.0;
    [self addAttribute:NSBaselineOffsetAttributeName value:@(baselineOffset) range:NSMakeRange(0, self.length)];
}

@end
