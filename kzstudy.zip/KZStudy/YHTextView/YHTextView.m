//
//  YHTextView.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/30.
//

#import "YHTextView.h"
#import "YYTextInput.h"
#import <CoreText/CoreText.h>

@interface YHTextView ()<UIScrollViewDelegate> {
    NSMutableAttributedString *_innerText; ///< nonnull, inner attributed text
    NSMutableAttributedString *_delectedText; ///< detected text for display
}

@end

@implementation YHTextView

#pragma mark - @protocol UITextInputTraits
@synthesize autocapitalizationType = _autocapitalizationType;
@synthesize autocorrectionType = _autocorrectionType;
@synthesize spellCheckingType = _spellCheckingType;
@synthesize keyboardType = _keyboardType;
@synthesize keyboardAppearance = _keyboardAppearance;
@synthesize returnKeyType = _returnKeyType;
@synthesize enablesReturnKeyAutomatically = _enablesReturnKeyAutomatically;
@synthesize secureTextEntry = _secureTextEntry;

#pragma mark - @protocol UITextInput
@synthesize selectedTextRange = _selectedTextRange;  //copy nonnull (YYTextRange*)
@synthesize markedTextRange = _markedTextRange;      //readonly     (YYTextRange*)
@synthesize markedTextStyle = _markedTextStyle;      //copy
@synthesize inputDelegate = _inputDelegate;         //assign
@synthesize tokenizer = _tokenizer;                 //readonly

#pragma mark - @protocol UITextInput optional
@synthesize selectionAffinity = _selectionAffinity;

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self _initTextView];
    }
    return self;
}

#pragma mark - Private Init

- (void)_initTextView {
    self.delaysContentTouches = NO;
    self.canCancelContentTouches = YES;
    self.multipleTouchEnabled = NO;
    self.clipsToBounds = YES;
    [super setDelegate:self];
        
    // UITextInputTraits
    _autocapitalizationType = UITextAutocapitalizationTypeSentences;
    _autocorrectionType = UITextAutocorrectionTypeDefault;
    _spellCheckingType = UITextSpellCheckingTypeDefault;
    _keyboardType = UIKeyboardTypeDefault;
    _keyboardAppearance = UIKeyboardAppearanceDefault;
    _returnKeyType = UIReturnKeyDefault;
    _enablesReturnKeyAutomatically = NO;
    _secureTextEntry = NO;
    
    // UITextInput
    _selectedTextRange = [YHTextRange defaultRange];
    _markedTextRange = nil;
    _markedTextStyle = nil;
    // 分词器
    _tokenizer = [[UITextInputStringTokenizer alloc] initWithTextInput:self];
    self.isAccessibilityElement = YES;
}


- (BOOL)hasText {
    return _innerText.length > 0;
}

- (void)insertText:(NSString *)text {
    if (text.length == 0) return;
    [self replaceRange:_selectedTextRange withText:text];
}

- (void)deleteBackward {
    
}

- (BOOL)canResignFirstResponder {
    return YES;
}

- (BOOL)canBecomeFirstResponder {
    return YES;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    if (!self.isFirstResponder) {
        [self performSelector:@selector(becomeFirstResponder) withObject:nil afterDelay:0];
    }
}

#pragma mark - @protocol UITextInput

- (void)setInputDelegate:(id<UITextInputDelegate>)inputDelegate {
    _inputDelegate = inputDelegate;
}

- (NSString *)textInRange:(YHTextRange *)range {
    range = [self _correctedTextRange:range];
    if (!range) return @"";
    return [_innerText.string substringWithRange:range.asRange];
}

- (void)replaceRange:(YHTextRange *)range withText:(NSString *)text {
    if (!range) return;
    if (!text) text = @"";
    if (range.asRange.length == 0 && text.length == 0) return;
    range = [self _correctedTextRange:range];
    
}

- (void)setMarkedTextStyle:(NSDictionary *)markedTextStyle {
    _markedTextStyle = markedTextStyle.copy;
}

- (YHTextPosition *)beginningOfDocument {
    return [YHTextPosition positionWithOffset:0];
}

- (YHTextPosition *)endOfDocument {
    return [YHTextPosition positionWithOffset:_innerText.length];
}

- (YHTextPosition *)positionFromPosition:(YHTextPosition *)position offset:(NSInteger)offset {
   return position;
}

- (YHTextPosition *)positionFromPosition:(YHTextPosition *)position inDirection:(UITextLayoutDirection)direction offset:(NSInteger)offset {
    return position;
}

- (YHTextRange *)textRangeFromPosition:(YHTextPosition *)fromPosition toPosition:(YHTextPosition *)toPosition {
    return [YHTextRange rangeWithStart:fromPosition end:toPosition];
}

- (NSComparisonResult)comparePosition:(YHTextPosition *)position toPosition:(YHTextPosition *)other {
    return [position compare:other];
}

- (NSInteger)offsetFromPosition:(YHTextPosition *)from toPosition:(YHTextPosition *)toPosition {
    return toPosition.offset - from.offset;
}

- (YHTextPosition *)positionWithinRange:(YHTextRange *)range farthestInDirection:(UITextLayoutDirection)direction {
    NSRange nsRange = range.asRange;
    if (direction == UITextLayoutDirectionLeft | direction == UITextLayoutDirectionUp) {
        return [YHTextPosition positionWithOffset:nsRange.location];
    } else {
        return [YHTextPosition positionWithOffset:nsRange.location + nsRange.length affinity:YHTextAffinityBackward];
    }
}

- (YHTextRange *)characterRangeByExtendingPosition:(YHTextPosition *)position inDirection:(UITextLayoutDirection)direction {
    YHTextRange *range = [YHTextRange new];
    return range;
}

- (YHTextPosition *)closestPositionToPoint:(CGPoint)point {
    return [YHTextPosition new];
}

- (YHTextPosition *)closestPositionToPoint:(CGPoint)point withinRange:(YHTextRange *)range {
    YHTextPosition *pos = (id)[self closestPositionToPoint:point];
    if (!pos) return nil;
    return pos;
}

- (YHTextRange *)characterRangeAtPoint:(CGPoint)point {
    return [YHTextRange new];
}

- (CGRect)firstRectForRange:(YHTextRange *)range {
    return CGRectZero;
}

- (CGRect)caretRectForPosition:(YHTextPosition *)position {
    return CGRectZero;
}

- (NSArray *)selectionRectsForRange:(YHTextRange *)range {
    return @[];
}

- (void)setMarkedText:(NSString *)markedText selectedRange:(NSRange)selectedRange {
    NSMutableString *mt = [NSMutableString stringWithString:_innerText.string];
    [mt appendString:markedText];
    _innerText = [[NSMutableAttributedString alloc]initWithString:mt];
    [self setNeedsDisplay];
}

- (void)unmarkText {
    
}


/// Whether the position is valid (not out of bounds).
- (BOOL)_isTextPositionValid:(YHTextPosition *)position {
    if (!position) return NO;
    if (position.offset < 0) return NO;
    if (position.offset > _innerText.length) return NO;
    if (position.offset == 0 && position.affinity == YHTextAffinityBackward) return NO;
    if (position.offset == _innerText.length && position.affinity == YHTextAffinityBackward) return NO;
    return YES;
}

/// Whether the range is valid (not out of bounds).
- (BOOL)_isTextRangeValid:(YHTextRange *)range {
    if (![self _isTextPositionValid:range.start]) return NO;
    if (![self _isTextPositionValid:range.end]) return NO;
    return YES;
}

/// Correct the position if it out of bounds.
- (YHTextPosition *)_correctedTextPosition:(YHTextPosition *)position {
    if (!position) return nil;
    if ([self _isTextPositionValid:position]) return position;
    if (position.offset < 0) {
        return [YHTextPosition positionWithOffset:0];
    }
    if (position.offset > _innerText.length) {
        return [YHTextPosition positionWithOffset:_innerText.length];
    }
    if (position.offset == 0 && position.affinity == YHTextAffinityBackward) {
        return [YHTextPosition positionWithOffset:position.offset];
    }
    if (position.offset == _innerText.length && position.affinity == YHTextAffinityBackward) {
        return [YHTextPosition positionWithOffset:position.offset];
    }
    return position;
}

/// Correct the range if it out of bounds.
- (YHTextRange *)_correctedTextRange:(YHTextRange *)range {
    if (!range) return nil;
    if ([self _isTextRangeValid:range]) return range;
    YHTextPosition *start = [self _correctedTextPosition:range.start];
    YHTextPosition *end = [self _correctedTextPosition:range.end];
    return [YHTextRange rangeWithStart:start end:end];
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CFAttributedStringRef drawStr = CFBridgingRetain([[NSAttributedString alloc] initWithString:_innerText.string]);
    CTFramesetterRef setter = CTFramesetterCreateWithAttributedString(drawStr);
    CGPathRef path = CGPathCreateWithRect(rect, NULL);
    CTFrameRef frame = CTFramesetterCreateFrame(setter, CFRangeMake(0, CFAttributedStringGetLength(drawStr)), path, NULL);
    
    CGContextSaveGState(ctx);
    CGContextScaleCTM(ctx, 1, -1);
    CGContextTranslateCTM(ctx, 0, -CGRectGetHeight(rect));
    CTFrameDraw(frame, ctx);
    CGContextRestoreGState(ctx);
    
    CGPathRelease(path);
    CFRelease(frame);
    CFRelease(setter);
    CFRelease(drawStr);
}

@end
