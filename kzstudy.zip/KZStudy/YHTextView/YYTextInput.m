//
//  YYTextInput.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/30.
//

#import "YYTextInput.h"

#ifndef YHTEXT_SWAP // swap two value
#define YHTEXT_SWAP(_a_, _b_)  do { __typeof__(_a_) _tmp_ = (_a_); (_a_) = (_b_); (_b_) = _tmp_; } while (0)
#endif

@implementation YHTextPosition

+ (instancetype)positionWithOffset:(NSInteger)offset {
    return [self positionWithOffset:offset affinity:YHTextAffinityForward];
}

+ (instancetype)positionWithOffset:(NSInteger)offset affinity:(YHTextAffinity)affinity {
    YHTextPosition *p = [self new];
    p->_offset = offset;
    p->_affinity = affinity;
    return p;
}

- (instancetype)copyWithZone:(NSZone *)zone {
    return [self.class positionWithOffset:_offset affinity:_affinity];
}

- (NSUInteger)hash {
    return _offset * 2 + (_affinity == YHTextAffinityForward ? 1 : 0);
}

- (BOOL)isEqual:(YHTextPosition *)object {
    if (!object) return NO;
    return _offset == object.offset && _affinity == object.affinity;
}

- (NSComparisonResult)compare:(YHTextPosition *)otherPosition {
    if (!otherPosition) return NSOrderedAscending;
    if (_offset < otherPosition.offset) return NSOrderedAscending;
    if (_offset > otherPosition.offset) return NSOrderedDescending;
    if (_affinity == YHTextAffinityBackward && otherPosition.affinity == YHTextAffinityForward) return NSOrderedAscending;
    if (_affinity == YHTextAffinityForward && otherPosition.affinity == YHTextAffinityBackward) return NSOrderedDescending;
    return NSOrderedSame;
}


- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p> (%@%@)", self.class, self, @(_offset), _affinity == YHTextAffinityForward ? @"F":@"B"];
}

@end

@implementation YHTextRange {
    YHTextPosition *_start;
    YHTextPosition *_end;
}

- (instancetype)init {
    self = [super init];
    if (!self) return nil;
    _start = [YHTextPosition positionWithOffset:0];
    _end = [YHTextPosition positionWithOffset:0];
    return self;
}

- (YHTextPosition *)start {
    return _start;
}

- (YHTextPosition *)end {
    return _end;
}

- (BOOL)isEmpty {
    return _start.offset == _end.offset;
}

- (NSRange)asRange {
    return NSMakeRange(_start.offset, _end.offset - _start.offset);
}

+ (instancetype)rangeWithRange:(NSRange)range {
    return [self rangeWithRange:range affinity:YHTextAffinityForward];
}

+ (instancetype)rangeWithRange:(NSRange)range affinity:(YHTextAffinity)affinity {
    YHTextPosition *start = [YHTextPosition positionWithOffset:range.location affinity:affinity];
    YHTextPosition *end = [YHTextPosition positionWithOffset:range.location + range.length affinity:affinity];
    return [self rangeWithStart:start end:end];
}

+ (instancetype)rangeWithStart:(YHTextPosition *)start end:(YHTextPosition *)end {
    if (!start || !end) return nil;
    if ([start compare:end] == NSOrderedDescending) {
        YHTEXT_SWAP(start, end);
    }
    YHTextRange *range = [YHTextRange new];
    range->_start = start;
    range->_end = end;
    return range;
}

+ (instancetype)defaultRange {
    return [self new];
}

- (instancetype)copyWithZone:(NSZone *)zone {
    return [self.class rangeWithStart:_start end:_end];
}

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p> (%@, %@)%@", self.class, self, @(_start.offset), @(_end.offset - _start.offset), _end.affinity == YHTextAffinityForward ? @"F":@"B"];
}

- (NSUInteger)hash {
    return (sizeof(NSUInteger) == 8 ? OSSwapInt64(_start.hash) : OSSwapInt32(_start.hash)) + _end.hash;
}

- (BOOL)isEqual:(YHTextRange *)object {
    if (!object) return NO;
    return [_start isEqual:object.start] && [_end isEqual:object.end];
}

@end

@implementation YHTextSelectionRect

@synthesize rect = _rect;
@synthesize writingDirection = _writingDirection;
@synthesize containsStart = _containsStart;
@synthesize containsEnd = _containsEnd;
@synthesize isVertical = _isVertical;

- (id)copyWithZone:(NSZone *)zone {
    YHTextSelectionRect *one = [self.class new];
    one.rect = _rect;
    one.writingDirection = _writingDirection;
    one.containsStart = _containsStart;
    one.containsEnd = _containsEnd;
    one.isVertical = _isVertical;
    return one;
}
@end

