//
//  KZTrackingManager.m
//  KZStudy
//
//  Created by yuhechuan on 2024/6/12.
//

#import "KZTrackingManager.h"
#import "KZTrackingModel.h"
#import "KZTrackingDBDelay.h"
#import "KZTrackingMergeDelay.h"
#import "KZTrackingTimeDelay.h"

@interface KZTrackingManager ()

@property (nonatomic, strong) KZTrackingDBDelay *dbTracer;
@property (nonatomic, strong) KZTrackingMergeDelay *mergeTracer;
@property (nonatomic, strong) KZTrackingTimeDelay *timeTracer;
@property (nonatomic, strong) KZTrackingModel *trackingModel;

@end

@implementation KZTrackingManager {
    struct {
        unsigned int startBatchTrackingUpload : 1;
    } _delegateState;
}

+ (instancetype)sharedTracking {
    static KZTrackingManager *trackingManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        trackingManager = [[KZTrackingManager alloc] init];
    });
    return trackingManager;
}

- (void)setDelegate:(id<KZTrackingDelegate>)delegate {
    _delegate = delegate;
    _delegateState.startBatchTrackingUpload = [delegate respondsToSelector:@selector(startBatchTrackingUpload:response:)];
}

- (void)addTimerTrackingData:(NSDictionary *)parameter {
    [self addTrackingData:parameter strategyType:KZTrackingStrategyTypeTime];
}

- (void)addTimerTrackingList:(NSArray <NSDictionary *>*)parameterList {
    [self addTrackingList:parameterList strategyType:KZTrackingStrategyTypeTime];
}

- (void)addMergeTrackingData:(NSDictionary *)parameter {
    [self addTrackingData:parameter strategyType:KZTrackingStrategyTypeMerge];
}

- (void)addMergeTrackingList:(NSArray <NSDictionary *>*)parameterList {
    [self addTrackingList:parameterList strategyType:KZTrackingStrategyTypeMerge];
}

- (void)addDBTrackingData:(NSDictionary *)parameter {
    [self addTrackingData:parameter strategyType:KZTrackingStrategyTypeDB];
}

- (void)addDBTrackingList:(NSArray<NSDictionary *> *)parameterList {
    [self addTrackingList:parameterList strategyType:KZTrackingStrategyTypeDB];
}

- (void)addTrackingData:(NSDictionary *)parameter
           strategyType:(KZTrackingStrategyType)strategyType {
    if (!parameter || parameter.count == 0) {
        return;
    }
    if ([NSThread isMainThread] == NO) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self addTrackingData:parameter strategyType:strategyType];
        });
        return;
    }
    id<ITracking> tracer = nil;
    if (strategyType == KZTrackingStrategyTypeMerge) {
        tracer = self.mergeTracer;
    } else if (strategyType == KZTrackingStrategyTypeTime) {
        tracer = self.timeTracer;
    } else if (strategyType == KZTrackingStrategyTypeDB) {
        tracer = self.dbTracer;
    }
    [tracer addTrackingData:parameter];
}

- (void)addTrackingList:(NSArray <NSDictionary *>*)parameterList
           strategyType:(KZTrackingStrategyType)strategyType {
    if (parameterList.count == 0) {
        return;
    }
    if ([NSThread isMainThread] == NO) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self addTrackingList:parameterList strategyType:strategyType];
        });
        return;
    }
    id<ITracking> tracer = nil;
    if (strategyType == KZTrackingStrategyTypeMerge) {
        tracer = self.mergeTracer;
    } else if (strategyType == KZTrackingStrategyTypeTime) {
        tracer = self.timeTracer;
    } else if (strategyType == KZTrackingStrategyTypeDB) {
        tracer = self.dbTracer;
    }
    [tracer addTrackingList:parameterList];
}

- (void)_startBatchTrackingUpload:(NSArray *)parameters
                         response:(KZTrackingResponse)response {
    if (_delegateState.startBatchTrackingUpload) {
        [self.delegate startBatchTrackingUpload:parameters response:response];
    }
}


- (KZTrackingDBDelay *)dbTracer {
    if (!_dbTracer) {
        _dbTracer = [[KZTrackingDBDelay alloc]init];
        __weak __typeof(self) weakSelf = self;
        _dbTracer.uploadBlock = ^(NSArray *parameters, KZTrackingResponse response) {
            [weakSelf _startBatchTrackingUpload:parameters response:response];
        };
        _dbTracer.trackingModel = self.trackingModel;
    }
    return _dbTracer;
}

- (KZTrackingMergeDelay *)mergeTracer {
    if (!_mergeTracer) {
        _mergeTracer = [[KZTrackingMergeDelay alloc]init];
        __weak __typeof(self) weakSelf = self;
        _mergeTracer.uploadBlock = ^(NSArray *parameters, KZTrackingResponse response) {
            [weakSelf _startBatchTrackingUpload:parameters response:response];
        };
    }
    return _mergeTracer;
}

- (KZTrackingTimeDelay *)timeTracer {
    if (!_timeTracer) {
        _timeTracer = [[KZTrackingTimeDelay alloc]init];
        __weak __typeof(self) weakSelf = self;
        _timeTracer.uploadBlock = ^(NSArray *parameters, KZTrackingResponse response) {
            [weakSelf _startBatchTrackingUpload:parameters response:response];
        };
    }
    return _timeTracer;
}

- (KZTrackingModel *)trackingModel {
    if (!_trackingModel) {
        _trackingModel = [[KZTrackingModel alloc]init];
    }
    return _trackingModel;
}

@end
