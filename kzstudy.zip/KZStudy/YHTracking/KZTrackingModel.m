//
//  KZTrackingModel.m
//  KZStudy
//
//  Created by yuhechuan on 2022/4/14.
//

#import "KZTrackingModel.h"
#import <UIKit/UIKit.h>

@implementation KZTrackingModel

- (instancetype)init {
    if (self = [super init]) {
        _openBatchUpload = YES;
        _maxBatchUploadCount = 50;
        _maxBatchUploadDataLength = 1 *1024 *1024;
        _retryNumberOfTimes = 0;
        _maxConcurrentOperationCount = 1;
    }
    return self;
}

- (NSString *)trackingCountKey {
    return @"count";
}

@end
