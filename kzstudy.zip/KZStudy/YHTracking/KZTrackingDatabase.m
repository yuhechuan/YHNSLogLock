//
//  KZTrackingDatabase.m
//  KZStudy
//
//  Created by yuhechuan on 2022/9/21.
//

#import "KZTrackingDatabase.h"
#import "FMDB.h"

@implementation KZTrackingDBInfo

- (instancetype)init {
    if (self = [super init]) {
        _trackingId = [NSUUID UUID].UUIDString;
        _trackingTime = [[NSDate date] timeIntervalSince1970];
    }
    return self;
}

@end

@interface KZDbColumnInfo : NSObject

@property(nonatomic, strong) NSString* columnName;
@property(nonatomic, strong) NSString* columnType;

@end

@implementation KZDbColumnInfo
@end

@implementation KZTrackingDatabase {
    FMDatabaseQueue* _dbQueue;
    dispatch_queue_t _taskQueue;
}

- (instancetype)init {
    if (self = [super init]) {
        NSString* dbPath = [KZTrackingDatabase dbPath:@"bz_tracking.sqlite"];
        _dbQueue =  [FMDatabaseQueue databaseQueueWithPath:dbPath];
        _taskQueue = dispatch_queue_create("com.bztrackingDatabase.tracking",
                                           DISPATCH_QUEUE_SERIAL);
        [KZTrackingDatabase removeDbFileProtection:dbPath];
        
    }
    return self;
}

/// 异步执行
- (void)asyncExecute:(void(^)(void))task {
    dispatch_async(_taskQueue, task);
}

/// 异步执行
- (void)syncExecute:(void(^)(void))task {
    dispatch_sync(_taskQueue, task);
}

/// 开启数据库
- (void)openDatabase {
    FMDatabaseQueue* dbQueue = _dbQueue;
    
    NSMutableString * sql = [[NSMutableString alloc] init];
    [sql appendFormat:@"CREATE TABLE IF NOT EXISTS '%@' (",[KZTrackingDatabase tableName]];
   
    NSArray *infos = [self packageColumnInfo];
    NSMutableArray *columns = [[NSMutableArray alloc] init];

    for (KZDbColumnInfo *info in infos) {
        NSString *c = [NSString stringWithFormat:@"'%@' %@", info.columnName, info.columnType];
        [columns addObject:c];
    }
    [sql appendString:[columns componentsJoinedByString:@","]];

    [sql appendString:@")"];
    [dbQueue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:sql];
    }];
}

/// 添加一条 批量埋点记录
- (void)dbInsertTracking:(KZTrackingDBInfo *)track {
    
    NSArray *infos = [self packageColumnInfo];
    NSMutableArray *titleArr = [[NSMutableArray alloc] init];
    for (KZDbColumnInfo *info  in infos){
        [titleArr addObject:info.columnName];
    }
    
    NSMutableArray *valueArr = [[NSMutableArray alloc] init];
    [valueArr addObject:track.trackingId];
    [valueArr addObject:track.trackingJosnData];
    [valueArr addObject:@(track.trackingTime)];
    
    
    NSMutableArray* questionAry = [NSMutableArray arrayWithCapacity:titleArr.count];
    for (int i= 0; i < titleArr.count; i++) {
        [questionAry addObject:@"?"];
    }
    
    NSString *sql = [NSString stringWithFormat:@"insert into %@ (%@) values(%@)",
                                [KZTrackingDatabase tableName],
                                [titleArr componentsJoinedByString:@","],
                                [questionAry componentsJoinedByString:@","]];
    __weak __typeof(self)weakSelf = self;
    [self asyncExecute:^{
        [weakSelf executeSql:sql values:valueArr];
    }];
}


- (BOOL)executeSql:(NSString *)sqlString values:(NSArray *)values{
    if (!_dbQueue) return NO;
    __block BOOL result = NO;
    [_dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
        NSError *error = nil;
        result = [db executeUpdate:sqlString values:values error:&error];
    }];
    return result;
}

/// 删除一条记录
- (void)dbDeleteTrackingId:(NSString *)trackingId {
    NSString *sql = [NSString stringWithFormat:@"delete from %@ where trackingId = '%@';",[KZTrackingDatabase tableName], trackingId];
    __weak __typeof(self)weakSelf = self;
    [self asyncExecute:^{
        [weakSelf executeSql:sql values:nil];
    }];
}

/// 获取所有记录 按照 入库时间 排序, 时间早的在前面
- (void)dbGetAllTrackingInfoResultBlock:(void(^)(NSArray <KZTrackingDBInfo *>*trackings))resultBlock {
    __weak __typeof(self)weakSelf = self;
    [self asyncExecute:^{
        [weakSelf bz_dbGetAllTrackingInfoResultBlock:resultBlock];
    }];
}

- (void)bz_dbGetAllTrackingInfoResultBlock:(void(^)(NSArray <KZTrackingDBInfo *>*trackings))resultBlock  {
    NSMutableArray *dataArray = [[NSMutableArray alloc] init];
    [_dbQueue inDatabase:^(FMDatabase * _Nonnull db) {
        NSString *querySql = [NSString stringWithFormat:@"select * from %@ order by trackingTime",[KZTrackingDatabase tableName]];
        FMResultSet *rs = [db executeQuery:querySql];
        NSError *error = nil;
        while([rs nextWithError:&error]) {
            KZTrackingDBInfo *info = [[KZTrackingDBInfo alloc]init];
            info.trackingId = [rs stringForColumnIndex:0];
            info.trackingJosnData = [rs stringForColumnIndex:1];
            info.trackingTime =  [rs unsignedLongLongIntForColumnIndex:2];
            [dataArray addObject:info];
        }
    }];
    if (resultBlock) {
        resultBlock(dataArray.copy);
    }
}

/// 清空表
- (void)clearDBTable {
    NSString *sql = [NSString stringWithFormat:@"delete from %@;",[KZTrackingDatabase tableName]];
    __weak __typeof(self)weakSelf = self;
    [self syncExecute:^{
        [weakSelf executeSql:sql values:nil];
    }];
}

/// 数据库 表 字段
- (NSArray <KZDbColumnInfo *>*)packageColumnInfo {
    
    KZDbColumnInfo *info1 = [[KZDbColumnInfo alloc]init];
    info1.columnName = @"trackingId";
    info1.columnType = @"text primary key";
    
    KZDbColumnInfo *info2 = [[KZDbColumnInfo alloc]init];
    info2.columnName = @"trackingJosnData";
    info2.columnType = @"text";
    
    KZDbColumnInfo *info3 = [[KZDbColumnInfo alloc]init];
    info3.columnName = @"trackingTime";
    info3.columnType = @"integer";
    return @[info1,info2,info3];
}

/// 去除保护
+ (void)removeDbFileProtection:(NSString *)dbPath {
    NSFileManager *fileManager  = [NSFileManager defaultManager];
    
    if(![fileManager fileExistsAtPath:dbPath])
        return;
    NSString* dbFolder = [dbPath stringByDeletingLastPathComponent];
    [fileManager setAttributes:[NSDictionary dictionaryWithObject:NSFileProtectionNone forKey:NSFileProtectionKey] ofItemAtPath:dbFolder error:nil];
    
    [fileManager setAttributes:[NSDictionary dictionaryWithObject:NSFileProtectionNone forKey:NSFileProtectionKey] ofItemAtPath:dbPath error:nil];
}

/// 数据库路径
+ (NSString *)dbPath:(NSString *)dbName {
    return [[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask]lastObject] URLByAppendingPathComponent:dbName].relativePath;
}

+ (NSString *)tableName {
    return @"trackingTable";
}

@end
