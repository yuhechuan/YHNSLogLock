//
//  KZTrackingDBDelay.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/15.
//

#import "KZTrackingDBDelay.h"
#import "KZBlockOperation.h"
#import "KZTrackingDatabase.h"
#import "NSString+KZExtension.h"
#import "NSObject+KZExtension.h"
#import "KZTrackingModel.h"


NSString *bz_hashKey(NSDictionary *parameter, BOOL mergeSameUpload) {
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:parameter];
    if(mergeSameUpload) {
        [dict removeObjectForKey:@"actual_time"];
    }
    [dict removeObjectForKey:@"req_random"];
    return [dict JSONString];
}

/// 单个点模型
@interface KZTrack: NSObject

@property (nonatomic, copy) NSString *trackKey;
@property (nonatomic, assign) int count;
@property (nonatomic, strong) NSDictionary *parameter;
@property (nonatomic, strong) NSMutableArray *actualTimeList;

@end

@implementation KZTrack

- (instancetype)initWithParameter:(NSDictionary *)parameter
                         trackKey:(NSString *)trackKey {
    if (self = [super init]) {
        _parameter = parameter;
        _trackKey = trackKey;
        _count = 1;
    }
    return self;
}

- (NSMutableArray *)actualTimeList {
    if(!_actualTimeList) {
        _actualTimeList = [NSMutableArray array];
    }
    return _actualTimeList;
}

@end


@interface YHTrackingPage: NSObject

@property (nonatomic, strong) NSArray <NSDictionary *>*parameters;
@property (nonatomic, assign) NSUInteger capacity;
@property (nonatomic, assign) int failTime;
@property (nonatomic, copy) NSString *trackingId;

@end

@implementation YHTrackingPage

- (instancetype)initWithParameters:(NSArray *)parameters {
    if (self = [super init]) {
        _parameters = parameters;
    }
    return self;
}

- (NSUInteger)capacity {
    if (self.parameters.count == 0) {
        return 0;
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:self.parameters options:NSJSONWritingPrettyPrinted error:nil];
    return data.length;
}


@end

@interface KZTrackingDBDelay ()

/// 追踪埋点列表
@property (nonatomic, strong) NSMutableDictionary <NSString *,KZTrack *>*trackingMap;
/// 失败的缓存数组
@property (nonatomic, strong) NSMutableArray <YHTrackingPage *>*failTrackingCache;
/// 串行队列
@property (nonatomic, strong) NSOperationQueue *uploadQueue;
/// 数据库管理类
@property (nonatomic, strong) KZTrackingDatabase *trackingDB;
/// 当前待上传的个数
@property (nonatomic, assign) int trackingCount;

@end

@implementation KZTrackingDBDelay {
    /// 添加追踪信号量
    dispatch_semaphore_t _trackingSemaphore;
    /// 添加失败追踪信号量
    dispatch_semaphore_t _failedSemaphore;
}

@synthesize trackingModel =_trackingModel;
@synthesize uploadBlock = _uploadBlock;

- (instancetype)init {
    if (self = [super init]) {
        [self setUp];
    }
    return self;
}

- (void)setUp {
    _trackingSemaphore = dispatch_semaphore_create(1);
    _failedSemaphore = dispatch_semaphore_create(1);
    [self addObservers];
    [self.trackingDB openDatabase];
}

- (void)addObservers {
    // 收到内存警告
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appReceiveMemoryWarning) name:UIApplicationDidReceiveMemoryWarningNotification
                                               object:nil];
    // 进入后台

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appWillResignActive)
                                                 name:UIApplicationWillResignActiveNotification
                                               object:nil];
    // 进入前台
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appDidBecomeActive)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];

    // 终止应用
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appWillTerminate)
                                                 name:UIApplicationWillTerminateNotification
                                            object:nil];
}



/// 存储一个请求
- (void)addTrackingData:(NSDictionary *)parameter {
    
    if ([self beforeTrackingLimit:parameter]) {
        [self startBatchTrackingUpload:@[parameter] response:nil];
        return;
    }
    
    dispatch_semaphore_wait(_trackingSemaphore, DISPATCH_TIME_FOREVER);
    NSString *hasKey = bz_hashKey(parameter, self.trackingModel.openMergeSameUpload);
    KZTrack *track = self.trackingMap[hasKey];
    if (track) {
        track.count ++;
        NSMutableDictionary *extend = [NSMutableDictionary dictionary];
        extend[@"actual_time"] = parameter[@"actual_time"];
        extend[@"req_random"] = parameter[@"req_random"];
        [track.actualTimeList addObject:extend];
    } else {
        track = [[KZTrack alloc]initWithParameter:parameter trackKey:hasKey];
        self.trackingMap[hasKey] = track;
    }
    self.trackingCount ++;
    
    dispatch_semaphore_signal(_trackingSemaphore);
    
    // 超出个数限制
    if (self.trackingCount >= self.trackingModel.maxBatchUploadCount) {
        [self batchTrackingClearRequired];
    }
}

- (void)addTrackingList:(NSArray<NSDictionary *> *)parameterList {
    for (NSDictionary *parameter in parameterList) {
        [self addTrackingData:parameter];
    }
}

- (BOOL)beforeTrackingLimit:(NSDictionary *)parameter {
    if (!self.trackingModel.openBatchUpload) {
        return YES;
    }
    if (self.trackingModel.trackingWhiteListString.length > 0) {
        NSString *actionName = parameter[@"action"];
        if (actionName.length > 0 && [self.trackingModel.trackingWhiteListString containsString:actionName]) {
            return YES;
        }
    }
    return NO;
}


/// 开始开始批量处理
- (void)batchTrackingClearRequired {
    if (self.trackingCount == 0) {
        return;
    }
    
    dispatch_semaphore_wait(_trackingSemaphore, DISPATCH_TIME_FOREVER);
    
    NSDictionary *uploadMap = self.trackingMap.copy;
    [self.trackingMap removeAllObjects];
    self.trackingCount = 0;
    NSArray *info = [self packageAvailableInfo:uploadMap];
    [self beforeUploadDatasWithInfos:info];
    
    dispatch_semaphore_signal(_trackingSemaphore);
}
/// 组装出可硬  上传数组
- (NSArray <YHTrackingPage *>*)packageAvailableInfo:(NSDictionary <NSString *,KZTrack *>*)uploadMap {
    NSArray *uploadMapArray = [self packageAvailableParameters:uploadMap];
    YHTrackingPage *info = [[YHTrackingPage alloc]initWithParameters:uploadMapArray.copy];
    return @[info];
}

/// 组装出 需求上传数数据
- (NSArray *)packageAvailableParameters:(NSDictionary <NSString *,KZTrack *>*)uploadMap {
    NSMutableArray *uploadMapArray = [NSMutableArray array];
    NSArray *tracks = [uploadMap allValues];
    for (KZTrack *t in tracks) {
        if (self.trackingModel.openMergeSameUpload) {
            NSMutableDictionary *mp = [NSMutableDictionary dictionaryWithDictionary:t.parameter];
            mp[self.trackingModel.trackingCountKey] = @(t.count);
            [uploadMapArray addObject:mp.copy];
        } else if(t.count > 1) {
            int c = t.count;
            while (c > 0) {
                [uploadMapArray addObject:t.parameter];
                c--;
            }
        } else {
            [uploadMapArray addObject:t.parameter];
        }
    }
    return uploadMapArray.copy;
}

/// 开始开始批量处理 之前
- (void)beforeUploadDatasWithInfos:(NSArray <YHTrackingPage *>*)infos {
    dispatch_semaphore_wait(_failedSemaphore, DISPATCH_TIME_FOREVER);
    [self.failTrackingCache  addObjectsFromArray:infos];
    dispatch_semaphore_signal(_failedSemaphore);
    [self uploadDatasWithInfos:infos];
}

/// 开始开始批量处理
- (void)uploadDatasWithInfos:(NSArray <YHTrackingPage *>*)infos {
    __weak __typeof(self)weakSelf = self;
    for (YHTrackingPage *info in infos) {
        KZBlockOperation *op = [KZBlockOperation blockOperationWithBlock:^(KZBlockOperation * _Nonnull operation) {
            [weakSelf startBatchTrackingUpload:info.parameters response:^(NSError *error) {
                if (error) {
                    [weakSelf uploadInfosError:info];
                } else {
                    [weakSelf uploadInfosSucceed:info];
                }
                [operation complete];
            }];
        }];
        [self.uploadQueue addOperation:op];
    }
}
/// 上传失败的回调
- (void)uploadInfosError:(YHTrackingPage *)info {
    if (!info) {
        return;
    }
    info.failTime ++;
    if (info.failTime < self.trackingModel.retryNumberOfTimes) {
        [self uploadDatasWithInfos:@[info]];
    }
}

/// 上传成功的回调
- (void)uploadInfosSucceed:(YHTrackingPage *)info {
    if (StringNotNullAndEmpty(info.trackingId)) {
        [self.trackingDB dbDeleteTrackingId:info.trackingId];
    }
    dispatch_semaphore_wait(_failedSemaphore, DISPATCH_TIME_FOREVER);
    if ([self.failTrackingCache containsObject:info]) {
        [self.failTrackingCache removeObject:info];
    }
    dispatch_semaphore_signal(_failedSemaphore);
}

/// 上传 失败的 追踪
- (void)batchTrackingClearFail {
    if (self.failTrackingCache.count == 0) {
        return;
    }
    dispatch_semaphore_wait(_failedSemaphore, DISPATCH_TIME_FOREVER);
    NSArray *uploadArr = self.failTrackingCache.copy;
    [self uploadDatasWithInfos:uploadArr];
    dispatch_semaphore_signal(_failedSemaphore);
}

/// 获取单前失败的和 内存中的  所有没有上传的埋点数据
- (NSArray <NSArray <NSDictionary *>*>*)fetchAllNotUploadTrackings {
    NSMutableArray *tracks = [NSMutableArray array];
    
    NSArray *uploadMapArray = [self packageAvailableParameters:self.trackingMap];
    [tracks addObject:uploadMapArray];
    
    for (YHTrackingPage *info in self.failTrackingCache) {
        if (info.parameters.count > 0) {
            [tracks addObject:info.parameters];
        }
    }
    return tracks.copy;
}


/// 存储所有 没有上传的数据
- (void)writeLocalStorageAllMemoryTrackings {
    NSArray *allTrackings = [self fetchAllNotUploadTrackings];
    for (NSArray *ts in allTrackings) {
        KZTrackingDBInfo *dbInfo = [[KZTrackingDBInfo alloc]init];
        dbInfo.trackingJosnData = [ts JSONString];
        [self.trackingDB dbInsertTracking:dbInfo];
    }
    self.trackingCount = 0;
    [self.trackingMap removeAllObjects];
    [self.failTrackingCache removeAllObjects];
}

/// 读取本地
- (void)readLocalStorageAllMemoryTrackings {
    __weak __typeof(self)weakSelf = self;
    [self.trackingDB dbGetAllTrackingInfoResultBlock:^(NSArray<KZTrackingDBInfo *> * _Nonnull trackings) {
        NSMutableArray *updateArr = [NSMutableArray array];
        for (KZTrackingDBInfo *dbInfo in trackings) {
            NSArray *ts = [dbInfo.trackingJosnData objectFromJSONString];
            YHTrackingPage *info = [[YHTrackingPage alloc]initWithParameters:ts];
            info.trackingId = dbInfo.trackingId;
            [updateArr addObject:info];
            /// 删除
            [weakSelf.trackingDB dbDeleteTrackingId:dbInfo.trackingId];
        }
        [weakSelf beforeUploadDatasWithInfos:updateArr];
    }];
}

#pragma mark -- 注册通知方法

/// app 即将终止
- (void)appWillTerminate {
    [self writeLocalStorageAllMemoryTrackings];
}

/// app 进入后台
- (void)appWillResignActive {
    [self writeLocalStorageAllMemoryTrackings];
}

/// app 进入前台
- (void)appDidBecomeActive {
    [self readLocalStorageAllMemoryTrackings];
    [self batchTrackingClearFail];
}

- (void)appReceiveMemoryWarning {
    [self batchTrackingClearFail];
    [self batchTrackingClearRequired];
}

- (void)startBatchTrackingUpload:(NSArray *)parameters
                        response:(KZTrackingResponse)response {
    if (self.uploadBlock) {
        self.uploadBlock(parameters, response);
    } else {
        if (response) {
            response(nil);
        }
    }
}

- (NSMutableDictionary<NSString *,KZTrack *> *)trackingMap {
    if (!_trackingMap) {
        _trackingMap = [NSMutableDictionary dictionary];
    }
    return _trackingMap;
}

- (NSMutableArray<YHTrackingPage *> *)failTrackingCache {
    if (!_failTrackingCache) {
        _failTrackingCache = [NSMutableArray array];
    }
    return _failTrackingCache;
}

- (NSOperationQueue *)uploadQueue {
    if (!_uploadQueue) {
        _uploadQueue = [[NSOperationQueue alloc]init];
        _uploadQueue.maxConcurrentOperationCount = self.trackingModel.maxConcurrentOperationCount;
    }
    return _uploadQueue;
}

- (KZTrackingDatabase *)trackingDB {
    if (!_trackingDB) {
        _trackingDB = [[KZTrackingDatabase alloc]init];
    }
    return _trackingDB;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
