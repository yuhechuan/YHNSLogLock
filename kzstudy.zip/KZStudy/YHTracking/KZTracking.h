//
//  KZTrackingMgr.h
//  KZStudy
//
//  Created by yuhechuan on 2024/6/12.
//

#ifndef KZTracking_h
#define KZTracking_h

@class KZTrackingModel;

typedef NS_ENUM(int, KZTrackingStrategyType) {
    KZTrackingStrategyTypeMerge = 1,
    KZTrackingStrategyTypeTime,
    KZTrackingStrategyTypeDB,
};

typedef void (^KZTrackingResponse)(NSError* error);
typedef void (^KZTrackingUploadBlock)(NSArray* parameters, KZTrackingResponse response);


@protocol KZTrackingDelegate <NSObject>

@required

/// 多个埋点的上报 回调 response 返回是否 上传产生了 错误 从而进一步处理, 如不返回结果会阻塞住 串行上传队列
- (void)startBatchTrackingUpload:(NSArray *)parameters
                        response:(KZTrackingResponse)response;

@end


@protocol ITracking <NSObject>

/// 上传代理
@property (nonatomic, copy) KZTrackingUploadBlock uploadBlock;

/// 存储一个请求 参数
- (void)addTrackingData:(NSDictionary *)parameter;
/// 存储多个请求 参数
- (void)addTrackingList:(NSArray <NSDictionary *>*)parameterList;

@optional
/// 配置 模型
@property (nonatomic, weak) KZTrackingModel *trackingModel;

@end



#endif /* KZTracking_h */
