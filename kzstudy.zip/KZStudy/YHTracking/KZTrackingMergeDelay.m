//
//  KZTrackingMergeDelay.m
//  KZStudy
//
//  Created by yuhechuan on 2024/6/12.
//

#import "KZTrackingMergeDelay.h"
#import "KZTrackingModel.h"

@interface KZTrackingMergeDelay ()

@property (nonatomic, strong) NSMutableArray *parameterCache;

@end

@implementation KZTrackingMergeDelay {
    dispatch_source_t _eventUnion;
}

@synthesize trackingModel =_trackingModel;
@synthesize uploadBlock = _uploadBlock;

- (instancetype)init {
    if (self = [super init]) {
        [self setUp];
    }
    return self;
}

- (void)setUp {
    _eventUnion = dispatch_source_create(DISPATCH_SOURCE_TYPE_DATA_ADD, 0, 0, dispatch_get_main_queue());
    /// 此处会导致循环引用
    __weak __typeof(self) weakSelf = self;
    dispatch_source_set_event_handler(_eventUnion, ^{
        [weakSelf uploadTrackingDatas];
    });
    dispatch_activate(_eventUnion);
}


- (void)addTrackingData:(NSDictionary *)parameter {
    [self.parameterCache addObject:parameter];
    dispatch_source_merge_data(_eventUnion, 1);
}

- (void)addTrackingList:(NSArray<NSDictionary *> *)parameterList {
    [self.parameterCache addObjectsFromArray:parameterList];
    dispatch_source_merge_data(_eventUnion, 1);
}

- (void)uploadTrackingDatas {
    NSArray *parameters = self.parameterCache.copy;
    [self.parameterCache removeAllObjects];
    [self batchUploadTrackingDatas:parameters];
}


- (void)batchUploadTrackingDatas:(NSArray *)parameters {
    if (self.uploadBlock) {
        self.uploadBlock(parameters, nil);
    }
}

- (NSMutableArray *)parameterCache {
    if (!_parameterCache) {
        _parameterCache = [NSMutableArray array];
    }
    return _parameterCache;
}

- (void)dealloc {
    if (_eventUnion) {
        dispatch_source_cancel(_eventUnion);
    }
}

@end
