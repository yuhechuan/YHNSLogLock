//
//  KZTrackingTimeDelay.h
//  KZStudy
//
//  Created by yuhechuan on 2024/6/12.
//

#import <Foundation/Foundation.h>
#import "KZTracking.h"

@interface KZTrackingTimeDelay : NSObject<ITracking>

@end
