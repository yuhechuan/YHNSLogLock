//
//  YHBlockOperation.h
//  KZStudy
//
//  Created by yuhechuan on 2022/4/14.
//

#import <Foundation/Foundation.h>

@class KZBlockOperation;

typedef void (^KZAsyncBlock)(KZBlockOperation * __nonnull operation);

@interface KZBlockOperation : NSOperation
/// 创建一个 operation
- (nonnull instancetype)initWithBlock:(nonnull KZAsyncBlock)block;
+ (nonnull instancetype)blockOperationWithBlock:(nonnull KZAsyncBlock)block;
/// 当异步任务完成时进行 标识 让 queue自动去移除
- (void)complete;

@end
