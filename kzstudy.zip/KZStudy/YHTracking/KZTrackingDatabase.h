//
//  KZTrackingDatabase.h
//  KZStudy
//
//  Created by yuhechuan on 2022/9/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZTrackingDBInfo : NSObject

@property (nonatomic, copy) NSString *trackingId;
@property (nonatomic, copy) NSString *trackingJosnData;
@property (nonatomic, assign) SInt64 trackingTime;

@end

@interface KZTrackingDatabase : NSObject

/// 开启数据库
- (void)openDatabase;

/// 添加一条 批量埋点记录
- (void)dbInsertTracking:(KZTrackingDBInfo *)track;

/// 删除一条记录
- (void)dbDeleteTrackingId:(NSString *)trackingId;

/// 获取所有记录 按照 入库时间 排序, 时间早的在前面
- (void)dbGetAllTrackingInfoResultBlock:(void(^)(NSArray <KZTrackingDBInfo *>*trackings))resultBlock;

/// 清空表
- (void)clearDBTable;

@end

NS_ASSUME_NONNULL_END
