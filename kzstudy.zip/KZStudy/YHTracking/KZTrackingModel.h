//
//  KZTrackingModel.h
//  KZStudy
//
//  Created by yuhechuan on 2022/4/14.
//

#import <Foundation/Foundation.h>

#define TRACK_DEBUG 1

NS_ASSUME_NONNULL_BEGIN

/**
 * 可以用后台给一些配置数据
 */
@interface KZTrackingModel : NSObject

/// 是否开启批量上传 默认是 YES
@property (nonatomic, assign) BOOL openBatchUpload;
/// 是否开启 相同点 合并上传
@property (nonatomic, assign) BOOL openMergeSameUpload;
/// 一次上传的最大数 默认是 50 超过将自动拆解
@property (nonatomic, assign) NSInteger maxBatchUploadCount;
/// 一次上传的 二进制 最大限制 超过将自动拆解
/// 在Tomcat下取消POST大小的限制（Tomcat默认2M） 所以默认长度是  1 * 1024 *1024
@property (nonatomic, assign) NSInteger maxBatchUploadDataLength;
/// 一次批量上传 失败重传次数限制 默认是0次
@property (nonatomic, assign) int retryNumberOfTimes;
/// 上传的最大并发数  默认是1
@property (nonatomic, assign) NSInteger maxConcurrentOperationCount;
/// 同一埋点数量 key
@property (nonatomic, copy, readonly) NSString *trackingCountKey;
/// 白名单 action名称 逗号分割
@property (nonatomic, copy) NSString *trackingWhiteListString;


@end

NS_ASSUME_NONNULL_END
