//
//  YHBlockOperation.m
//  KZStudy
//
//  Created by yuhechuan on 2022/4/14.
//

#import "KZBlockOperation.h"

@interface KZBlockOperation ()

@property (nonatomic, assign, getter = isExecuting) BOOL executing;
@property (nonatomic, assign, getter = isFinished) BOOL finished;


@property (nonatomic, copy) KZAsyncBlock executionBlock;

@end

@implementation KZBlockOperation

@synthesize executing = _executing;
@synthesize finished = _finished;

- (nonnull instancetype)initWithBlock:(nonnull KZAsyncBlock)block {
    if (self = [super init]) {
        self.executionBlock = block;
    }
    return self;
}

+ (nonnull instancetype)blockOperationWithBlock:(nonnull KZAsyncBlock)block {
    return [[KZBlockOperation alloc]initWithBlock:block];
}

- (void)start {
    @synchronized (self) {
        if (self.isCancelled) {
            self.finished = YES;
            return;
        }
        
        self.finished = NO;
        self.executing = YES;
        if (self.executionBlock) {
            self.executionBlock(self);
        } else {
            self.finished = YES;
            self.executing = NO;
        }
    }
}

- (void)cancel {
    @synchronized (self) {
        [super cancel];
        if (self.isExecuting) {
            self.finished = YES;
            self.executing = NO;
        }
    }
}

- (void)complete {
    @synchronized (self) {
        if (self.isExecuting) {
            self.finished = YES;
            self.executing = NO;
        }
    }
}

- (void)setFinished:(BOOL)finished {
    [self willChangeValueForKey:@"isFinished"];
    _finished = finished;
    [self didChangeValueForKey:@"isFinished"];
}

- (void)setExecuting:(BOOL)executing {
    [self willChangeValueForKey:@"isExecuting"];
    _executing = executing;
    [self didChangeValueForKey:@"isExecuting"];
}

- (BOOL)isConcurrent {
    return YES;
}

@end
