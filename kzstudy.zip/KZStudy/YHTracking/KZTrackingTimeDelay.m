//
//  KZTrackingTimeDelay.m
//  KZStudy
//
//  Created by yuhechuan on 2024/6/12.
//

#import "KZTrackingTimeDelay.h"

@interface KZTrackingTimeDelay ()

@property (nonatomic, strong) NSMutableArray *parameterCache;
@property (nonatomic, assign) BOOL delaying;
@property (nonatomic, assign) int originTrackingCount;

@end

@implementation KZTrackingTimeDelay

@synthesize uploadBlock = _uploadBlock;

- (void)addTrackingData:(NSDictionary *)parameter {
    [self.parameterCache addObject:parameter];
    self.originTrackingCount ++;
    [self startTimeDelayStrategy];
}

- (void)addTrackingList:(NSArray<NSDictionary *> *)parameterList {
    [self.parameterCache addObjectsFromArray:parameterList];
    self.originTrackingCount += (int)parameterList.count;
    [self startTimeDelayStrategy];
}

- (void)startTimeDelayStrategy {
    if (self.delaying) {
        return;
    }
    self.delaying = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self uploadTrackingDatas];
    });
}

- (void)uploadTrackingDatas {
    NSArray *parameters = self.parameterCache.copy;
    if (parameters.count == 0) {
        return;
    }
    [self.parameterCache removeAllObjects];
    
    /// 合并异常打点, 事件丢失
    int realTrackingCount = (int)parameters.count;
    if (realTrackingCount != self.originTrackingCount) {
        NSString *toast = [NSString stringWithFormat:@"merge error originCount: %d realCount:%d", self.originTrackingCount, realTrackingCount];
        NSAssert(NO, toast);
    }
    
    /// 去打点
    [self batchUploadTrackingDatas:parameters];
    
    self.delaying = NO;
    /// 清空数量
    self.originTrackingCount = 0;
}

- (void)batchUploadTrackingDatas:(NSArray *)parameters {
    if (self.uploadBlock) {
        self.uploadBlock(parameters, nil);
    }
}


- (NSMutableArray *)parameterCache {
    if (!_parameterCache) {
        _parameterCache = [NSMutableArray array];
    }
    return _parameterCache;
}


@end
