//
//  KZTrackingDBDelay.h
//  KZStudy
//
//  Created by yuhechuan on 2022/3/15.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "KZTracking.h"

@interface KZTrackingDBDelay : NSObject<ITracking>

@end
