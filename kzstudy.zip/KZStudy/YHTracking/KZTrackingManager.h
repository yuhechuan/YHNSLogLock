//
//  KZTrackingManager.h
//  KZStudy
//
//  Created by yuhechuan on 2024/6/12.
//

#import <Foundation/Foundation.h>
#import "KZTracking.h"
/**
 * ? 坐船策略 现在不好实现
 *
 * 1. 需要时时上报的埋点名单 (需整理)
 * 2. 延时上报是否会影响业务, 现在埋点里面带着 actual_time上报时间字段
 * 3. 埋点丢失(卸载, 关闭app之后不再打开), 是否可以接受
 * 4. 同一个埋点,参数完全相同时, 是否可以只支持一个count字段
 * 5.batch接口参数过长 失败问题
 *
 *  =====================================
 *
 * 1. 进入后台时 上报会失败  所以入库处理
 * 2. 本地的分页处理, 支持一次读取部分数据
 * 3. 本地和内存两套方案
 * 4. 加入时间戳 (服务端支持)
 * 5. 服务端支持灰度, 一次上报个数, 缓存策略
 *
 */
@interface KZTrackingManager : NSObject

/// 单例
+ (instancetype)sharedTracking;

/// 上传代理
@property (nonatomic, weak) id<KZTrackingDelegate>delegate;

/// 事件联合
- (void)addMergeTrackingData:(NSDictionary *)parameter;
- (void)addMergeTrackingList:(NSArray <NSDictionary *>*)parameterList;

/// 本地数据库
- (void)addDBTrackingData:(NSDictionary *)parameter;
- (void)addDBTrackingList:(NSArray <NSDictionary *>*)parameterList;

/// 时间延迟
- (void)addTimerTrackingData:(NSDictionary *)parameter;
- (void)addTimerTrackingList:(NSArray <NSDictionary *>*)parameterList;


// 根据类型做延迟
- (void)addTrackingData:(NSDictionary *)parameter
           strategyType:(KZTrackingStrategyType)strategyType;
- (void)addTrackingList:(NSArray <NSDictionary *>*)parameterList
           strategyType:(KZTrackingStrategyType)strategyType;


@end
