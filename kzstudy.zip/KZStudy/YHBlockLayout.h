//
//  YHBlockLayout.h
//  KZStudy
//
//  Created by yuhechuan on 2022/2/16.
//

#import <Foundation/Foundation.h>

#define BeeHiveDATA(sectname) __attribute((used, section("__DATA,"#sectname" ")))

#define BeeHiveMod(name) \
class YHDefer; char * k##name##_mod BeeHiveDATA(BeehiveMods) = ""#name"";

// 比较全的block结构
struct Block_literal_1 {
    void *isa; // initialized to &_NSConcreteStackBlock or &_NSConcreteGlobalBlock
    int flags;
    int reserved;
    void (*invoke)(void *, ...);
    struct Block_descriptor_1 {
    unsigned long int reserved;         // NULL
        unsigned long int size;         // sizeof(struct Block_literal_1)
        // optional helper functions
        void (*copy_helper)(void *dst, void *src);     // IFF (1<<25)
        void (*dispose_helper)(void *src);             // IFF (1<<25)
        // required ABI.2010.3.16
        const char *signature;                         // IFF (1<<30)
    } *descriptor;
    // imported variables
};

enum { // Flags from BlockLiteral
    BLOCK_HAS_COPY_DISPOSE =  (1 << 25), // 判断是否存在copy和dispose函数
    BLOCK_HAS_CTOR =          (1 << 26), // helpers have C++ code
    BLOCK_IS_GLOBAL =         (1 << 28), // 那么该块是一个全局块
    BLOCK_HAS_STRET =         (1 << 29), // IF !BLOCK_HAS_SIGNATURE
    BLOCK_HAS_SIGNATURE =     (1 << 30), // 是否存在签名
};

struct block_bescriptor {
    // 保留变量
    unsigned long int reserved;                // NULL
    // block的内存大小
    unsigned long int size;
    // optional helper functions
    // 拷贝block中被 __block 修饰的外部变量
    void (*copy_helper)(void *dst, void *src); // IFF (1<<25)
    //和 copy 方法配置应用，用来释放资源
    void (*dispose_helper)(void *src);         // IFF (1<<25)
    // block的签名
    const char *signature;                     // IFF (1<<30)
};

// block的内存结构
struct block_layout {
    // 指向所属类的指针，也就是block的类型
    void *isa;  // initialized to &_NSConcreteStackBlock or &_NSConcreteGlobalBlock
    // 标志变量，在实现block的内部操作时会用到
    int flags;
    // 保留变量
    int reserved;
    // 执行时调用的函数指针，block内部的执行代码都在这个函数中
    void (*invoke)(void *, ...);
    // block的详细描述，包含 copy/dispose 函数，处理block引用外部变量时使用
    struct block_bescriptor *descriptor;
    // imported variables
};

@interface YHBlockLayout : NSObject

// 获取block的方法签名
+ (NSMethodSignature *)getSignatureWithBlock:(id)block;

@end
