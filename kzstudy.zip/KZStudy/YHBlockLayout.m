//
//  YHBlockLayout.m
//  KZStudy
//
//  Created by yuhechuan on 2022/2/16.
//

#import "YHBlockLayout.h"

@implementation YHBlockLayout


+ (NSMethodSignature *)getSignatureWithBlock:(id)block {
    struct block_layout *blockRef = (__bridge struct block_layout *)block;
    int flags = blockRef->flags;
    if (flags & BLOCK_HAS_SIGNATURE) {
        void *signatureLocation = blockRef->descriptor;
        signatureLocation += sizeof(unsigned long int);
        signatureLocation += sizeof(unsigned long int);
        if (flags & BLOCK_HAS_COPY_DISPOSE) {
            signatureLocation += sizeof(void(*)(void *dst, void *src));
            signatureLocation += sizeof(void (*)(void *src));
        }
        const char *signature = (*(const char **)signatureLocation);
        return [NSMethodSignature signatureWithObjCTypes:signature];
     }
     return nil;
}

@end
