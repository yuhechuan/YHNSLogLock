//
//  UINavigationController+Animated.m
//  KZStudy
//
//  Created by yuhechuan on 2021/9/6.
//

#import "UINavigationController+Animated.h"

@implementation UINavigationController (Animated)
/**
 * 动画结束后
 */
- (void)pushViewController:(UIViewController *)viewController
                  animated:(BOOL)animated
                completion: (void (^)(void))completion {
    [CATransaction setCompletionBlock:completion];
    [CATransaction begin];
    [self pushViewController:viewController animated:animated];
    [CATransaction commit];
}

@end
