//
//  YPSeniorLabel.m
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/5.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import "YPSeniorLabel.h"
#import "YPSeniorLayer.h"
#import "YPTextSelectView.h"
#import "YPSeniorLayout+Select.h"
#import "YPTextInput.h"
#import <objc/runtime.h>
#import "YPCustomMenuObject.h"
#import "YPMagnifierView.h"
#import "YPMagnifierWindow.h"
#import "YPMenuController.h"
#import "YPAttributeLayoutInfo.h"
#import "YPSeniorLayoutInject.h"
#import "YPCalloutBar.h"

#define kHighlithtFadeDuration  0.09

#define kContentFadeDuration  0.08

static dispatch_queue_t SeniorLabelGetReleaseQueue() {
    return dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0);
}

@interface YPSeniorLabel ()<YPSeniorLayerDelegate, UIGestureRecognizerDelegate>
{
    //layout
    NSMutableAttributedString *_layoutAttrString;
    YPSeniorLayout *_textLayout;
    YPSeniorLayoutInject *_layoutInject;
    // 用于控制 是否正在 绘制 控制长按手势是否起作用
    BOOL _updateFinish;
    
    //link
    NSMutableAttributedString *_linkAttrString;
    YPLinkAttribute *_linkAttribute;
    NSRange _linkRange;
    //gestures
    UILongPressGestureRecognizer *_longPressGesture;
    UIPanGestureRecognizer *_panGesture;
    
    //select
    YPTextSelectView *_textSelectView;
    YPTextRange *_selectRange;
    YPCustomMenuObject *_defaultMenuObject;
    BOOL _touchBegan;
    BOOL _touchEnd;
    BOOL _touchGrabBegan;
    BOOL _touchGrabEnd;
    BOOL _touchShouldNotCancelSelect;
    BOOL _selectTrunkRange;


    NSTimeInterval _callPhoneInterval;
    
    //magnifier
    YPMagnifierView *_magnifierView;
}

@end

@implementation YPSeniorLabel

#pragma mark -- Override

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initLabel];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self initLabel];
    }
    return self;
}

- (void)setFrame:(CGRect)frame {
    CGSize oldSize = self.bounds.size;
    [super setFrame:frame];
    CGSize newSize = self.bounds.size;
    if (!CGSizeEqualToSize(oldSize, newSize)) {
        [self setNeedsViewLayout];

    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

// 返回自定义宿主图层
+ (Class)layerClass {
    return [YPSeniorLayer class];
}

- (void)initLabel {
    ///basic
    _layoutInject = [[YPSeniorLayoutInject alloc] init];
    YPSeniorLayer *seniorLayer = (YPSeniorLayer *)self.layer;
    /**
     这个值定义了图层的逻辑坐标空间(以点为单位)和物理坐标空间(以像素为单位)之间的映射。更高的比例因子表明，在渲染时，层中的每个点都由一个以上的像素表示。例如，如果比例因子是2.0，图层的边界是50 x 50点，用来显示图层内容的位图的大小是100 x 100像素。
     这个属性的默认值是1.0。对于附加到视图上的层，视图会自动将比例因子更改为适合当前屏幕的值。对于您自己创建和管理的层，您必须根据屏幕的分辨率和所提供的内容自己设置此属性的值。Core Animation使用您指定的值作为提示来决定如何渲染内容。
     */
    seniorLayer.contentsScale = [[UIScreen mainScreen] scale];
    _updateFinish = NO;
    
    ///properties
    self.opaque = NO;
    self.clearContentWhenRedraw = YES;
    self.seniorDrawsAsynchronously = NO;
    self.ignorGeneralProperties = NO;
    self.fadeDuration = kContentFadeDuration;
    ///Select module
    //long press gesture
    _longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    _longPressGesture.delegate = self;
    /**
     The purpose of using delaysTouchesBegan is to first respond to a long-press gesture,
     rather than a click action, when long-press a link.
     */
    _longPressGesture.delaysTouchesBegan = YES;
    [self addGestureRecognizer:_longPressGesture];
    //pan gesture
    _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
    _panGesture.delaysTouchesBegan = YES;
    [self addGestureRecognizer:_panGesture];
    //select view
    _textSelectView = [[YPTextSelectView alloc] init];
    [self addSubview:_textSelectView];
    self.canSelectOperation = NO;
    self.canShowMagnifier = NO;
    self.useWordSelect = NO;
    _defaultMenuObject = [[YPCustomMenuObject alloc] init];
    self.menuDelegate = _defaultMenuObject;
    self.selectBackgroundColor = [[UIColor blueColor] colorWithAlphaComponent:0.1];
    self.cursorColor = [UIColor blueColor];
    //magnifier view
    _magnifierView = [[YPMagnifierView alloc] init];
    _magnifierView.needMagnifierView = self;
    //notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didHideMenuController) name:YPMenuControllerDidHideMenuNotification object:nil];
    //initialize select
    [self stopSelectOperation];

}
// 返回内容 size
// 该方法的默认实现返回视图的现有大小。子类可以重写此方法以根据任何子视图的期望布局返回自定义值。
- (CGSize)sizeThatFits:(CGSize)size {
    CGSize ls = [self seniorLabelContentSizeWithConstraintSize:size];
    return ls;
}
/**
 自定义视图通常显示布局系统不知道的内容。设置此属性允许自定义视图根据其内容向布局系统传递它希望的大小。这种内在的大小必须独立于内容框架，因为没有办法基于改变的高度动态地向布局系统传达改变的宽度。
 如果一个自定义视图对于给定的维度没有固有的大小，它可以使用UIViewNoIntrinsicMetric来描述这个维度。
 */
- (CGSize)intrinsicContentSize {
    return [self seniorLabelContentSizeWithConstraintSize:self.frame.size];
}

- (void)dealloc {
    if (_longPressGesture) {
        [_longPressGesture removeTarget:nil action:NULL];
        [self removeGestureRecognizer:_longPressGesture];
    }
    if (_panGesture) {
        [_panGesture removeTarget:nil action:NULL];
        [self removeGestureRecognizer:_panGesture];
    }

    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark -- Voice Over
/**
 用于 无障碍使用 是否支持
 */
- (BOOL)isAccessibilityElement {
    return YES;
}

- (NSString *)accessibilityLabel {
    return self.attributedString.string;
}

- (UIAccessibilityTraits)accessibilityTraits {
    return UIAccessibilityTraitStaticText;
}

#pragma mark -- Basic Properties
- (void)setSeniorDrawsAsynchronously:(BOOL)seniorDrawsAsynchronously {
    _seniorDrawsAsynchronously = seniorDrawsAsynchronously;
    ((YPSeniorLayer *)self.layer).seniorDrawsAsynchronously = seniorDrawsAsynchronously;
}

- (void)setAttributedString:(NSAttributedString *)attributedString {
    if (!attributedString) {
        attributedString = [NSMutableAttributedString new];
    }
    _attributedString = attributedString;
    _layoutAttrString = nil;
    _layoutAttrString = attributedString.mutableCopy;
    
    //handle properties for layout attributed string.
    // 如果存在对齐方式 设置对齐方式
    if (self.alignment) {
        _layoutAttrString.alignment = self.alignment;
    }
    // 
    if (self.lineBreakMode) {
        if (self.lineBreakMode == NSLineBreakByTruncatingTail || self.lineBreakMode == NSLineBreakByTruncatingHead || self.lineBreakMode == NSLineBreakByTruncatingMiddle) {
            _layoutAttrString.lineBreakMode = NSLineBreakByWordWrapping;
        }else{
            _layoutAttrString.lineBreakMode = self.lineBreakMode;
        }
    }
    if (self.font || self.textColor) {
        [_layoutAttrString enumerateAttributesInRange:NSMakeRange(0, _layoutAttrString.length) options:0 usingBlock:^(NSDictionary<NSAttributedStringKey,id> * _Nonnull attrs, NSRange range, BOOL * _Nonnull stop) {
              if (!attrs[NSFontAttributeName] && self.font) {
                  [_layoutAttrString setFont:self.font range:range];
              }
              if (!attrs[NSForegroundColorAttributeName] && self.textColor) {
                  [_layoutAttrString setColor:self.textColor range:range];
              }
          }];
    }
    
    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

- (void)setFont:(UIFont *)font {
    if (!font) {
        font = [UIFont systemFontOfSize:17];
    }
    _font = font;
    if (_layoutAttrString.length > 0) {
        _layoutAttrString.font = font;
    }
    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

- (void)setTextColor:(UIColor *)textColor {

    if (!textColor) {
        textColor = [UIColor blackColor];
    }
    _textColor = textColor;
    if (_layoutAttrString.length > 0) {
        _layoutAttrString.color = textColor;
    }
    
    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

- (void)setAlignment:(NSTextAlignment)alignment {
    
    _alignment = alignment;
    if (_layoutAttrString.length > 0) {
        _layoutAttrString.alignment = alignment;
    }

    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    
    _lineBreakMode = lineBreakMode;
    _layoutInject.lineBreakMode = lineBreakMode;
    if (_layoutAttrString.length > 0) {
        if (lineBreakMode == NSLineBreakByTruncatingTail || lineBreakMode == NSLineBreakByTruncatingHead || lineBreakMode == NSLineBreakByTruncatingMiddle) {
            _layoutAttrString.lineBreakMode = NSLineBreakByWordWrapping;
        }else{
            _layoutAttrString.lineBreakMode = lineBreakMode;
        }
    }
    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

- (void)setNumberOfLines:(NSInteger)numberOfLines {

    _numberOfLines = numberOfLines;
    _layoutInject.numberOfLines = numberOfLines;
    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

- (void)setTruncationAttrStr:(NSAttributedString *)truncationAttrStr {

    _truncationAttrStr = truncationAttrStr;
    _layoutInject.truncationAttrStr = truncationAttrStr;
    if (self.ignorGeneralProperties) return;
    [self configGeneralPropertiesRedraw];
}

#pragma mark -- Select Properties
- (void)setCanSelectOperation:(BOOL)canSelectOperation {
    _canSelectOperation = canSelectOperation;
    if (canSelectOperation) {
        _longPressGesture.enabled = YES;
    }else{
        _longPressGesture.enabled = NO;
    }
}

- (void)setCursorColor:(UIColor *)cursorColor {
    _cursorColor = cursorColor;
    _textSelectView.cursorColor = cursorColor;
}

- (void)setSelectBackgroundColor:(UIColor *)selectBackgroundColor {
    _selectBackgroundColor = selectBackgroundColor;
    _textSelectView.selectBackgroundColor = selectBackgroundColor;
}

- (void)setMenuDelegate:(id<YPSelectMenuProtocol>)menuDelegate {
    BOOL isValid = NO;
    if (menuDelegate && [menuDelegate conformsToProtocol:@protocol(YPSelectMenuProtocol)]) {
        if ([menuDelegate respondsToSelector:@selector(customMenuItems)] &&
            [menuDelegate respondsToSelector:@selector(canPerfomSelector:)]) {
            isValid = YES;
        }
    }
    if (isValid) {
        _menuDelegate = menuDelegate;
    }else{
        _menuDelegate = _defaultMenuObject;
    }
}

#pragma mark -- Private

- (void)configGeneralPropertiesRedraw {
    if (self.clearContentWhenRedraw){
        [self clearLayerContents];
    }
    [self setNeedsViewLayout];
}

- (CGSize)seniorLabelContentSizeWithConstraintWidth:(CGFloat)constraintWidth {
    return [YPSeniorLayout getDisplayContentSizeWithAttrStr:_layoutAttrString
                                             constraintSize:CGSizeMake(constraintWidth, MAXFLOAT)
                                              numberOfLines:self.numberOfLines
                                                     inject:_layoutInject.copy
                                                   viewSize:[UIScreen mainScreen].bounds.size];
}

- (CGSize)seniorLabelContentSizeWithConstraintSize:(CGSize)constraintSize {
    return [YPSeniorLayout getDisplayContentSizeWithAttrStr:_layoutAttrString
                                             constraintSize:constraintSize
                                              numberOfLines:self.numberOfLines
                                                     inject:_layoutInject.copy
                                                   viewSize:[UIScreen mainScreen].bounds.size];
}

- (void)configAutoDetectWithDetectType:(YPAutoDetectCheckType)detectType
                              emojiDic:(NSDictionary *)emojiDic
                             emojiSize:(CGSize)emojiSize
                           emojiBundle:(NSBundle *)emojiBundle
                             linkColor:(UIColor *)linkColor
                        underlineStyle:(NSUnderlineStyle)underlineStyle
                        underlineColor:(UIColor *)underlineColor
{
    [self configAutoDetectWithDetectType:detectType
                                emojiDic:emojiDic
                               emojiSize:emojiSize
                             emojiBundle:emojiBundle
                        tapBackViewColor:nil
                          highLightColor:nil
                               linkColor:linkColor
                          underlineStyle:underlineStyle
                          underlineColor:underlineColor];
}

- (void)configAutoDetectWithDetectType:(YPAutoDetectCheckType)detectType
                              emojiDic:(NSDictionary *)emojiDic
                             emojiSize:(CGSize)emojiSize
                           emojiBundle:(NSBundle *)emojiBundle
                      tapBackViewColor:(UIColor *)tapBackViewColor
                        highLightColor:(UIColor *)highLightColor
                             linkColor:(UIColor *)linkColor
                        underlineStyle:(NSUnderlineStyle)underlineStyle
                        underlineColor:(UIColor *)underlineColor
{
    YPAutoDetectConfig *config = [[YPAutoDetectConfig alloc] initWithDetectType:detectType];
    config.emojiDic = emojiDic;
    config.emojiSize = emojiSize;
    config.emojiBundle = emojiBundle;
    config.tapBackViewColor = tapBackViewColor;
    config.highLightColor = highLightColor;
    config.linkColor = linkColor;
    config.underlineStyle = underlineStyle;
    config.underlineColor = underlineColor;
    [self configAutoDetectWithConfig:config];
}

- (void)configAutoDetectWithConfig:(YPAutoDetectConfig *)config
{
    _layoutAttrString = [YPSeniorLayout createAutoDetectAttrWithOriginalAttr:_layoutAttrString
                                                                detectConfig:config];
    [self configGeneralPropertiesRedraw];
}

- (void)setNeedsViewLayout {
    [self.layer setNeedsDisplay];
}

- (void)clearLayerContents {
    if (self.layer.contents) {
        CGImageRef image = (__bridge_retained CGImageRef)(self.layer.contents);
        self.layer.contents = nil;
        if (image) {
            dispatch_async(SeniorLabelGetReleaseQueue(), ^{
                CFRelease(image);
            });
        }
    }
}

- (void)handleDetectResultWithResult:(NSTextCheckingResult *)result {
    switch (result.resultType) {
        case NSTextCheckingTypeLink:
            [[UIApplication sharedApplication] openURL:result.URL];
            break;
            
        case NSTextCheckingTypePhoneNumber:
        {
             NSTimeInterval currentTimeInterval = [[NSDate date] timeIntervalSince1970] * 1000;
             if (currentTimeInterval - _callPhoneInterval < 1000) {
                 //In order to solve the problem of continuous calls causing a status bar exception.
                return;
             }
             _callPhoneInterval = currentTimeInterval;
             [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",result.phoneNumber]]];
        }
            break;
        default:
            break;
    }
}

- (void)highlightLink:(YPLinkAttribute *)link linkRange:(NSRange)linkRange {
    if (!_layoutAttrString) return;
    NSMutableAttributedString *linkAttrStr = _layoutAttrString.mutableCopy;
    if (link.highlightColor) [linkAttrStr setColor:link.highlightColor range:linkRange];
    if (link.highlightBackViewColor){
        YPBorderAttribute *border = [[YPBorderAttribute alloc] init];
        border.cornerRadius = 3;
        border.fillColor = link.highlightBackViewColor;
        [linkAttrStr setBorder:border range:linkRange];
    };
    // 赋值属性给 touchEnd 用
    _linkAttrString = linkAttrStr;
    _linkAttribute = link;
    _linkRange = linkRange;
    [self setNeedsViewLayout];
}

- (void)multipleEventEnded {
    
    if ([self isSelectOperating] && (_touchShouldNotCancelSelect) && !_selectTrunkRange) {
        [self finishSelectOperation];
    }
    [[YPMagnifierWindow shareWindow] hiddenMagnifierView:_magnifierView];
    _touchEnd = NO;
    _touchBegan = NO;
    _touchGrabBegan = NO;
    _touchGrabEnd = NO;
    _touchShouldNotCancelSelect = NO;
    _selectTrunkRange = NO;
    // 清空link信息
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(kHighlithtFadeDuration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (self->_linkAttrString) {
            self->_linkAttrString = nil;
            self->_linkAttribute = nil;
            self->_linkRange = NSMakeRange(0, 0);
            [self setNeedsViewLayout];
        }
    });
}

- (BOOL)isValidDelegate {
    if (self.delegate && [self.delegate conformsToProtocol:@protocol(YPSeniorLabelProtocol)]) {
        return YES;
    }
    return NO;
}

#pragma mark -- Select Methods

- (void)stopSelectOperationWithTriggerDelegate {
    if ([self isValidDelegate] && [self.delegate respondsToSelector:@selector(seniorLabelShouldEndSelecting:)]) {
        if (![self.delegate seniorLabelShouldEndSelecting:self]) {
            return;
        }
    }
    
    [self stopSelectOperation];
    
    if ([self isValidDelegate] && [self.delegate respondsToSelector:@selector(seniorLabelDidEndSelecting:)]) {
        [self.delegate seniorLabelDidEndSelecting:self];
    }
}

- (void)stopSelectOperation {
    _selectRange = nil;
    _panGesture.enabled = NO;
    _textSelectView.hidden = YES;
    [[YPMagnifierWindow shareWindow] hiddenMagnifierView:_magnifierView];
    _touchEnd = NO;
    _touchBegan = NO;
    _touchGrabBegan = NO;
    _touchGrabEnd = NO;
    _touchShouldNotCancelSelect = NO;
}

- (void)updateSelectOperation {
    NSArray *rects = [_textLayout selectRectsWithTextRange:_selectRange];
    [_textSelectView updateSelectWithRects:rects];
}

// 是否存在 操作菜单
- (BOOL)isSelectOperating {
    if (!_textSelectView.hidden) {
        return YES;
    }else{
        return NO;
    }
}

- (BOOL)showMenuForCurrentSelect {
    if ([YPMenuController sharedMenuController].menuVisible) {
        return NO;
    }
    [YPMenuController sharedMenuController].menuItems = [self.menuDelegate customMenuItems];
    //Transform into CoreText's coordinate system.
    CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
    //show on top margin
    CGPoint topPoint = [_textLayout topPointForShowMenuController];
    topPoint = CGPointApplyAffineTransform(topPoint, transform);
    [YPMenuController sharedMenuController].styleConfig.arrowDirection = YPMenuControllerArrowDown;
    [[YPMenuController sharedMenuController] menuVisibleInView:self targetRect:CGRectMake(topPoint.x, topPoint.y, 0, 0) animated:YES];
    if (![YPMenuController sharedMenuController].menuVisible) {
        //show on bottom margin with arrow up.
        CGRect bottomRect = [_textLayout bottomRectForShowMenuController];
        bottomRect = CGRectApplyAffineTransform(bottomRect, transform);
        [YPMenuController sharedMenuController].styleConfig.arrowDirection = YPMenuControllerArrowUp;
        [[YPMenuController sharedMenuController] menuVisibleInView:self targetRect:bottomRect animated:YES];
        if (![YPMenuController sharedMenuController].menuVisible) {
            //show on bottom margin with arrow down.
            [YPMenuController sharedMenuController].styleConfig.arrowDirection = YPMenuControllerArrowDown;
            [[YPMenuController sharedMenuController] menuVisibleInView:self targetRect:bottomRect animated:YES];
            if (![YPMenuController sharedMenuController].menuVisible) {
                //show on middle window.
                [YPMenuController sharedMenuController].styleConfig.arrowDirection = YPMenuControllerArrowDown;
                [[YPMenuController sharedMenuController] menuVisibleInView:self targetX:topPoint.x menuWindowY:CGRectGetHeight(UIScreen.mainScreen.bounds)/2.0 animated:YES];
            }
        }
    }
    if (![YPMenuController sharedMenuController].menuVisible) {
        return NO;
    }
    return YES;
}

- (void)finishSelectOperation {
    NSRange range = NSMakeRange(_selectRange.start.location, _selectRange.end.location - _selectRange.start.location);
    //menu select
    NSAttributedString *menuSelectAttr = [[NSAttributedString alloc] initWithString:@""];
    NSRange menuSeletRange = NSMakeRange(NSNotFound, 0);
    if (NSMaxRange(range) <= _layoutAttrString.length) {
        menuSelectAttr = [_layoutAttrString attributedSubstringFromRange:range];
        menuSeletRange = range;
    }
  
    BOOL shouldShwoMenu = YES;
    if ([self.menuDelegate respondsToSelector:@selector(shouldShowMenuWithSeniorLabel:selectContent:range:)]) {
        shouldShwoMenu = [self.menuDelegate shouldShowMenuWithSeniorLabel:self selectContent:menuSelectAttr range:menuSeletRange];
    }
    //history boss chat select
    NSString *transformSelect = [_textLayout selectStringWithLayoutAttr:_layoutAttrString range:range];
    if ([self.menuDelegate respondsToSelector:@selector(currentSelectContent:)]) {
        [self.menuDelegate currentSelectContent:transformSelect];
    }
    [self showMenuForCurrentSelect];

    if (!shouldShwoMenu) {
        [YPMenuController sharedMenuController].calloutBar.hidden = YES;
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    if (![self isSelectOperating]) return NO;

    if ([self.menuDelegate canPerfomSelector:action]) {
        return YES;
    }
    return NO;
}

- (id)forwardingTargetForSelector:(SEL)aSelector {
    if ([self.menuDelegate respondsToSelector:aSelector]) {
        return self.menuDelegate;
    }
    NSLog(@"YPSeniorLabel unrecognized selector(%@) sent to menuObject(%@) object",NSStringFromSelector(aSelector),NSStringFromClass(self.menuDelegate.class));
    return nil;
}

- (void)didHideMenuController {
    if (_touchBegan || _touchEnd) {
        return;
    }
    if (!_touchShouldNotCancelSelect) {
        [self stopSelectOperationWithTriggerDelegate];
    }
}

- (void)showMagnifier {
    CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);

    CGPoint currentPoint = CGPointZero;
    if (_touchBegan) {
        currentPoint = [_textLayout startGrabberPoint];

    }else if (_touchEnd){
        currentPoint = [_textLayout endGrabberPoint];
        
    }else{
        return;
    }
    
    //Point on label view.
    CGPoint transformPoint = CGPointApplyAffineTransform(currentPoint, transform);
    _magnifierView.touchMagnifierPoint = transformPoint;
    
    //Point on the magnifier window.
    CGPoint windowPoint = [self convertPoint:transformPoint toView:[[UIApplication sharedApplication] keyWindow]];
    _magnifierView.center = CGPointMake(windowPoint.x - kMagnifierSize.width/2., windowPoint.y - kMagnifierSize.height);
    
    [[YPMagnifierWindow shareWindow] showMagnifierView:_magnifierView];
}

#pragma mark -- Gestures
- (void)longPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan) {
        if (!_updateFinish) return;
        CGPoint tapPoint = [gesture locationInView:self];
        // Transform into CoreText's coordinate system.
        CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
        CGPoint transformPoint = CGPointApplyAffineTransform(tapPoint, transform);
        if (CGRectContainsPoint(_textLayout.truncationPosition, transformPoint)) {
            return;
        }
        
        // if (_textLayout.isTruncated) return;
        if ([YPMenuController sharedMenuController].menuVisible) return;
        NSArray *menuItems = [self.menuDelegate customMenuItems];
        if (!menuItems || menuItems.count < 1) {
            return;
        }
        if ([self isSelectOperating]) {
            [self stopSelectOperationWithTriggerDelegate];
        }

        
        if (self.useWordSelect) {
            // Transform into CoreText's coordinate system.
            CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
            CGPoint transformPoint = CGPointApplyAffineTransform(tapPoint, transform);
            _selectRange = [_textLayout selectWordTextRangeForPoint:transformPoint];
            
        }else{
            _selectRange = [_textLayout selectAlltextRange];
        }
        //show select
        [self showSelectStyle];
    }
}

- (NSRange)selectedTextRange {
    if (![self isSelectOperating] || !_selectRange) return NSMakeRange(0, 0);
    return NSMakeRange(_selectRange.start.location, _selectRange.end.location - _selectRange.start.location);
}

- (void)setSelectedTextRange:(NSRange)selectedTextRange {
    if (selectedTextRange.location >= _layoutAttrString.length ||
        NSMaxRange(selectedTextRange) > _layoutAttrString.length) {
        return;
    }
    if (!_updateFinish) return;
    if (_textLayout.isTruncated) return;
    if ([YPMenuController sharedMenuController].menuVisible) return;
    NSArray *menuItems = [self.menuDelegate customMenuItems];
    if (!menuItems || menuItems.count < 1) {
        return;
    }
    if ([self isValidDelegate] && [self.delegate respondsToSelector:@selector(seniorLabelShouldBeginSelecting:)]) {
        BOOL begain = [self.delegate seniorLabelShouldBeginSelecting:self];
        if (!begain) return;
    }
    _selectRange = [_textLayout selectWordTextRangeForRange:selectedTextRange];
    //show select
    /**
     Set `_touchShouldNotCancelSelect` to YES to avoid the fact that when you have a selected style and then click on the link to set the selection range outside, the selected style of the bar doesn't appear.
     */
    _touchShouldNotCancelSelect = YES;
    [self showSelectStyle];
    //reset
    _touchShouldNotCancelSelect = NO;
}

- (void)showSelectStyle {
    if (!_selectRange) return;
    _textSelectView.frame = CGRectMake(0, 0, _textLayout.viewSize.width, _textLayout.viewSize.height);
    _textSelectView.hidden = NO;
    [self bringSubviewToFront:_textSelectView];
    _panGesture.enabled = YES;
    [self updateSelectOperation];
    [self finishSelectOperation];
    if ([self isValidDelegate] && [self.delegate respondsToSelector:@selector(seniorLabelDidBeginSelecting:)]) {
        [self.delegate seniorLabelDidBeginSelecting:self];
    }
}

- (void)panAction:(UIPanGestureRecognizer *)gesture {
    if (![self isSelectOperating]) return;
    
    if (gesture.state == UIGestureRecognizerStateBegan){
        _touchShouldNotCancelSelect = YES;
        
    } else if (gesture.state == UIGestureRecognizerStateChanged) {
        CGPoint tapPoint = [gesture locationInView:self];
        
        if (_touchBegan || _touchEnd) {
            CGPoint validPoinst = tapPoint;
            CGFloat fixOffset = CGRectGetHeight(_textSelectView.startGrabber.dot.frame) + 4;
            if (_touchGrabBegan) {
                validPoinst = CGPointMake(tapPoint.x, tapPoint.y + fixOffset);
                
            }else if (_touchGrabEnd) {
                validPoinst = CGPointMake(tapPoint.x, tapPoint.y - fixOffset);
            }
            // Transform into CoreText's coordinate system.
            CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
            CGPoint transformPoint = CGPointApplyAffineTransform(validPoinst, transform);
        
            // 适配trunk 模式下的 选中
            if (CGRectContainsPoint(_textLayout.truncationPosition, transformPoint)) {
                _selectTrunkRange = YES;
            } else {
                _selectTrunkRange = NO;
            }
            
            YPTextPosition *currentPosition = [_textLayout closestPositionForPoint:transformPoint];

            if (currentPosition && currentPosition.location != _selectRange.start.location && currentPosition.location != _selectRange.end.location) {
                //select length limit
                if (self.useWordSelect && [self.menuDelegate respondsToSelector:@selector(selectMaxLengthWithSeniorLabel:)]) {
                    NSInteger selectLength = [self.menuDelegate selectMaxLengthWithSeniorLabel:self];
                    if (selectLength > 0) {
                        NSInteger sr = 0;
                        if (_touchBegan) {
                            sr = currentPosition.location - _selectRange.end.location;
                            
                        }else if (_touchEnd) {
                            sr = _selectRange.start.location - currentPosition.location;
                        }
                        if (labs(sr) > selectLength) {
                            return;
                        }
                    }
                }
                //handle select
                if (_touchBegan && [_selectRange updateRangeStartPosition:currentPosition]) {
                    _touchEnd = YES;
                    _touchBegan = NO;
                    
                }else if (_touchEnd && [_selectRange updateRangeEndPosition:currentPosition]){
                    _touchEnd = NO;
                    _touchBegan = YES;
                    
                }
                [self updateSelectOperation];
                if (self.canShowMagnifier) {
                    [self showMagnifier];
                }
            }
        }
    }
    else if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled){
        [self multipleEventEnded];
    }
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer == _longPressGesture) {
        
        if ([self isValidDelegate] && [self.delegate respondsToSelector:@selector(seniorLabelShouldBeginSelecting:)]) {
            return [self.delegate seniorLabelShouldBeginSelecting:self];
        }
    }
    
    CGPoint tapPoint = [gestureRecognizer locationInView:self];
    // Transform into CoreText's coordinate system.
    // 变化坐标用
    CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
    
    //truncate 类型的点击回调
    if (self.truncationAction && self.truncationAttrStr && !CGRectIsEmpty(_textLayout.truncationPosition)) {
        CGRect rect = CGRectApplyAffineTransform(_textLayout.truncationPosition, transform);
        if(CGRectContainsPoint(rect, tapPoint)){
            return NO;
        }
    }
    return YES;
}

/**
 when touch the screen will call pointInside -> shouldReceiveTouch,
 and point in pointInside method is same as touch'location in shouldReceiveTouch method.
 */
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([self isSelectOperating]) {
        
        CGPoint tapPoint = [touch locationInView:self];
        CGFloat pointOffsetX = 6;
        CGFloat verticalOffset = 3;
        CGFloat widthOffset = 12;
        //start rect
        CGRect startGrabberFrame = _textSelectView.startGrabber.frame;
        CGRect startRect = CGRectMake(CGRectGetMinX(startGrabberFrame) - pointOffsetX,
                                      CGRectGetMinY(startGrabberFrame) - verticalOffset,
                                      CGRectGetWidth(startGrabberFrame) + widthOffset,
                                      CGRectGetHeight(_textSelectView.startGrabber.dot.frame) + verticalOffset);
        //end rect
        CGRect endGrabberFrame = _textSelectView.endGrabber.frame;
        CGFloat endDotHeight = CGRectGetHeight(_textSelectView.endGrabber.dot.frame);
        CGRect endRect = CGRectMake(CGRectGetMinX(endGrabberFrame) - pointOffsetX,
                                    CGRectGetMaxY(endGrabberFrame) - endDotHeight,
                                    CGRectGetWidth(endGrabberFrame) + widthOffset,
                                    endDotHeight + verticalOffset);

       if (CGRectContainsPoint(startRect, tapPoint)) {
           _touchGrabBegan = YES;
           _touchBegan = YES;

       }else if (CGRectContainsPoint(endRect, tapPoint)){
           _touchGrabEnd = YES;
           _touchEnd = YES;
           
       }else{
           _touchGrabEnd = NO;
           _touchGrabBegan = NO;
           // Transform into CoreText's coordinate system.
           CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
           CGPoint transformPoint = CGPointApplyAffineTransform(tapPoint, transform);
           YPTextPosition *currentPosition = [_textLayout closestPositionForPoint:transformPoint];
           if (currentPosition) {
               if (currentPosition.location == _selectRange.start.location || currentPosition.location == _selectRange.start.location + 1 || currentPosition.location == _selectRange.start.location -1) {
                   _touchBegan = YES;
                   
               }else if (currentPosition.location == _selectRange.end.location || currentPosition.location == _selectRange.end.location + 1 || currentPosition.location == _selectRange.end.location -1){
                   _touchEnd = YES;
               }
           }
       }
        //use word select and is selecting we should cancel select when click screen or scroll.
        if (self.useWordSelect && !_touchBegan && !_touchEnd) {
           BOOL containt = NO;
           CGRect startSafeRect = CGRectMake(_textSelectView.startGrabber.frame.origin.x - 10,
                                             _textSelectView.startGrabber.frame.origin.y - 10,
                                             _textSelectView.startGrabber.frame.size.width + 20,
                                             _textSelectView.startGrabber.frame.size.height + 10);
            
           CGRect endSafeRect = CGRectMake(_textSelectView.endGrabber.frame.origin.x - 10,
                                           _textSelectView.endGrabber.frame.origin.y,
                                           _textSelectView.endGrabber.frame.size.width + 20,
                                           _textSelectView.endGrabber.frame.size.height + 10);
           if (CGRectContainsPoint(startSafeRect, tapPoint)) {
               containt = YES;

           }else if (CGRectContainsPoint(endSafeRect, tapPoint)) {
               containt = YES;

           }
           else{
               for (UIView * perMask in _textSelectView.maskViews) {
                   if (CGRectContainsPoint(perMask.frame, tapPoint)) {
                       containt = YES;
                       break;;
                   }
               }
           }
           if (!containt) {
               //execute cancel select operation
               [self stopSelectOperationWithTriggerDelegate];
           }
        }
    }
    return YES;
}

#pragma mark -- Touch Delegate

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    if ([self isSelectOperating]) {
        CGFloat edge = 10;
        CGRect edgeRect = CGRectMake(-edge, -edge, self.frame.size.width + edge*2 + edge/2, self.frame.size.height + edge*2 + edge/2);
        if (CGRectContainsPoint(edgeRect, point)) {
            return YES;
        }
    }
    return [super pointInside:point withEvent:event];
}


// 处理点击
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (![self isSelectOperating]) {
        //not select state
        UITouch *touch = touches.anyObject;
        CGPoint tapPoint = [touch locationInView:self];
        // Transform into CoreText's coordinate system.
        // 变化坐标用
        CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
        
        //truncate 类型的点击回调
        if (self.truncationAction && self.truncationAttrStr && !CGRectIsEmpty(_textLayout.truncationPosition)) {
            CGRect rect = CGRectApplyAffineTransform(_textLayout.truncationPosition, transform);
            if(CGRectContainsPoint(rect, tapPoint)){
                self.truncationAction();
                return;
            }
        }
        
        //link 类型的 状态变化
        if (_textLayout.linkInfoMap && _textLayout.linkInfoMap.count > 0) {
            for (YPLinkAttribute *link in _textLayout.linkInfoMap.keyEnumerator) {
                YPAttributeLayoutInfo *info = [_textLayout.linkInfoMap objectForKey:link];
                for (NSValue *rectValue in info.rectValues) {
                    CGRect rect = CGRectApplyAffineTransform(rectValue.CGRectValue, transform);
                    if(CGRectContainsPoint(rect, tapPoint)){
                        [self highlightLink:link linkRange:info.linkTextRange];
                        return;
                    }
                }
            }
        }
        
        //attach 类型的点击回调
        if (_textLayout.attachmentMap && _textLayout.attachmentMap.count > 0) {
            for (YPAttachmentAttribute *attachment in _textLayout.attachmentMap.keyEnumerator) {
                if (!attachment.clickAction) continue;
                YPAttributeLayoutInfo *info = [_textLayout.attachmentMap objectForKey:attachment];
                CGRect rect = CGRectApplyAffineTransform(info.layoutPosition, transform);
                if(CGRectContainsPoint(rect, tapPoint)){
                    attachment.clickAction(_layoutAttrString, NSMakeRange(0, 0));
                    return;
                }
            }
        }
        [super touchesBegan:touches withEvent:event];
        
    }else{
        //select state
        _touchShouldNotCancelSelect = YES;
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    if (![self isSelectOperating]) {
        [super touchesMoved:touches withEvent:event];
    }else{
        _touchShouldNotCancelSelect = YES;
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    if (![self isSelectOperating]) {
        // link 类型的点击回调
        if (_linkAttribute) {
            if (_linkAttribute.clickAction) {
                _linkAttribute.clickAction(self.attributedString, _linkRange);
                
            }else if(_linkAttribute.checkResult){
                if (self.linkTypeAction) {
                    self.linkTypeAction(_linkAttribute.checkResult, self.attributedString, _linkRange);
                }else{
                    [self handleDetectResultWithResult:_linkAttribute.checkResult];
                }
            }else{
                if (self.linkTypeAction) {
                    self.linkTypeAction(nil, self.attributedString, _linkRange);
                }
            }
        }
        [super touchesEnded:touches withEvent:event];
    }
    // 清空一些属性
    [self multipleEventEnded];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    if (![self isSelectOperating]) {
        [super touchesCancelled:touches withEvent:event];
    }
    [self multipleEventEnded];
}

#pragma mark -- YPSeniorLayerDelegate
// 开始画
- (YPSeniorLayerTask *)createLayerNewLayoutTask {
    YPSeniorLayerTask *layerTask = [[YPSeniorLayerTask alloc] init];
    //temp variables
    NSMutableAttributedString *layoutAttrString = _layoutAttrString;
    NSMutableAttributedString *highLightAttrString = _linkAttrString;
    BOOL enableAsyncDraw = self.seniorDrawsAsynchronously;
    YPSeniorLayoutInject *inject = _layoutInject.copy;
    NSArray *preSelectArrs = _textLayout.selectRectArray;
    __block YPSeniorLayout *layout = _textLayout;
    CGFloat fadeDuration = self.fadeDuration;

    //will layout, call back in main thread.
    layerTask.WillLayout = ^(CALayer * layer){
        // 清除动画
        [layer removeAnimationForKey:@"contents"];
        __strong YPSeniorLabel *label = (YPSeniorLabel *)layer.delegate;
        if (!label) return;
        label->_updateFinish = NO;
        
        if (layout.attachmentViewMap && layout.attachmentViewMap.count > 0) {
           for (YPAttachmentAttribute *attachment in layout.attachmentViewMap.keyEnumerator) {
               UIView *v = attachment.content;
               if (v.superview) {
                   [v removeFromSuperview];
               }
           }
        }
       if (layout.attachmentLayerMap && layout.attachmentLayerMap.count > 0) {
           for (YPAttachmentAttribute *attachment in layout.attachmentLayerMap.keyEnumerator) {
               CALayer *l = attachment.content;
               if (l.superlayer) {
                   [l removeFromSuperlayer];
               }
           }
       }
    };
    //layout, call back in sub thread when enable async.
    layerTask.Layout = ^(CGContextRef  _Nullable context, CGSize layerSize, BOOL (^hasCancelled)(void)){
        if (hasCancelled()) return;
        // _linkAttrString 优先级高 是_layoutAttrString 增加了其他属性的富文本
        NSAttributedString *drawAttrString = highLightAttrString ? highLightAttrString : layoutAttrString;
        if (drawAttrString) {
            if (hasCancelled && hasCancelled()) return;
            // 组装绘制 所需对象 信息
            layout = [YPSeniorLayout layoutWithInject:inject attrStr:drawAttrString viewSize:layerSize];
            if (layout) {
                // 主绘制方法
                [layout drawWithContextRef:context isCancel:hasCancelled];
            }
        }
    };
    //end layout, call back in main thread.
    layerTask.DidLayout = ^(CALayer * _Nonnull layer, BOOL finished){
        [layer removeAnimationForKey:@"contents"];
        if(!finished) return;
                
        __strong YPSeniorLabel *label = (YPSeniorLabel *)layer.delegate;
        if (!label) return;
        CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(label.frame)), 1.f, -1.f);
        if ([label isSelectOperating] && preSelectArrs) {
            layout.selectRectArray = preSelectArrs;
        }
        label->_textLayout = layout;
        label->_updateFinish = YES;
        if (layout.attachmentViewMap && layout.attachmentViewMap.count > 0) {
            for (YPAttachmentAttribute *attachment in layout.attachmentViewMap.keyEnumerator) {
                YPAttributeLayoutInfo *info = [layout.attachmentViewMap objectForKey:attachment];
                CGRect rect = CGRectApplyAffineTransform(info.layoutPosition, transform);
                UIView *v = attachment.content;
                v.frame = rect;
                [label addSubview:v];
            }
        }
        if (layout.attachmentLayerMap && layout.attachmentLayerMap.count > 0) {
            for (YPAttachmentAttribute *attachment in layout.attachmentLayerMap.keyEnumerator) {
                YPAttributeLayoutInfo *info = [layout.attachmentLayerMap objectForKey:attachment];
                CGRect rect = CGRectApplyAffineTransform(info.layoutPosition, transform);
                CALayer *l = attachment.content;
                l.frame = rect;
                [layer addSublayer:l];
            }
        }
        if (highLightAttrString) {
            CATransition *transition = [CATransition animation];
            transition.duration = kHighlithtFadeDuration;
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
            transition.type = kCATransitionFade;
            [layer addAnimation:transition forKey:@"contents"];
            
        }else if (enableAsyncDraw && fadeDuration > 0){
            CATransition *transition = [CATransition animation];
            transition.duration = fadeDuration;
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
            transition.type = kCATransitionFade;
            [layer addAnimation:transition forKey:@"contents"];
        }
    };
    return layerTask;
}

@end
