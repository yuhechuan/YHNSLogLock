//
//  YPSeniorLine.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2017/12/14.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import "YPSeniorLine.h"

@interface YPSeniorLine ()

@property (nonatomic, assign, readwrite) CTLineRef lineRef;
@property (nonatomic, assign, readwrite) CTLineRef originLineRef;

@property (nonatomic, assign, readwrite) CGPoint lineOriginPoint;
@property (nonatomic, assign, readwrite) NSRange stringRange;
@property (nonatomic, assign, readwrite) CGFloat lineWidth;
@property (nonatomic, assign, readwrite) CGRect frame;
@property (nonatomic, assign, readwrite) CGFloat height;
@property (nonatomic, assign, readwrite) CGFloat top;
@property (nonatomic, assign, readwrite) CGFloat bottom;
@property (nonatomic, assign, readwrite) CGFloat left;
@property (nonatomic, assign, readwrite) CGFloat right;
@property (nonatomic, assign, readwrite) CGFloat ascent;
@property (nonatomic, assign, readwrite) CGFloat descent;
@property (nonatomic, assign, readwrite) CGFloat leading;
/// 自定义行初始 loc
@property (nonatomic, assign, readwrite) NSUInteger customLineRefloc;

@end

@implementation YPSeniorLine

- (void)setLineRef:(CTLineRef)lineRef {
    if (_lineRef != lineRef) {
        //_lineRef
        if (_lineRef) {
            CFRelease(_lineRef);
        }
        if (lineRef) {
            CFRetain(lineRef);
            _lineRef = lineRef;
            //range
            CFRange range = CTLineGetStringRange(_lineRef);
            _stringRange = NSMakeRange(range.location, range.length);
            //line width
            _lineWidth = CTLineGetTypographicBounds(_lineRef, &_ascent, &_descent, &_leading);
            _frame = CGRectMake(_lineOriginPoint.x, _lineOriginPoint.y - _descent, _lineWidth, _ascent + _descent);
        }
    }
}

- (CGFloat)height {
    return CGRectGetHeight(_frame);
}

- (CGFloat)top {
    return CGRectGetMaxY(_frame);
}

- (CGFloat)bottom {
    return CGRectGetMinY(_frame);
}

- (CGFloat)left {
    return CGRectGetMinX(_frame);
}

- (CGFloat)right {
    return CGRectGetMaxX(_frame);
}


+ (YPSeniorLine *)seniorLineInstanceWithLineRef:(CTLineRef)lineRef lineOriginPoint:(CGPoint)lineOriginPoint {
    if (!lineRef) return nil;
    YPSeniorLine *line =[[YPSeniorLine alloc] init];
    line->_lineOriginPoint = lineOriginPoint;
    [line setLineRef:lineRef];
    return line;
}

+ (YPSeniorLine *)seniorLineInstanceWithLineRef:(CTLineRef)lineRef
                                  originLineRef:(CTLineRef)originLineRef
                                lineOriginPoint:(CGPoint)lineOriginPoint
                               customLineRefloc:(NSUInteger)customLineRefloc {
    YPSeniorLine *line =[[YPSeniorLine alloc] init];
    line->_originLineRef = originLineRef;
    line->_lineOriginPoint = lineOriginPoint;
    [line setLineRef:lineRef];
    line.customLineRefloc = customLineRefloc;

    return line;
}


- (void)dealloc {
    if (_lineRef) CFRelease(_lineRef);
}


@end
