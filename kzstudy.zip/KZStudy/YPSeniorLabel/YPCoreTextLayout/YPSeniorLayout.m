//
//  YPSeniorLayout.m
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/11.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import "YPSeniorLayout.h"
#import "YPSeniorAttribute.h"
#import <objc/runtime.h>
#import "YPAttributeLayoutInfo.h"
#import "YPSeniorLayoutInject.h"

#define MAX_METRIC_NUMBER 10000000.0f

static const void *YPRectValueBindLineIndexKey = &YPRectValueBindLineIndexKey;

inline NSRegularExpression* getEmojiRegex(void) {
    static NSRegularExpression *regex = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        regex = [NSRegularExpression regularExpressionWithPattern:@"\\[[^ \\[\\]]+?\\]" options:kNilOptions error:NULL];
    });
    return regex;
}

static NSPredicate* getDatePredicate(void) {
    static NSPredicate *predicate = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^\\d{4}-\\d{1,2}-\\d{1,2}"];
    });
    return predicate;

}

static NSDataDetector* getDetector(NSTextCheckingTypes checkType) {
    
    static NSDataDetector *detector = nil;
    if (detector && detector.checkingTypes == checkType) {
        return detector;
    }else{
        detector = [[NSDataDetector alloc] initWithTypes:checkType error:NULL];
        return detector;
    }
}

static BOOL HasSeparatorSuffix(NSString *string) {
    if ([string hasSuffix:@"\n"] ||
        [string hasSuffix:@"\u2028"] ||
        [string hasSuffix:@"\u2029"]) {
        return YES;
    }
    return NO;
}

@implementation YPSeniorLayout

#pragma mark -- Layout text
+ (YPSeniorLayout *)layoutWithInject:(YPSeniorLayoutInject *)inject
                             attrStr:(NSAttributedString *)attrStr
                            viewSize:(CGSize)viewSize
{
    if (CGSizeEqualToSize(viewSize, CGSizeZero) || attrStr.length < 1) {
        return nil;
    }
    YPSeniorLayout *layout = [[YPSeniorLayout alloc] init];
    layout->_inject = inject;
    layout->_viewSize = viewSize;
    layout->_attrStr = attrStr;
    //handle attributes and text elements.
    [layout handleDrawElementsForAttrStr:attrStr];
    return layout;
}

- (void)dealloc {
    if (_ctFrame != nil) {
        CFRelease(_ctFrame);
    }
    if (_frameSetter != nil) {
        CFRelease(_frameSetter);
    }
}

- (void)setCtFrame:(CTFrameRef)ctFrame {
    if (_ctFrame != ctFrame) {
        if (_ctFrame) {
            CFRelease(_ctFrame);
        }
        if (ctFrame) {
            CFRetain(ctFrame);
        }
        _ctFrame = ctFrame;
    }
}
- (void)setFrameSetter:(CTFramesetterRef)frameSetter {
    if (_frameSetter != frameSetter) {
        if (_frameSetter) {
            CFRelease(_frameSetter);
        }
        if (frameSetter) {
            CFRetain(frameSetter);
        }
        _frameSetter = frameSetter;
    }
 
}

- (void)handleDrawElementsForAttrStr:(NSAttributedString *)attrStr {
    // 根据带属性字符串创建一个不可变的框架设置对象
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)attrStr);
    if (!setterRef) return;
    self.frameSetter = setterRef;
    CFRelease(setterRef);
    
    //display frameRef:The ctFrame's lines is related to view size.
    CGMutablePathRef allPath = CGPathCreateMutable();
    CGPathAddRect(allPath, NULL, CGRectMake(0 , 0, _viewSize.width, _viewSize.height));
    // 创建核心文本框架对象
    CTFrameRef frameRef = CTFramesetterCreateFrame(_frameSetter, CFRangeMake(0, 0), allPath, NULL);
    self.ctFrame = frameRef;
    CFRelease(allPath);
    CFRelease(frameRef);
    if (!frameRef) return;

    NSMutableArray *lineArr = [[NSMutableArray alloc] init];
    
    // 以 YPAttributeLayoutInfo为key  YPLinkAttribute,YPAttachmentAttribute,YPBorderAttribute, YPQuoteAttribute为value
    YPAttributeLayoutInfoMap *linkInfoMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    YPAttributeLayoutInfoMap *attachmentMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    YPAttributeLayoutInfoMap *attachmentImageMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    YPAttributeLayoutInfoMap *attachmentViewMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    YPAttributeLayoutInfoMap *attachmentLayerMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    YPAttributeLayoutInfoMap *borderInfoMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    YPAttributeLayoutInfoMap *quoteInfoMap = [YPAttributeLayoutInfoMap weakToStrongObjectsMapTable];
    
    CFArrayRef lineCFArray = CTFrameGetLines(_ctFrame);
    NSInteger lineCount = CFArrayGetCount(lineCFArray);
    NSInteger drawLineCount = lineCount;
    // 获取显示行数
    if (self.inject.numberOfLines > 0) {
        drawLineCount = MIN(self.inject.numberOfLines, drawLineCount);
    }
    CGPoint *perLineOrigins = NULL;
    if (drawLineCount > 0) {
        //mormal attrs vars
        // 申请一个 CGPoint的数组 用于装每行的起始坐标
        perLineOrigins = malloc(drawLineCount * sizeof(CGPoint));
        CTFrameGetLineOrigins(_ctFrame, CFRangeMake(0, drawLineCount), perLineOrigins);
        //block border vars
        CGFloat bx = 0;
        CGFloat br = 0;
        CGFloat bh = 0;
        YPSeniorLine *bFirstLine = nil;
        YPSeniorLine *bLastLine = nil;
        YPBorderAttribute *bBorderAttr = nil;
        //quote vars
        YPSeniorLine *qFirstLine = nil;
        YPSeniorLine *qLastLine = nil;
        YPQuoteAttribute *quoteAttr = nil;
        for (CFIndex lineIndex = 0; lineIndex < drawLineCount; lineIndex++) {
            //create senior line
            // 获取当前行的 行对象
            CTLineRef curLineRef = CFArrayGetValueAtIndex(lineCFArray, lineIndex);
            // 获取当前行起始坐标
            CGPoint curOriginPoint = perLineOrigins[lineIndex];
            // 组装自定义 行对象
            YPSeniorLine *currentLine = [self createSeniorLineWithAttrStr:attrStr
                                                                  lineRef:curLineRef
                                                          lineOriginPoint:curOriginPoint
                                                                lineIndex:lineIndex
                                                            drawLineCount:drawLineCount];
            [lineArr addObject:currentLine];

            //get runs from line
            // 获取CTRuns 字对象数组
            CFArrayRef runCFArray = CTLineGetGlyphRuns(currentLine.lineRef);
            CFIndex runsCount = CFArrayGetCount(runCFArray);
            if (!runCFArray || runsCount < 1) {
                continue;
            }
            //get first run attributes
            // 拿到第一个
            CTRunRef runRef = CFArrayGetValueAtIndex(runCFArray, 0);
            NSDictionary *attributesDic = (NSDictionary *)CTRunGetAttributes(runRef);
            //search block border, block border only use with paragraph style.
            YPBorderAttribute *bAttr = attributesDic[YPBorderAttributeName];
            BOOL userBlock = bAttr.borderStyle == YPBorderBlockAround ||
                             bAttr.borderStyle == YPBorderBlockTiled;
            // 如果首个字对象中存在边框信息
            if (bAttr && userBlock) {
                // 记录边框起始行
                if (!bBorderAttr) {
                    //config current attr
                    bBorderAttr = bAttr;
                    bFirstLine = currentLine;
                    bx = curOriginPoint.x;
                    br = currentLine.right;
                    
                } else {
                    if (bx > curOriginPoint.x) {
                        bx = curOriginPoint.x;
                    }
                    if (br < currentLine.right) {
                        br = currentLine.right;
                    }
                }
                bLastLine = currentLine;
                
            }else{
                // 多个不同属性边框时候  比如12行 中间隔一行  56行
                [self assembleBorderForMap:borderInfoMap bFirstLine:bFirstLine bLastLine:bLastLine bBorderAttr:bBorderAttr bx:bx bh:bh br:br];
                bBorderAttr = nil;
            }
            //search quote
            YPQuoteAttribute *qAttr = attributesDic[YPQuoteAttributeName];
            if (qAttr) {
                if (!quoteAttr) {
                    quoteAttr = qAttr;
                    qFirstLine = currentLine;
                }
                qLastLine = currentLine;
            }else{
                
                [self assembleQuoteForMap:quoteInfoMap qFirstLine:qFirstLine qLastLine:qLastLine quoteAttr:quoteAttr];
                quoteAttr = nil;
            }
            for (CFIndex runIndex = 0; runIndex < runsCount; runIndex++) {
                //handle multiple YPAttribure
                CTRunRef runRef = CFArrayGetValueAtIndex(runCFArray, runIndex);
                NSDictionary *attributesDic = (NSDictionary *)CTRunGetAttributes(runRef);
                
                YPAttachmentAttribute *attachment = attributesDic[YPAttachmentAttributeName];
                YPLinkAttribute *runlink = attributesDic[YPLinkAttributeName];
                YPBorderAttribute *runBorder = attributesDic[YPBorderAttributeName];
                // 算出 字块的frame
                CGRect runBounds = CGRectZero;
                if (attachment || runlink || runBorder){
                    CGPoint runPosition = CGPointZero;
                    CTRunGetPositions(runRef, CFRangeMake(0, 1), &runPosition);
                    CGFloat ascent, descent, leading, runWidth;
                    runWidth = CTRunGetTypographicBounds(runRef, CFRangeMake(0, 0), &ascent, &descent, &leading);
                    runPosition.x += curOriginPoint.x;
                    runPosition.y = curOriginPoint.y - descent;
                    runBounds = CGRectMake(runPosition.x, runPosition.y, runWidth, ascent + descent);
                }
                
                //handle attachment
                // 如果存在 附件类型的插入
                if (attachment) {
                    YPAttributeLayoutInfoMap *map = nil;
                    if ([attachment.content isKindOfClass:UIImage.class]) {
                        map = attachmentImageMap;
                    }else if ([attachment.content isKindOfClass:UIView.class]) {
                        map = attachmentViewMap;
                    }else if ([attachment.content isKindOfClass:CALayer.class]) {
                        map = attachmentLayerMap;
                    }
                    if (map) {
                        YPAttributeLayoutInfo *info = [map objectForKey:attachment];
                        if (!info) {
                            info = [[YPAttributeLayoutInfo alloc] init];
                            [map setObject:info forKey:attachment];
                            [attachmentMap setObject:info forKey:attachment];
                        }
                        info.layoutPosition = runBounds;
                    }
                }
                //handle link
                if (runlink) {
                    CFRange runRange = CTRunGetStringRange(runRef);
                    NSRange range = NSMakeRange(runRange.location + currentLine.customLineRefloc, runRange.length);
                    YPAttributeLayoutInfo *info = [linkInfoMap objectForKey:runlink];
                    if (!info) {
                        info = [[YPAttributeLayoutInfo alloc] init];
                        info.rectValues = [[YPValuesArray alloc] init];
                        info.linkTextRange = range;
                        [linkInfoMap setObject:info forKey:runlink];
                    }else{
                        info.linkTextRange = NSUnionRange(info.linkTextRange, range);
                    }
                    [info.rectValues addObject:[NSValue valueWithCGRect:runBounds]];
                }
                //handle normal border
                // 如果存在边框 并且边框类型是 normal
                if (runBorder && runBorder.borderStyle == YPBorderNormal) {
                    YPAttributeLayoutInfo *info = [borderInfoMap objectForKey:runBorder];
                    if (!info) {
                        info = [[YPAttributeLayoutInfo alloc] init];
                        info.rectValues = [[YPValuesArray alloc] init];
                        [borderInfoMap setObject:info forKey:runBorder];
                    }
                    CGRect borderRect = UIEdgeInsetsInsetRect(runBounds, runBorder.insets);
                    
                    // 如果当前行 两段的range的border是同一个对象那么合并这两个 frame 画一个 大的边框
                    // ⚠️ 这样会存在一个问题 设置的2段range 会失效被合并,如果想分开 用两个 YPBorderAttribute 对象进行设置
                    NSValue *lastValue = [info.rectValues lastObject];
                    if (lastValue) {
                        NSNumber *lastIndex = objc_getAssociatedObject(lastValue, YPRectValueBindLineIndexKey);
                        // 如果两个
                        if (lastIndex.integerValue == lineIndex) {
                            borderRect = CGRectUnion(lastValue.CGRectValue, borderRect);
                            [info.rectValues removeObject:lastValue];
                        }
                    }
                    NSValue *curRect = [NSValue valueWithCGRect:borderRect];
                    objc_setAssociatedObject(curRect, YPRectValueBindLineIndexKey, @(lineIndex), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                    [info.rectValues addObject:curRect];
                    
                }
            }
        }
        //when border and quote styles end, the style position is not calculated.
        // 当最后一行也带着边框信息的时候  用于处理真实的边框frame
        [self assembleBorderForMap:borderInfoMap bFirstLine:bFirstLine bLastLine:bLastLine bBorderAttr:bBorderAttr bx:bx bh:bh br:br];
        // 当最后一行也带着边框信息的时候  用于处理真实的边框frame
        [self assembleQuoteForMap:quoteInfoMap qFirstLine:qFirstLine qLastLine:qLastLine quoteAttr:quoteAttr];
    }
    
    _lineArray = lineArr;
    _attachmentMap = attachmentMap;
    _attachmentImageMap = attachmentImageMap;
    _attachmentViewMap = attachmentViewMap;
    _attachmentLayerMap = attachmentLayerMap;
    _linkInfoMap = linkInfoMap;
    _borderInfoMap = borderInfoMap;
    _quoteInfoMap = quoteInfoMap;
    //Release
    if (perLineOrigins) free(perLineOrigins);
}

// 算出真实的 边框frame
- (void)assembleBorderForMap:(YPAttributeLayoutInfoMap *)infoMap
                  bFirstLine:(YPSeniorLine *)bFirstLine
                   bLastLine:(YPSeniorLine *)bLastLine
                 bBorderAttr:(YPBorderAttribute *)bBorderAttr
                          bx:(CGFloat)bx
                          bh:(CGFloat)bh
                          br:(CGFloat)br
{
    if (!bBorderAttr) return;
    YPAttributeLayoutInfo *info = [infoMap objectForKey:bBorderAttr];
    if (!info) {
        info = [[YPAttributeLayoutInfo alloc] init];
        //Block pattern uses rectValues to deal with YPBorderAttributeName object reuse.
        info.rectValues = [[YPValuesArray alloc] init];
        [infoMap setObject:info forKey:bBorderAttr];
    }
    bh = bFirstLine.lineOriginPoint.y - bLastLine.lineOriginPoint.y + bFirstLine.ascent + bLastLine.descent;
    CGFloat oringBlockY = bLastLine.lineOriginPoint.y - bLastLine.descent;
    CGRect rect = CGRectMake(bx, oringBlockY, br - bx, bh);
    CGRect borderRect = UIEdgeInsetsInsetRect(rect, bBorderAttr.insets);
    [info.rectValues addObject:[NSValue valueWithCGRect:borderRect]];
}
// 算出真实的 背景frame
- (void)assembleQuoteForMap:(YPAttributeLayoutInfoMap *)infoMap
                 qFirstLine:(YPSeniorLine *)qFirstLine
                  qLastLine:(YPSeniorLine *)qLastLine
                  quoteAttr:(YPQuoteAttribute *)quoteAttr
{
    if (!quoteAttr) return;
    YPAttributeLayoutInfo *info = [infoMap objectForKey:quoteAttr];
    if (!info) {
        info = [[YPAttributeLayoutInfo alloc] init];
        //Quote pattern uses rectValues to deal with YPQuoteAttribute object reuse.
        info.rectValues = [[YPValuesArray alloc] init];
        [infoMap setObject:info forKey:quoteAttr];
    }
    CGFloat qh = qFirstLine.lineOriginPoint.y - qLastLine.lineOriginPoint.y + qFirstLine.ascent + qLastLine.descent;
    CGFloat qy = qLastLine.lineOriginPoint.y - qLastLine.descent;
    CGFloat left = quoteAttr.quoteLeft >= 0 ? quoteAttr.quoteLeft : 0;
    CGFloat width = quoteAttr.quoteWidth > 0 ? quoteAttr.quoteWidth : 4;
    CGRect rect = CGRectMake(left, qy, width, qh);
    [info.rectValues addObject:[NSValue valueWithCGRect:rect]];
}

- (YPSeniorLine *)createSeniorLineWithAttrStr:(NSAttributedString *)attrStr
                                      lineRef:(CTLineRef)lineRef
                              lineOriginPoint:(CGPoint)lineOriginPoint
                                    lineIndex:(NSInteger)lineIndex
                                drawLineCount:(NSInteger)drawLineCount {
    
    YPSeniorLine *seniorLine = [YPSeniorLine seniorLineInstanceWithLineRef:lineRef lineOriginPoint:lineOriginPoint];
    _isTruncated = NO;
    NSRange lastLineRange = seniorLine.stringRange;
    //whether lineRef is lastLine and NSLineBreakByTruncating and last line can't display all content
    // 如果是最后一行
    // NSLineBreakByTruncatingTail 结尾部分的内容以……方式省略，显示头的文字内容。
    // NSLineBreakByTruncatingHead 前面部分文字以……方式省略，显示尾部文字内容。
    // NSLineBreakByTruncatingMiddle 中间的内容以……方式省略，显示头尾的文字内容。

    
    // 当最后一行 切显示模式是 省略 且文字不是全展开状态
    if ((lineIndex == drawLineCount - 1)
        && (self.inject.lineBreakMode == NSLineBreakByTruncatingTail || self.inject.lineBreakMode == NSLineBreakByTruncatingHead || self.inject.lineBreakMode == NSLineBreakByTruncatingMiddle)
        && (lastLineRange.location + lastLineRange.length < attrStr.length))
    {
        _isTruncated = YES;
        //creat truncation attribute string Line and get truncation attribute string
        CTLineRef truncationStingLineRef = NULL;
        NSAttributedString *truncationAttrStr;
        // 如果自定义 truncationAtttrStr 存在自定义尾部字符串 则用自定义
        if (self.inject.truncationAttrStr) {
            truncationAttrStr = self.inject.truncationAttrStr;
            truncationStingLineRef = CTLineCreateWithAttributedString((CFAttributedStringRef)self.inject.truncationAttrStr);
        }else{
            // 创建默认...
            NSUInteger truncationAttrIndex = lastLineRange.location + lastLineRange.length - 1;
            NSMutableDictionary *truncAttrDic = [[NSMutableDictionary alloc] init];
            
            NSDictionary *lastAttrDic = [attrStr attributesAtIndex:truncationAttrIndex effectiveRange:NULL];
            UIFont *truncFont = lastAttrDic[NSFontAttributeName];
            if (truncFont && truncFont.pointSize >= 12) {
                truncAttrDic[NSFontAttributeName] = truncFont;
            }else{
                truncAttrDic[NSFontAttributeName] = [UIFont systemFontOfSize:12];
            }
            UIColor *truncColor = lastAttrDic[NSForegroundColorAttributeName];
            if (truncColor) {
                truncAttrDic[NSForegroundColorAttributeName] = truncColor;
            }else{
                truncAttrDic[NSForegroundColorAttributeName] = UIColor.blackColor;
            }
            truncationAttrStr = [[NSAttributedString alloc] initWithString:YPTruncationPlaceholder attributes:truncAttrDic];
            truncationStingLineRef = CTLineCreateWithAttributedString((CFAttributedStringRef)truncationAttrStr);
        }
        
        //creat truncation Line
        // 现在只支持end NSLineBreakByTruncatingTail
        CTLineTruncationType type = kCTLineTruncationEnd;
        //if (_lineBreakMode == NSLineBreakByTruncatingHead) {
        //type = kCTLineTruncationStart;
        //} else if (_lineBreakMode == NSLineBreakByTruncatingMiddle) {
        //type = kCTLineTruncationMiddle;
        //}
        CTLineRef truncationLineRef = NULL;
        CTLineRef justifiedLine = NULL;
        double lineWidth = 0.;
        if (HasSeparatorSuffix([attrStr attributedSubstringFromRange:lastLineRange].string)) {
            NSRange deleteFeedCharacterRange = NSMakeRange(lastLineRange.location, lastLineRange.length - 1);
            
            NSMutableAttributedString *justAttrStr = [attrStr attributedSubstringFromRange:deleteFeedCharacterRange].mutableCopy;
            [justAttrStr appendAttributedString:truncationAttrStr];
            justifiedLine = CTLineCreateWithAttributedString((CFAttributedStringRef)justAttrStr);
            
            double justifiedLineWidth = CTLineGetTypographicBounds(justifiedLine, NULL, NULL, NULL);
            //The lineRef will be truncated if its width is greater than the param width,so - 0.5.
            double fixWidth = justifiedLineWidth - 0.5;
            lineWidth = fixWidth > _viewSize.width ? _viewSize.width : fixWidth;
            
        }else{
            NSMutableAttributedString *justAttrStr = [attrStr attributedSubstringFromRange:lastLineRange].mutableCopy;
            [justAttrStr appendAttributedString:truncationAttrStr];
            justifiedLine = CTLineCreateWithAttributedString((CFAttributedStringRef)justAttrStr);
            
            lineWidth = seniorLine.lineWidth;
        }
        // 从现有行创建截断行。
        truncationLineRef = CTLineCreateTruncatedLine(justifiedLine, lineWidth, type, truncationStingLineRef);
        
        if (justifiedLine) CFRelease(justifiedLine);
        //The line specified in truncationToken should have a width less than the width specified by the width parameter.
        //If the width of the line specified in truncationToken is greater, this function will return NULL if truncation is needed.
        //For a special case : the last line's string is "".
        if (!truncationLineRef) truncationLineRef = CFRetain(truncationStingLineRef);
        
        //calculate trunc postion
        // 计算tunc位置 用于点击
        double truncStrWidth = CTLineGetTypographicBounds(truncationStingLineRef, NULL, NULL, NULL);
        CGFloat truncDescent = 0;
        CGFloat truncAescent = 0;
        double truncLineWidth = CTLineGetTypographicBounds(truncationLineRef, &truncAescent, &truncDescent, NULL);
        double truncX = seniorLine.left + truncLineWidth - truncStrWidth;
        // 用于trun类型的点击
        _truncationPosition = CGRectMake(truncX, seniorLine.lineOriginPoint.y-truncDescent, truncStrWidth, truncAescent + truncDescent);
        CFRange range = CTLineGetStringRange(lineRef);
        seniorLine = [YPSeniorLine seniorLineInstanceWithLineRef:truncationLineRef
                                                   originLineRef:lineRef
                                                 lineOriginPoint:lineOriginPoint
                                                customLineRefloc:range.location];

        //release
        CFRelease(truncationLineRef);
        CFRelease(truncationStingLineRef);
    }
    return seniorLine;
}

+ (YPSeniorLine *)createSeniorLineWithAttrStr:(NSAttributedString *)attrStr
                                     lineRef:(CTLineRef)lineRef
                             lineOriginPoint:(CGPoint)lineOriginPoint
                                   lineIndex:(NSInteger)lineIndex
                               drawLineCount:(NSInteger)drawLineCount
                                      inject:(YPSeniorLayoutInject *)inject
                                    viewSize:(CGSize)viewSize {
    YPSeniorLine *seniorLine = [YPSeniorLine seniorLineInstanceWithLineRef:lineRef lineOriginPoint:lineOriginPoint];
    NSRange lastLineRange = seniorLine.stringRange;
    //whether lineRef is lastLine and NSLineBreakByTruncating and last line can't display all content
    // 如果是最后一行
    // NSLineBreakByTruncatingTail 结尾部分的内容以……方式省略，显示头的文字内容。
    // NSLineBreakByTruncatingHead 前面部分文字以……方式省略，显示尾部文字内容。
    // NSLineBreakByTruncatingMiddle 中间的内容以……方式省略，显示头尾的文字内容。

    
    // 当最后一行 切显示模式是 省略 且文字不是全展开状态
    if ((lineIndex == drawLineCount - 1)
        && (inject.lineBreakMode == NSLineBreakByTruncatingTail || inject.lineBreakMode == NSLineBreakByTruncatingHead || inject.lineBreakMode == NSLineBreakByTruncatingMiddle)
        && (lastLineRange.location + lastLineRange.length < attrStr.length))
    {
        //creat truncation attribute string Line and get truncation attribute string
        CTLineRef truncationStingLineRef = NULL;
        NSAttributedString *truncationAttrStr;
        // 如果自定义 truncationAtttrStr 存在自定义尾部字符串 则用自定义
        if (inject.truncationAttrStr) {
            truncationAttrStr = inject.truncationAttrStr;
            truncationStingLineRef = CTLineCreateWithAttributedString((CFAttributedStringRef)inject.truncationAttrStr);
        }else{
            // 创建默认...
            NSUInteger truncationAttrIndex = lastLineRange.location + lastLineRange.length - 1;
            NSMutableDictionary *truncAttrDic = [[NSMutableDictionary alloc] init];
            
            NSDictionary *lastAttrDic = [attrStr attributesAtIndex:truncationAttrIndex effectiveRange:NULL];
            UIFont *truncFont = lastAttrDic[NSFontAttributeName];
            if (truncFont && truncFont.pointSize >= 12) {
                truncAttrDic[NSFontAttributeName] = truncFont;
            }else{
                truncAttrDic[NSFontAttributeName] = [UIFont systemFontOfSize:12];
            }
            UIColor *truncColor = lastAttrDic[NSForegroundColorAttributeName];
            if (truncColor) {
                truncAttrDic[NSForegroundColorAttributeName] = truncColor;
            }else{
                truncAttrDic[NSForegroundColorAttributeName] = UIColor.blackColor;
            }
            truncationAttrStr = [[NSAttributedString alloc] initWithString:YPTruncationPlaceholder attributes:truncAttrDic];
            truncationStingLineRef = CTLineCreateWithAttributedString((CFAttributedStringRef)truncationAttrStr);
        }
        
        //creat truncation Line
        // 现在只支持end NSLineBreakByTruncatingTail
        CTLineTruncationType type = kCTLineTruncationEnd;
        //if (_lineBreakMode == NSLineBreakByTruncatingHead) {
        //type = kCTLineTruncationStart;
        //} else if (_lineBreakMode == NSLineBreakByTruncatingMiddle) {
        //type = kCTLineTruncationMiddle;
        //}
        CTLineRef truncationLineRef = NULL;
        CTLineRef justifiedLine = NULL;
        double lineWidth = 0.;
        if (HasSeparatorSuffix([attrStr attributedSubstringFromRange:lastLineRange].string)) {
            NSRange deleteFeedCharacterRange = NSMakeRange(lastLineRange.location, lastLineRange.length - 1);
            
            NSMutableAttributedString *justAttrStr = [attrStr attributedSubstringFromRange:deleteFeedCharacterRange].mutableCopy;
            [justAttrStr appendAttributedString:truncationAttrStr];
            justifiedLine = CTLineCreateWithAttributedString((CFAttributedStringRef)justAttrStr);
            
            double justifiedLineWidth = CTLineGetTypographicBounds(justifiedLine, NULL, NULL, NULL);
            //The lineRef will be truncated if its width is greater than the param width,so - 0.5.
            double fixWidth = justifiedLineWidth - 0.5;
            lineWidth = fixWidth > viewSize.width ? viewSize.width : fixWidth;
            
        }else{
            NSMutableAttributedString *justAttrStr = [attrStr attributedSubstringFromRange:lastLineRange].mutableCopy;
            [justAttrStr appendAttributedString:truncationAttrStr];
            justifiedLine = CTLineCreateWithAttributedString((CFAttributedStringRef)justAttrStr);
            
            lineWidth = seniorLine.lineWidth;
        }
        // 从现有行创建截断行。
        truncationLineRef = CTLineCreateTruncatedLine(justifiedLine, lineWidth, type, truncationStingLineRef);
        
        if (justifiedLine) CFRelease(justifiedLine);
        //The line specified in truncationToken should have a width less than the width specified by the width parameter.
        //If the width of the line specified in truncationToken is greater, this function will return NULL if truncation is needed.
        //For a special case : the last line's string is "".
        if (!truncationLineRef) truncationLineRef = CFRetain(truncationStingLineRef);
        
        seniorLine = [YPSeniorLine seniorLineInstanceWithLineRef:truncationLineRef lineOriginPoint:lineOriginPoint];

        //release
        CFRelease(truncationLineRef);
        CFRelease(truncationStingLineRef);
    }
    return seniorLine;
    
}

#pragma mark -- Draw

- (void)drawWithContextRef:(CGContextRef)contextRef
                  isCancel:(BOOL (^)(void))isCancel
{
    if (!contextRef) {
        return;
    }
    //transform modified coordinate system to coreText coordinate system
    CGContextSetTextMatrix(contextRef, CGAffineTransformIdentity);
    // 在上下文中更改用户坐标系的原点。
    CGContextTranslateCTM(contextRef, 0, self.viewSize.height);
    // 在上下文中改变用户坐标系的比例。
    CGContextScaleCTM(contextRef, 1.0, -1.0);

    //draw border
    if (isCancel && isCancel()) return;
    [self drawBorderWithContextRef:contextRef viewSize:self.viewSize isCancel:isCancel];
    
    //draw text
    if (isCancel && isCancel()) return;
    [self drawTextWithContextRef:contextRef isCancel:isCancel];
    
    //draw image
    if (isCancel && isCancel()) return;
    [self drawImageWithContextRef:contextRef isCancel:isCancel];
    
    //draw quote
    if (isCancel && isCancel()) return;
    [self drawQuoteWithContextRef:contextRef isCancel:isCancel];
}

- (void)drawBorderWithContextRef:(CGContextRef)contextRef
                        viewSize:(CGSize)viewSize
                        isCancel:(BOOL (^)(void))isCancel
{
    if (self.borderInfoMap && self.borderInfoMap.count > 0) {
        CGContextSaveGState(contextRef);
        for (YPBorderAttribute *border in self.borderInfoMap.keyEnumerator) {
            if (isCancel && isCancel()) break;
            YPAttributeLayoutInfo *info = [self.borderInfoMap objectForKey:border];
            BOOL userTiledBlock = border.borderStyle == YPBorderBlockTiled;
            for (NSValue *rectVaue in info.rectValues) {
                if (isCancel && isCancel()) break;
                CGRect pathRect = rectVaue.CGRectValue;
                if (userTiledBlock) {
                    CGFloat ox = CGRectGetMinX(pathRect);
                    CGFloat adjustX = ox > 0 ? ox : 1;
                    CGFloat adjustWidth = viewSize.width - adjustX * 2;
                    pathRect = CGRectMake(adjustX, pathRect.origin.y, adjustWidth, pathRect.size.height);
                }
                //border
                UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:pathRect cornerRadius:border.cornerRadius];
                [path closePath];
                if (border.fillColor) {
                    CGContextSaveGState(contextRef);
                    CGContextAddPath(contextRef, path.CGPath);
                    CGContextSetFillColorWithColor(contextRef, border.fillColor.CGColor);
                    CGContextFillPath(contextRef);
                    CGContextRestoreGState(contextRef);
                }
                if(border.borderColor && border.borderWidth > 0){
                    CGContextSaveGState(contextRef);
                    CGContextAddPath(contextRef, path.CGPath);
                    CGContextSetLineWidth(contextRef, border.borderWidth);
                    CGContextSetStrokeColorWithColor(contextRef, border.borderColor.CGColor);
                    CGContextStrokePath(contextRef);
                    CGContextRestoreGState(contextRef);
                }
                //boder underline
                if (border.underlineColor && border.underlineWidth > 0) {
                    CGFloat oringinY = CGRectGetMinY(pathRect);
                    if (border.underlineStyle == YPBorderUnderLineCenterNormal || border.underlineStyle == YPBorderUnderLineCenterDash) {
                        oringinY += CGRectGetHeight(pathRect)/2.0;
                    }
                    CGPoint startPoint = CGPointMake(pathRect.origin.x, oringinY);
                    CGPoint endPoint = CGPointMake(CGRectGetMaxX(pathRect), oringinY);
                    UIBezierPath *underlinePath = [UIBezierPath bezierPath];
                    [underlinePath moveToPoint:startPoint];
                    [underlinePath addLineToPoint:endPoint];
                    CGContextSaveGState(contextRef);
                    CGContextAddPath(contextRef, underlinePath.CGPath);
                    CGContextSetLineWidth(contextRef,  border.underlineWidth);
                    CGContextSetStrokeColorWithColor(contextRef, border.underlineColor.CGColor);
                    if (border.underlineStyle == YPBorderUnderLineDash || border.underlineStyle == YPBorderUnderLineCenterDash) {
                        CGFloat painted = border.dashPaintedLength > 0 ? border.dashPaintedLength : 4;
                        CGFloat notPainted = border.dashNotPaintedLength > 0 ? border.dashNotPaintedLength : 4;
                        CGFloat dash[] = {painted, notPainted};
                        CGContextSetLineDash(contextRef, 0, dash, 2);
                    }
                    CGContextStrokePath(contextRef);
                    CGContextRestoreGState(contextRef);
                }
            }
        }
        CGContextRestoreGState(contextRef);
    }
}

- (void)drawTextWithContextRef:(CGContextRef)contextRef
                      isCancel:(BOOL (^)(void))isCancel
{
    /*
     可以直接用 CTFrameDraw 画整体 但是不支持每行 isCancel
     CGContextSaveGState(contextRef);
     if (isCancel && isCancel()) return;
     CTFrameDraw(self.ctFrame, contextRef);
     CGContextRestoreGState(contextRef);
     */
    
    /*
     可以直接用 CTLineDraw 一行一行画 支持每行 isCancel
     CGContextSaveGState(contextRef);
     CGContextSetTextPosition(contextRef, line.lineOriginPoint.x, line.lineOriginPoint.y);
     CTLineDraw(line.lineRef, contextRef);
     CGContextRestoreGState(contextRef);
     */
    
    CGContextSaveGState(contextRef);
    for (YPSeniorLine *line in _lineArray) {
        if (isCancel && isCancel()) break;
        CFArrayRef runCFArray = CTLineGetGlyphRuns(line.lineRef);
        CFIndex runsCount = CFArrayGetCount(runCFArray);
        if (!runCFArray || runsCount < 1) {
            continue;
        }
        CGContextSetTextPosition(contextRef, line.lineOriginPoint.x, line.lineOriginPoint.y);
        for (CFIndex runIndex = 0; runIndex < runsCount; runIndex++) {
            CGContextSaveGState(contextRef);
            CTRunRef runRef = CFArrayGetValueAtIndex(runCFArray, runIndex);
            NSDictionary *attributesDic = (NSDictionary *)CTRunGetAttributes(runRef);

            NSShadow *shandow = attributesDic[NSShadowAttributeName];
            if (shandow) {
                UIColor *shadowColor = (UIColor *)shandow.shadowColor;
                if (!shadowColor || ![shadowColor isKindOfClass:UIColor.class]) {
                    shadowColor = [[UIColor blackColor] colorWithAlphaComponent:0.33];
                }
                CGContextSetShadowWithColor(contextRef, shandow.shadowOffset, shandow.shadowBlurRadius, shadowColor.CGColor);
            }
            CGAffineTransform textMatrix = CTRunGetTextMatrix(runRef);

            if (CGAffineTransformIsIdentity(textMatrix)) {
                CTRunDraw(runRef, contextRef, CFRangeMake(0, 0));

            } else {
                CGPoint pos = CGContextGetTextPosition(contextRef);

                // set tx and ty to current text pos according to DTCoreText
                textMatrix.tx = pos.x;
                textMatrix.ty = pos.y;

                CGContextSetTextMatrix(contextRef, textMatrix);
                CTRunDraw(runRef, contextRef, CFRangeMake(0, 0));
                // restore identity
                CGContextSetTextMatrix(contextRef, CGAffineTransformIdentity);
            }
           CGContextRestoreGState(contextRef);
        }
    }
    CGContextRestoreGState(contextRef);
}

// 画图
- (void)drawImageWithContextRef:(CGContextRef)contextRef
                       isCancel:(BOOL (^)(void))isCancel
{
    CGContextSaveGState(contextRef);
    for (YPAttachmentAttribute * attachment in self.attachmentImageMap.keyEnumerator) {
        if (isCancel && isCancel()) break;
        YPAttributeLayoutInfo *info = [self.attachmentImageMap objectForKey:attachment];
        UIImage *image = attachment.content;
        if (image) {
            CGContextDrawImage(contextRef, info.layoutPosition, image.CGImage);
        }
    }
    CGContextRestoreGState(contextRef);
}
// 画背景
- (void)drawQuoteWithContextRef:(CGContextRef)contextRef
                       isCancel:(BOOL (^)(void))isCancel
{
    if (self.quoteInfoMap && self.quoteInfoMap.count > 0) {
        CGContextSaveGState(contextRef);
        for (YPQuoteAttribute *quote in self.quoteInfoMap.keyEnumerator) {
            if (isCancel && isCancel()) break;
            YPAttributeLayoutInfo *info = [self.quoteInfoMap objectForKey:quote];
            for (NSValue *value in info.rectValues) {
                if (isCancel && isCancel()) break;
                UIBezierPath *path = [UIBezierPath bezierPathWithRect:value.CGRectValue];
                [path closePath];
                UIColor *fillColor = quote.quoteColor ? quote.quoteColor : UIColor.lightGrayColor;
                CGContextSaveGState(contextRef);
                CGContextAddPath(contextRef, path.CGPath);
                CGContextSetFillColorWithColor(contextRef, fillColor.CGColor);
                CGContextFillPath(contextRef);
                CGContextRestoreGState(contextRef);
            }
        }
        CGContextRestoreGState(contextRef);
    }
}

#pragma mark -- Auto detect atrributedString
+ (NSMutableAttributedString *)createAutoDetectAttrWithOriginalAttr:(NSAttributedString*)originalAttr
                                                       detectConfig:(YPAutoDetectConfig *)detectConfig
{
    //
    if (originalAttr.length < 1 || !detectConfig || detectConfig.detectType == YPAutoDetectCheckType_None) {
        return originalAttr.mutableCopy;
    }
    
    NSMutableAttributedString *assembleAttributeString = originalAttr.mutableCopy;
    //judge detecting
    NSTextCheckingType checkType = 0; //NSTextCheckingType
    BOOL needEmojiDetect = NO; //EmojiCheckingType
    
    if (detectConfig.detectType == YPAutoDetectCheckType_All){
        checkType = NSTextCheckingTypeLink | NSTextCheckingTypePhoneNumber;
        if (detectConfig.emojiDic) {
            needEmojiDetect = YES;
        }
    }else{
        if (detectConfig.detectType & YPAutoDetectCheckType_Link){
            checkType  |= NSTextCheckingTypeLink;
        }
        if (detectConfig.detectType & YPAutoDetectCheckType_Phone){
            checkType |= NSTextCheckingTypePhoneNumber;
        }
        if (detectConfig.detectType & YPAutoDetectCheckType_Emoji &&
            detectConfig.emojiDic && detectConfig.emojiDic.count > 0) {
            needEmojiDetect = YES;
        }
    }
    
    //detect emoji
    // emoji 表情检测替换
    if (needEmojiDetect) {
        NSRegularExpression *regex = getEmojiRegex();
        // 检测表情规则 数组
        NSArray <NSTextCheckingResult *> *matchArr = [regex matchesInString:assembleAttributeString.string options:kNilOptions range:NSMakeRange(0, assembleAttributeString.length)];
        NSUInteger cutEmojiCharLength = 0;
        for (NSTextCheckingResult *result in matchArr) {
            if (result.range.location == NSNotFound || result.range.length <= 1) {
                continue;
            }
            NSRange range = result.range;
            range.location -= cutEmojiCharLength;
            // 添加占位符
            NSAttributedString *subEmojiAttr = [assembleAttributeString attributedSubstringFromRange:range];
            NSString *emoString = subEmojiAttr.string;
            NSString *imageName = [detectConfig.emojiDic objectForKey:emoString];
            UIImage *emojiImage = [UIImage imageNamed:imageName]; // [YPImage imageNamed:imageName inBundle:detectConfig.emojiBundle];
            if (!emojiImage) continue;
            UIFont *alignFont = detectConfig.emojiAlignFont;
            if (!alignFont) {
                alignFont = [UIFont systemFontOfSize:14];
            }
            NSMutableAttributedString *emojiAttrStr = [NSMutableAttributedString configEmojiStringImage:emojiImage imageSize:detectConfig.emojiSize alignToFont:alignFont emojiString:emoString];
            NSDictionary *subAttributes = [subEmojiAttr attributesAtIndex:0 effectiveRange:NULL];
            if (subAttributes) {
                [emojiAttrStr addAttributes:subAttributes range:NSMakeRange(0, emojiAttrStr.length)];
            }
            [assembleAttributeString replaceCharactersInRange:range withAttributedString:emojiAttrStr];
            
            cutEmojiCharLength += range.length - 1;
        }
    }
    
    //detect phone and link
    // 自动检测 link 文字
    if (checkType != 0) {
        NSDataDetector *detector = getDetector(checkType);
        [detector enumerateMatchesInString:assembleAttributeString.string options:kNilOptions range:NSMakeRange(0, assembleAttributeString.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
            switch (result.resultType) {
                case NSTextCheckingTypeLink:
                case NSTextCheckingTypePhoneNumber:
                {
                    if (result.phoneNumber) {
                        //exclude `0000[emoji]000` and `date(ex:0000-00-00)` pattern
                        if ([result.phoneNumber containsString:YPAttachmentPlaceholder] ||
                            [getDatePredicate() evaluateWithObject:result.phoneNumber]) {
                            break;
                        }
                    }
                    if (detectConfig.linkColor) {
                        [assembleAttributeString setColor:detectConfig.linkColor range:result.range];
                    }
                    if (detectConfig.underlineStyle) {
                        [assembleAttributeString setUnderlineStyle:detectConfig.underlineStyle range:result.range];
                        [assembleAttributeString setUnderlineColor:detectConfig.underlineColor range:result.range];
                    }
                    
                    YPLinkAttribute *link = [[YPLinkAttribute alloc] init];
                    link.highlightColor = detectConfig.highLightColor;
                    link.highlightBackViewColor = detectConfig.tapBackViewColor;
                    link.checkResult = result;
                    [assembleAttributeString setLink:link range:result.range];
                }
                    break;
                default:
                    break;
            }
        }];
    }
    return assembleAttributeString;
}

#pragma mark -- Content size

+ (CGSize)getDisplayContentSizeWithAttrStr:(NSAttributedString *)attrStr
                            constraintSize:(CGSize)constraintSize
                             numberOfLines:(NSInteger)numberOfLines {
    return [self getDisplayContentSizeWithAttrStr:attrStr
                                   constraintSize:constraintSize
                                    numberOfLines:numberOfLines
                                           inject:nil
                                         viewSize:CGSizeZero];
}

/**
算高度代码
 */
+ (CGSize)getDisplayContentSizeWithAttrStr:(NSAttributedString *)attrStr
                            constraintSize:(CGSize)constraintSize
                             numberOfLines:(NSInteger)numberOfLines
                                    inject:(YPSeniorLayoutInject *)inject
                                  viewSize:(CGSize)viewSize {
    if (attrStr.length < 1) {
        return CGSizeZero;
    }
    if (constraintSize.width > MAX_METRIC_NUMBER) {
        constraintSize.width = MAX_METRIC_NUMBER;
    }
    if (constraintSize.width < CGFLOAT_MIN) {
        constraintSize.width = MAX_METRIC_NUMBER;
    }
    if (constraintSize.height > MAX_METRIC_NUMBER) {
        constraintSize.height = MAX_METRIC_NUMBER;
    }
    
    if (constraintSize.height < CGFLOAT_MIN) {
        constraintSize.height = MAX_METRIC_NUMBER;
    }

    //create ctframe
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)attrStr);
    CGMutablePathRef allPath = CGPathCreateMutable();
    CGPathAddRect(allPath, NULL, CGRectMake(0 , 0, constraintSize.width, constraintSize.height));
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), allPath, NULL);
    CFRelease(allPath);
    CFRelease(setterRef);
    if (!frameRef) return CGSizeZero;
    
    //get ctlines
    CFArrayRef lineCFArray = CTFrameGetLines(frameRef);
    NSInteger lineCount = CFArrayGetCount(lineCFArray);
    if (lineCount < 1){
        CFRelease(frameRef);
        return CGSizeZero;
    }
    
    //caculate size
    CGFloat maxWidth = 0;
    CGFloat lastWidth = 0;

    CGFloat height = 0;
    YPSeniorLine *lastLine = nil;
    NSInteger showCount = lineCount;
    if (numberOfLines > 0) {
        showCount = MIN(numberOfLines, showCount);
    }
    // 申请一个 CGPoint的数组
    CGPoint *perLineOrigins = malloc(showCount * sizeof(CGPoint));
    CTFrameGetLineOrigins(frameRef, CFRangeMake(0, showCount), perLineOrigins);
    
    // 获取最大宽度 和 最后一行
    for (CFIndex lineIndex = 0; lineIndex < showCount; lineIndex++) {
        CTLineRef lineRef = CFArrayGetValueAtIndex(lineCFArray, lineIndex);
        CGPoint currentOriginPoint = perLineOrigins[lineIndex];
        YPSeniorLine *currentLine = [YPSeniorLayout createSeniorLineWithAttrStr:attrStr
                                                                         lineRef:lineRef
                                                                 lineOriginPoint:currentOriginPoint
                                                                       lineIndex:lineIndex
                                                                   drawLineCount:showCount
                                                                          inject:inject
                                                                        viewSize:viewSize];
        //the tailIndent usually is negative.cgsi
        CGFloat tailIndent = 0;
        // 获取段尾缩进
        CTParagraphStyleRef paragraphStyle = (__bridge CTParagraphStyleRef)[attrStr attribute:(id)kCTParagraphStyleAttributeName atIndex:currentLine.stringRange.location effectiveRange:NULL];
        if (paragraphStyle) {
            CTParagraphStyleGetValueForSpecifier(paragraphStyle, kCTParagraphStyleSpecifierTailIndent, sizeof(tailIndent), &tailIndent);
        }
        CGFloat curLineWidth = currentLine.right - tailIndent;
        if (curLineWidth > maxWidth) {
            maxWidth = curLineWidth;
        }
        // 存下最后一行的CTLine对象
        if (lineIndex == showCount -1) {
            lastLine = currentLine;
            lastWidth = curLineWidth;
        }
    }
    
    if (@available(iOS 12.0, *)) {
        //All right
    }else{
        //We found that the width calculated by the system on iOS 11.4.1 will be 0.3 less.
        maxWidth += 0.3;
    }
    
    height = constraintSize.height - lastLine.frame.origin.y + lastLine.leading;
    
    //Release
    free(perLineOrigins);
    CFRelease(frameRef);
    /*
     Reference `https://www.cocoanetics.com/2010/02/understanding-uifont/` and
     `https://developer.apple.com/library/archive/documentation/TextFonts/Conceptual/CocoaTextArchitecture/FontHandling/FontHandling.html#//apple_ref/doc/uid/TP40009459-CH5-SW1`,
     we can know that `lineHeight = Ascent + Descent + 1 + leading`.
     */
    if (maxWidth > constraintSize.width) {
        maxWidth = constraintSize.width;
    }
    return CGSizeMake(ceil(maxWidth), ceil(height + 1.5));
}

+ (CGFloat)contentHeightWithAttribureStr:(NSAttributedString *)attribureStr
                         constraintWidth:(CGFloat)constraintWidth
                           numberOfLines:(NSInteger)numberOfLines {
    return [YPSeniorLayout contentSizeWithAttribureStr:attribureStr
                                        constraintSize:CGSizeMake(constraintWidth, MAXFLOAT)
                                         numberOfLines:numberOfLines].height;
}


+ (CGSize)contentSizeWithAttribureStr:(NSAttributedString *)attribureStr
                       constraintSize:(CGSize)constraintSize
                        numberOfLines:(NSInteger)numberOfLines {
    return [YPSeniorLayout getDisplayContentSizeWithAttrStr:attribureStr
                                             constraintSize:constraintSize
                                              numberOfLines:numberOfLines];
}


+ (CGFloat)contentHeightWithAttribureStr:(NSAttributedString *)attribureStr
                         constraintWidth:(CGFloat)constraintWidth
                           numberOfLines:(NSInteger)numberOfLines
                              detectType:(YPAutoDetectCheckType)detectType
                                emojiDic:(NSDictionary *)emojiDic
                             emojiBundle:(NSBundle *)emojiBundle
                               emojiSize:(CGSize)emojiSize {
    return [YPSeniorLayout contentSizeWithAttribureStr:attribureStr
                                        constraintSize:CGSizeMake(constraintWidth, MAXFLOAT)
                                         numberOfLines:numberOfLines
                                            detectType:detectType
                                              emojiDic:emojiDic
                                           emojiBundle:emojiBundle
                                             emojiSize:emojiSize].height;
}

+ (CGSize)contentSizeWithAttribureStr:(NSAttributedString *)attribureStr
                       constraintSize:(CGSize)constraintSize
                        numberOfLines:(NSInteger)numberOfLines
                           detectType:(YPAutoDetectCheckType)detectType
                             emojiDic:(NSDictionary *)emojiDic
                          emojiBundle:(NSBundle *)emojiBundle
                            emojiSize:(CGSize)emojiSize {

    NSMutableAttributedString *heightAttrStr = attribureStr.mutableCopy;
    // 如果存在 表情占位符 替换 再算
    if ((detectType == YPAutoDetectCheckType_All || detectType & YPAutoDetectCheckType_Emoji) && emojiDic.count > 1) {
        NSRegularExpression *regex = getEmojiRegex();
        NSArray <NSTextCheckingResult *> *matchArr = [regex matchesInString:heightAttrStr.string options:kNilOptions range:NSMakeRange(0, heightAttrStr.length)];
        NSUInteger cutEmojiCharLength = 0;
        for (NSTextCheckingResult *result in matchArr) {
            if (result.range.location == NSNotFound || result.range.length <= 1) {
                continue;
            }
            NSRange range = result.range;
            range.location -= cutEmojiCharLength;
            
            NSString *emoString = [heightAttrStr.string substringWithRange:range];
            NSString *imageName = [emojiDic objectForKey:emoString];
            UIImage *emojiImage = [UIImage imageNamed:imageName];  //[YPImage imageNamed:imageName inBundle:emojiBundle];
            if (!emojiImage) continue;
            
            NSMutableAttributedString *emojiAttrStr = [NSMutableAttributedString configEmojiStringImage:emojiImage imageSize:emojiSize alignToFont:[UIFont systemFontOfSize:14] emojiString:emoString];
            
            [heightAttrStr replaceCharactersInRange:range withAttributedString:emojiAttrStr];
            cutEmojiCharLength += range.length - 1;
        }
    }
    
    return [YPSeniorLayout getDisplayContentSizeWithAttrStr:heightAttrStr
                                             constraintSize:constraintSize
                                              numberOfLines:numberOfLines];
}

#pragma mark -- Utilities
// 获取显示行数
+ (NSInteger)getDisplayLineWithAttrStr:(NSAttributedString *)attrStr
                        constraintSize:(CGSize)constraintSize
{
    if (attrStr.length < 1) {
        return 0;
    }
    if (constraintSize.width > MAX_METRIC_NUMBER) {
        constraintSize.width = MAX_METRIC_NUMBER;
    }
    if (constraintSize.height > MAX_METRIC_NUMBER) {
        constraintSize.height = MAX_METRIC_NUMBER;
    }
    //create ctframe
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)attrStr);
    CGMutablePathRef allPath = CGPathCreateMutable();
    CGPathAddRect(allPath, NULL, CGRectMake(0 , 0, constraintSize.width, constraintSize.height));
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), allPath, NULL);
    CFRelease(allPath);
    CFRelease(setterRef);
    if (!frameRef) return 0;

    //get ctlines
    CFArrayRef lineCFArray = CTFrameGetLines(frameRef);
    NSInteger lineCount = CFArrayGetCount(lineCFArray);
    CFRelease(frameRef);
    return lineCount;
}

@end
