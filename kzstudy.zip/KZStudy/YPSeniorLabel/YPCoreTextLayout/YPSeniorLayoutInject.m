//
//  YPSeniorLayoutInject.m
//  YPSeniorLabel
//
//  Created by doit on 2019/12/19.
//  Copyright © 2019 Yaping Liu. All rights reserved.
//

#import "YPSeniorLayoutInject.h"

@implementation YPSeniorLayoutInject

- (id)copyWithZone:(NSZone *)zone {
    typeof(self) inject = [[self.class alloc] init];
    inject.truncationAttrStr = self.truncationAttrStr;
    inject.lineBreakMode = self.lineBreakMode;
    inject.numberOfLines = self.numberOfLines;
    return inject;
}

@end
