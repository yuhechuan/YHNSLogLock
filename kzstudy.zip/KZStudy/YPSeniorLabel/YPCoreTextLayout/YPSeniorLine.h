//
//  YPSeniorLine.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2017/12/14.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@interface YPSeniorLine : NSObject

@property (nonatomic, assign, readonly) CTLineRef lineRef;
@property (nonatomic, assign, readonly) CGPoint lineOriginPoint;
@property (nonatomic, assign, readonly) NSRange stringRange;
@property (nonatomic, assign, readonly) CGFloat lineWidth;
@property (nonatomic, assign, readonly) CGRect frame;
@property (nonatomic, assign, readonly) CGFloat height;
@property (nonatomic, assign, readonly) CGFloat top;
@property (nonatomic, assign, readonly) CGFloat bottom;
@property (nonatomic, assign, readonly) CGFloat left;
@property (nonatomic, assign, readonly) CGFloat right;
@property (nonatomic, assign, readonly) CGFloat ascent;
@property (nonatomic, assign, readonly) CGFloat descent;
@property (nonatomic, assign, readonly) CGFloat leading;
@property (nonatomic, assign, readonly) NSUInteger customLineRefloc; /// 自定义行初始 loc

+ (YPSeniorLine *)seniorLineInstanceWithLineRef:(CTLineRef)lineRef lineOriginPoint:(CGPoint)lineOriginPoint;
+ (YPSeniorLine *)seniorLineInstanceWithLineRef:(CTLineRef)lineRef
                                  originLineRef:(CTLineRef)originLineRef
                                lineOriginPoint:(CGPoint)lineOriginPoint
                               customLineRefloc:(NSUInteger)customLineRefloc;

@end
