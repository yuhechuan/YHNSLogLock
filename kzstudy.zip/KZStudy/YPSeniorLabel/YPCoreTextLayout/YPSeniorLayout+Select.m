//
//  YPSeniorLayout+Select.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/24.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPSeniorLayout+Select.h"
#import "YPTextInput.h"
#import <objc/runtime.h>
#import "YPAttributeLayoutInfo.h"
#import <CoreFoundation/CoreFoundation.h>

@implementation YPSeniorLayout (Select)

- (void)setSelectRectArray:(NSArray<YPTextSelectionRect *> *)selectRectArray {
    objc_setAssociatedObject(self, @selector(selectRectArray), selectRectArray, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (NSArray<YPTextSelectionRect *> *)selectRectArray {
    return objc_getAssociatedObject(self, @selector(selectRectArray));
}

- (YPTextPosition *)closestPositionForPoint:(CGPoint)point {
    
    NSUInteger lineIndex = [self closestLineIndexForPoint:point];
    if (lineIndex == NSNotFound) return nil;
    
    YPSeniorLine *selectLine = self.lineArray[lineIndex];
    CGPoint indexPoint = CGPointMake(point.x - selectLine.lineOriginPoint.x, 0);
    CFIndex index = CTLineGetStringIndexForPosition(selectLine.lineRef, indexPoint);
    if (index == kCFNotFound) return nil;
    YPTextPosition *textPosition = [[YPTextPosition alloc] init];
    textPosition.lineIndex = lineIndex;
    textPosition.location = index;
    
    return textPosition;
    
}

- (NSUInteger)closestLineIndexForPoint:(CGPoint)point {
    if (self.lineArray.count < 1) return NSNotFound;
    
    NSUInteger min = 0, max = self.lineArray.count - 1, mid = 0;
    NSUInteger lineIndex = NSNotFound;
 
    while (min <= max) {
        mid = (min + max)/2;
        YPSeniorLine *line = self.lineArray[mid];
        CGFloat lineBottom = line.bottom;
        CGFloat lineTop = line.top;
        if (point.y >= lineBottom && point.y <= lineTop) {
            lineIndex = mid;
            break;
        }
        //Note: the higher the array index, the lower the y value.
        if (point.y < lineBottom) {
            min = mid + 1;
        } else {
            if (mid == 0) break;
            max = mid - 1;
        }
    }
    
    return lineIndex;
}

- (NSArray <YPTextSelectionRect *>*)selectRectsWithTextRange:(YPTextRange *)textRange {
    
    if (!textRange.start || !textRange.end ||
        textRange.start.lineIndex == NSNotFound || textRange.end.lineIndex == NSNotFound ||
        textRange.start.lineIndex >= self.lineArray.count ||
        textRange.end.lineIndex >= self.lineArray.count) {
        return [[NSArray alloc] init];
    }
    
    NSMutableArray *selectRects = [[NSMutableArray alloc] init];
    //start line
    YPSeniorLine *startLine = self.lineArray[textRange.start.lineIndex];
    CGFloat startOffset = CTLineGetOffsetForStringIndex(startLine.lineRef, textRange.start.location, NULL);
    
    //end line
    YPSeniorLine *endLine = self.lineArray[textRange.end.lineIndex];
    CGFloat endOffset = CTLineGetOffsetForStringIndex(endLine.lineRef, textRange.end.location, NULL);

    //On the same line.
    if (textRange.start.lineIndex == textRange.end.lineIndex) {
        //start line rect
        YPTextSelectionRect *startRect = [[YPTextSelectionRect alloc] init];
        CGFloat offsetLeading = startOffset + startLine.left;
        startRect.rect = CGRectMake(offsetLeading, startLine.bottom, endOffset - startOffset, startLine.height);
        startRect.containsStart = YES;
        startRect.startAndEndSameLine = YES;
        [selectRects addObject:startRect];

        //end line rect
        YPTextSelectionRect *endRect = [[YPTextSelectionRect alloc] init];
        endRect.rect = CGRectMake(0, endLine.bottom, endOffset + endLine.left, endLine.height);
        endRect.containsEnd = YES;
        endRect.startAndEndSameLine = YES;
        [selectRects addObject:endRect];

    }
    //On the different line.
    else {
        
        //start line rect
        YPTextSelectionRect *startRect = [[YPTextSelectionRect alloc] init];
        CGFloat offsetLeading = startOffset + startLine.left;
        startRect.rect = CGRectMake(offsetLeading, startLine.bottom, self.viewSize.width - offsetLeading, startLine.height);
        startRect.containsStart = YES;
        [selectRects addObject:startRect];
        
        //end line rect
        YPTextSelectionRect *endRect = [[YPTextSelectionRect alloc] init];
        endRect.rect = CGRectMake(0, endLine.bottom, endOffset + endLine.left, endLine.height);
        endRect.containsEnd = YES;
        [selectRects addObject:endRect];
        
        //other line rect
        CGFloat otherWidth = self.viewSize.width;
        if (textRange.end.lineIndex - textRange.start.lineIndex == 1 && startOffset >= endOffset) {
            otherWidth = 0;
        }
        YPTextSelectionRect *otherRect = [[YPTextSelectionRect alloc] init];
        otherRect.rect = CGRectMake(0, endLine.top, otherWidth, startLine.bottom - endLine.top);
        [selectRects addObject:otherRect];

    }
    self.selectRectArray = selectRects;
    return selectRects;
}


- (YPTextRange *)selectAlltextRange {
    if (self.lineArray.count < 1) return nil;
    YPTextPosition *start = [[YPTextPosition alloc] init];
    start.lineIndex = 0;
    start.location = 0;
    
    YPTextPosition *end = [[YPTextPosition alloc] init];
    end.lineIndex = self.lineArray.count - 1;
    YPSeniorLine *line = self.lineArray[end.lineIndex];
    end.location = line.stringRange.location + line.stringRange.length;

    return [YPTextRange textRangeWithStartPosition:start endPosition:end];
}

- (YPTextRange *)selectWordTextRangeForPoint:(CGPoint)point {
    if (self.lineArray.count < 1) return nil;
    YPTextPosition *closetPos = [self closestPositionForPoint:point];
    if (!closetPos) return nil;
    YPSeniorLine *line = self.lineArray[closetPos.lineIndex];

    if (closetPos.location == NSMaxRange(line.stringRange)) {
        NSInteger baseIndex = closetPos.location - 1;
        if (baseIndex >= line.stringRange.location) {
            NSInteger preIndex = baseIndex - 1;
            if (preIndex >= line.stringRange.location) {
                NSRange validRange = NSMakeRange(preIndex, 2);
                NSString *word = [self.attrStr.string substringWithRange:validRange];
                if ([self _isWordWithString:word]) {
                    return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:preIndex endLoc:NSMaxRange(validRange)];
                }
            }
            return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:baseIndex endLoc:baseIndex + 1];
        }
    }else if (closetPos.location == line.stringRange.location) {
        NSInteger baseIndex = closetPos.location;
        NSInteger nextIndex = baseIndex + 1;
        if (nextIndex < NSMaxRange(line.stringRange)) {
            NSRange validRange = NSMakeRange(baseIndex, 2);
            NSString *word = [self.attrStr.string substringWithRange:validRange];
            if ([self _isWordWithString:word]) {
                return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:baseIndex endLoc:NSMaxRange(validRange)];
            }
        }
        return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:baseIndex endLoc:baseIndex + 1];
        
    }else{
        NSInteger baseIndex = closetPos.location - 1;
        //from base index to closest index
        NSRange validRange = NSMakeRange(baseIndex, 2);
        if (NSMaxRange(validRange) <= NSMaxRange(line.stringRange)) {
            NSString *word = [self.attrStr.string substringWithRange:validRange];
            if ([self _isWordWithString:word]) {
                return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:baseIndex endLoc:NSMaxRange(validRange)];
            }
        }
        //from pre base index to base index
        NSInteger preBaseIndex = baseIndex - 1;
        if (preBaseIndex >= 0 && preBaseIndex >= line.stringRange.location) {
            NSRange validRange = NSMakeRange(preBaseIndex, 2);
            if (NSMaxRange(validRange) <= NSMaxRange(line.stringRange)) {
                NSString *word = [self.attrStr.string substringWithRange:validRange];
                if ([self _isWordWithString:word]) {
                    return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:preBaseIndex endLoc:NSMaxRange(validRange)];
                }
            }
        }
        return [self _textRangeWithLineIndex:closetPos.lineIndex startLoc:baseIndex endLoc:baseIndex + 1];
    }
    
    return nil;
}

- (YPTextRange *)selectWordTextRangeForRange:(NSRange)textRange {
    if (self.lineArray.count < 1 || NSMaxRange(textRange) > self.attrStr.length) return nil;
    //create text position
    YPTextPosition *start = [[YPTextPosition alloc] init];
    start.location = textRange.location;
    start.lineIndex = NSNotFound;
    YPTextPosition *end = [[YPTextPosition alloc] init];
    end.location = NSMaxRange(textRange);
    end.lineIndex = NSNotFound;

    for(NSInteger index = 0; index < self.lineArray.count; index++) {
        YPSeniorLine *line = self.lineArray[index];
        if (NSLocationInRange(start.location, line.stringRange)) {
            start.lineIndex = index;
        }
        if (NSLocationInRange(end.location - 1, line.stringRange)) {
            end.lineIndex = index;
            break;
        }
    }
    if (start.lineIndex == NSNotFound || end.lineIndex == NSNotFound) return nil;
    //create select range
    return [YPTextRange textRangeWithStartPosition:start endPosition:end];
}

- (YPTextRange *)_textRangeWithLineIndex:(NSInteger)lineIndex
                                startLoc:(NSInteger)startLoc
                                  endLoc:(NSInteger)endLoc {
    YPTextPosition *start = [[YPTextPosition alloc] init];
    start.lineIndex = lineIndex;
    start.location = startLoc;
    
    YPTextPosition *end = [[YPTextPosition alloc] init];
    end.lineIndex = start.lineIndex;
    end.location = endLoc;

    return [YPTextRange textRangeWithStartPosition:start endPosition:end];
}

- (BOOL)_isWordWithString:(NSString *)word {
    if (!word || word.length < 2) return NO;
    CFStringTokenizerRef ref = CFStringTokenizerCreate(NULL, (__bridge CFStringRef)word, CFRangeMake(0, word.length), kCFStringTokenizerUnitWordBoundary, NULL);
    
    CFStringTokenizerAdvanceToNextToken(ref);
    CFRange range = CFStringTokenizerGetCurrentTokenRange(ref);
    BOOL result = range.length == word.length;
    CFRelease(ref);
    return result;
}

- (CGPoint)topPointForShowMenuController {
    CGPoint point = CGPointZero;
    if (self.selectRectArray.count < 1) return point;
    
    YPTextSelectionRect *startRect = [self.selectRectArray firstObject];
    if (!startRect) return point;
    
    point = CGPointMake(startRect.rect.origin.x + startRect.rect.size.width/2, startRect.rect.origin.y + startRect.rect.size.height);

    return point;
}

- (CGRect)bottomRectForShowMenuController {
    CGRect rect = CGRectZero;
    if (self.selectRectArray.count < 2) return rect;
    
    YPTextSelectionRect *endRect = self.selectRectArray[1];
    if (!endRect) return rect;
    
    return endRect.rect;
}

- (CGPoint)startGrabberPoint {
    CGPoint point = CGPointZero;
    if (self.selectRectArray.count < 1) return point;
    
    YPTextSelectionRect *startRect = [self.selectRectArray firstObject];
    if (!startRect) return point;

    return CGPointMake(startRect.rect.origin.x, startRect.rect.origin.y + startRect.rect.size.height);
}

- (CGPoint)endGrabberPoint {
    CGPoint point = CGPointZero;
    if (self.selectRectArray.count < 2) return point;
    
    YPTextSelectionRect *endRect = self.selectRectArray[1];
    if (!endRect) return point;
    
    return CGPointMake(endRect.rect.origin.x + endRect.rect.size.width, endRect.rect.origin.y + endRect.rect.size.height);
}


- (NSString *)selectStringWithLayoutAttr:(NSMutableAttributedString *)layoutAttr
                                   range:(NSRange)range {
    NSMutableString *originalString = [[NSMutableString alloc] init];
    if (range.length + range.location > layoutAttr.length) {
        return originalString;
    }
    NSAttributedString *subLayoutAttr = [layoutAttr attributedSubstringFromRange:range];
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)subLayoutAttr);
    
    CGMutablePathRef allPath = CGPathCreateMutable();
    CGPathAddRect(allPath, NULL, CGRectMake(0 , 0, 99999, 99999));
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), allPath, NULL);
    
    CFArrayRef lineCFArray = CTFrameGetLines(frameRef);
    NSInteger lineCount = CFArrayGetCount(lineCFArray);

    for (CFIndex lineIndex = 0; lineIndex < lineCount; lineIndex++ ) {
        CTLineRef lineRef = CFArrayGetValueAtIndex(lineCFArray, lineIndex);
        CFArrayRef runCFArray = CTLineGetGlyphRuns(lineRef);
        NSInteger runsCount = CFArrayGetCount(runCFArray);
        if (!runCFArray ||runsCount < 1) {
            continue;
        }
        for (CFIndex runIndex = 0; runIndex < runsCount; runIndex++) {
            //handle multiple YPAttribure
            CTRunRef runRef = CFArrayGetValueAtIndex(runCFArray, runIndex);
            NSDictionary *attributesDic = (NSDictionary *)CTRunGetAttributes(runRef);
            YPAttachmentAttribute *attachment = attributesDic[YPAttachmentAttributeName];
            if (attachment && attachment.representString) {
                [originalString appendString:attachment.representString];
            }else {
                CFRange subRange = CTRunGetStringRange(runRef);
                if (subRange.location + subRange.length <= subLayoutAttr.length) {
                    NSString *subString = [subLayoutAttr attributedSubstringFromRange:NSMakeRange(subRange.location, subRange.length)].string;
                    [originalString appendString:subString];
                }
            }
        }
    }
    
    CFRelease(setterRef);
    CFRelease(allPath);
    CFRelease(frameRef);

    return originalString.copy;

}
@end
