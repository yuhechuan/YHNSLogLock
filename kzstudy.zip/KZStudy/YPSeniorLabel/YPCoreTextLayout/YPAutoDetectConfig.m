//
//  YPAutoDetectConfig.m
//  YPSeniorLabel
//
//  Created by doit on 2019/8/10.
//  Copyright © 2019 Yaping Liu. All rights reserved.
//

#import "YPAutoDetectConfig.h"

@implementation YPAutoDetectConfig

- (instancetype)initWithDetectType:(YPAutoDetectCheckType)detectType
{
    self = [super init];
    if (self) {
        _detectType = detectType;
    }
    return self;
}

@end
