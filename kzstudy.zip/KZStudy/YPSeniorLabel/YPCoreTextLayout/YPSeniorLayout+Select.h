//
//  YPSeniorLayout+Select.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/24.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPSeniorLayout.h"

@class YPTextRange,YPTextPosition,YPTextSelectionRect;

/*
 Note: All the coordinates involved in this document belong to the CoreText coordinate system.
 */

@interface YPSeniorLayout (Select)

@property (nonatomic, strong) NSArray <YPTextSelectionRect *> *selectRectArray;

- (YPTextPosition *)closestPositionForPoint:(CGPoint)point;

- (YPTextRange *)selectAlltextRange;

- (YPTextRange *)selectWordTextRangeForPoint:(CGPoint)point;

- (YPTextRange *)selectWordTextRangeForRange:(NSRange)textRange;

- (NSArray <YPTextSelectionRect *>*)selectRectsWithTextRange:(YPTextRange *)textRange;

- (CGPoint)topPointForShowMenuController;

- (CGRect)bottomRectForShowMenuController;

- (CGPoint)startGrabberPoint;

- (CGPoint)endGrabberPoint;

- (NSString *)selectStringWithLayoutAttr:(NSMutableAttributedString *)layoutAttr
                                   range:(NSRange)range;

@end
