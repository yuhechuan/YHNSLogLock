//
//  YPAutoDetectConfig.h
//  YPSeniorLabel
//
//  Created by doit on 2019/8/10.
//  Copyright © 2019 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_OPTIONS(NSUInteger, YPAutoDetectCheckType) {
    YPAutoDetectCheckType_None = 0,
    YPAutoDetectCheckType_All = 1,
    YPAutoDetectCheckType_Link = 1 << 1, //email or url
    YPAutoDetectCheckType_Phone = 1 << 2,
    YPAutoDetectCheckType_Emoji = 1 << 3
};

@interface YPAutoDetectConfig : NSObject

- (instancetype)init __attribute__((unavailable("Must use `initWithDetectType:` instead.")));

- (instancetype)initWithDetectType:(YPAutoDetectCheckType)detectType NS_DESIGNATED_INITIALIZER;

//The detect type
@property (nonatomic, assign, readonly) YPAutoDetectCheckType detectType;

/**
 The emoji dictionary which key is string and value is iamge name.
 */
@property (nonatomic, strong) NSDictionary *emojiDic;

//If it is CGSizeZero ,use the emoji image size
@property (nonatomic, assign) CGSize emojiSize;

//The bundle to which emoji image file belongs. If nil, use main bundle.
@property (nonatomic, strong) NSBundle *emojiBundle;

//The emoji align font, default will align system font with 14 size.
@property (nonatomic, strong) UIFont *emojiAlignFont;

//Change back view color when click link.
@property (nonatomic, strong) UIColor *tapBackViewColor;

//Change string color when click link.
@property (nonatomic, strong) UIColor *highLightColor;

//Link string's color.
@property (nonatomic, strong) UIColor *linkColor;

//`NSUnderlineStyle` line style.
@property (nonatomic, assign) NSUnderlineStyle underlineStyle;

//Line color. Default nil: same as link color.
@property (nonatomic, strong) UIColor *underlineColor;

@end

