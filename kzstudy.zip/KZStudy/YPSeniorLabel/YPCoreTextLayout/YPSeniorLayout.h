//
//  YPSeniorLayout.h
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/11.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import "NSMutableAttributedString+YP.h"
#import "YPSeniorLine.h"
#import "YPAutoDetectConfig.h"

FOUNDATION_EXTERN NSRegularExpression* getEmojiRegex(void);

@class YPAttributeLayoutInfo, YPSeniorLayoutInject;

typedef NSMapTable <id, YPAttributeLayoutInfo *> YPAttributeLayoutInfoMap;

@interface YPSeniorLayout : NSObject

#pragma mark -- Layout

+ (YPSeniorLayout *)layoutWithInject:(YPSeniorLayoutInject *)inject
                             attrStr:(NSAttributedString *)attrStr
                            viewSize:(CGSize)viewSize;

@property (nonatomic, strong, readonly) YPSeniorLayoutInject *inject;

@property (nonatomic, strong, readonly) NSAttributedString *attrStr;

@property (nonatomic, assign, readonly) CGSize viewSize;

@property (nonatomic, assign, readonly) CTFrameRef ctFrame;

@property (nonatomic, assign, readonly) CTFramesetterRef frameSetter;

@property (nonatomic, strong, readonly) NSMutableArray <YPSeniorLine *> *lineArray;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *attachmentMap;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *attachmentImageMap;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *attachmentViewMap;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *attachmentLayerMap;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *borderInfoMap;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *linkInfoMap;

@property (nonatomic, strong, readonly) YPAttributeLayoutInfoMap *quoteInfoMap;

@property (nonatomic, assign, readonly) CGRect truncationPosition;

@property (nonatomic, assign, readonly) BOOL isTruncated;

#pragma mark -- Draw
- (void)drawWithContextRef:(CGContextRef)contextRef
                  isCancel:(BOOL (^)(void))isCancel;


#pragma mark -- Auto detect atrributedString
/*
 Create auto detect attribute string.
 
 @param originalAttr  The original attribte string.
 @param detectConfig  The auto detect config.
 */
+ (NSMutableAttributedString *)createAutoDetectAttrWithOriginalAttr:(NSAttributedString*)originalAttr
                                                       detectConfig:(YPAutoDetectConfig *)detectConfig;

#pragma mark -- Content size
/*
 @param attribureStr        The string with attributes.
 @param constraintSize      The restrict size.
 @param numberOfLines       The numberOfLines.
 @param inject              The inject.
 @param viewSize            The viewSize.

 
 return The content size.
 */
+ (CGSize)getDisplayContentSizeWithAttrStr:(NSAttributedString *)attrStr
                            constraintSize:(CGSize)constraintSize
                             numberOfLines:(NSInteger)numberOfLines
                                    inject:(YPSeniorLayoutInject *)inject
                                  viewSize:(CGSize)viewSize;
/*
 @param attribureStr        The string with attributes.
 @param constraintWidth     The restrict width.
 @param numberOfLines       The numberOfLines.
 
 return The content height.
 */
+ (CGFloat)contentHeightWithAttribureStr:(NSAttributedString *)attribureStr
                         constraintWidth:(CGFloat)constraintWidth
                           numberOfLines:(NSInteger)numberOfLines;

/*
 @param attribureStr        The string with attributes.
 @param constraintSize      The restrict size.
 @param numberOfLines       The numberOfLines.
 
 return The content size.
 */
+ (CGSize)contentSizeWithAttribureStr:(NSAttributedString *)attribureStr
                       constraintSize:(CGSize)constraintSize
                        numberOfLines:(NSInteger)numberOfLines;
/*
 @param attribureStr        The string with attributes.
 @param constraintWidth     The restrict width.
 @param numberOfLines       The numberOfLines.
 @param detectType          The detect type.
 @param emojiDic            Emoji dictionary which key is string and value is iamge name.
 @param emojiBundle         Emoji bundle. If nil, use main bundle.
 @param emojiSize           Emoji size. If it is CGSizeZero ,use the emoji image size.
 
 return The content height.
 */
+ (CGFloat)contentHeightWithAttribureStr:(NSAttributedString *)attribureStr
                         constraintWidth:(CGFloat)constraintWidth
                           numberOfLines:(NSInteger)numberOfLines
                              detectType:(YPAutoDetectCheckType)detectType
                                emojiDic:(NSDictionary *)emojiDic
                             emojiBundle:(NSBundle *)emojiBundle
                               emojiSize:(CGSize)emojiSize;


/*
 @param attribureStr        The string with attributes.
 @param constraintSize      The restrict size.
 @param numberOfLines       The numberOfLines.
 @param detectType          The detect type.
 @param emojiDic            Emoji dictionary which key is string and value is iamge name.
 @param emojiBundle         Emoji bundle. If nil, use main bundle.
 @param emojiSize           Emoji size. If it is CGSizeZero ,use the emoji image size.
 
 return The content size.
 */
+ (CGSize)contentSizeWithAttribureStr:(NSAttributedString *)attribureStr
                       constraintSize:(CGSize)constraintSize
                        numberOfLines:(NSInteger)numberOfLines
                           detectType:(YPAutoDetectCheckType)detectType
                             emojiDic:(NSDictionary *)emojiDic
                          emojiBundle:(NSBundle *)emojiBundle
                            emojiSize:(CGSize)emojiSize;


#pragma mark -- Utilities
/*
@param attribureStr        The string with attributes.
@param constraintWidth     The restrict width.

return lines for restrict width.
*/
+ (NSInteger)getDisplayLineWithAttrStr:(NSAttributedString *)attrStr
                        constraintSize:(CGSize)constraintSize;

@end
