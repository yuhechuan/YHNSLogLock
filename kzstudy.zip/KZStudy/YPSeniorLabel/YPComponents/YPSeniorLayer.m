//
//  YPSeniorLayer.m
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/12.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import "YPSeniorLayer.h"
#import <stdatomic.h>
/**
自己实现一个并发队列
主要是因为并行队列无法精确的控制线程数量，很有可能创建过多的线程，导致 CPU 线程调度过于频繁，影响交互性能。
 */
//Layout queue
static dispatch_queue_t SeniorLayerGetLayoutQueue() {

#define MAX_QUEUE_COUNT 16
    static int queueCount;
    static dispatch_queue_t queues[MAX_QUEUE_COUNT];
    static dispatch_once_t onceToken;
    static atomic_int counter = 0;
    dispatch_once(&onceToken, ^{
        //processorCount: The number of logical CPU.
        NSUInteger processorCount = [NSProcessInfo processInfo].activeProcessorCount;
        if (processorCount < 1) {
            queueCount = 1;
        }else if (processorCount > MAX_QUEUE_COUNT){
            queueCount = MAX_QUEUE_COUNT;
        }else{
            queueCount = (int)processorCount;
        }
        for (NSUInteger i = 0; i < queueCount; i++) {
            dispatch_queue_attr_t attr = dispatch_queue_attr_make_with_qos_class(DISPATCH_QUEUE_SERIAL, QOS_CLASS_USER_INITIATED, 0);
            queues[i] = dispatch_queue_create("jstd.ypsenior.render", attr);
        }
    });
    // 原子操作 counter++
    atomic_fetch_add_explicit(&counter, 1, __ATOMIC_SEQ_CST);
    
    return queues[(counter) % queueCount];
#undef MAX_QUEUE_COUNT

}

//Release contents queue
static dispatch_queue_t SeniorLayerGetReleaseQueue() {
    return dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0);
}


@implementation YPSeniorLayerTask

@end

@interface YPSeniorLayer ()
{
    atomic_int _threadCountValue;

}

@end

@implementation YPSeniorLayer

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}
+ (id)defaultValueForKey:(NSString *)key
{
    if ([key isEqualToString:@"seniorDrawsAsynchronously"]) {
        return @YES;
    } else {
        return [super defaultValueForKey:key];
    }
}
- (void)dealloc {
    [self cancelAsyncLayout];
}
// 标记要刷新
- (void)setNeedsDisplay {
    [self cancelAsyncLayout];
    [super setNeedsDisplay];
}

// 系统调用 绘制方法
- (void)display {
    [self layout:self.seniorDrawsAsynchronously];
}

- (void)layout:(BOOL)asyncDraw {
    id <YPSeniorLayerDelegate> layerDelegate = (id)self.delegate;
    YPSeniorLayerTask *layerTask = [layerDelegate createLayerNewLayoutTask];
    if (!layerTask.Layout) {
        if (layerTask.WillLayout) {
            layerTask.WillLayout(self);
        }
        self.contents = nil;
        if (layerTask.DidLayout) {
            layerTask.DidLayout(self, YES);
        }
        return;
    }
    
    if (asyncDraw) {
        ////Async draw
        //WillLayout
        if (layerTask.WillLayout) layerTask.WillLayout(self);
        if (self.bounds.size.width < 1 || self.bounds.size.height < 1) {
            CGImageRef image = (__bridge_retained CGImageRef)(self.contents);
            self.contents = nil;
            if (image) {
                dispatch_async(SeniorLayerGetReleaseQueue(), ^{
                    CFRelease(image);
                });
            }
            if (layerTask.DidLayout) layerTask.DidLayout(self, YES);
            return;
        }
        
        int32_t countValue = _threadCountValue;
        // 如果被标记为 需要更新 两个值会不同 等待系统下次调用时机
        BOOL (^hasCancelled)(void) = ^BOOL() {
            return countValue != self->_threadCountValue;
        };
        CGSize layerSize = self.bounds.size;
        BOOL layerOpaque = self.opaque;
        CGFloat layerscale = self.contentsScale;
        CGColorRef backgroundColor = (layerOpaque && self.backgroundColor) ? CGColorRetain(self.backgroundColor) : NULL;
        dispatch_async(SeniorLayerGetLayoutQueue(), ^{
            if (hasCancelled()) {
                CGColorRelease(backgroundColor);
                return;
            }
            // 您可以使用此函数配置绘图环境 图形上下文，以便将其呈现为位图
            UIGraphicsBeginImageContextWithOptions(layerSize, layerOpaque, layerscale);
            // 获取图形上下文
            CGContextRef context = UIGraphicsGetCurrentContext();
            if (layerOpaque) {
                // 将当前图形状态的副本压入上下文的图形状态堆栈。
                CGContextSaveGState(context);
                {
                    if (!backgroundColor || CGColorGetAlpha(backgroundColor) < 1) {
                        CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);
                    }else if (backgroundColor) {
                        CGContextSetFillColorWithColor(context, backgroundColor);
                    }
                    CGContextAddRect(context, CGRectMake(0, 0, layerSize.width * layerscale, layerSize.height * layerscale));
                    // 绘制当前路径内的区域
                    CGContextFillPath(context);
                }
                // 将当前图形状态设置为最近保存的状态。
                CGContextRestoreGState(context);
                CGColorRelease(backgroundColor);
            }
            
            //Layout 关键内容绘制 方法
            layerTask.Layout(context, layerSize, hasCancelled);
            
            //DidLayout
            if (hasCancelled()) {
                UIGraphicsEndImageContext();
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (layerTask.DidLayout) layerTask.DidLayout(self, NO);
                });
                return;
            }
            // 获取图片
            UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
            // 从堆栈顶部移除当前基于位图的图形上下文。
            UIGraphicsEndImageContext();
            if (hasCancelled()) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (layerTask.DidLayout) layerTask.DidLayout(self, NO);
                });
                return;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if (hasCancelled()) {
                    if (layerTask.DidLayout) layerTask.DidLayout(self, NO);
                } else {
                    self.contents = (__bridge id)(image.CGImage);
                    if (layerTask.DidLayout) layerTask.DidLayout(self, YES);
                }
            });
        });
    }else{
        ////Sync draw
        [self cancelAsyncLayout];
        if (layerTask.WillLayout) layerTask.WillLayout(self);
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, self.opaque, self.contentsScale);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGSize size = self.bounds.size;
        if (self.opaque) {
            CGContextSaveGState(context);
            {
                if (!self.backgroundColor || CGColorGetAlpha(self.backgroundColor) < 1) {
                    CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);
                }else if (self.backgroundColor) {
                    CGContextSetFillColorWithColor(context, self.backgroundColor);
                }
                CGContextAddRect(context, CGRectMake(0, 0, self.contentsScale * size.width, self.contentsScale * size.height));
                CGContextFillPath(context);
            }
            CGContextRestoreGState(context);
        }
        layerTask.Layout(context, size ,^{return NO;});
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        self.contents = (__bridge id)(image.CGImage);
        if (layerTask.DidLayout) layerTask.DidLayout(self, YES);
    }
}

- (void)cancelAsyncLayout {
    atomic_fetch_add_explicit(&_threadCountValue, 1, __ATOMIC_SEQ_CST);
}

@end
