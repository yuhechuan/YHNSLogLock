//
//  YPMagnifierView.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/6/1.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kMagnifierSize CGSizeMake(140, 45)

@interface YPMagnifierView : UIView

@property (nonatomic , weak) UIView *needMagnifierView;

@property (nonatomic, assign) CGPoint touchMagnifierPoint;

@end
