//
//  YPSeniorLayer.h
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/12.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class YPSeniorLayerTask;

@protocol YPSeniorLayerDelegate <NSObject>
@required
- (YPSeniorLayerTask *)createLayerNewLayoutTask;

@end

@interface YPSeniorLayer : CALayer

@property (nonatomic, assign) BOOL seniorDrawsAsynchronously;

@end

@interface YPSeniorLayerTask : NSObject

@property (nullable, nonatomic, copy) void (^WillLayout)(CALayer *layer);

@property (nullable, nonatomic, copy) void (^Layout)(CGContextRef _Nullable context, CGSize layerSize ,BOOL(^hasCanceled)(void));

@property (nullable, nonatomic, copy) void (^DidLayout)(CALayer *layer, BOOL finished);

@end
NS_ASSUME_NONNULL_END
