//
//  YPMagnifierWindow.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/6/1.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPMagnifierWindow.h"

@implementation YPMagnifierWindow

+ (instancetype)shareWindow {
    static YPMagnifierWindow *window = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        window = [[YPMagnifierWindow alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        
    });
    return window;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.windowLevel = UIWindowLevelStatusBar + 1.;
        self.userInteractionEnabled = NO;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)showMagnifierView:(YPMagnifierView *)magnifierView {
    if (magnifierView.superview != self) {
        [self addSubview:magnifierView];;
    }
    self.hidden = NO;
}

- (void)hiddenMagnifierView:(YPMagnifierView *)magnifierView {
    if (magnifierView.superview) {
        [magnifierView removeFromSuperview];
    }
    self.hidden = YES;
}

@end
