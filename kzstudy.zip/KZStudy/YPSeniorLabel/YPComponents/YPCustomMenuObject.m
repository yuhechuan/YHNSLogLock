//
//  YPCustomMenuObject.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/28.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPCustomMenuObject.h"
#import "YPMenuController.h"

@interface YPCustomMenuObject ()

@property (nonatomic, strong) NSString *currentContent;

@end

@implementation YPCustomMenuObject

- (NSArray<YPMenuItem *> *)customMenuItems {
    YPMenuItem *copy = [[YPMenuItem alloc] initSystemWithAction:@selector(copyAction) title:@"Copy"];
    return @[copy];
}

- (void)currentSelectContent:(NSString *)selectContent {
    self.currentContent = selectContent;
}

- (BOOL)canPerfomSelector:(SEL)aSelector {
    if (@selector(copyAction) == aSelector) {
        return YES;
    }
    return NO;
}

- (void)copyAction {
    [[UIPasteboard generalPasteboard] setString:self.currentContent];
}

@end
