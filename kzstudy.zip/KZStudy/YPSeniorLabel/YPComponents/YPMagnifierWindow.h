//
//  YPMagnifierWindow.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/6/1.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YPMagnifierView.h"

@interface YPMagnifierWindow : UIWindow

+ (instancetype)shareWindow;

- (void)showMagnifierView:(YPMagnifierView *)magnifierView;

- (void)hiddenMagnifierView:(YPMagnifierView *)magnifierView;

@end
