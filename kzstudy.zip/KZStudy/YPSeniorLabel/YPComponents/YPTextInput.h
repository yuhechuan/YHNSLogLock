//
//  YPTextInput.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/24.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YPTextPosition : NSObject

@property (nonatomic, assign) long location;

@property (nonatomic, readwrite, assign) NSUInteger lineIndex;

- (NSComparisonResult)compare:(YPTextPosition *)aPosition;

@end

@interface YPTextRange : NSObject

@property (nonatomic, readonly, strong) YPTextPosition *start;

@property (nonatomic, readonly, strong) YPTextPosition *end;

+ (YPTextRange *)textRangeWithStartPosition:(YPTextPosition *)start endPosition:(YPTextPosition *)end;

- (BOOL)updateRangeStartPosition:(YPTextPosition *)start;

- (BOOL)updateRangeEndPosition:(YPTextPosition *)end;

@end

@interface YPTextSelectionRect : NSObject

@property (nonatomic, assign) CGRect rect;

@property (nonatomic, assign) BOOL containsStart;

@property (nonatomic, assign) BOOL containsEnd;

@property (nonatomic, assign) BOOL startAndEndSameLine;

@end


NS_ASSUME_NONNULL_END
