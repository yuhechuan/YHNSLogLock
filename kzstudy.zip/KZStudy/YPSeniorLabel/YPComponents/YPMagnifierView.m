//
//  YPMagnifierView.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/6/1.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPMagnifierView.h"

#define kPadding 4.0
#define kRadius 6.0
#define kHeight 23.0
#define kArrow 10.0

@interface YPMagnifierView ()

@property (nonatomic, strong) UIImageView *coverImageView;

@property (nonatomic, strong) UIImageView *textImageView;

@end

@implementation YPMagnifierView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
        self.backgroundColor = [UIColor clearColor];
        self.textImageView = [[UIImageView alloc] init];
        self.textImageView.frame = CGRectMake(kPadding, kPadding, kMagnifierSize.width - 2 * kPadding, kHeight);
        self.textImageView.layer.cornerRadius = kRadius;
        self.textImageView.layer.masksToBounds = YES;
        [self addSubview:self.textImageView];

        self.coverImageView = [[UIImageView alloc] init];
        self.coverImageView.frame = (CGRect){.origin = CGPointZero, .size = kMagnifierSize};
        self.coverImageView.image = [self.class coverImage];
        [self addSubview:self.coverImageView];
    }
    return self;
}

- (void)setTouchMagnifierPoint:(CGPoint)touchMagnifierPoint {
    _touchMagnifierPoint = touchMagnifierPoint;
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(kMagnifierSize.width, kHeight), NO, 0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //current only support 14/15/16 font size.
    CGFloat xStart = _touchMagnifierPoint.x - (kMagnifierSize.width - 2 * kPadding) /2. + kRadius/2. + kRadius + 3.5;
    CGContextScaleCTM(ctx, 1.3, 1.3);
    CGContextTranslateCTM(ctx, -xStart, -_touchMagnifierPoint.y - 2);
    [self.needMagnifierView.layer renderInContext:ctx];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.textImageView.image = image;
    
}

+ (UIImage *)coverImage {
    static UIImage *image;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        CGSize size = kMagnifierSize;
        CGRect rect = (CGRect) {.size = size, .origin = CGPointZero};
        
        UIGraphicsBeginImageContextWithOptions(size, NO, 0);
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        CGPathRef boxPath = CGPathCreateWithRect(rect, NULL);
        
        CGMutablePathRef path = CGPathCreateMutable();
        CGPathMoveToPoint(path, NULL, kPadding + kRadius, kPadding);
        CGPathAddLineToPoint(path, NULL, size.width - kPadding - kRadius, kPadding);
        CGPathAddQuadCurveToPoint(path, NULL, size.width - kPadding, kPadding, size.width - kPadding, kPadding + kRadius);
        CGPathAddLineToPoint(path, NULL, size.width - kPadding, kHeight);
        CGPathAddCurveToPoint(path, NULL, size.width - kPadding, kPadding + kHeight, size.width - kPadding - kRadius, kPadding + kHeight, size.width - kPadding - kRadius, kPadding + kHeight);
        CGPathAddLineToPoint(path, NULL, size.width / 2 + kArrow, kPadding + kHeight);
        CGPathAddLineToPoint(path, NULL, size.width / 2, kPadding + kHeight + kArrow);
        CGPathAddLineToPoint(path, NULL, size.width / 2 - kArrow, kPadding + kHeight);
        CGPathAddLineToPoint(path, NULL, kPadding + kRadius, kPadding + kHeight);
        CGPathAddQuadCurveToPoint(path, NULL, kPadding, kPadding + kHeight, kPadding, kHeight);
        CGPathAddLineToPoint(path, NULL, kPadding, kPadding + kRadius);
        CGPathAddQuadCurveToPoint(path, NULL, kPadding, kPadding, kPadding + kRadius, kPadding);
        CGPathCloseSubpath(path);
        
        CGMutablePathRef arrowPath = CGPathCreateMutable();
        CGPathMoveToPoint(arrowPath, NULL, size.width / 2 - kArrow, kPadding + kHeight);
        CGPathAddLineToPoint(arrowPath, NULL, size.width / 2 + kArrow, kPadding + kHeight);
        CGPathAddLineToPoint(arrowPath, NULL, size.width / 2, kPadding + kHeight + kArrow);
        CGPathCloseSubpath(arrowPath);
        
        //inner shadow
        CGContextSaveGState(context); {
            CGFloat blurRadius = 25;
            CGSize offset = CGSizeMake(0, 15);
            CGColorRef shadowColor = [UIColor colorWithWhite:0 alpha:0.16].CGColor;
            CGColorRef opaqueShadowColor = CGColorCreateCopyWithAlpha(shadowColor, 1.0);
            CGContextAddPath(context, path);
            CGContextClip(context);
            CGContextSetAlpha(context, CGColorGetAlpha(shadowColor));
            CGContextBeginTransparencyLayer(context, NULL); {
                CGContextSetShadowWithColor(context, offset, blurRadius, opaqueShadowColor);
                CGContextSetBlendMode(context, kCGBlendModeSourceOut);
                CGContextSetFillColorWithColor(context, opaqueShadowColor);
                CGContextAddPath(context, path);
                CGContextFillPath(context);
            } CGContextEndTransparencyLayer(context);
            CGColorRelease(opaqueShadowColor);
        } CGContextRestoreGState(context);
        
        //outer shadow
        CGContextSaveGState(context); {
            CGContextAddPath(context, boxPath);
            CGContextAddPath(context, path);
            CGContextEOClip(context);
            CGColorRef shadowColor = [UIColor colorWithWhite:0 alpha:0.6].CGColor;
            CGContextSetShadowWithColor(context, CGSizeMake(0, 1.5), 3, shadowColor);
            CGContextBeginTransparencyLayer(context, NULL); {
                CGContextAddPath(context, path);
                [[UIColor colorWithWhite:0.7 alpha:1.000] setFill];
                CGContextFillPath(context);
            } CGContextEndTransparencyLayer(context);
        } CGContextRestoreGState(context);
        
        //arrow
        CGContextSaveGState(context); {
            CGContextAddPath(context, arrowPath);
            [[UIColor colorWithWhite:1 alpha:0.95] set];
            CGContextFillPath(context);
        } CGContextRestoreGState(context);
        
        //stroke
        CGContextSaveGState(context); {
            CGContextAddPath(context, path);
            [[UIColor colorWithWhite:0.6 alpha:1] setStroke];
            CGContextSetLineWidth(context, 1);
            CGContextStrokePath(context);
        } CGContextRestoreGState(context);
        
        CFRelease(boxPath);
        CFRelease(path);
        CFRelease(arrowPath);
        
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
    });
    return image;
}
@end
