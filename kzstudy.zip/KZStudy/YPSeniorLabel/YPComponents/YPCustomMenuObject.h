//
//  YPCustomMenuObject.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/28.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YPLabelProtocols.h"

@interface YPCustomMenuObject : NSObject<YPSelectMenuProtocol>

@end
