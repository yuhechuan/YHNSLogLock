//
//  YPTextSelectView.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/23.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPTextSelectView.h"

#import "YPTextInput.h"

#define kDotDiameter 10

#define kGrabberWidth 2

#pragma mark -- YPTextCursorLayer

typedef NS_ENUM(NSInteger, TextGrabberDirection) {
    TextGrabberDirectionUp,
    TextGrabberDirectionDown,
};

@interface YPTextGrabber ()

@property (nonatomic, assign) TextGrabberDirection direction;

@property (nonatomic, strong) UIColor *grabberColor;

@end

@implementation YPTextGrabber

- (instancetype)init
{
    self = [super init];
    if (self) {

        //dot
        self.dot = [[UIView alloc] init];
        self.dot.layer.cornerRadius = 5;
        self.dot.layer.masksToBounds = YES;
        self.multipleTouchEnabled = NO;
        self.dot.multipleTouchEnabled = NO;
    }
    return self;
}

- (void)setGrabberColor:(UIColor *)grabberColor {
    _grabberColor = grabberColor;
    self.dot.backgroundColor = grabberColor;
    self.backgroundColor = grabberColor;
}

- (void)layoutSubviews {

    CGFloat layerWidth = CGRectGetWidth(self.bounds);
    CGFloat layerHeight = CGRectGetHeight(self.bounds);
    
    //dot
    CGRect dotFrame = self.dot.frame;
    if (self.direction == TextGrabberDirectionUp) {
        self.dot.frame = CGRectMake(-CGRectGetWidth(dotFrame)/2 + layerWidth/2, 0, kDotDiameter, kDotDiameter);
    }else {
        self.dot.frame = CGRectMake(-CGRectGetWidth(dotFrame)/2 + layerWidth/2, layerHeight - CGRectGetHeight(dotFrame), kDotDiameter, kDotDiameter);
    }
    [self addSubview:self.dot];

}

@end


#pragma mark -- YPTextSelectView

@interface YPTextSelectView ()

@end

@implementation YPTextSelectView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.userInteractionEnabled = NO;
        self.maskViews = [[NSMutableArray alloc] init];
        self.startGrabber = [[YPTextGrabber alloc] init];
        self.startGrabber.direction = TextGrabberDirectionUp;
        [self addSubview:self.startGrabber];
        
        self.endGrabber = [[YPTextGrabber alloc] init];
        self.endGrabber.direction = TextGrabberDirectionDown;
        [self addSubview:self.endGrabber];

    }
    return self;
}

- (void)setCursorColor:(UIColor *)cursorColor {
    _cursorColor = cursorColor;
    self.startGrabber.grabberColor = cursorColor;
    self.endGrabber.grabberColor = cursorColor;
}

- (void)updateSelectWithRects:(NSArray <YPTextSelectionRect *>*)rects {
    
    [self.maskViews enumerateObjectsUsingBlock:^(UIView  * _Nonnull view, NSUInteger idx, BOOL * _Nonnull stop) {
        [view removeFromSuperview];
    }];
    [self.maskViews removeAllObjects];
    
    NSArray *renderRects = rects.copy;
    CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, CGRectGetHeight(self.frame)), 1.f, -1.f);
    [renderRects enumerateObjectsUsingBlock:^(YPTextSelectionRect * _Nonnull rectObject, NSUInteger idx, BOOL * _Nonnull stop) {
        UIView *maskView = [[UIView alloc] init];
        maskView.backgroundColor = self.selectBackgroundColor;

        CGRect maskRect = CGRectApplyAffineTransform(rectObject.rect, transform);
        maskRect = CGRectStandardize(maskRect);
        if (rectObject.containsStart) {
            [self.startGrabber setNeedsLayout];
            [self.startGrabber layoutIfNeeded];
            self.startGrabber.frame = CGRectMake(maskRect.origin.x, maskRect.origin.y-kDotDiameter, kGrabberWidth, maskRect.size.height + kDotDiameter);
            maskView.frame = maskRect;

        }else if (rectObject.containsEnd){
            [self.endGrabber setNeedsLayout];
            [self.endGrabber layoutIfNeeded];
            self.endGrabber.frame = CGRectMake(maskRect.origin.x+maskRect.size.width, maskRect.origin.y , kGrabberWidth, maskRect.size.height + kDotDiameter);
            CGFloat lineWidth = rectObject.startAndEndSameLine ? 0. : rectObject.rect.size.width;
            maskView.frame = CGRectMake(maskRect.origin.x, maskRect.origin.y, lineWidth, maskRect.size.height);

        }else{
            maskView.frame = maskRect;
        }
        
        [self insertSubview:maskView atIndex:0];
        [self.maskViews addObject:maskView];
    }];


}

@end
