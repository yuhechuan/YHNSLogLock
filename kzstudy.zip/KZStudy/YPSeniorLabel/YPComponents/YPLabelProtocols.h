//
//  YPLabelProtocols.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/7/10.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#ifndef YPLabelProtocols_h
#define YPLabelProtocols_h

@class YPSeniorLabel, YPMenuItem;

#pragma mark -- YPSeniorLabelProtocol
/*
 The YPSeniorLabelProtocol protocol defines a set of optional methods you can use to receive  messages for YPSeniorLabel objects.
 */
@protocol YPSeniorLabelProtocol <NSObject>

@optional
- (BOOL)seniorLabelShouldBeginSelecting:(YPSeniorLabel *)seniorLabel;

- (BOOL)seniorLabelShouldEndSelecting:(YPSeniorLabel *)seniorLabel;

- (void)seniorLabelDidBeginSelecting:(YPSeniorLabel *)seniorLabel;

- (void)seniorLabelDidEndSelecting:(YPSeniorLabel *)seniorLabel;

@end


#pragma mark -- YPSelectMenuProtocol
/*
 The YPSelectMenuProtocol protocol defines a set of optional methods you can use to receive messages for YPMenuController.
 */
@protocol YPSelectMenuProtocol <NSObject>

@required
- (NSArray <YPMenuItem *> *)customMenuItems;

- (BOOL)canPerfomSelector:(SEL)aSelector;

- (void)currentSelectContent:(NSString *)selectContent;

@optional
/**
 If select faild, the range location will be NSNotFound.
 */
- (BOOL)shouldShowMenuWithSeniorLabel:(YPSeniorLabel *)seniorLabel
                        selectContent:(NSAttributedString *)selectContent
                                range:(NSRange)range;

/**
 Limit max select length.
 This method only works if `useWordSelect` is set to YES.
 */
- (NSInteger)selectMaxLengthWithSeniorLabel:(YPSeniorLabel *)seniorLabel;

@end

#endif /* YPLabelProtocols_h */
