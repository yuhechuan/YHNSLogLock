//
//  YPTextSelectView.h
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/23.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YPTextGrabber, YPTextSelectionRect;

@interface YPTextGrabber : UIView

@property (nonatomic, strong) UIView *dot;

@end

@interface YPTextSelectView : UIView

@property (nonatomic, strong) YPTextGrabber *startGrabber;

@property (nonatomic, strong) YPTextGrabber *endGrabber;

@property (nonatomic, strong) UIColor *cursorColor;

@property (nonatomic, strong) UIColor *selectBackgroundColor;

@property (nonatomic, strong) NSMutableArray *maskViews;

- (void)updateSelectWithRects:(NSArray <YPTextSelectionRect *>*)rects;

@end
