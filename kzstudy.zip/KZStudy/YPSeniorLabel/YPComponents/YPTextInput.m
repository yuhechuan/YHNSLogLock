//
//  YPTextInput.m
//  YPSeniorLabel
//
//  Created by Yaping Liu on 2018/5/24.
//  Copyright © 2018年 Yaping Liu. All rights reserved.
//

#import "YPTextInput.h"

@implementation YPTextPosition

- (NSComparisonResult)compare:(YPTextPosition *)aPosition {
    if (aPosition.location > self.location) {
        return NSOrderedAscending;
    }else if (aPosition.location < self.location){
        return NSOrderedDescending;
    }else{
        return NSOrderedSame;
    }
}

@end


@implementation YPTextRange

+ (YPTextRange *)textRangeWithStartPosition:(YPTextPosition *)start endPosition:(YPTextPosition *)end {
    YPTextRange *range = [[YPTextRange alloc] init];
    range->_start = start;
    range->_end = end;
    return range;
}

- (BOOL)updateRangeStartPosition:(YPTextPosition *)start {
    return [self updateRangeStartPosition:start endPosition:_end];
}

- (BOOL)updateRangeEndPosition:(YPTextPosition *)end {
    return [self updateRangeStartPosition:_start endPosition:end];
}

- (BOOL)updateRangeStartPosition:(YPTextPosition *)start endPosition:(YPTextPosition *)end {
    BOOL needReverse = NO;
    if ([end compare:start] == NSOrderedAscending) {
        YPTextPosition *temp = end;
        end = start;
        start = temp;
        needReverse = YES;
    }
    _start = start;
    _end = end;
    return needReverse;
}

@end


@implementation YPTextSelectionRect

@end
