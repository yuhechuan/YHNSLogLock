//
//  YPSeniorLabel.h
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/5.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YPSeniorLayout.h"
#import "YPLabelProtocols.h"

@interface YPSeniorLabel : UIView

#pragma mark -- Basic Properties
/*
 Clear layer's contents before layer redraw.
 Default YES.
 */
@property (nonatomic, assign) BOOL clearContentWhenRedraw;

/*
 Drawing operations execute asynchronously.
 Default NO.
 */
@property (nonatomic, assign) BOOL seniorDrawsAsynchronously;

/*
 The animation interval for content to appear when asynchronous drawing is turned on.
 Default 0.1, when it is less than or equal to 0, there is no animation effect.
 */
@property (nonatomic, assign) CGFloat fadeDuration;

/*
 Ignoring redrawing can improve performance when using
 `-configAutoDetectWith....` methods.
 General properties include attributedString, font, textColor,
 numberOfLines, lineBreakMode, alignment, truncationAttrStr.
 Default NO.
*/
@property (nonatomic, assign) BOOL ignorGeneralProperties;

/*
 Setting the custom truncation.
 */
@property (nonatomic, strong) NSAttributedString *truncationAttrStr;

/*
 Click truncatin call back.
 */
@property (nonatomic, copy) YPTruncActionBlock truncationAction;

/*
 If automatic detection is configured, this callback will be called automatically;
 if the configured custom link does not have a callback, the callback will also be called.
 */
@property (nonatomic, copy) YPLinkTypeBlock linkTypeAction;

/*
 Receive messages for YPSeniorLabel objects.
 */
@property (nonatomic, weak) id<YPSeniorLabelProtocol>delegate;

/*
 Setting attributed string.
 */
@property (nonatomic, strong) NSAttributedString *attributedString;

/**
 Draw attributed string.
 */
@property (nonatomic, strong, readonly) NSAttributedString *layoutAttrString;

/**
 Setting text lines.
 */
@property (nonatomic, assign) NSInteger numberOfLines;

/**
 Auto set value for `attributedString`.
 */
@property (nonatomic, strong) UIFont *font;
@property (nonatomic, strong) UIColor *textColor;
@property (nonatomic, assign) NSLineBreakMode lineBreakMode;
@property (nonatomic, assign) NSTextAlignment alignment;

#pragma mark -- Select
/*
 Custom whether you need to make a selection. Default NO.
 Note: The text cannot be selected if it has be truncated.
 */
@property (nonatomic, assign) BOOL canSelectOperation;

/*
 Custom whether you need to make a magnifier. Default NO.
 */
@property (nonatomic, assign) BOOL canShowMagnifier;

/*
 Use auto word select. Default NO.
 */
@property (nonatomic, assign) BOOL useWordSelect;
/**
 * TruncationAction 是否高于手势 响应 默认是YES 设置为NO, label或者父视图存在手势时  TruncationAction 失效
 */
@property (nonatomic, assign) BOOL cancelsGestureWhenTruncationAction;

/*
 Custom menu function. The default only Chinese copy button.
 */
@property (nonatomic, weak) id<YPSelectMenuProtocol>menuDelegate;

/*
 Default blue color.
 */
@property (nonatomic, strong) UIColor *cursorColor;

/*
 Default blub color with 0.1 alpha component.
 */
@property (nonatomic, strong) UIColor *selectBackgroundColor;

/**
 The select text range.
 */
@property (nonatomic, assign) NSRange selectedTextRange;

/**
 Show menu for current select.
 For example, when you update the menu frame, you can use this method refresh.
 */
- (BOOL)showMenuForCurrentSelect;

#pragma mark -- Basic methods
/**
 Setting with detecting config
 
 @param detectType       The detect type
 @param emojiDic         The emoji dictionary which key is string and value is iamge name.
 @param emojiSize        Emoji size. If CGSizeZero, use the emoji image size.
 @param emojiBundle      Emoji bundle. If nil, use main bundle.
 @param linkColor        The link color.
 @param underlineStyle   The link underline style.
 @param underlineColor   The link underline color, default is nil which same as link color.
 */
- (void)configAutoDetectWithDetectType:(YPAutoDetectCheckType)detectType
                              emojiDic:(NSDictionary *)emojiDic
                             emojiSize:(CGSize)emojiSize
                           emojiBundle:(NSBundle *)emojiBundle
                             linkColor:(UIColor *)linkColor
                        underlineStyle:(NSUnderlineStyle)underlineStyle
                        underlineColor:(UIColor *)underlineColor;

/**
 Setting with detecting config
 
 @param config       The detect config.
 */
- (void)configAutoDetectWithConfig:(YPAutoDetectConfig *)config;

/**
 Get current label object content size.
 
 @param constraintWidth The constraint width.
 */
- (CGSize)seniorLabelContentSizeWithConstraintWidth:(CGFloat)constraintWidth;

/**
 Get current label object content size.
 
 @param constraintSize The constraint size.
 */
- (CGSize)seniorLabelContentSizeWithConstraintSize:(CGSize)constraintSize;

@end
