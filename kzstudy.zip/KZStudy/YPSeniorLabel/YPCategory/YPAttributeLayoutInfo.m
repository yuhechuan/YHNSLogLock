//
//  YPAttributeLayoutInfo.m
//  YPSeniorLabel
//
//  Created by doit on 2019/10/16.
//  Copyright © 2019 Yaping Liu. All rights reserved.
//

#import "YPAttributeLayoutInfo.h"

@implementation YPAttributeLayoutInfo

@end
