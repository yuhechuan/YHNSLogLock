//
//  YPSeniorAttribute.m
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/9.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import "YPSeniorAttribute.h"

YPAttributedStringKey const YPLinkAttributeName = @"YPLinkAttributeName";

YPAttributedStringKey const YPAttachmentAttributeName = @"YPAttachmentAttributeName";

YPAttributedStringKey const YPBorderAttributeName = @"YPBorderAttributeName";

YPAttributedStringKey const YPQuoteAttributeName = @"YPQuoteAttributeName";

NSString *const YPAttachmentPlaceholder = @"\uFFFC";
// ...
NSString *const YPTruncationPlaceholder = @"\u2026";


@implementation YPLinkAttribute

- (id)copyWithZone:(NSZone *)zone {
    typeof(self) link = [[self.class alloc] init];
    link.highlightColor = self.highlightColor;
    link.highlightBackViewColor = self.highlightBackViewColor;
    link.clickAction = self.clickAction;
    link.checkResult = self.checkResult;
    return link;
}


@end


@implementation YPAttachmentAttribute

- (id)copyWithZone:(NSZone *)zone {
    typeof(self) attachment = [[self.class alloc] init];
    attachment.content = self.content;
    attachment.clickAction = self.clickAction;
    attachment.representString = self.representString;
    return attachment;
}

@end


@implementation YPBorderAttribute

- (id)copyWithZone:(NSZone *)zone {
    typeof(self) border = [[self.class alloc] init];
    border.borderColor = self.borderColor;
    border.borderWidth = self.borderWidth;
    border.fillColor = self.fillColor;
    border.cornerRadius = self.cornerRadius;
    border.insets = self.insets;
    border.borderStyle = self.borderStyle;
    border.underlineColor = self.underlineColor;
    border.underlineWidth = self.underlineWidth;
    border.underlineStyle = self.underlineStyle;
    border.dashPaintedLength = self.dashPaintedLength;
    border.dashNotPaintedLength = self.dashNotPaintedLength;
    return border;
}

@end


@implementation YPQuoteAttribute

- (id)copyWithZone:(NSZone *)zone {
    typeof(self) quote = [[self.class alloc] init];
    quote.quoteColor = self.quoteColor;
    quote.quoteWidth = self.quoteWidth;
    quote.quoteLeft = self.quoteLeft;
    return quote;
}

@end
