//
//  YPSeniorAttribute.h
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/9.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

/************** YPAttributedStringKey attribute name **************/
typedef NSString *YPAttributedStringKey;
//link
UIKIT_EXTERN YPAttributedStringKey const YPLinkAttributeName;
//attatchment
UIKIT_EXTERN YPAttributedStringKey const YPAttachmentAttributeName;
//border
UIKIT_EXTERN YPAttributedStringKey const YPBorderAttributeName;
//quote
UIKIT_EXTERN YPAttributedStringKey const YPQuoteAttributeName;

/************** Utilities **************/
UIKIT_EXTERN NSString *const YPAttachmentPlaceholder;

UIKIT_EXTERN NSString *const YPTruncationPlaceholder;

/************** Blocks **************/
typedef void(^YPActionBlock)(NSAttributedString *attrStr, NSRange textRange);

typedef void(^YPLinkTypeBlock)(NSTextCheckingResult *result, NSAttributedString *attrStr, NSRange textRange);

typedef void(^YPTruncActionBlock)(void);

#pragma mark -- YPLinkAttribute
@interface YPLinkAttribute : NSObject <NSCopying>
/**
 Highlight color when click link.
 */
@property (nonatomic, strong) UIColor *highlightColor;
/**
 Highlight link background color when click link.
 */
@property (nonatomic, strong) UIColor *highlightBackViewColor;
/**
 Click link call back.
 */
@property (nonatomic, copy) YPActionBlock clickAction;

//Auto detect result.
@property (nonatomic, strong) NSTextCheckingResult *checkResult;

@end

#pragma mark -- YPAttachmentAttribute
@interface YPAttachmentAttribute : NSObject <NSCopying>
/**
 Attachment content.
 Temporary support only image, The view will be supported later.
 */
@property (nonatomic, strong) id content;
/**
 Click attachment call back.
 */
@property (nonatomic, copy) YPActionBlock clickAction;

/**
 Current attachment represent string such as emoji image and so on.
 */
@property (nonatomic, strong) NSString *representString;

@end

#pragma mark -- YPBorderAttribute
typedef NS_ENUM(NSInteger, YPBorderStyle) {
    YPBorderNormal,
    YPBorderBlockAround,
    YPBorderBlockTiled
};
typedef NS_ENUM(NSInteger, YPBorderUnderLineStyle) {
    YPBorderUnderLineNormal,
    YPBorderUnderLineDash,
    YPBorderUnderLineCenterNormal,
    YPBorderUnderLineCenterDash
};
@interface YPBorderAttribute : NSObject <NSCopying>
///Border Properties
/**
 Border style.
 Block border style which should only use in paragraph.
 Default normal style.
 */
@property (nonatomic, assign) YPBorderStyle borderStyle;
/**
 Border line color.
 */
@property (nonatomic, strong) UIColor *borderColor;
/**
 Border line width.
 */
@property (nonatomic, assign) CGFloat borderWidth;
/**
 Border corner radius.
 */
@property (nonatomic, assign) CGFloat cornerRadius;
/**
 Border fill color.
 */
@property (nonatomic, strong) UIColor *fillColor;
/**
 Border insets.
 */
@property (nonatomic, assign) UIEdgeInsets insets;

///Underline Properties
/**
 Border underline style.
 */
@property (nonatomic, assign) YPBorderUnderLineStyle underlineStyle;
/**
 Border underline width.
 */
@property (nonatomic, assign) CGFloat underlineWidth;
/**
 Border underline color.
 */
@property (nonatomic, strong) UIColor *underlineColor;
/**
 Border underline dash segment painted length.
 Default length is 4;
 */
@property (nonatomic, assign) CGFloat dashPaintedLength;
/**
 Border underline dash segment not painted length.
 Default length is 4;
 */
@property (nonatomic, assign) CGFloat dashNotPaintedLength;

@end

#pragma mark -- YPQuoteAttribute
@interface YPQuoteAttribute : NSObject <NSCopying>
/**
 Quote color.
 */
@property (nonatomic, strong) UIColor *quoteColor;
/**
 Quote width.
 Default 4.0.
 */
@property (nonatomic, assign) CGFloat quoteWidth;
/**
 Quote distance to the left.
 Default 0.
 */
@property (nonatomic, assign) CGFloat quoteLeft;

@end


