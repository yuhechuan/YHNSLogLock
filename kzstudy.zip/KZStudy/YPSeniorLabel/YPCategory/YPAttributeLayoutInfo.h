//
//  YPAttributeLayoutInfo.h
//  YPSeniorLabel
//
//  Created by doit on 2019/10/16.
//  Copyright © 2019 Yaping Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSMutableArray <NSValue *> YPValuesArray;

@interface YPAttributeLayoutInfo : NSObject

#pragma mark -- General
@property (nonatomic, strong) YPValuesArray *rectValues;

#pragma mark -- Link
/**
 link text range in all attributeString.
 Use to return text range and draw highlight text and background color.
 */
@property (nonatomic, assign) NSRange linkTextRange;

#pragma mark -- Attachment
//draw image and detect click position use this rect
@property (nonatomic, assign) CGRect layoutPosition;

@end

NS_ASSUME_NONNULL_END
