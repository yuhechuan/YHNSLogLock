//
//  NSMutableAttributedString+YP.m
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/6.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import "NSMutableAttributedString+YP.h"
#import <CoreText/CoreText.h>
#import "YPAttributeLayoutInfo.h"

@implementation NSAttributedString (YP)

#pragma mark -- Getter General
//font
- (UIFont *)font {
   return [self fontAtIndex:0];
}
- (UIFont *)fontAtIndex:(NSUInteger)index {
   return [self attribute:NSFontAttributeName atIndex:index];
}

//color
- (UIColor *)color {
    return [self colorAtIndex:0];
}
- (UIColor *)colorAtIndex:(NSUInteger)index {
    UIColor *color = [self attribute:NSForegroundColorAttributeName atIndex:index];
    return color;
}

//backgroundColor
- (UIColor *)backgroundColor {
    return [self backgroundColorAtIndex:0];
}
- (UIColor *)backgroundColorAtIndex:(NSUInteger)index {
    return [self attribute:NSBackgroundColorAttributeName atIndex:0];
}

//underlineStyle
- (NSUnderlineStyle)underlineStyle {
    return [self underlineStyleAtIndex:0];
}
- (NSUnderlineStyle)underlineStyleAtIndex:(NSUInteger)index {
    NSNumber *style = [self attribute:NSUnderlineStyleAttributeName atIndex:index];
    return style.integerValue;
}

//underlineColor
- (UIColor *)underlineColor {
    return [self underlineColorAtIndex:0];
}
- (UIColor *)underlineColorAtIndex:(NSUInteger)index {
    UIColor *color = [self attribute:NSUnderlineColorAttributeName atIndex:index];
    return color;
}

//link
- (YPLinkAttribute *)link {
   return [self attribute:YPLinkAttributeName atIndex:0];
}

//border
- (YPBorderAttribute *)border {
    return [self attribute:YPBorderAttributeName atIndex:0];
}

//quote
- (YPQuoteAttribute *)quote {
    return [self attribute:YPQuoteAttributeName atIndex:0];
}

//shadow
- (NSShadow *)shadow {
    return [self attribute:NSShadowAttributeName atIndex:0];
}

#pragma mark -- Getter ParagraphStyle Property

//paragraphStyle
- (NSParagraphStyle *)paragraphStyle {
    return [self paragraphStyleAtIndex:0];
}
- (NSParagraphStyle *)paragraphStyleAtIndex:(NSUInteger)index {
    NSParagraphStyle *style = [self attribute:NSParagraphStyleAttributeName atIndex:index];
    return style;
}

#define ParagraphStyleGetting(attribute) \
NSParagraphStyle *style = self.paragraphStyle; \
if (!style) style = [NSParagraphStyle defaultParagraphStyle]; \
return style.attribute;
- (CGFloat)lineSpacing {
    ParagraphStyleGetting(lineSpacing);
}
- (NSLineBreakMode)lineBreakMode {
    ParagraphStyleGetting(lineBreakMode);
}
- (NSTextAlignment)alignment {
    ParagraphStyleGetting(alignment);
}
- (CGFloat)minimumLineHeight {
    ParagraphStyleGetting(minimumLineHeight);
}
- (CGFloat)maximumLineHeight {
    ParagraphStyleGetting(maximumLineHeight);
}
- (CGFloat)firstLineHeadIndent {
    ParagraphStyleGetting(firstLineHeadIndent);
}
- (CGFloat)headIndent {
    ParagraphStyleGetting(headIndent);
}
- (CGFloat)tailIndent{
    ParagraphStyleGetting(tailIndent);
}
- (CGFloat)paragraphSpacing {
    ParagraphStyleGetting(paragraphSpacing);
}
- (CGFloat)paragraphSpacingBefore {
    ParagraphStyleGetting(paragraphSpacingBefore);
}
#pragma mark -- Basic

- (id)attribute:(NSString *)attributeName atIndex:(NSUInteger)index {
    if (!attributeName || index > self.length || self.length == 0){
        return nil;
    }
    if (self.length > 0 && index == self.length){
        index--;
    }
    return [self attribute:attributeName atIndex:index effectiveRange:NULL];
}

@end

@implementation NSMutableAttributedString (YP)

#pragma mark -- Mutable Setter General
//font
- (void)setFont:(UIFont *)font {
    [self setFont:font range:NSMakeRange(0, self.length)];
}
- (void)setFont:(UIFont *)font range:(NSRange)range  {
    //In iOS7 and later, UIFont is toll-free bridged to CTFontRef.
    [self configAttribute:NSFontAttributeName value:font range:range];
}

//color
- (void)setColor:(UIColor *)color {
    [self setColor:color range:NSMakeRange(0, self.length)];
}
- (void)setColor:(UIColor *)color range:(NSRange)range {
    [self configAttribute:NSForegroundColorAttributeName value:color range:range];
}

//backgroundColor
- (void)setBackgroundColor:(UIColor *)backgroundColor {
    [self setBackgroundColor:backgroundColor range:NSMakeRange(0, self.length)];
}
- (void)setBackgroundColor:(UIColor *)backgroundColor range:(NSRange)range {
    [self configAttribute:NSBackgroundColorAttributeName value:backgroundColor range:range];
}

//underlineStyle
-(void)setUnderlineStyle:(NSUnderlineStyle)underlineStyle {
    [self setUnderlineStyle:underlineStyle range:NSMakeRange(0, self.length)];
}
-(void)setUnderlineStyle:(NSUnderlineStyle)underlineStyle range:(NSRange)range{
    if (underlineStyle == 0x00) {
        return;
    }
    [self configAttribute:NSUnderlineStyleAttributeName value:@(underlineStyle) range:range];
}

//underlineColor
- (void)setUnderlineColor:(UIColor *)underlineColor {
    [self setUnderlineColor:underlineColor range:NSMakeRange(0, self.length)];
}
- (void)setUnderlineColor:(UIColor *)underlineColor range:(NSRange)range {
    [self configAttribute:NSUnderlineColorAttributeName value:underlineColor range:range];
}

//runDelegate
- (void)setRunDelegate:(CTRunDelegateRef)runDelegate range:(NSRange)range {
    [self configAttribute:(id)kCTRunDelegateAttributeName value:(__bridge id)runDelegate range:range];
}

//link
- (void)setLink:(YPLinkAttribute *)link {
    [self setLink:link range:NSMakeRange(0, self.length)];
}
- (void)setLink:(YPLinkAttribute *)link range:(NSRange)range {
    [self configAttribute:YPLinkAttributeName value:link range:range];
}

//border
- (void)setBorder:(YPBorderAttribute *)border {
    [self setBorder:border range:NSMakeRange(0, self.length)];
}
- (void)setBorder:(YPBorderAttribute *)border range:(NSRange)range {
    [self configAttribute:YPBorderAttributeName value:border range:range];
}

//quote
- (void)setQuote:(YPQuoteAttribute *)quote {
    [self setQuote:quote range:NSMakeRange(0, self.length)];
}
- (void)setQuote:(YPQuoteAttribute *)quote range:(NSRange)range {
    [self configAttribute:YPQuoteAttributeName value:quote range:range];
}

//shadow
- (void)setShadow:(NSShadow *)shadow {
    [self setShadow:shadow range:NSMakeRange(0, self.length)];
}
- (void)setShadow:(NSShadow *)shadow range:(NSRange)range {
    [self configAttribute:NSShadowAttributeName value:shadow range:range];
}

#pragma mark -- Mutable Setter ParagraphStyle Property

//paragraphStyle
- (void)setParagraphStyle:(NSParagraphStyle *)paragraphStyle {
    [self setParagrphStyle:paragraphStyle range:NSMakeRange(0, self.length)];
}
- (void)setParagrphStyle:(NSParagraphStyle *)paragraphStyle range:(NSRange)range {
   //NSParagraphStyle are supported on CoreText and UIKit.
    [self configAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:range];
}

#define ParagraphStyleSetting(_property_name) \
[self enumerateAttribute:NSParagraphStyleAttributeName \
inRange:range \
options:kNilOptions \
usingBlock: ^(NSParagraphStyle *value, NSRange subRange, BOOL *stop) { \
    NSMutableParagraphStyle *style = nil; \
    if (value) { \
        if (CFGetTypeID((__bridge CFTypeRef)(value)) == CTParagraphStyleGetTypeID()) { \
            value = [self styleWithCTStyle:(__bridge CTParagraphStyleRef)(value)]; \
        } \
        if (value._property_name == _property_name) return; \
        if ([value isKindOfClass:[NSMutableParagraphStyle class]]) { \
            style = (id)value; \
        } else { \
            style = value.mutableCopy; \
        } \
    } else { \
        if ([NSParagraphStyle defaultParagraphStyle]._property_name == _property_name) return; \
        style = [NSParagraphStyle defaultParagraphStyle].mutableCopy; \
    } \
    style._property_name = _property_name; \
    [self setParagrphStyle:style range:subRange]; \
}];
//lineSpacing
- (void)setLineSpacing:(CGFloat)lineSpacing {
    [self setLineSpacing:lineSpacing range:NSMakeRange(0, self.length)];
}
- (void)setLineSpacing:(CGFloat)lineSpacing range:(NSRange)range {
    ParagraphStyleSetting(lineSpacing);
}
//lineBreakMode
- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    [self setLineBreakMode:lineBreakMode range:NSMakeRange(0, self.length)];
}
- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode range:(NSRange)range {
    ParagraphStyleSetting(lineBreakMode);
}
//minimumLineHeight
- (void)setMinimumLineHeight:(CGFloat)minimumLineHeight {
    [self setMinimumLineHeight:minimumLineHeight range:NSMakeRange(0, self.length)];
}
- (void)setMinimumLineHeight:(CGFloat)minimumLineHeight range:(NSRange)range {
    ParagraphStyleSetting(minimumLineHeight);
}
//maximumLineHeight
-(void)setMaximumLineHeight:(CGFloat)maximumLineHeight {
    [self setMaximumLineHeight:maximumLineHeight range:NSMakeRange(0, self.length)];
}
- (void)setMaximumLineHeight:(CGFloat)maximumLineHeight range:(NSRange)range {
    ParagraphStyleSetting(maximumLineHeight);
}
//alignment
- (void)setAlignment:(NSTextAlignment)alignment {
    [self setAlignment:alignment range:NSMakeRange(0, self.length)];
}
- (void)setAlignment:(NSTextAlignment)alignment range:(NSRange)range {
    ParagraphStyleSetting(alignment);
}
//firstLineHeadIndent
- (void)setFirstLineHeadIndent:(CGFloat)firstLineHeadIndent {
    [self setFirstLineHeadIndent:firstLineHeadIndent range:NSMakeRange(0, self.length)];
}
- (void)setFirstLineHeadIndent:(CGFloat)firstLineHeadIndent range:(NSRange)range {
    ParagraphStyleSetting(firstLineHeadIndent);
}
//headIndent
- (void)setHeadIndent:(CGFloat)headIndent {
    [self setHeadIndent:headIndent range:NSMakeRange(0, self.length)];
}
- (void)setHeadIndent:(CGFloat)headIndent range:(NSRange)range {
    ParagraphStyleSetting(headIndent);
}
//tailIndent
- (void)setTailIndent:(CGFloat)tailIndent {
    [self setTailIndent:tailIndent range:NSMakeRange(0, self.length)];
}
- (void)setTailIndent:(CGFloat)tailIndent range:(NSRange)range {
    ParagraphStyleSetting(tailIndent);
}
//paragraphSpacing
- (void)setParagraphSpacing:(CGFloat)paragraphSpacing {
    [self setParagraphSpacing:paragraphSpacing range:NSMakeRange(0, self.length)];
}
- (void)setParagraphSpacing:(CGFloat)paragraphSpacing range:(NSRange)range {
    ParagraphStyleSetting(paragraphSpacing);
}
//paragraphSpacingBefore
- (void)setParagraphSpacingBefore:(CGFloat)paragraphSpacingBefore {
    [self setParagraphSpacingBefore:paragraphSpacingBefore range:NSMakeRange(0, self.length)];
}
- (void)setParagraphSpacingBefore:(CGFloat)paragraphSpacingBefore range:(NSRange)range {
    ParagraphStyleSetting(paragraphSpacingBefore);
}

- (NSParagraphStyle *)styleWithCTStyle:(CTParagraphStyleRef)CTStyle {
    if (CTStyle == NULL) return [NSParagraphStyle defaultParagraphStyle];
    
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    CGFloat lineSpacing;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierLineSpacing, sizeof(CGFloat), &lineSpacing)) {
        style.lineSpacing = lineSpacing;
    }
#pragma clang diagnostic pop
    
    CGFloat paragraphSpacing;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierParagraphSpacing, sizeof(CGFloat), &paragraphSpacing)) {
        style.paragraphSpacing = paragraphSpacing;
    }
    
    CTTextAlignment alignment;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierAlignment, sizeof(CTTextAlignment), &alignment)) {
        style.alignment = NSTextAlignmentFromCTTextAlignment(alignment);
    }
    
    CGFloat firstLineHeadIndent;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierFirstLineHeadIndent, sizeof(CGFloat), &firstLineHeadIndent)) {
        style.firstLineHeadIndent = firstLineHeadIndent;
    }
    
    CGFloat headIndent;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierHeadIndent, sizeof(CGFloat), &headIndent)) {
        style.headIndent = headIndent;
    }
    
    CGFloat tailIndent;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierTailIndent, sizeof(CGFloat), &tailIndent)) {
        style.tailIndent = tailIndent;
    }
    
    CTLineBreakMode lineBreakMode;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierLineBreakMode, sizeof(CTLineBreakMode), &lineBreakMode)) {
        style.lineBreakMode = (NSLineBreakMode)lineBreakMode;
    }
    
    CGFloat minimumLineHeight;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierMinimumLineHeight, sizeof(CGFloat), &minimumLineHeight)) {
        style.minimumLineHeight = minimumLineHeight;
    }
    
    CGFloat maximumLineHeight;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierMaximumLineHeight, sizeof(CGFloat), &maximumLineHeight)) {
        style.maximumLineHeight = maximumLineHeight;
    }
    
    CTWritingDirection baseWritingDirection;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierBaseWritingDirection, sizeof(CTWritingDirection), &baseWritingDirection)) {
        style.baseWritingDirection = (NSWritingDirection)baseWritingDirection;
    }
    
    CGFloat lineHeightMultiple;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierLineHeightMultiple, sizeof(CGFloat), &lineHeightMultiple)) {
        style.lineHeightMultiple = lineHeightMultiple;
    }
    
    CGFloat paragraphSpacingBefore;
    if (CTParagraphStyleGetValueForSpecifier(CTStyle, kCTParagraphStyleSpecifierParagraphSpacingBefore, sizeof(CGFloat), &paragraphSpacingBefore)) {
        style.paragraphSpacingBefore = paragraphSpacingBefore;
    }
    
    return style;
}

#pragma mark -- Method

- (void)configHighLightColor:(nullable UIColor *)highlightColor
            tapBackViewColor:(nullable UIColor *)tapBackViewColor
                 clickAction:(nullable YPActionBlock)clickAction {
    
    YPLinkAttribute *linkAttr = [[YPLinkAttribute alloc] init];
    linkAttr.highlightColor = highlightColor;
    linkAttr.clickAction = clickAction;
    linkAttr.highlightBackViewColor = tapBackViewColor;
    
    [self setLink:linkAttr range:NSMakeRange(0, self.length)];
}

- (void)configBorderWithBorderStyle:(YPBorderStyle)borderStyle
                        borderColor:(nullable UIColor *)borderColor
                        borderWidth:(CGFloat)borderWidth
                        conerRadius:(NSInteger)conerRadius
                          fillColor:(nullable UIColor *)fillColor
                             insets:(UIEdgeInsets)insets {

    YPBorderAttribute *borderAttr = [[YPBorderAttribute alloc] init];
    borderAttr.borderStyle = borderStyle;
    borderAttr.borderColor = borderColor;
    borderAttr.borderWidth = borderWidth;
    borderAttr.cornerRadius = conerRadius;
    borderAttr.fillColor = fillColor;
    borderAttr.insets = insets;
    [self setBorder:borderAttr range:NSMakeRange(0, self.length)];

}

- (void)configQuoteWithQuoteColor:(nullable UIColor *)quoteColor
                       quoteWidth:(CGFloat)quoteWidth
                        quoteLeft:(CGFloat)quoteLeft {
    YPQuoteAttribute *quote = [[YPQuoteAttribute alloc] init];
    quote.quoteColor = quoteColor;
    quote.quoteWidth = quoteWidth;
    quote.quoteLeft = quoteLeft;
    [self setQuote:quote range:NSMakeRange(0, self.length)];
}

+ (NSMutableAttributedString *)configAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                                 alignToFont:(UIFont *)font
                                         attachmentAlignment:(YPAttachmentAlignment)attachmentAlignment
                                                 clickAction:(nullable YPActionBlock)clickAction
{
    return [self configAttachmentStringContent:content attachmentSize:attachmentSize representString:nil alignToFont:font attachmentAlignment:attachmentAlignment clickAction:clickAction];
}

+ (NSMutableAttributedString *)configAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                             representString:(NSString *)representString
                                                 alignToFont:(UIFont *)font
                                         attachmentAlignment:(YPAttachmentAlignment)attachmentAlignment
                                                 clickAction:(nullable YPActionBlock)clickAction
{
    NSMutableAttributedString *attachmentAttrStr = [[NSMutableAttributedString alloc] initWithString:YPAttachmentPlaceholder];
    
    YPAttachmentAttribute *attachment = [[YPAttachmentAttribute alloc] init];
    attachment.content = content;
    attachment.clickAction = clickAction;
    attachment.representString = representString;
    [attachmentAttrStr configAttribute:YPAttachmentAttributeName value:attachment range:NSMakeRange(0, attachmentAttrStr.length)];
    
    CTRunDelegateCallbacks callBacks;
    callBacks.version = kCTRunDelegateVersion1;
    callBacks.getAscent = ascentCallBacks;
    callBacks.getDescent = descentCallBacks;
    callBacks.getWidth = widthCallBacks;
    callBacks.dealloc = deallocCallback;
    //attachmentAlignment
    CGFloat ascent = attachmentSize.height;
    CGFloat descent = 0;
    switch (attachmentAlignment)
    {
        case YPAttachmentAlignmentTop:
        {
            ascent = font.ascender;
            descent = attachmentSize.height - font.ascender;
            if (descent < 0) {
                descent = 0;
                ascent = attachmentSize.height;
            }
        }
            break;
        case YPAttachmentAlignmentCenter:
        {
            CGFloat fontHeight = font.ascender - font.descender;
            CGFloat yFontOffset = font.ascender - fontHeight * 0.5;
            ascent = attachmentSize.height * 0.5 + yFontOffset;
            descent = attachmentSize.height - ascent;
            if (descent < 0) {
                descent = 0;
                ascent = attachmentSize.height;
            }
        }
            break;
        case YPAttachmentAlignmentBottom:
        {
            ascent = attachmentSize.height + font.descender;
            descent = -font.descender;
            if (ascent < 0) {
                ascent = 0;
                descent = attachmentSize.height;
            }
        }
            break;
    }
    
    NSDictionary *delegateDic = @{@"ascent":@(ascent),@"width":@(attachmentSize.width),@"descent":@(descent)};
    CTRunDelegateRef runDelegate = CTRunDelegateCreate(&callBacks, (__bridge_retained void *)delegateDic);
    [attachmentAttrStr setRunDelegate:runDelegate range:NSMakeRange(0, attachmentAttrStr.length)];
    
    CFRelease(runDelegate);
    return attachmentAttrStr;
}

+ (NSMutableAttributedString *)configEmojiStringImage:(UIImage *)image
                                            imageSize:(CGSize)imageSize
                                          alignToFont:(UIFont *)font
                                          emojiString:(NSString *)emojiString {
    
    NSMutableAttributedString *emojiAttrStr = [[NSMutableAttributedString alloc] initWithString:YPAttachmentPlaceholder];

    YPAttachmentAttribute *attachment = [[YPAttachmentAttribute alloc] init];
    attachment.content = image;
    attachment.representString = emojiString;
    [emojiAttrStr configAttribute:YPAttachmentAttributeName value:attachment range:NSMakeRange(0, emojiAttrStr.length)];
    // 设置占位符
    CTRunDelegateCallbacks callBacks;
    callBacks.version = kCTRunDelegateVersion1;
    callBacks.getAscent = ascentCallBacks;
    callBacks.getDescent = descentCallBacks;
    callBacks.getWidth = widthCallBacks;
    callBacks.dealloc = deallocCallback;
    CGSize attachmentSize = CGSizeEqualToSize(imageSize, CGSizeZero) ? image.size : imageSize;
    CGFloat fontHeight = font.ascender - font.descender;
    CGFloat yFontOffset = font.ascender - fontHeight * 0.5;
    CGFloat ascent = attachmentSize.height * 0.5 + yFontOffset;
    CGFloat descent = attachmentSize.height - ascent;
    NSDictionary *delegateDic = @{@"ascent":@(ascent),@"width":@(attachmentSize.width),@"descent":@(descent)};
    CTRunDelegateRef runDelegate = CTRunDelegateCreate(&callBacks, (__bridge_retained void *)delegateDic);
    [emojiAttrStr setRunDelegate:runDelegate range:NSMakeRange(0, emojiAttrStr.length)];
    
    CFRelease(runDelegate);

    return emojiAttrStr;
}

#pragma mark -- Mutable Basic
- (void)configAttribute:(NSString *)name value:(id)value range:(NSRange)range {
    if (!name || [NSNull isEqual:name] || !value || [NSNull isEqual:value]) {
        return;
    }
    if (range.location + range.length > self.length) {
        return;
    }
    [self addAttribute:name value:value range:range];
}

#pragma mark -- Private

static CGFloat ascentCallBacks(void *refCon){
    return [(NSNumber *)[(__bridge NSDictionary *)refCon valueForKey:@"ascent"] floatValue];
    
}
static CGFloat descentCallBacks(void *refCon){
    return [(NSNumber *)[(__bridge NSDictionary *)refCon valueForKey:@"descent"] floatValue];
}
static CGFloat widthCallBacks(void *refCon){
    
    return [(NSNumber *)[(__bridge NSDictionary *)refCon valueForKey:@"width"] floatValue];
}
static void deallocCallback(void *ref) {
    NSDictionary *dic = (__bridge_transfer NSDictionary *)(ref);
    dic = nil; // release
}

@end
