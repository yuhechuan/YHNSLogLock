//
//  NSMutableAttributedString+YP.h
//  MediaLayerDemo
//
//  Created by Yaping Liu on 2017/5/6.
//  Copyright © 2017年 Yaping Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YPSeniorAttribute.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, YPAttachmentAlignment) {
    YPAttachmentAlignmentTop,
    YPAttachmentAlignmentCenter,
    YPAttachmentAlignmentBottom
};


@interface NSAttributedString (YP)

@property (nonatomic, strong, readonly) UIFont *font;

@property (nonatomic, strong, readonly) UIColor *color;

@property (nonatomic, strong, readonly) UIColor *backgroundColor;

@property (nonatomic, assign, readonly) NSUnderlineStyle underlineStyle;

@property (nonatomic, strong, readonly) UIColor *underlineColor;

@property (nonatomic, strong, readonly) NSParagraphStyle *paragraphStyle;

@property (nonatomic, assign, readonly) CGFloat lineSpacing;

@property (nonatomic, assign, readonly) CGFloat minimumLineHeight;

@property (nonatomic, assign, readonly) CGFloat maximumLineHeight;

@property (nonatomic, assign, readonly) NSTextAlignment alignment;

@property (nonatomic, assign, readonly) NSLineBreakMode lineBreakMode;

@property (nonatomic, assign, readonly) CGFloat firstLineHeadIndent;

@property (nonatomic, assign, readonly) CGFloat headIndent;

@property (nonatomic, assign, readonly) CGFloat tailIndent;

@property (nonatomic, assign, readonly) CGFloat paragraphSpacing;

@property (nonatomic, assign, readonly) CGFloat paragraphSpacingBefore;

@property (nonatomic, strong, readonly) YPLinkAttribute *link;

@property (nonatomic, strong, readonly) YPBorderAttribute *border;

@property (nonatomic, strong, readonly) YPQuoteAttribute *quote;

@property (nonatomic, strong, readonly) NSShadow *shadow;

@end


@interface NSMutableAttributedString (YP)
#pragma mark -- General Properties
//font
@property (nonatomic, strong, readwrite) UIFont *font;
- (void)setFont:(UIFont *)font range:(NSRange)range;
//color
@property (nonatomic, strong, readwrite) UIColor *color;
- (void)setColor:(UIColor *)color range:(NSRange)range;
//backgroundColor
@property (nonatomic, strong, readwrite) UIColor *backgroundColor;
- (void)setBackgroundColor:(UIColor *)backgroundColor range:(NSRange)range;
//underlineStyle
@property (nonatomic, assign, readwrite) NSUnderlineStyle underlineStyle;
-(void)setUnderlineStyle:(NSUnderlineStyle)underlineStyle range:(NSRange)range;
//underlineColor
@property (nonatomic, strong, readwrite) UIColor *underlineColor;
- (void)setUnderlineColor:(UIColor *)underlineColor range:(NSRange)range;
//paragraphStyle
@property (nonatomic, strong, readwrite) NSParagraphStyle *paragraphStyle;
//link
@property (nonatomic, strong, readwrite) YPLinkAttribute *link;
- (void)setLink:(YPLinkAttribute *)link range:(NSRange)range;
//border
@property (nonatomic, strong, readwrite) YPBorderAttribute *border;
- (void)setBorder:(YPBorderAttribute *)border range:(NSRange)range;
//quote
@property (nonatomic, strong, readwrite) YPQuoteAttribute *quote;
- (void)setQuote:(YPQuoteAttribute *)quote range:(NSRange)range;
//shadow
@property (nonatomic, strong, readwrite) NSShadow *shadow;
- (void)setShadow:(NSShadow *)shadow range:(NSRange)range;

#pragma mark -- Paragraph Style Properties
//lineSpacing
@property (nonatomic, assign, readwrite) CGFloat lineSpacing;
- (void)setLineSpacing:(CGFloat)lineSpacing range:(NSRange)range;
//minimumLineHeight
@property (nonatomic, assign, readwrite) CGFloat minimumLineHeight;
- (void)setMinimumLineHeight:(CGFloat)minimumLineHeight range:(NSRange)range;
//maximumLineHeight
@property (nonatomic, assign, readwrite) CGFloat maximumLineHeight;
- (void)setMaximumLineHeight:(CGFloat)maximumLineHeight range:(NSRange)range;
//alignment
@property (nonatomic, assign, readwrite) NSTextAlignment alignment;
- (void)setAlignment:(NSTextAlignment)alignment range:(NSRange)range;
//NSLineBreakMode
@property (nonatomic, assign, readwrite) NSLineBreakMode lineBreakMode;
- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode range:(NSRange)range;
//firstLineHeadIndent
@property (nonatomic, assign, readwrite) CGFloat firstLineHeadIndent;
- (void)setFirstLineHeadIndent:(CGFloat)firstLineHeadIndent range:(NSRange)range;
//headIndent
@property (nonatomic, assign, readwrite) CGFloat headIndent;
- (void)setHeadIndent:(CGFloat)headIndent range:(NSRange)range;
//tailIndent
@property (nonatomic, assign, readwrite) CGFloat tailIndent;
- (void)setTailIndent:(CGFloat)tailIndent range:(NSRange)range;
//paragraphSpacing
@property (nonatomic, assign, readwrite) CGFloat paragraphSpacing;
- (void)setParagraphSpacing:(CGFloat)paragraphSpacing range:(NSRange)range;
//paragraphSpacingBefore
@property (nonatomic, assign, readwrite) CGFloat paragraphSpacingBefore;
- (void)setParagraphSpacingBefore:(CGFloat)paragraphSpacingBefore range:(NSRange)range;

#pragma mark -- Commen Methods

/**
 Config link
 
 @param highlightColor      highlight color
 @param tapBackViewColor    click back view color
 @param clickAction         click action call back
 
 */
- (void)configHighLightColor:(nullable UIColor *)highlightColor
            tapBackViewColor:(nullable UIColor *)tapBackViewColor
                 clickAction:(nullable YPActionBlock)clickAction;

/**
 Config border
 @param borderStyle     border style
 @param borderColor     border color
 @param borderWidth     border width
 @param conerRadius     conerRadius
 @param fillColor       fillColor
 
 */
- (void)configBorderWithBorderStyle:(YPBorderStyle)borderStyle
                        borderColor:(nullable UIColor *)borderColor
                        borderWidth:(CGFloat)borderWidth
                        conerRadius:(NSInteger)conerRadius
                          fillColor:(nullable UIColor *)fillColor
                             insets:(UIEdgeInsets)insets;
/**
 Config quote
 @param quoteColor     quote color
 @param quoteWidth     quote width
 @param quoteLeft     quote left
 */
- (void)configQuoteWithQuoteColor:(nullable UIColor *)quoteColor
                       quoteWidth:(CGFloat)quoteWidth
                        quoteLeft:(CGFloat)quoteLeft;

/**
 Config attachment
 
 @param content                 Support view / layer / image.
 @param attachmentSize          The content size.
 @param font                    The content will align to the font.
 @param attachmentAlignment     Alignment.
 @param clickAction             Click action call back.
 
 return attachment's attributed string

 */
+ (NSMutableAttributedString *)configAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                                 alignToFont:(UIFont *)font
                                         attachmentAlignment:(YPAttachmentAlignment)attachmentAlignment
                                                 clickAction:(nullable YPActionBlock)clickAction;

/**
 Config attachment
 
 @param content                 Support view / layer / image.
 @param attachmentSize          The content size.
 @param representString         When select will auto replace attachment with `representString`.
 @param font                    The content will align to the font.
 @param attachmentAlignment     Alignment.
 @param clickAction             Click action call back.
 
 return attachment's attributed string

 */
+ (NSMutableAttributedString *)configAttachmentStringContent:(id)content
                                              attachmentSize:(CGSize)attachmentSize
                                             representString:(nullable NSString *)representString
                                                 alignToFont:(UIFont *)font
                                         attachmentAlignment:(YPAttachmentAlignment)attachmentAlignment
                                                 clickAction:(nullable YPActionBlock)clickAction;

/**
 Config Emoji
 
 @param image           Image.
 @param imageSize       Image size.
 @param font            The content will align to the font.
 @param emojiString     A string used for original emoji string.
 
 return image's attributed string
 */

+ (NSMutableAttributedString *)configEmojiStringImage:(UIImage *)image
                                            imageSize:(CGSize)imageSize
                                          alignToFont:(UIFont *)font
                                          emojiString:(NSString *)emojiString;

@end

NS_ASSUME_NONNULL_END
