//
//  YPMenuController+Tooltip.m
//  YPMenuController
//
//  Created by doit on 2019/9/7.
//

#import "YPMenuController+Tooltip.h"

@implementation YPMenuController (Tooltip)

+ (void)showToolTipInPosition:(CGPoint)position
                  toolTipSize:(CGSize)toolTipSize
                  contentAttr:(NSAttributedString *)contentAttr
{
    [self showToolTipInPosition:position
                    toolTipSize:toolTipSize
             barBackgroundColor:[UIColor.blackColor colorWithAlphaComponent:0.6]
                    contentAttr:contentAttr];
}


+ (void)showToolTipInPosition:(CGPoint)position
                  toolTipSize:(CGSize)toolTipSize
           barBackgroundColor:(UIColor *)barBackgroundColor
                  contentAttr:(NSAttributedString *)contentAttr
{
    if (!contentAttr) {
        return;
    }
    YPMenuStyleConfig *config = [[YPMenuStyleConfig alloc] init];
    config.menuType = YPMenuControllerCustom;
    config.barContentHeight = toolTipSize.height;
    config.barBackgroundColor = barBackgroundColor;
    
    UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, toolTipSize.width, toolTipSize.height)];
    contentLabel.backgroundColor = [UIColor clearColor];
    contentLabel.numberOfLines = 0;
    contentLabel.attributedText = contentAttr;

    NSArray *menus = @[[[YPMenuItem alloc] initWithCustomView:contentLabel]];
    [YPMenuController sharedMenuController].styleConfig = config;
    [YPMenuController sharedMenuController].menuItems = menus;
    [[YPMenuController sharedMenuController] menuVisibleInView:contentLabel windowRect:CGRectMake(position.x, position.y, 0, 0) animated:YES];
}

@end
