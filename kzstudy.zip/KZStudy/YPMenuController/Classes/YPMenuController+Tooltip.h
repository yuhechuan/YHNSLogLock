//
//  YPMenuController+Tooltip.h
//  YPMenuController
//
//  Created by doit on 2019/9/7.
//

#import "YPMenuController.h"

NS_ASSUME_NONNULL_BEGIN

@interface YPMenuController (Tooltip)

+ (void)showToolTipInPosition:(CGPoint)position
                  toolTipSize:(CGSize)toolTipSize
                  contentAttr:(NSAttributedString *)contentAttr;


+ (void)showToolTipInPosition:(CGPoint)position
                  toolTipSize:(CGSize)toolTipSize
           barBackgroundColor:(UIColor *)barBackgroundColor
                  contentAttr:(NSAttributedString *)contentAttr;

@end

NS_ASSUME_NONNULL_END
