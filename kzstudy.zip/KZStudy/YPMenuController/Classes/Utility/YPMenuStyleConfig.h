//
//  YPMenuStyleConfig.h
//
//  Created by Yaping Liu on 3/26/19.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "YPMenuComponets.h"

NS_ASSUME_NONNULL_BEGIN

@interface YPMenuStyleConfig : NSObject
#pragma mark -- Bar properties
/**
 Menu type.
 The default is `YPMenuControllerSystem`.
 */
@property (nonatomic, assign) YPMenuControllerType menuType;
/**
 Arrow direction.
 The default is `YPMenuControllerArrowDefault`.
 */
@property (nonatomic, assign) YPMenuControllerArrowDirection arrowDirection;
/*
 The default is YES.
 */
@property (nonatomic, assign) BOOL autoDismiss;
/*
 The default is YES.
 The default is not catch event
 */
@property (nonatomic, assign) BOOL breakThroughEvent;
/**
 Bar content height.
 The default is automatically calculated based on `menuType`.
 */
@property (nonatomic, assign) CGFloat barContentHeight;
/**
 Bar background color.
 The default is red:31 green:31 blue:31 alpha:0.96.
 */
@property (nonatomic, strong) UIColor *barBackgroundColor;
/**
 Bar shadow color.
 The default is grayColor.
 */
@property (nonatomic, strong) UIColor *barShadowColor;

/**
 The shadow offset. Defaults to (0, 0).
 */

@property (nonatomic, assign)  CGSize barShadowOffset;

/**
 The blur radius used to create the shadow. Defaults to 3.
 */

@property (nonatomic, assign)  CGFloat barShadowRadius;
/**
 Bar dismis delay interval.
 The default is 0.
 */
@property (nonatomic, assign) NSTimeInterval barDismissDelayInterval;
/**
 Bar to top of window distance,
 when less than this distance will not show menu.
 The default is status bar height.
 */
@property (nonatomic, assign) CGFloat topLimitMargin;

#pragma mark -- Menu button properties
/****
 Notice:
 The properties in this section is invalid when `menuType` is `YPMenuControllerCustom`.
 */

/**
 Spacing between image and title.
 The default is 5.
 */
@property (nonatomic, assign) CGFloat contentSpace;
/**
 Menu button content edge insets.
 The default is UIEdgeInsetsMake(0, 15, 0, 15).
 */
@property (nonatomic, assign) UIEdgeInsets menuContentEdge;
/**
 Title color.
 The default is whiteColor.
 */
@property (nonatomic, strong) UIColor *titleColor;
/**
 Touch highlight color.
 The default is lightGrayColor.
 */
@property (nonatomic, strong) UIColor *backHighlightColor;

/**
 Title font.
 The default is system font with 14 size.
 */
@property (nonatomic, strong) UIFont *titleFont;


#pragma mark -- Separator properties

/**
 Separator line color.
 The default is whiteColor.
 */
@property (nonatomic, strong) UIColor *separatorLineColor;

/**
 Separator line top and bottom margin.
 The default is 11.
 */
@property (nonatomic, assign) CGFloat separatorLineMargin;

/**
 Separator line width.
 The default is 1.
 */
@property (nonatomic, assign) CGFloat separatorLineWidth;


#pragma mark -- Other properties
/**
 Skip button triangle image color.
 The default is whiteColor.
 */
@property (nonatomic, strong) UIColor *skipTriangleColor;



@end

NS_ASSUME_NONNULL_END
