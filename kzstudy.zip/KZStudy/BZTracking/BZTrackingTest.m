//
//  BZTrackingTest.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/29.
//

#import "BZTrackingTest.h"
#import "KZTrackingManager.h"

@interface BZTrackingTest ()<KZTrackingDelegate>

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) int testCount;


@end

@implementation BZTrackingTest

- (instancetype)init {
    if (self = [super init]) {
        [KZTrackingManager sharedTracking].delegate = self;
        self.testCount = 1000;
        //[self addTimerAction];
    }
    return self;
}

- (void)addTimerAction {
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(NSTimer * _Nonnull timer) {
        for (int i = 0; i < self.testCount; i ++) {
            [self addMergeTrackingData:@{@"key": @"timer"}];
        }
    }];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}


- (void)test1 {
    for (int i = 0; i < self.testCount; i ++) {
        [self addMergeTrackingData:@{@"key": @(i)}];
    }
}

- (void)test2 {
    for (int i = 0; i < self.testCount; i ++) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self addMergeTrackingData:@{@"key": @(i)}];
        });
    }
}

- (void)test3 {
    for (int i = 0; i < self.testCount; i ++) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self addMergeTrackingData:@{@"key": @(i)}];
        });
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self addMergeTrackingData:@{@"key": @(i + 1000)}];
        });
    }
}

- (void)test4 {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        for (int i = 0; i < self.testCount; i ++) {
            [self addMergeTrackingData:@{@"key": @(i)}];
        }
    });
    
    for (int i = 0; i < self.testCount; i ++) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self addMergeTrackingData:@{@"key": @(i)}];
        });
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        for (int i = 0; i < self.testCount; i ++) {
            [self addMergeTrackingData:@{@"key": @(i)}];
        }
    });
    
    
    dispatch_async(dispatch_queue_create("BZTrackingTest1", DISPATCH_QUEUE_SERIAL), ^{
        for (int i = 0; i < self.testCount; i ++) {
            [self addMergeTrackingData:@{@"key": @(i)}];
        }
    });
    
    dispatch_async(dispatch_queue_create("BZTrackingTest2", DISPATCH_QUEUE_CONCURRENT), ^{
        for (int i = 0; i < self.testCount; i ++) {
            [self addMergeTrackingData:@{@"key": @(i)}];
        }
    });
}

- (void)test5 {
    for (int i = 0; i < self.testCount; i ++) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self addMergeTrackingData:@{@"key": @(i)}];
        });
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        for (int i = 0; i < self.testCount; i ++) {
            [self addMergeTrackingData:@{@"key": @(i)}];
        }
    });
}

- (void)addMergeTrackingData:(NSDictionary *)dict {
    [[KZTrackingManager sharedTracking] addMergeTrackingData:dict];
}

- (void)startBatchTrackingUpload:(NSArray *)parameters response:(KZTrackingResponse)response {
    NSLog(@"startBatchTrackingUpload: %lu 个", (unsigned long)parameters.count);
}

@end
