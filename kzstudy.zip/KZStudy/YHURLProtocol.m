//
//  YHURLProtocol.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/15.
//

#import "YHURLProtocol.h"

static NSString * const kzNetworkHasRequestKey = @"KZTracking.KZNSURLHTTPProtocol.hasRequstKey";

@implementation YHURLProtocol


+ (void)load {
    [NSURLProtocol registerClass:[YHURLProtocol class]];
}

+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    //basic
    if (!request || !request.URL || !request.URL.scheme) {
        return NO;
    }
    //scheme
    NSString *schemeLowercaseString = [[request URL] scheme].lowercaseString;
    if(![schemeLowercaseString isEqualToString:@"http"] && ![schemeLowercaseString isEqualToString:@"https"]) {
        return NO;
    }
    if ([self propertyForKey:kzNetworkHasRequestKey inRequest:request]) {
        return NO;
    }
    NSString *absoluteString = [[request URL] absoluteString];

    NSArray <NSString *>*holdupList = @[];
    for (NSString *api in holdupList) {
        if ([absoluteString isEqualToString:api]) {
            return YES;
        }
    }
    //property
    return NO;
}

+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request {
    NSMutableURLRequest *mutableRequest = request.mutableCopy;
    [self setProperty:@YES forKey:kzNetworkHasRequestKey inRequest:mutableRequest];
    return mutableRequest;
}

- (instancetype)initWithRequest:(NSURLRequest *)request cachedResponse:(nullable NSCachedURLResponse *)cachedResponse client:(nullable id <NSURLProtocolClient>)client {
    return [super initWithRequest:request cachedResponse:cachedResponse client:client];;
}

// 开始请求
- (void)startLoading {
}

// 取消请求
- (void)stopLoading {
}

@end
