struct _NSRange{
    ulong location;
    ulong length;
};

// 职位排序 解决 参数组装错误问题 玉河川
class native BBSortPosiListDSM {
    function findSectionInfoWithType_(sectionType) {
        NSLog("=========================yuhechuan hook method findSectionInfoWithType========================");
        var begin = 0;
        var end = self.sortDS.count();
        var maxShowCount = self.showSectionMaxCount();
        if (sectionType == 1 && end > maxShowCount) {
            end = maxShowCount;
        }
        if (sectionType == 2) {
            begin = maxShowCount;
        }

        var positions = NSMutableArray.alloc().init();
        var i = begin;
        while (i < end) {
            positions.addObject_(self.sortDS.objectAtIndex_(i));
            i = i + 1;
        }
        return positions;
    }
}
// 高搜关键词 热标 灰度问题 玉河川
class native BBAdvanceTabKeywordHandler {
    static function keywordGroupExpandStatus_expandLineCount_(sectionInfo,expandLineCount) {
        NSLog("=========================yuhechuan hook method========================");
        var contentMaxWidth = appGetScreenContentWidth() - 2 * 20;
        var keywordFont = BBAdvanceTabHKCellItemView.itemKeywordFont();
        var tagMarginL = BBAdvanceTabHKCellItemView.itemHotTagMarginLeft();
        var tagSize = BBAdvanceTabHKCellItemView.itemHotTagSize();
        var arrSize = BBAdvanceTabHKCellItemView.arrowImgSize();

        var allCount = 0;
        var i = 0;
        var rowsInfo = NSMutableArray.alloc().init();
        var rowsInfoCount = sectionInfo.rowsInfo().count();
        while (allCount < rowsInfoCount) {
            var isOver = 0;
            var currWidth = 0;
            var lineArr = NSMutableArray.alloc().init();
            while (allCount < rowsInfoCount) {
                var itemInfo = sectionInfo.rowsInfo().objectAtIndex_(allCount);
                
                if (StringIsNullOrEmpty(itemInfo.showTitle())) {
                    allCount = allCount + 1;
                    continue;
                }
                var dict = new NSMutableDictionary;
                dict.setObject_forKey_(keywordFont,"NSFont");
                var twidth = itemInfo.showTitle().sizeWithAttributes_(dict).width();
                var needWidth = ceil(twidth) + 12 + 12;
                BOOL showHot = StringNotNullAndEmpty(itemInfo.itemInfo().iconUrl());
                if ((sectionInfo.groupType() == 1 || sectionInfo.groupType() == 2) && showHot) {
                    needWidth = needWidth + ceil(tagMarginL) + ceil(tagSize.width);
                }
                
                if (lineArr.count() == 0) { // 当前行还没有内容
                    var minw = needWidth;
                    if (minw > contentMaxWidth) {
                        minw = contentMaxWidth;
                    }
                    itemInfo.setItemSize_(CGSizeMake(minw, 34));
                    lineArr.addObject_(itemInfo);
                    currWidth = ceil(itemInfo.itemSize().width());
                    allCount = allCount + 1;
                    
                    if (currWidth >= contentMaxWidth || (currWidth + 10) >= contentMaxWidth) { // 第一个放下后，第二个放不下，下一个需要新起一行
                        isOver = 1;
                    }
                } else {                                                                                // 有了至少一个内容
                    if ((needWidth + 10 + currWidth) > contentMaxWidth) { // 第二个放不下
                        isOver = 1;
                    } else {
                        itemInfo.setItemSize_(CGSizeMake(needWidth, 34));
                        lineArr.addObject_(itemInfo);
                        allCount = allCount + 1;

                        currWidth = currWidth + 10 + needWidth;
                        if (currWidth >= contentMaxWidth || (currWidth + 10) >= contentMaxWidth) { // 这个放下后，下一个放不下，下一个需要新起一行
                            isOver = 1;
                        }
                    }
                }
                if (isOver) {
                    break;
                }
            }
            
            if (lineArr.count() > 0) {
                var rowsModel = BBAdvanceTabModel.alloc().init();
                rowsModel.setRowsInfoForShow_(lineArr.copy());
                rowsInfo.addObject_(rowsModel);
            }
        }

        if (rowsInfo.count() <= expandLineCount) {
            sectionInfo.setRowsInfoForShow_(rowsInfo);
            return;
        }

        if (sectionInfo.isExpand()) {
            var singleRowInfo = rowsInfo.lastObject();
            if (singleRowInfo.rowsInfoForShow().count() == 1) {
                var lastInfo = singleRowInfo.rowsInfoForShow.lastObject;
                if ((lastInfo.itemSize.width + 10 + arrSize.width) > contentMaxWidth) {
                    lastInfo.itemSize = CGSizeMake(ceil(contentMaxWidth - arrSize.width - 10), 34);
                }
                var arrowItem = new BBAdvanceTabModel;
                arrowItem.itemType = 1;
                arrowItem.itemSize = CGSizeMake(ceil(contentMaxWidth - lastInfo.itemSize.width), 34);
                var arr = NSMutableArray.arrayWithArray_(singleRowInfo.rowsInfoForShow);
                arr.addObject_(arrowItem);
                singleRowInfo.rowsInfoForShow = arr.copy();
            } else {
                var currRowWidth = 0;
                var j = 0;
                var singleRowCount = singleRowInfo.rowsInfoForShow.count();
                while (j < singleRowCount) {
                    currRowWidth = currRowWidth + singleRowInfo.objectAtIndex_(i).itemSize().width();
                    if (j != singleRowCount - 1) {
                        currRowWidth = currRowWidth + 10;
                    }
                    j = j + 1;
                }
                if (currRowWidth + 10 + arrSize.width > contentMaxWidth) {
                    var lastInfo = singleRowInfo.rowsInfoForShow.lastObject;
                    var arr = NSMutableArray.arrayWithArray_(singleRowInfo.rowsInfoForShow);
                    arr.removeLastObject();
                    singleRowInfo.rowsInfoForShow = arr.copy;

                    var newArr = NSMutableArray.array();
                    newArr.addObject_(lastInfo);
                    var arrowItem = new BBAdvanceTabModel;
                    arrowItem.itemType = 1;
                    arrowItem.itemSize = CGSizeMake(ceil(contentMaxWidth - lastInfo.itemSize.width), 34);
                    newArr.addObject_(arrowItem);
                    
                    var rowsModel = new BBAdvanceTabModel;
                    rowsModel.rowsInfoForShow = newArr.copy;
                    rowsInfo.addObject_(rowsModel);
                } else {
                    var arrowItem = new BBAdvanceTabModel;
                    arrowItem.itemType = 1;
                    arrowItem.itemSize = CGSizeMake(ceil(contentMaxWidth - currRowWidth), 34);
                    var arr = NSMutableArray.arrayWithArray_(singleRowInfo.rowsInfoForShow);
                    arr.addObject_(arrowItem);
                    singleRowInfo.rowsInfoForShow = arr.copy;
                }
            }
        } else {
            var l = rowsInfo.count() - expandLineCount;
            var r1 = new _NSRange;
            r1.location = expandLineCount;
            r1.length = l;
            
            rowsInfo.removeObjectsInRange_(r1);
            var singleRowInfo = rowsInfo.objectAtIndex_(expandLineCount - 1);
            if (singleRowInfo.rowsInfoForShow.count() == 1) {
                var lastInfo = singleRowInfo.rowsInfoForShow.lastObject;
                if ((lastInfo.itemSize.width + 10 + arrSize.width) > contentMaxWidth) {
                    lastInfo.itemSize = CGSizeMake(ceil(contentMaxWidth - arrSize.width - 10), 34);
                }
                var arrowItem = new BBAdvanceTabModel;
                arrowItem.itemType = 1;
                arrowItem.itemSize = CGSizeMake(ceil(contentMaxWidth - lastInfo.itemSize.width), 34);
                var arr = NSMutableArray.arrayWithArray_(singleRowInfo.rowsInfoForShow);
                arr.addObject_(arrowItem);
                singleRowInfo.rowsInfoForShow = arr.copy;

            } else {
                var currRowWidth = 0;
                var breakIndex = -1;
                var rowsCount = singleRowInfo.rowsInfoForShow.count();
                var j = 0;
                while(j < rowsCount) {
                    var widthSingle = singleRowInfo.rowsInfoForShowobjectAtIndex_(j).itemSize.width;
                    if (j >= 1 && (currRowWidth + widthSingle + arrSize.width) > contentMaxWidth) {
                        breakIndex = j;
                        break;
                    }
                    currRowWidth = currRowWidth + widthSingle + 10;
                }

                if (breakIndex == -1 &&
                    (currRowWidth + arrSize.width) > contentMaxWidth) { // for循环结束的时候肯定增加了一个kBossAdvanceTabContentItemMargin
                    breakIndex = rowsCount - 1;
                    currRowWidth = currRowWidth - singleRowInfo.rowsInfoForShow.lastObject.itemSize.width - 10;
                }
                
                var rowsInfoForShow = NSMutableArray.arrayWithArray_(singleRowInfo.rowsInfoForShow);
                if (breakIndex != -1) {
                    var r2 = new _NSRange;
                    r2.location = breakIndex;
                    var l1 = rowsCount - breakIndex;
                    r2.length = l1;
                    
                    rowsInfoForShow.removeObjectsInRange_(r2);
                }
                var arrowItem = new BBAdvanceTabModel;
                arrowItem.itemType = 1;
                arrowItem.itemSize = CGSizeMake(ceil(contentMaxWidth - (currRowWidth - 10)),
                                                34); // for循环结束的时候肯定增加了一个kBossAdvanceTabContentItemMargin
                rowsInfoForShow.addObject_(arrowItem);
                singleRowInfo.rowsInfoForShow = rowsInfoForShow.copy;
            }
        }
        sectionInfo.expandLineCount = expandLineCount;
        sectionInfo.rowsInfoForShow = rowsInfo;
    }
}


