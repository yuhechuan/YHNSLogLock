//
//  UITableView+YHFastProxy.h
//  KZStudy
//
//  Created by yuhechuan on 2022/3/8.
//

#import <UIKit/UIKit.h>
#import "YHTableViewFastProxy.h"

NS_ASSUME_NONNULL_BEGIN

@interface UITableView (YHFastProxy)

// 其他代理对象 用于给外界机会处理 特殊代理方法 必须在 访问 fastProxy之前 设置才起作用
@property (nonatomic, weak) id delegateTarget;

// 快捷代理  随列表 生命周期
@property (nonatomic, strong, readonly) YHTableViewFastProxy *fastProxy;

@end

NS_ASSUME_NONNULL_END
