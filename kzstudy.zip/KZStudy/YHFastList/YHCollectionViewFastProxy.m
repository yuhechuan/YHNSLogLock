//
//  YHCollectionViewFastProxy.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/8.
//

#import "YHCollectionViewFastProxy.h"

@implementation YHCollectionViewCellInfo
@end

@implementation YHCollectionViewInfo

// 自动 构建数据源
- (NSArray <YHCollectionViewCellInfo *>*)constructionDatas:(NSArray *)datas {
    return [self constructionDatas:datas deploy:nil];
}

- (NSArray <YHCollectionViewCellInfo *>*)constructionDatas:(NSArray *)datas
                                               deploy:(YHCollectionViewCellInfoBlcok)deploy {
    if (self.cellArr.count == 0) {
        return @[];
    }
    NSMutableArray *dataArr = [NSMutableArray array];
    Class class = self.cellArr.firstObject;
    for (id obj in datas) {
        YHCollectionViewCellInfo *cellInfo = [[YHCollectionViewCellInfo alloc]init];
        cellInfo.data = obj;
        cellInfo.cellType = class;
        cellInfo.itemSize = self.itemSize;
        // 给外部一个机会修改 cell的配置
        if (deploy) {
            deploy(cellInfo);
        }
        [dataArr addObject:cellInfo];
    }
    return dataArr.copy;
}

@end

@interface YHCollectionViewFastProxy ()

// 数据源
@property (nonatomic, strong) NSMutableArray <YHCollectionViewCellInfo *>*dataList;
// 当前 TableView 配置
@property (nonatomic, strong) YHCollectionViewInfo *collectionViewInfo;
// 布局
@property (nonatomic, strong) UICollectionViewFlowLayout *flowLayout;
// 其他代理对象 用于给外界机会处理 特殊代理方法
@property (nonatomic, weak) id delegateTarget;

@end

@implementation YHCollectionViewFastProxy

// 用于 其他代理的转发
- (instancetype)initDelegateTarget:(id)delegateTarget {
    if (self = [super init]) {
        self.delegateTarget = delegateTarget;
    }
    return self;
}

// cell的注册及 设置
- (void)bz_register:(YHCollectionViewInfoBlcok)infoBlcok {
    YHCollectionViewInfo *info = self.collectionViewInfo;
    if (infoBlcok) {
        infoBlcok(info);
    }
    
    for (Class class in info.cellArr) {
        [self.collectionView registerClass:class forCellWithReuseIdentifier:NSStringFromClass(class)];
    }
    if (info.minimumInteritemSpacing > 0) {
        self.flowLayout.minimumInteritemSpacing = info.minimumInteritemSpacing;
    }
    
    if (info.minimumLineSpacing > 0) {
        self.flowLayout.minimumLineSpacing = info.minimumLineSpacing;
    }
    
    self.flowLayout.scrollDirection = info.scrollDirection;
    
    if (!UIEdgeInsetsEqualToEdgeInsets(info.sectionInset, UIEdgeInsetsZero)) {
        self.flowLayout.sectionInset = info.sectionInset;
    }
}

// 统一根据 BZTableViewInfo 配置 显示数据
- (void)bz_reload:(NSArray *)datas {
    [self.dataList removeAllObjects];
    [self bz_appandReload:datas];
}

- (void)bz_appandReload:(NSArray *)datas {
    NSArray <YHCollectionViewCellInfo *>* cellInfos = [self.collectionViewInfo constructionDatas:datas];
    [self.dataList addObjectsFromArray:cellInfos];
    [self.collectionView reloadData];
}

// 统一自定义 BZTableViewCellInfo 数组 显示数据
- (void)bz_reloadInfo:(NSArray <YHCollectionViewCellInfo *>*)datas {
    [self.dataList removeAllObjects];
    [self bz_appandReloadInfo:datas];
}

- (void)bz_appandReloadInfo:(NSArray <YHCollectionViewCellInfo *>*)datas {
    [self.dataList addObjectsFromArray:datas];
    [self.collectionView reloadData];
}

// 时时配置 BZTableViewCellInfo 数据
- (void)bz_reload:(NSArray *)datas deploy:(YHCollectionViewCellInfoBlcok)deploy {
    [self.dataList removeAllObjects];
    [self bz_appandReload:datas deploy:deploy];
}

- (void)bz_appandReload:(NSArray *)datas deploy:(YHCollectionViewCellInfoBlcok)deploy {
    NSArray <YHCollectionViewCellInfo *>* cellInfos = [self.collectionViewInfo constructionDatas:datas deploy:deploy];
    [self.dataList addObjectsFromArray:cellInfos];
    [self.collectionView reloadData];
}

// 清空数据源
- (void)bz_clearUpAllDatas {
    [self.dataList removeAllObjects];
}

// 当前数据源
- (NSArray <YHCollectionViewCellInfo *> *)bz_dataSource {
    return self.dataList.copy;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.item >= self.dataList.count) {
        return [UICollectionViewCell new];
    }
    YHCollectionViewCellInfo *cellInfo = self.dataList[indexPath.item];
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass(cellInfo.cellType)
                                                                             forIndexPath:indexPath];
    if (self.cellForItemAtIndexPath) {
        self.cellForItemAtIndexPath(cell, cellInfo, indexPath);
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.item >= self.dataList.count) {
        return;
    }
    YHCollectionViewCellInfo *cellInfo = self.dataList[indexPath.item];
    if (self.didSelectItemAtIndexPath) {
        self.didSelectItemAtIndexPath(cellInfo, indexPath);
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.item >= self.dataList.count) {
        return CGSizeZero;
    }
    YHCollectionViewCellInfo *cellInfo = self.dataList[indexPath.item];
    if (self.sizeForItemAtIndexPath) {
        return self.sizeForItemAtIndexPath(cellInfo, indexPath);
    }
    return cellInfo.itemSize;
}

// 方法转发
- (BOOL)respondsToSelector:(SEL)aSelector {
    if (self.delegateTarget && [self.delegateTarget respondsToSelector:aSelector]) {
        return YES;
    }
    return [super respondsToSelector:aSelector];
}

- (void)forwardInvocation:(NSInvocation *)invocation {
    if (self.delegateTarget) {
        [invocation invokeWithTarget:self.delegateTarget];
    }
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)selector {
    return [self.delegateTarget methodSignatureForSelector:selector];
}

- (NSMutableArray<YHCollectionViewCellInfo *> *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

- (YHCollectionViewInfo *)collectionViewInfo {
    if (!_collectionViewInfo) {
        _collectionViewInfo = [[YHCollectionViewInfo alloc]init];
        _collectionViewInfo.scrollDirection = UICollectionViewScrollDirectionVertical;
    }
    return _collectionViewInfo;
}

- (UICollectionViewFlowLayout *)flowLayout {
    if (!_flowLayout) {
        _flowLayout = (UICollectionViewFlowLayout *)self.collectionView.collectionViewLayout;
    }
    return _flowLayout;
}

@end
