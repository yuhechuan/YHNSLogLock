//
//  YHTableViewFastProxy.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/8.
//

#import "YHTableViewFastProxy.h"


@implementation YHTableViewCellInfo
@end

@implementation YHTableViewInfo

// 自动 构建数据源
- (NSArray <YHTableViewCellInfo *>*)constructionDatas:(NSArray *)datas {
    return [self constructionDatas:datas deploy:nil];
}

- (NSArray <YHTableViewCellInfo *>*)constructionDatas:(NSArray *)datas
                                               deploy:(YHTableViewCellInfoBlcok)deploy {
    if (self.cellArr.count == 0) {
        return @[];
    }
    NSMutableArray *dataArr = [NSMutableArray array];
    Class class = self.cellArr.firstObject;
    for (id obj in datas) {
        YHTableViewCellInfo *cellInfo = [[YHTableViewCellInfo alloc]init];
        cellInfo.data = obj;
        cellInfo.cellType = class;
        cellInfo.rowHeight = self.rowHeight;
        // 给外部一个机会修改 cell的配置
        if (deploy) {
            deploy(cellInfo);
        }
        [dataArr addObject:cellInfo];
    }
    return dataArr.copy;
}

@end

@interface YHTableViewFastProxy ()
// 数据源
@property (nonatomic, strong) NSMutableArray <YHTableViewCellInfo *>*dataList;
// 当前 TableView 配置
@property (nonatomic, strong) YHTableViewInfo *tableViewInfo;
// 其他代理对象 用于给外界机会处理 特殊代理方法
@property (nonatomic, weak) id delegateTarget;

@end

@implementation YHTableViewFastProxy

// 用于 其他代理的转发
- (instancetype)initDelegateTarget:(id)delegateTarget {
    if (self = [super init]) {
        self.delegateTarget = delegateTarget;
    }
    return self;
}

- (void)bz_register:(YHTableViewInfoBlcok)infoBlcok {
    if (infoBlcok) {
        infoBlcok(self.tableViewInfo);
    }
    for (Class class in self.tableViewInfo.cellArr) {
        [self.tableView registerClass:class forCellReuseIdentifier:NSStringFromClass(class)];
    }
    if (!UIEdgeInsetsEqualToEdgeInsets(self.tableViewInfo.contentInset, UIEdgeInsetsZero)) {
        self.tableView.contentInset = self.tableViewInfo.contentInset;
    }
}

- (void)bz_reload:(NSArray *)datas {
    [self.dataList removeAllObjects];
    [self bz_appandReload:datas];
}

- (void)bz_appandReload:(NSArray *)datas {
    NSArray <YHTableViewCellInfo *>* cellInfos = [self.tableViewInfo constructionDatas:datas];
    [self.dataList addObjectsFromArray:cellInfos];
    [self.tableView reloadData];
}

- (void)bz_reloadInfo:(NSArray <YHTableViewCellInfo *>*)datas {
    [self.dataList removeAllObjects];
    [self bz_appandReloadInfo:datas];
}

- (void)bz_appandReloadInfo:(NSArray <YHTableViewCellInfo *>*)datas {
    [self.dataList addObjectsFromArray:datas];
    [self.tableView reloadData];
}

- (void)bz_reload:(NSArray *)datas deploy:(YHTableViewCellInfoBlcok)deploy {
    [self.dataList removeAllObjects];
    [self bz_appandReload:datas deploy:deploy];
}

- (void)bz_appandReload:(NSArray *)datas deploy:(YHTableViewCellInfoBlcok)deploy {
    NSArray <YHTableViewCellInfo *>* cellInfos = [self.tableViewInfo constructionDatas:datas deploy:deploy];
    [self.dataList addObjectsFromArray:cellInfos];
    [self.tableView reloadData];
}


// 清空数据源
- (void)bz_clearUpAllDatas {
    [self.dataList removeAllObjects];
}

// 当前数据源
- (NSArray <YHTableViewCellInfo *> *)bz_dataSource {
    return self.dataList.copy;
}
// 删除一行 带动画
- (BOOL)bz_deleteAtIndexPath:(NSIndexPath *)indexPath {
    if (!indexPath || indexPath.row >= self.dataList.count) {
        return NO;
    }
    [self.dataList removeObjectAtIndex:indexPath.row];
    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
    return YES;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= self.dataList.count) {
        return [[UITableViewCell alloc] init];
    }
    YHTableViewCellInfo *cellInfo = self.dataList[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(cellInfo.cellType) forIndexPath:indexPath];
    if (self.cellForRowAtIndexPath) {
        self.cellForRowAtIndexPath(cell,cellInfo, indexPath);
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= self.dataList.count) {
        return;
    }
    YHTableViewCellInfo *cellInfo = self.dataList[indexPath.row];
    if (self.didSelectRowAtIndexPath) {
        self.didSelectRowAtIndexPath(cellInfo, indexPath);
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= self.dataList.count) {
        return CGFLOAT_MIN;
    }
    YHTableViewCellInfo *cellInfo = self.dataList[indexPath.row];
    if (self.heightForRowAtIndexPath) {
        return self.heightForRowAtIndexPath(cellInfo, indexPath);
    }
    return cellInfo.rowHeight;
}

// 设置代理的时候  拿到代理里面的所有方法 判断respondsToSelector 并根据方法存起了 下次执行代理时直接取缓存判断是否可以相应,
// 并且第一次  设置代理时会 调用父类设置代理的方法, 再次设置 只会更新本类的缓存

// 方法转发
- (BOOL)respondsToSelector:(SEL)aSelector {
    if (self.delegateTarget && [self.delegateTarget respondsToSelector:aSelector]) {
        return YES;
    }
    return [super respondsToSelector:aSelector];
}

- (void)forwardInvocation:(NSInvocation *)invocation {
    if (self.delegateTarget) {
        [invocation invokeWithTarget:self.delegateTarget];
    }
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)selector {
    return [self.delegateTarget methodSignatureForSelector:selector];
}


- (NSMutableArray *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

- (YHTableViewInfo *)tableViewInfo {
    if (!_tableViewInfo) {
        _tableViewInfo = [[YHTableViewInfo alloc]init];
    }
    return _tableViewInfo;
}

@end
