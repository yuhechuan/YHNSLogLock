//
//  YHTableViewFastProxy.h
//  KZStudy
//
//  Created by yuhechuan on 2022/3/8.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YHTableViewCellInfo : NSObject

// 数据
@property (nonatomic, strong) id data;
// cell类型cell的class
@property (nonatomic, assign) Class cellType;
// cell高度
@property (nonatomic, assign) CGFloat rowHeight;

@end


@interface YHTableViewInfo : NSObject

// 注册cell
@property (nonatomic, copy) NSArray <Class>*cellArr;
// cell高度
@property (nonatomic, assign) CGFloat rowHeight;
// default UIEdgeInsetsZero. add additional scroll area around content
@property (nonatomic, assign) UIEdgeInsets contentInset;
// 自动 构建数据源 只有一种cell 类型时 可用
- (NSArray <YHTableViewCellInfo *>*)constructionDatas:(NSArray *)datas;

@end

typedef void (^YHTableViewInfoBlcok)(YHTableViewInfo *info);
typedef void (^YHTableViewCellInfoBlcok)(YHTableViewCellInfo *info);

@interface YHTableViewFastProxy : NSObject<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) UITableView *tableView;
// 同UITableViewDelegate的cellForRowAtIndexPath
@property (nonatomic, copy) void(^cellForRowAtIndexPath)(UITableViewCell *cell,YHTableViewCellInfo *cellInfo, NSIndexPath *indexPath);
// 同UITableViewDelegate的didSelectRowAtIndexPath
@property (nonatomic, copy) void(^didSelectRowAtIndexPath)(YHTableViewCellInfo *cellInfo, NSIndexPath *indexPath);
// 同UITableViewDelegate的heightForRowAtIndexPath
@property (nonatomic, copy) CGFloat (^heightForRowAtIndexPath)(YHTableViewCellInfo *cellInfo, NSIndexPath *indexPath);
// 用于 其他代理的转发
- (instancetype)initDelegateTarget:(id)delegateTarget;

// cell的注册及 设置
- (void)bz_register:(YHTableViewInfoBlcok)infoBlcok;

// 统一根据 BZTableViewInfo 配置 显示数据
- (void)bz_reload:(NSArray *)datas;
- (void)bz_appandReload:(NSArray *)datas;

// 统一自定义 BZTableViewCellInfo 数组 显示数据
- (void)bz_reloadInfo:(NSArray <YHTableViewCellInfo *>*)datas;
- (void)bz_appandReloadInfo:(NSArray <YHTableViewCellInfo *>*)datas;

// 时时配置 BZTableViewCellInfo 数据
- (void)bz_reload:(NSArray *)datas deploy:(YHTableViewCellInfoBlcok)deploy;
- (void)bz_appandReload:(NSArray *)datas deploy:(YHTableViewCellInfoBlcok)deploy;


// 清空数据源
- (void)bz_clearUpAllDatas;
// 删除一行 带动画
- (BOOL)bz_deleteAtIndexPath:(NSIndexPath *)indexPath;

// 当前数据源
- (NSArray <YHTableViewCellInfo *> *)bz_dataSource;

@end


NS_ASSUME_NONNULL_END
