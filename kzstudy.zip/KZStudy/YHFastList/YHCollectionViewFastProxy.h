//
//  YHCollectionViewFastProxy.h
//  KZStudy
//
//  Created by yuhechuan on 2022/3/8.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YHCollectionViewCellInfo : NSObject
// 数据
@property (nonatomic, strong) id data;
// cell类型cell的class
@property (nonatomic, assign) Class cellType;
// item大小
@property (nonatomic, assign) CGSize itemSize;

@end

@interface YHCollectionViewInfo : NSObject

// 注册cell
@property (nonatomic, copy) NSArray <Class>*cellArr;
// 这两个属性和collectionView的滚动方向有关系:
// 滚动方向相同的间距为minimumLineSpacing  垂直的minimumInteritemSpacing
@property (nonatomic, assign) CGFloat minimumLineSpacing;
@property (nonatomic, assign) CGFloat minimumInteritemSpacing;
// default is UICollectionViewScrollDirectionVertical  滚动方向
@property (nonatomic) UICollectionViewScrollDirection scrollDirection;
// 四周边距
@property (nonatomic) UIEdgeInsets sectionInset;
// item大小
@property (nonatomic, assign) CGSize itemSize;
// 自动 构建数据源 只有一种cell 类型时 可用
- (NSArray <YHCollectionViewCellInfo *>*)constructionDatas:(NSArray *)datas;

@end

typedef void (^YHCollectionViewInfoBlcok)(YHCollectionViewInfo *info);
typedef void (^YHCollectionViewCellInfoBlcok)(YHCollectionViewCellInfo *info);

@interface YHCollectionViewFastProxy : NSObject<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, weak) UICollectionView *collectionView;

// 同UITableViewDelegate的cellForRowAtIndexPath
@property (nonatomic, copy) void(^cellForItemAtIndexPath)(UICollectionViewCell *cell,YHCollectionViewCellInfo *cellInfo, NSIndexPath *indexPath);
// 同UITableViewDelegate的didSelectRowAtIndexPath
@property (nonatomic, copy) void(^didSelectItemAtIndexPath)(YHCollectionViewCellInfo *cellInfo, NSIndexPath *indexPath);
// 同UITableViewDelegate的heightForRowAtIndexPath
@property (nonatomic, copy) CGSize (^sizeForItemAtIndexPath)(YHCollectionViewCellInfo *cellInfo, NSIndexPath *indexPath);

// 用于 其他代理的转发
- (instancetype)initDelegateTarget:(id)delegateTarget;

// cell的注册及 设置
- (void)bz_register:(YHCollectionViewInfoBlcok)infoBlcok;

// 统一根据 BZTableViewInfo 配置 显示数据
- (void)bz_reload:(NSArray *)datas;
- (void)bz_appandReload:(NSArray *)datas;

// 统一自定义 BZTableViewCellInfo 数组 显示数据
- (void)bz_reloadInfo:(NSArray <YHCollectionViewCellInfo *>*)datas;
- (void)bz_appandReloadInfo:(NSArray <YHCollectionViewCellInfo *>*)datas;

// 时时配置 BZTableViewCellInfo 数据
- (void)bz_reload:(NSArray *)datas deploy:(YHCollectionViewCellInfoBlcok)deploy;
- (void)bz_appandReload:(NSArray *)datas deploy:(YHCollectionViewCellInfoBlcok)deploy;


// 清空数据源
- (void)bz_clearUpAllDatas;
// 当前数据源
- (NSArray <YHCollectionViewCellInfo *> *)bz_dataSource;

@end

NS_ASSUME_NONNULL_END
