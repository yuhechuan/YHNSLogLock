//
//  UITableView+YHFastProxy.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/8.
//

#import "UITableView+YHFastProxy.h"
#import <objc/runtime.h>


@implementation UITableView (YHFastProxy)

@dynamic delegateTarget;

- (void)setDelegateTarget:(id)delegateTarget {
    __weak __typeof(delegateTarget)weakTarget = delegateTarget;
    id (^block)(void) = ^{
        return weakTarget;
    };
    objc_setAssociatedObject(self, @selector(setDelegateTarget:), block, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (id)delegateTarget {
    id (^block)(void) = objc_getAssociatedObject(self, @selector(setDelegateTarget:));
    if (block) {
        return block();
    }
    return nil;
}

- (YHTableViewFastProxy *)fastProxy {
    YHTableViewFastProxy *p = (YHTableViewFastProxy *)objc_getAssociatedObject(self, _cmd);
    if (!p) {
        YHTableViewFastProxy *py = [[YHTableViewFastProxy alloc]initDelegateTarget:self.delegateTarget];
        self.delegate = py;
        self.dataSource = py;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableHeaderView = [[UIView alloc] init];
        self.tableFooterView = [[UIView alloc] init];
        py.tableView = self;
        objc_setAssociatedObject(self, _cmd, py, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        p = py;
    }
    return p;
}

@end
