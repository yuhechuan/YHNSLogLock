//
//  KZClassStrongLayout.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZClassStrongLayout.h"

#import "KZIvarReference.h"
#import "KZObjectInStructReference.h"

#import <objc/runtime.h>

@implementation KZClassStrongLayout

+ (NSArray *)getReferencesForObjectsInStructEncoding:(KZIvarReference *)wrapper encoding:(const char *)encoding {
    // 待完善，结构体属性获取
    NSMutableArray *references = NSMutableArray.new;
    return references;
}

+ (NSArray<KZObjectReference *> *)getClassReferences:(Class)aCls {
    NSMutableArray<KZObjectReference *> *result = [NSMutableArray new];
    
    unsigned int count;
    // 获取 对象的成员变量 列表
    Ivar *ivars = class_copyIvarList(aCls, &count);
    for (unsigned int i = 0; i < count; ++i) {
        Ivar ivar = ivars[i];
        KZIvarReference *wrapper = [[KZIvarReference alloc] initWithIvar:ivar];
        // 如果 属性是结构体 对象 还没有实现
        if (wrapper.type == KZIvarStructType) {
            const char *encoding = ivar_getTypeEncoding(wrapper.ivar);
            NSArray *references = [self getReferencesForObjectsInStructEncoding:wrapper encoding:encoding];
            [result addObjectsFromArray:references];
        } else {
            [result addObject:wrapper];
        }
    }
    free(ivars);
    
    return [result copy];
}
// 获取第一个成员变量的位置
+ (NSUInteger)getMinimumIvarIndex:(Class)aCls {
    NSUInteger minimumIndex = 1;
    unsigned int count;
    Ivar *ivars = class_copyIvarList(aCls, &count);
    
    if (count > 0) {
        Ivar ivar = ivars[0];
        ptrdiff_t offset = ivar_getOffset(ivar);
        minimumIndex = offset / (sizeof(void *));
    }
    
    free(ivars);
    
    return minimumIndex;
}
/*
@interface Dog : NSObject

@property (nonatomic, strong) id property1;
 
@property (nonatomic, weak) id property2;
@property (nonatomic, unsafe_unretained) id property3;
@property (nonatomic, weak) id property4;
@property (nonatomic, strong) id property5;
@property (nonatomic, strong) id property6;
 
@property (nonatomic, unsafe_unretained) id property7;
@property (nonatomic, strong) id property8;
@property (nonatomic, strong) id property9;
 
@property (nonatomic, weak) id property10;
@property (nonatomic, weak) id property11;
@property (nonatomic, strong) id property12;

@end
 
 const uint8_t *fullLayout = class_getIvarLayout(aCls);
 fullLayout 是个 放着 uint8_t类型的数组  uint8_t 是char 类型的 占8位 用16进制表示 就是 0x12
 这两位中的后一位表示了连续的strong）类型的实例变量的数量，前一位表示连续的非strong类型的实例变量的数量
 fullLayout 数组 是这样的 [0x01, 0x32, 0x12, 0x21]
 
 */

+ (NSIndexSet *)getLayoutAsIndexesForDescription:(NSUInteger)minimumIndex layoutDescription:(const uint8_t *)layoutDescription {
    NSMutableIndexSet *interestingIndexes = [NSMutableIndexSet new];
    NSUInteger currentIndex = minimumIndex;
    
    
    while (*layoutDescription != '\x00') {
        // 0xf0  1111 0000
        int upperNibble = (*layoutDescription & 0xf0) >> 4;
        // 0xf   0000 1111
        int lowerNibble = *layoutDescription & 0xf;
        
        // 高位表示非strong属性个数
        currentIndex += upperNibble;
        
        // 低位表示strong属性个数
        [interestingIndexes addIndexesInRange:NSMakeRange(currentIndex, lowerNibble)];
        currentIndex += lowerNibble;
        
        ++layoutDescription;
    }
    
    return interestingIndexes;
}

+ (NSArray *)getStrongReferencesForClass:(Class)aCls {
    /// 获取对象中的所有属性
    NSArray *classReferences = [self getClassReferences:aCls];
    
    //获取type 不为 KZIvarUnknownType 的成员信息
    NSArray *ivars = [classReferences filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        if ([evaluatedObject isKindOfClass:[KZIvarReference class]]) {
            KZIvarReference *wrapper = evaluatedObject;
            return wrapper.type != KZIvarUnknownType;
        }
        return YES;
    }]];
    
    // 成员信息
    const uint8_t *fullLayout = class_getIvarLayout(aCls);
    
    if (!fullLayout) return nil;
    // 获取第一个成员变量的位置
    NSUInteger minimumIndex = [self getMinimumIvarIndex:aCls];
    // 获取 强引用的成员的 indexs数组
    NSIndexSet *parsedLayout = [self getLayoutAsIndexesForDescription:minimumIndex layoutDescription:fullLayout];
    
    // 筛选出强引用的 成员
    NSArray *filteredIvars = [ivars filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(KZObjectReference *evaluatedObject, NSDictionary *bindings) {
        // evaluatedObject是KZIvarReference 实例  返回 ivar的index
        return [parsedLayout containsIndex:[evaluatedObject indexInIvarLayout]];
    }]];
    
    return filteredIvars;
}

+ (NSArray<KZObjectReference *> *)getObjectStrongReferences:(id)object layoutCache:(nullable NSMutableDictionary *)layoutCache {
    // layoutCache 为缓存
    NSMutableArray *array = NSMutableArray.new;
    
    Class previousClass = nil;
    Class currentClass = object_getClass(object);
    
    /// 沿着继承链把 所有强引用 属性找出来
    while (previousClass != currentClass) {
        NSArray<KZObjectReference *> *ivars;
        
        /// 先在缓存中寻找
        if (layoutCache && currentClass) {
            ivars = [layoutCache objectForKey:@((uintptr_t)currentClass)];
        }
        
        // 缓存中没有 直接去当前对象中拿
        if (ivars == nil) {
            ivars = [self getStrongReferencesForClass:currentClass];
            if (layoutCache && currentClass) {
                layoutCache[@((uintptr_t)currentClass)] = ivars;
            }
        }
        [array addObjectsFromArray:ivars];
        
        previousClass = currentClass;
        currentClass = class_getSuperclass(currentClass);
    }
    
    return array.copy;
}

@end
