//
//  KZBlockStrongLayout.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/**
 enum {
    BLOCK_DEALLOCATING =      (0x0001),  // runtime
     BLOCK_REFCOUNT_MASK =     (0xfffe),  // runtime    用来标识栈Block
     BLOCK_NEEDS_FREE =        (1 << 24), // runtime    用来标识堆
     BLOCK_HAS_COPY_DISPOSE =  (1 << 25), // compiler compiler 含有copy_dispose助手    如果标记为BLOCK_HAS_COPY_DISPOSE代表含有copy_dispose助手，说明该lay_out拥有Block_descriptor_2
 
     BLOCK_HAS_CTOR =          (1 << 26), // compiler: helpers have C++ code
     BLOCK_IS_GC =             (1 << 27), // runtime
     BLOCK_IS_GLOBAL =         (1 << 28), // compiler 是否为全局Block
     BLOCK_USE_STRET =         (1 << 29), // compiler: undefined if !BLOCK_HAS_SIGNATURE
     BLOCK_HAS_SIGNATURE  =    (1 << 30), // compiler    判断是否有签名
     BLOCK_HAS_EXTENDED_LAYOUT=(1 << 31)  // compiler

 };

 */

// 标志的值用来描述块对象

enum { // Flags from BlockLiteral
    KZ_BLOCK_HAS_COPY_DISPOSE =  (1 << 25), // 判断是否存在copy和dispose函数
    KZ_BLOCK_HAS_CTOR =          (1 << 26), // helpers have C++ code  
    KZ_BLOCK_IS_GLOBAL =         (1 << 28), // 那么该块是一个全局块
    KZ_BLOCK_HAS_STRET =         (1 << 29), // IF !BLOCK_HAS_SIGNATURE
    KZ_BLOCK_HAS_SIGNATURE =     (1 << 30), // 是否存在签名
};

struct KZBlockDescriptor {
    // 保留变量
    unsigned long int reserved;                // NULL
    // block的内存大小
    unsigned long int size;
    // optional helper functions
    // 拷贝block中被 __block 修饰的外部变量
    void (*copy_helper)(void *dst, void *src); // IFF (1<<25)
    //和 copy 方法配置应用，用来释放资源
    void (*dispose_helper)(void *src);         // IFF (1<<25)
    // block的签名
    const char *signature;                     // IFF (1<<30)
};

// block的内存结构
struct KZBlockLiteral {
    // 指向所属类的指针，也就是block的类型
    void *isa;  // initialized to &_NSConcreteStackBlock or &_NSConcreteGlobalBlock
    // 标志变量，在实现block的内部操作时会用到
    int flags;
    // 保留变量
    int reserved;
    // 执行时调用的函数指针，block内部的执行代码都在这个函数中
    void (*invoke)(void *, ...);
    // block的详细描述，包含 copy/dispose 函数，处理block引用外部变量时使用
    struct KZBlockDescriptor *descriptor;
    // imported variables
};

@interface KZBlockStrongLayout : NSObject

+ (NSArray *)getBlockStrongReferences:(void *)block;
// 判断 对象是否是 block类型
+ (BOOL)objectIsBlock:(id)object;

@end

NS_ASSUME_NONNULL_END
