//
//  KZBlockStrongLayout.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/27.
//

#import "KZBlockStrongLayout.h"
#import "KZBlockStrongRelationDetector.h"
#import <objc/runtime.h>

static Class _BlockClass() {
    static dispatch_once_t onceToken;
    static Class blockClass;
    dispatch_once(&onceToken, ^{
        void (^testBlock)(void) = [^{} copy];
        blockClass = [testBlock class];
        while(class_getSuperclass(blockClass) && class_getSuperclass(blockClass) != [NSObject class]) {
            blockClass = class_getSuperclass(blockClass);
        }
    });
    return blockClass;
}

@implementation KZBlockStrongLayout

+ (NSArray *)getBlockStrongReferences:(void *)block {
    if (![self objectIsBlock:(id)(block)]) {
        return nil;
    }
    
    NSMutableArray *results = NSMutableArray.new;
    void **blockReference = block;
    NSIndexSet *strongLayout = [self getBlockStrongLayout:block];
    // 取出被 block强引用的对象
    [strongLayout enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL * _Nonnull stop) {
        void **reference = &blockReference[idx];
        
        if (reference && (*reference)) {
            id object = (id)(*reference);
            if (object) [results addObject:object];
        }
    }];
    
    return results.copy;
}

+ (NSIndexSet *)getBlockStrongLayout:(void *)block {
    struct KZBlockLiteral *blockLiteral = block;
    /**
     BLOCK_HAS_CTOR - Block has a C++ constructor/destructor, which gives us a good chance it retains
     objects that are not pointer aligned, so omit them.
     BLOCK_HAS_CTOR—Block有一个c++的构造函数/析构函数，这给了我们一个很好的机会来保留它
     对象不是指针对齐的，所以省略它们。

     !BLOCK_HAS_COPY_DISPOSE - Block doesn't have a dispose function, so it does not retain objects and
     we are not able to blackbox it.
     BLOCK_HAS_COPY_DISPOSE—Block没有dispose函数，所以它不保留对象
     我们无法封锁它。
     */
    // 如果block 助手有c++代码  或者 没有 存在copy和dispose函数 不做处理
    if ((blockLiteral->flags & KZ_BLOCK_HAS_CTOR) || !(blockLiteral->flags & KZ_BLOCK_HAS_COPY_DISPOSE)) {
        return nil;
    }
    
    // 拿到 dispose 函数地址
    void (*dispose_helper)(void *src) = blockLiteral->descriptor->dispose_helper;
    
    // 算出 block 捕获的变量个数
    // 空的 block 占32 字节
    const size_t ptrSize = sizeof(void *); // 8
    // 这个减一没有看懂 可能是为了 过滤掉 int 4 类型的
    
    const size_t elements = (blockLiteral->descriptor->size + ptrSize - 1) / ptrSize;
    
    void *obj[elements];
    void *detectors[elements];
    
    /// 模拟 block里面的 东西
    for (size_t i = 0; i < elements; ++i) {
        KZBlockStrongRelationDetector *detector = [[KZBlockStrongRelationDetector alloc] init];
        obj[i] = detectors[i] = detector;
    }
    // 手动调用一下 block的销毁函数   捕获的变量
    @autoreleasepool {
        dispose_helper(obj);
    }
    
    // 保存强引用的 的变量
    NSMutableIndexSet *layout = [NSMutableIndexSet indexSet];
    for (size_t i = 0; i < elements; ++i) {
        KZBlockStrongRelationDetector *detector = (KZBlockStrongRelationDetector *)(detectors[i]);
        /// 只有被调用过 release 的 对象才表示强引用
        if (detector.isStrong) {
            [layout addIndex:i];
        }
        
        [detector trueRelease];
    }
    return layout;
}

+ (BOOL)objectIsBlock:(id)object {
    Class blockClass = _BlockClass();
    
    Class candidate = object_getClass(object);
    return [candidate isSubclassOfClass:blockClass];
}

@end
