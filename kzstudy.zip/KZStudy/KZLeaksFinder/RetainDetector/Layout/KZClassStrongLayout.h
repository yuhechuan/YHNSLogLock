//
//  KZClassStrongLayout.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import <Foundation/Foundation.h>
@class KZObjectReference;

NS_ASSUME_NONNULL_BEGIN

@interface KZClassStrongLayout : NSObject
// 获取 对象的 成员变量 信息
+ (NSArray<KZObjectReference *> *)getClassReferences:(Class)aCls;

+ (NSArray<KZObjectReference *> *)getObjectStrongReferences:(id)obj layoutCache:(nullable NSMutableDictionary *)layoutCache;

@end

NS_ASSUME_NONNULL_END
