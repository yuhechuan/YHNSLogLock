//
//  KZNodeEnumerator.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/27.
//

#import "KZNodeEnumerator.h"

#import "KZObjectiveCGraphElement.h"

@interface KZNodeEnumerator ()

@property (nonatomic, strong) NSSet *retainedObjectsSnapshot;
@property (nonatomic, strong) NSEnumerator *enumerator;

@end

@implementation KZNodeEnumerator

- (instancetype)initWithObject:(KZObjectiveCGraphElement *)object {
    if (self = [super init]) {
        self.object = object;
    }
    return self;
}
// 每个 KZObjectiveCGraphElement 都会递归去查询他的 强引用列表
- (KZNodeEnumerator *)nextObject {
    if (self.object == nil) return nil;
    
    if (self.retainedObjectsSnapshot == nil) {
        self.retainedObjectsSnapshot = [self.object allRetainedObjects];
        self.enumerator = [self.retainedObjectsSnapshot objectEnumerator];
    }
    
    KZObjectiveCGraphElement *next = [self.enumerator nextObject];
    if (next) {
        return [[KZNodeEnumerator alloc] initWithObject:next];
    }
    return nil;
}

- (BOOL)isEqual:(id)object {
    if ([object isKindOfClass:KZNodeEnumerator.class]) {
        KZNodeEnumerator *enumerator = (KZNodeEnumerator *)object;
        return [self.object isEqual:enumerator.object];
    }
    return NO;
}

- (NSUInteger)hash {
    return [self.object hash];
}

@end
