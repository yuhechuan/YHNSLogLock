//
//  KZRetaionDetectorConfiger.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZRetaionDetectorConfiger.h"

@interface KZRetaionDetectorConfiger ()

@property (nonatomic, strong) NSMutableDictionary *filterDictionary;

@property (nonatomic, assign) BOOL shouldInspectTimers;

@end

@implementation KZRetaionDetectorConfiger

- (instancetype)init {
    if (self = [super init]) {
        self.filterDictionary = NSMutableDictionary.new;
        self.layoutCache = NSMutableDictionary.new;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceiveMemoryWarning) name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
    }
    return self;
}

+ (instancetype)configer {
    KZRetaionDetectorConfiger *configer = [[KZRetaionDetectorConfiger alloc] init];
    [configer addFilterWithClass:[UIView class] ivarNames:@[@"_subviewCache"]];
    [configer addFilterWithClass:NSClassFromString(@"UIHeldAction") ivarNames:@[@"m_target"]];
    [configer addFilterWithClass:NSClassFromString(@"_UIViewControllerOneToOneTransitionContext") ivarNames:@[@"_toViewController", @"_fromViewController"]];
    [configer addFilterWithClass:[UITouch class] ivarNames:@[@"_view", @"_gestureRecognizers", @"_window", @"_warpedIntoView"]];
    return configer;
}

- (void)addFilterWithClass:(Class)aCls ivarNames:(nullable NSArray *)ivarNames {
    if (aCls != NULL) {
        [self.filterDictionary setObject:ivarNames ? : @[] forKey:NSStringFromClass(aCls)];
    }
}

- (BOOL)shouldBreakDetectorClass:(Class)aCls byIvarName:(nullable NSString *)ivarName {
    if (aCls == NULL) return NO;
    
    for (NSString *key in self.filterDictionary) {
        NSArray *ivarNames = self.filterDictionary[key];
        Class filterClass = NSClassFromString(key);
        
        if ([aCls isSubclassOfClass:filterClass]) {
            if (ivarNames && [ivarNames containsObject:ivarName]) {
                return YES;
            }
        }
    }
    return NO;
}

- (void)didReceiveMemoryWarning {
    [self.layoutCache removeAllObjects];
}

@end
