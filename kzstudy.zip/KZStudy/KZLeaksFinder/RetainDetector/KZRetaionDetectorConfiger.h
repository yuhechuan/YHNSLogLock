//
//  KZRetaionDetectorConfiger.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import <UIKit/UIkit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZRetaionDetectorConfiger : NSObject

@property (nonatomic, strong, nullable) NSMutableDictionary *layoutCache;

+ (instancetype)configer;
// 给一个类添加 过滤 成员变量 会覆盖默认设置 
- (void)addFilterWithClass:(Class)aCls ivarNames:(nullable NSArray *)ivarNames;
// aCls里面的成员变量 是否在过滤名单里面
- (BOOL)shouldBreakDetectorClass:(Class)aCls byIvarName:(nullable NSString *)ivarName;

@end

NS_ASSUME_NONNULL_END
