//
//  KZRetainDetector.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZRetainDetector.h"
#import "KZNodeEnumerator.h"

@interface KZRetainDetector ()

@property (nonatomic, strong) KZRetaionDetectorConfiger *configer;

@property (nonatomic, strong) NSMutableSet *objectSet;
@property (nonatomic, strong) KZObjectiveCGraphElement *detectElement;

@end

@implementation KZRetainDetector

- (instancetype)initWithConfiger:(nullable KZRetainDetectorShareBlock)block {
    if (self = [super init]) {
        self.objectSet = NSMutableSet.new;
        // 生个成员变量 过滤器
        KZRetaionDetectorConfiger *configer = [KZRetaionDetectorConfiger configer];
        if (block) block(configer);
        self.configer = configer;
    }
    return self;
}

// 检测 跟内存泄漏 关联对象
- (void)setCandidate:(id)candidate {
    if (candidate) {
        self.detectElement = [KZObjectiveCGraphElement elementWithObject:candidate configuration:self.configer namePath:nil fromClass:NULL];
    }
}

- (nonnull NSSet<NSArray<KZObjectiveCGraphElement *> *> *)findRetainCycles {
    if (self.detectElement == nil) return nil;
    // 主要获取方法
    NSMutableSet *retainCycles = [self findRetainCyclesInStackDepth:10];
    self.detectElement = nil;
    [self.objectSet removeAllObjects];
    
    NSMutableSet *brokenCycles = [NSMutableSet set];
    for (NSArray *itemCycle in retainCycles) {
        for (KZObjectiveCGraphElement *element in itemCycle) {
            if (element.object == nil) {
                [brokenCycles addObject:itemCycle];
                break;
            }
        }
    }
    // 删除 element.object 为 nil 的元素
    [retainCycles minusSet:brokenCycles];
    return retainCycles;
}

/**
 * 大概逻辑是
 *  把所有强引用对象 都加入栈中 判断同一个对象是否被2次加入栈 如果被2次 认为存在循环引用
 */
- (NSMutableSet *)findRetainCyclesInStackDepth:(NSUInteger)stackDepth {
    NSMutableSet *retainCycles = NSMutableSet.new;
    KZNodeEnumerator *wrappedObject = [[KZNodeEnumerator alloc] initWithObject:self.detectElement];
    
    NSMutableArray *stack = NSMutableArray.new;
    NSMutableSet *objectsOnPath = NSMutableSet.new;
    // 先加入当前 没有释放的对象
    [stack addObject:wrappedObject];
    
    /**
     YHTableViewController -> 入栈
     获取栈顶元素, 然后算出强引用集合构造遍历器
     遍历器里的内容如下

     UITableView  入栈
     __NSMallocBlock__
     YHStudent
     UIView
     _nibBundle
     UITraitCollection
     UINavigationContentAdjustments
     */
    
    while (stack.count > 0) {
        @autoreleasepool {
            KZNodeEnumerator *top = [stack lastObject];
            
            if (![objectsOnPath containsObject:top]) {
                if ([self.objectSet containsObject:@([top.object objectAddress])]) {
                    [stack removeLastObject];
                    continue;
                }
                
                [self.objectSet addObject:@([top.object objectAddress])];
            }
            
            [objectsOnPath addObject:top];
            
            KZNodeEnumerator *firstAdjacent = [top nextObject];
            // 如果对象的 强引用列表不为空
            if (firstAdjacent) {
                BOOL shouldPushToStack = NO;
                // 对象 之前访问过
                if ([objectsOnPath containsObject:firstAdjacent]) {
                    NSUInteger index = [stack indexOfObject:firstAdjacent];
                    NSInteger length = [stack count] - index;
                    
                    if (index == NSNotFound) {
                        // Object got deallocated between checking if it exists and grabbing its index
                        shouldPushToStack = YES;
                    } else {
                        NSRange cycleRange = NSMakeRange(index, length);
                        NSMutableArray *cycle = [[stack subarrayWithRange:cycleRange] mutableCopy];
                        [cycle replaceObjectAtIndex:0 withObject:firstAdjacent];
                        
                        // 处理一下顺序 加入 循环数组
                        [retainCycles addObject:[self shiftToUnifiedCycle:[self unwrapCycle:cycle]]];
                    }
                } else {
                    shouldPushToStack = YES;
                }
                
                if (shouldPushToStack) {
                    if (stack.count < stackDepth) {
                        [stack addObject:firstAdjacent];
                    }
                }
            } else {
                // 如果对象的 强引用列表为空 则出栈
                [stack removeLastObject];
                [objectsOnPath removeObject:top];
            }
        }
    }
    return retainCycles;
}

// 吧对象的名字 加入数组
- (NSArray *)extractClassNamesFromGraphObjects:(NSArray<KZObjectiveCGraphElement *> *)array {
    NSMutableArray *arrayOfClassNames = [NSMutableArray new];
    
    for (KZObjectiveCGraphElement *obj in array) {
        [arrayOfClassNames addObject:[obj classNameOrNull]];
    }
    
    return arrayOfClassNames;
}

- (NSComparisonResult)compareStringArray:(NSArray<NSString *> *)a1 withArray:(NSArray<NSString *> *)a2 {
    // a1 and a2 should be the same length
    for (NSUInteger i = 0; i < [a1 count]; ++i) {
        NSString *s1 = a1[i];
        NSString *s2 = a2[i];
        
        NSComparisonResult comparision = [s1 compare:s2];
        if (comparision != NSOrderedSame) {
            return comparision;
        }
    }
    
    return NSOrderedSame;
}

- (NSArray *)shiftToUnifiedCycle:(NSArray<KZObjectiveCGraphElement *> *)array {
    // 把对象的名字 加入数组 最低地址 排在最前面
    NSArray<NSString *> *arrayOfClassNames = [self extractClassNamesFromGraphObjects:[self shiftBufferToLowestAddress:array]];
    
    NSArray<NSString *> *copiedArray = [arrayOfClassNames arrayByAddingObjectsFromArray:arrayOfClassNames];
    NSUInteger originalLength = [arrayOfClassNames count];
    
    NSArray *currentMinimalArray = arrayOfClassNames;
    NSUInteger minimumIndex = 0;
    
    for (NSUInteger i = 0; i < originalLength; ++i) {
        NSArray<NSString *> *nextSubarray = [copiedArray subarrayWithRange:NSMakeRange(i, originalLength)];
        if ([self compareStringArray:currentMinimalArray
                           withArray:nextSubarray] == NSOrderedDescending) {
            currentMinimalArray = nextSubarray;
            minimumIndex = i;
        }
    }
    
    NSRange minimumArrayRange = NSMakeRange(minimumIndex,
                                            [array count] - minimumIndex);
    NSMutableArray<KZObjectiveCGraphElement *> *minimumArray = [[array subarrayWithRange:minimumArrayRange] mutableCopy];
    [minimumArray addObjectsFromArray:[array subarrayWithRange:NSMakeRange(0, minimumIndex)]];
    return minimumArray;
}

// 拿到对应的对象 集合
- (NSArray *)unwrapCycle:(NSArray<KZNodeEnumerator *> *)cycle {
    NSMutableArray *unwrappedArray = [NSMutableArray new];
    for (KZNodeEnumerator *wrapped in cycle) {
        [unwrappedArray addObject:wrapped.object];
    }
    
    return unwrappedArray;
}

// 保证 最低地址的数据排在最前面
- (NSArray *)shiftBufferToLowestAddress:(NSArray<KZObjectiveCGraphElement *> *)cycle {
    NSUInteger idx = 0, lowestAddressIndex = 0;
    size_t lowestAddress = NSUIntegerMax;
    for (KZObjectiveCGraphElement *obj in cycle) {
        if ([obj objectAddress] < lowestAddress) {
            lowestAddress = [obj objectAddress];
            lowestAddressIndex = idx;
        }
        idx++;
    }
    
    if (lowestAddressIndex == 0) {
        return cycle;
    }
    
    NSRange cycleRange = NSMakeRange(lowestAddressIndex, [cycle count] - lowestAddressIndex);
    NSMutableArray<KZObjectiveCGraphElement *> *array = [[cycle subarrayWithRange:cycleRange] mutableCopy];
    [array addObjectsFromArray:[cycle subarrayWithRange:NSMakeRange(0, lowestAddressIndex)]];
    return array;
}


@end
