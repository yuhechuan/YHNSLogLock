//
//  KZNodeEnumerator.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/27.
//

#import <Foundation/Foundation.h>

@class KZObjectiveCGraphElement;

NS_ASSUME_NONNULL_BEGIN

@interface KZNodeEnumerator : NSEnumerator

@property (nonatomic, strong) KZObjectiveCGraphElement *object;

- (instancetype)initWithObject:(KZObjectiveCGraphElement *)object;

- (KZNodeEnumerator *)nextObject;

@end

NS_ASSUME_NONNULL_END
