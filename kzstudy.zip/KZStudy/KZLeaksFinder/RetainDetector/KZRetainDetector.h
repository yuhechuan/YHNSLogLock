//
//  KZRetainDetector.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import <Foundation/Foundation.h>
#import "KZObjectiveCGraphElement.h"
/**
 1.  检测 跟内存泄漏对象 强引用表  分为3种类型
 block 对象  捕捉的强引用类型
 NSTimer 对象 主要是 target
 其他OC对象  强引用的 成员变量
 
 2. 通过迭代器 KZNodeEnumerator  分别算出 内存泄漏对象 强引用表里面每个 元素的 强引用表
 
 3.  通过算法 获取 是否存在 相互引用
   
 */

NS_ASSUME_NONNULL_BEGIN

typedef void (^KZRetainDetectorShareBlock)(KZRetaionDetectorConfiger *confier);

@interface KZRetainDetector : NSObject

- (instancetype)initWithConfiger:(nullable KZRetainDetectorShareBlock)block;

- (void)setCandidate:(id)candidate;

- (nonnull NSSet<NSArray<KZObjectiveCGraphElement *> *> *)findRetainCycles;

@end

NS_ASSUME_NONNULL_END
