//
//  KZObjectiveCGraphElement.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectiveCGraphElement.h"

#import "KZBlockStrongLayout.h"
#import "KZObjectiveCBlockElement.h"
#import "KZObjectiveCNSCFTimerElement.h"
#import "KZObjectiveCObjectElement.h"

#import <objc/message.h>
#import <objc/runtime.h>

@implementation KZObjectiveCGraphElement

+ (instancetype)elementWithObject:(id)object
                    configuration:(KZRetaionDetectorConfiger *)configer
                         namePath:(nullable NSArray<NSString *> *)namePath
                        fromClass:(nullable Class)fromClass {
    // 检查是否有 namePath 在过滤器里面
    if ([configer shouldBreakDetectorClass:fromClass byIvarName:namePath.firstObject]) {
        return nil;
    }
    
    // 如果是 block
    if ([KZBlockStrongLayout objectIsBlock:object]) {
        KZObjectiveCBlockElement *blockElement = [[KZObjectiveCBlockElement alloc] initWithObject:object configuration:configer namePath:namePath];
        return blockElement;
    } else {
        // 如果是 NSTimer
        if ([object_getClass(object) isSubclassOfClass:[NSTimer class]]) {
            KZObjectiveCNSCFTimerElement *timerElement = [[KZObjectiveCNSCFTimerElement alloc] initWithObject:object configuration:configer namePath:namePath];
            return timerElement;
        } else {
            // 其他oc对象
            KZObjectiveCObjectElement *objectElement = [[KZObjectiveCObjectElement alloc] initWithObject:object configuration:configer namePath:namePath];
            return objectElement;
        }
    }
}

- (instancetype)initWithObject:(id)object configuration:(KZRetaionDetectorConfiger *)configer namePath:(NSArray<NSString *> *)namePath {
    if (self = [super init]) {
        _namePath = namePath;
        _configer = configer;
        
        // 是否对象 允许被弱引用
        Class aCls = object_getClass(object);
        BOOL (*allowsWeakReference)(id, SEL) =
        (__typeof__(allowsWeakReference))class_getMethodImplementation(aCls, @selector(allowsWeakReference));
        
        if (allowsWeakReference && (IMP)allowsWeakReference != _objc_msgForward) {
            if (allowsWeakReference(object, @selector(allowsWeakReference))) {
                _object = object;
            }
        } else {
            _object = object;
        }
    }
    return self;
}

- (NSSet *)allRetainedObjects {
    // associations object
    return [NSSet set];
}

- (BOOL)isEqual:(id)object {
  if ([object isKindOfClass:[KZObjectiveCGraphElement class]]) {
      KZObjectiveCGraphElement *objcObject = object;
    return objcObject.object == _object;
  }
  return NO;
}

- (NSUInteger)hash {
  return (size_t)_object;
}

// 重写打印属性
- (NSString *)description {
  if (_namePath) {
    NSString *namePathStringified = [_namePath componentsJoinedByString:@" -> "];
    return [NSString stringWithFormat:@"-> %@ -> %@ ", namePathStringified, [self classNameOrNull]];
  }
  return [NSString stringWithFormat:@"-> %@ ", [self classNameOrNull]];
}

- (size_t)objectAddress {
  return (size_t)_object;
}

- (NSString *)classNameOrNull {
  NSString *className = NSStringFromClass([self objectClass]);
  if (!className) className = @"(null)";

  return className;
}

- (Class)objectClass {
    return object_getClass(self.object);
}

@end
