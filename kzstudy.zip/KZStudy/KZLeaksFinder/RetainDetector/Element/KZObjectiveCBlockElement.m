//
//  KZObjectiveCBlockElement.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectiveCBlockElement.h"

#import "KZBlockStrongLayout.h"

@implementation KZObjectiveCBlockElement

- (NSSet *)allRetainedObjects {
    __attribute__((objc_precise_lifetime)) id anObject = self.object;
    if (anObject == nil) return nil;
    
    NSMutableArray *retainedObjects = [[[super allRetainedObjects] allObjects] mutableCopy];
    void *blockObjectReference = (__bridge void *)anObject;
    NSArray *allRetainedReferences = [KZBlockStrongLayout getBlockStrongReferences:blockObjectReference];
    
    for (id object in allRetainedReferences) {
        KZObjectiveCGraphElement *element = [KZObjectiveCGraphElement elementWithObject:object
                                                                          configuration:self.configer
                                                                               namePath:nil
                                                                              fromClass:[self objectClass]];
        if (element) [retainedObjects addObject:element];
    }
    
    return [NSSet setWithArray:retainedObjects];
}

@end
