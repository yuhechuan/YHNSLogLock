//
//  KZObjectiveCObjectElement.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectiveCObjectElement.h"

#import "KZClassStrongLayout.h"
#import "KZRetaionDetectorConfiger.h"
#import "KZObjectReference.h"

#import <objc/runtime.h>

@implementation KZObjectiveCObjectElement

- (NSSet *)allRetainedObjects {
    Class aCls = object_getClass(self.object);
    if (!self.object || !aCls) {
      return nil;
    }
    
    // 获取强引用 成员
    NSArray *strongIvars = [KZClassStrongLayout getObjectStrongReferences:self.object layoutCache:self.configer.layoutCache];
    
    NSMutableArray *retainedObjects = [[[super allRetainedObjects] allObjects] mutableCopy];
    
    for (KZObjectReference *reference in strongIvars) {
        // 获取成员变量的值 如果有值才 存起来
        id referencedObject = [reference objectReferenceFromObject:self.object];
        if (referencedObject) {
            NSArray *namePath = [reference namePath];
            
            KZObjectiveCGraphElement *element = [KZObjectiveCGraphElement elementWithObject:referencedObject
                                                                              configuration:self.configer
                                                                                   namePath:namePath
                                                                                  fromClass:[self objectClass]];
            if (element) [retainedObjects addObject:element];
        }
    }
    // NS开头的系统类
    if ([NSStringFromClass(aCls) hasPrefix:@"__NSCF"]) {
        return [NSSet setWithArray:retainedObjects];
    }
    // 类对象直接返回nil 感觉应该提前
    if (class_isMetaClass(aCls)) {
      return nil;
    }
    
    // 快速枚举协议 如果对象支持 for/in 遍历 把集合里面的内容也加入 
    if ([aCls conformsToProtocol:@protocol(NSFastEnumeration)]) {
        BOOL retainsKeys = [self objectRetainsEnumerableKeys];
        BOOL retainsValues = [self objectRetainsEnumerableValues];
        
        // 是否支持KVC
        BOOL isKeyValued = NO;
        if ([aCls instancesRespondToSelector:@selector(objectForKey:)]) {
            isKeyValued = YES;
        }
        
        //// 尝试10次 
        NSInteger tries = 10;
        for (NSInteger i = 0 ; i < tries; ++i) {
            NSMutableSet *temporaryRetainedObjects = [NSMutableSet new];
            @try {
                for (id subObject in self.object) {
                    if (retainsKeys) {
                        KZObjectiveCGraphElement *element = [KZObjectiveCGraphElement elementWithObject:subObject
                                                                                          configuration:self.configer
                                                                                               namePath:nil
                                                                                              fromClass:[self objectClass]];
                        if (element) [temporaryRetainedObjects addObject:element];
                    }
                    if (isKeyValued && retainsValues) {
                        KZObjectiveCGraphElement *element = [KZObjectiveCGraphElement elementWithObject:[self.object objectForKey:subObject]
                                                                                          configuration:self.configer
                                                                                               namePath:nil
                                                                                              fromClass:[self objectClass]];
                        if (element) [temporaryRetainedObjects addObject:element];
                    }
                }
            } @catch (NSException *exception) {
                continue;
            }
            
            [retainedObjects addObjectsFromArray:[temporaryRetainedObjects allObjects]];
            break;
        }
    }
    
    return [NSSet setWithArray:retainedObjects];
}

// 指定在垃圾收集的环境中，指针是否应该使用弱读写屏障。
- (BOOL)objectRetainsEnumerableKeys {
    if ([self.object respondsToSelector:@selector(pointerFunctions)]) {
        NSPointerFunctions *pointerFunctions = [self.object pointerFunctions];
        if (pointerFunctions.usesWeakReadAndWriteBarriers) {
            return NO;
        }
    }
    
    if ([self.object respondsToSelector:@selector(keyPointerFunctions)]) {
        NSPointerFunctions *pointerFunctions = [self.object keyPointerFunctions];
        if (pointerFunctions.usesWeakReadAndWriteBarriers) {
            return NO;
        }
    }
    return YES;
}

- (BOOL)objectRetainsEnumerableValues {
    if ([self.object respondsToSelector:@selector(valuePointerFunctions)]) {
        NSPointerFunctions *pointerFuncations = [self.object valuePointerFunctions];
        if (pointerFuncations.usesWeakReadAndWriteBarriers) {
            return NO;
        }
    }
    return YES;
}

@end
