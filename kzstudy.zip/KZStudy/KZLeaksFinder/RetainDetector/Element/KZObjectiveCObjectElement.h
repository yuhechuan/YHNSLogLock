//
//  KZObjectiveCObjectElement.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectiveCGraphElement.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZObjectiveCObjectElement : KZObjectiveCGraphElement

@end

NS_ASSUME_NONNULL_END
