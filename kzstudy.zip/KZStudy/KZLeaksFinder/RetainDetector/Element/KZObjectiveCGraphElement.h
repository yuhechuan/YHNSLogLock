//
//  KZObjectiveCGraphElement.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import <Foundation/Foundation.h>
#import "KZRetaionDetectorConfiger.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZObjectiveCGraphElement : NSObject

@property (nonatomic, copy, nullable) NSArray<NSString *> *namePath;

@property (nonatomic, strong, nullable) id object;

@property (nonatomic, strong, nonnull) KZRetaionDetectorConfiger *configer;


+ (instancetype)elementWithObject:(id)object
                    configuration:(KZRetaionDetectorConfiger *)configer
                         namePath:(nullable NSArray<NSString *> *)namePath
                        fromClass:(nullable Class)fromClass;

- (NSSet *)allRetainedObjects;

- (Class)objectClass;

- (size_t)objectAddress;

- (NSString *)classNameOrNull;

@end

NS_ASSUME_NONNULL_END
