//
//  KZObjectiveCNSCFTimerElement.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectiveCNSCFTimerElement.h"

@implementation KZObjectiveCNSCFTimerElement

typedef struct {
    long _unknown; // This is always 1
    id target;
    SEL selector;
    NSDictionary *userInfo;
} _KZNSCFTimerInfoStruct;

- (NSSet *)allRetainedObjects {
    __attribute__((objc_precise_lifetime)) NSTimer *timer = self.object;
    
    if (timer == nil) return nil;
    
    NSMutableSet *retainedObjects = [[super allRetainedObjects] mutableCopy];
    
    CFRunLoopTimerContext context;
    CFRunLoopTimerGetContext((CFRunLoopTimerRef)timer, &context);
    
    if (context.info && context.retain) {
        _KZNSCFTimerInfoStruct infoStruct = *(_KZNSCFTimerInfoStruct *)(context.info);
        if (infoStruct.target) {
            KZObjectiveCGraphElement *element = [KZObjectiveCGraphElement elementWithObject:infoStruct.target
                                                                              configuration:self.configer
                                                                                   namePath:@[@"target"]
                                                                                  fromClass:[self objectClass]];
            if (element) [retainedObjects addObject:element];
        }
        
        if (infoStruct.userInfo) {
            /// 可能是个bug 应该加入 infoStruct.userInfo
            KZObjectiveCGraphElement *element = [KZObjectiveCGraphElement elementWithObject:infoStruct.target
                                                                              configuration:self.configer
                                                                                   namePath:@[@"userInfo"]
                                                                                  fromClass:[self objectClass]];
            if (element) [retainedObjects addObject:element];
        }
    }
    
    return retainedObjects;
}

@end
