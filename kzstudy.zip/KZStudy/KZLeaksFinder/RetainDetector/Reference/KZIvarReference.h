//
//  KZIvarReference.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectReference.h"
#import <objc/runtime.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, KZIvarType) {
    KZIvarObjectType,
    KZIvarBlockType,
    KZIvarStructType,
    KZIvarUnknownType,
};


@interface KZIvarReference : KZObjectReference

@property (nonatomic, copy, nullable) NSString *name;

@property (nonatomic, assign) KZIvarType type;

@property (nonatomic, assign) ptrdiff_t offset;

@property (nonatomic, assign) NSUInteger index;

@property (nonatomic, assign, nonnull) Ivar ivar;

- (nonnull instancetype)initWithIvar:(nonnull Ivar)ivar;

@end

NS_ASSUME_NONNULL_END
