//
//  KZObjectInStructReference.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectReference.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZObjectInStructReference : KZObjectReference

@end

NS_ASSUME_NONNULL_END
