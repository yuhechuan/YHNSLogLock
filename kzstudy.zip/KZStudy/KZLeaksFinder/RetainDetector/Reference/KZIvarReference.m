//
//  KZIvarReference.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZIvarReference.h"

@implementation KZIvarReference

- (instancetype)initWithIvar:(Ivar)ivar {
  if (self = [super init]) {
    _name = @(ivar_getName(ivar));
    _type = [self convertEncodingToType:ivar_getTypeEncoding(ivar)];
    _offset = ivar_getOffset(ivar);
    _index = _offset / sizeof(void *);
    _ivar = ivar;
  }
  return self;
}

- (KZIvarType)convertEncodingToType:(const char *)typeEncoding {
  if (typeEncoding[0] == '{') {
    return KZIvarStructType;
  }

  if (typeEncoding[0] == '@') {
    if (strncmp(typeEncoding, "@?", 2) == 0) {
      return KZIvarBlockType;
    }
    return KZIvarObjectType;
  }

  return KZIvarUnknownType;
}

- (NSString *)description {
  return [NSString stringWithFormat:@"[%@, index: %lu]", _name, (unsigned long)_index];
}

#pragma mark - overwrite

- (NSUInteger)indexInIvarLayout {
  return _index;
}

- (id)objectReferenceFromObject:(id)object {
  return object_getIvar(object, _ivar);
}

- (NSArray<NSString *> *)namePath {
  return @[@(ivar_getName(_ivar))];
}

@end
