//
//  KZObjectReference.h
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZObjectReference : NSObject

- (NSUInteger)indexInIvarLayout;

- (nullable id)objectReferenceFromObject:(nullable id)object;

- (nullable NSArray<NSString *> *)namePath;

@end

NS_ASSUME_NONNULL_END
