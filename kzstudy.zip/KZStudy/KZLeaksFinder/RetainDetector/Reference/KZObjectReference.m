//
//  KZObjectReference.m
//  MemoryDetectorDemo
//
//  Created by qianye on 2021/9/26.
//

#import "KZObjectReference.h"

@implementation KZObjectReference

- (NSUInteger)indexInIvarLayout {
    return 0;
}

- (nullable id)objectReferenceFromObject:(nullable id)object {
    return nil;
}

- (nullable NSArray<NSString *> *)namePath {
    return nil;
}

@end
