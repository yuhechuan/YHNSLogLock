//
//  KZLeaksAspect.m
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/2.
//

#import "KZLeaksAspect.h"
#import <pthread.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <UIKit/UIKit.h>

@interface KZAspectIdentifier : NSObject
@property (nonatomic, assign) SEL selector;
@property (nonatomic, strong) KZLeaksAspectBlock block;
@property (nonatomic, strong) Class cls;
- (instancetype)initWithSelector:(SEL)selector cls:(Class)cls block:(KZLeaksAspectBlock)block;
@end

@interface KZAspectContainer : NSObject
- (void)addAspect:(KZAspectIdentifier *)aspect;
- (BOOL)removeAspect:(id)aspect;
- (BOOL)hasAspects;
@property (atomic, copy) NSArray *aspects;
@end

@interface NSInvocation (Aspects)

- (NSArray *)arguments;
- (id)returnValue;

@end

static NSString *const AspectsSubclassSuffix = @"_KZAspects_";
static NSString *const KZAspectsSelectorPrefix = @"kz_aspects";

@implementation KZLeaksAspect

+ (void)hook:(Class)cls selector:(SEL)selector usingBlock:(KZLeaksAspectBlock)block {
    __block KZAspectIdentifier *identifier = nil;
    [self performLocked:^{
        if ([self isSelectorAllowedAndTrack:cls selector:selector]) {
            identifier = [[KZAspectIdentifier alloc] initWithSelector:selector cls:cls block:block];
            if (identifier) {
                KZAspectContainer *aspectContainer = [self getContainerWithClass:cls selector:selector];
                [aspectContainer addAspect:identifier];
                
                // Modify the class to allow message interception.
                [self prepareHookWithClass:cls selector:selector];
            }
        }
    }];
}

+ (BOOL)isSelectorAllowedAndTrack:(Class)cls selector:(SEL)selector {
    static NSSet *disallowedSelectorList;
    static dispatch_once_t pred;
    dispatch_once(&pred, ^{
        disallowedSelectorList = [NSSet setWithObjects:@"retain", @"release", @"autorelease", @"forwardInvocation:", nil];
    });
    
    NSString *selectorName = NSStringFromSelector(selector);
    if ([disallowedSelectorList containsObject:selectorName]) {
        NSLog(@"Selector %@ is blacklisted.", selectorName);
        return NO;
    }
    
    if (![self respondsToSelector:selector] && ![cls instancesRespondToSelector:selector]) {
        NSLog(@"Unable to find selector -[%@ %@].", NSStringFromClass(cls), selectorName);
        return NO;
    }
    
    return YES;
}

+ (void)performLocked:(dispatch_block_t)block {
    static pthread_mutex_t lock;
    
    static pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&lock, &attr);
    
    pthread_mutex_lock(&lock);
    block();
    pthread_mutex_unlock(&lock);
}

+ (KZAspectContainer *)getContainerWithClass:(Class)cls selector:(SEL)selector {
    SEL aliasSelector = [self aliasForSelector:selector];
    KZAspectContainer *aspectContainer = objc_getAssociatedObject(cls, aliasSelector);
    if (!aspectContainer) {
        aspectContainer = [KZAspectContainer new];
        objc_setAssociatedObject(cls, aliasSelector, aspectContainer, OBJC_ASSOCIATION_RETAIN);
    }
    return aspectContainer;
}

+ (SEL)aliasForSelector:(SEL)selector {
    return NSSelectorFromString([KZAspectsSelectorPrefix stringByAppendingFormat:@"_%@", NSStringFromSelector(selector)]);
}

+ (void)prepareHookWithClass:(Class)cls selector:(SEL)selector {
    Class klass = [self hookClass:cls];
    Method targetMethod = class_getInstanceMethod(klass, selector);
    IMP targetMethodIMP = method_getImplementation(targetMethod);
    if (targetMethodIMP != _objc_msgForward) {
        // Make a method alias for the existing method implementation, it not already copied.
        const char *typeEncoding = method_getTypeEncoding(targetMethod);
        SEL aliasSelector = [self aliasForSelector:selector];
        if (![klass instancesRespondToSelector:aliasSelector]) {
            BOOL addedAlias = class_addMethod(klass, aliasSelector, method_getImplementation(targetMethod), typeEncoding);
            NSCAssert(addedAlias, @"Original implementation for %@ is already copied to %@ on %@", NSStringFromSelector(selector), NSStringFromSelector(aliasSelector), klass);
        }

        // We use forwardInvocation to hook in.
        class_replaceMethod(klass, selector, _objc_msgForward, typeEncoding);
    }
}

+ (Class)hookClass:(Class)cls {
    Class baseClass = object_getClass(cls);
    NSString *className = NSStringFromClass(baseClass);

    if ([className hasSuffix:AspectsSubclassSuffix]) {
        return baseClass;
    } else if (class_isMetaClass(baseClass)) {
        [self swizzleClassInPlace:cls];
    }
    return cls;
}

+ (void)_modifySwizzledClasses:(void (^)(NSMutableSet *swizzledClasses))block {
    static NSMutableSet *swizzledClasses;
    static dispatch_once_t pred;
    dispatch_once(&pred, ^{
        swizzledClasses = [NSMutableSet new];
    });
    @synchronized(swizzledClasses) {
        block(swizzledClasses);
    }
}

+ (void)swizzleClassInPlace:(Class)klass {
    NSString *className = NSStringFromClass(klass);
    [self _modifySwizzledClasses:^(NSMutableSet *swizzledClasses) {
        if (![swizzledClasses containsObject:className]) {
            [self swizzleForwardInvocation:klass];
            [swizzledClasses addObject:className];
        }
    }];
}

static NSString *const KZAspectsForwardInvocationSelectorName = @"_kz_aspects_forwardInvocation:";
+ (void)swizzleForwardInvocation:(Class)klass {
    // If there is no method, replace will act like class_addMethod.
    Method kzAspectsMethod = class_getClassMethod(self, @selector(_KZAspectsAreBeingCalledWithInvocation:));
    IMP originalImplementation = class_replaceMethod(klass, @selector(forwardInvocation:), method_getImplementation(kzAspectsMethod), method_getTypeEncoding(kzAspectsMethod));
    if (originalImplementation) {
        class_addMethod(klass, NSSelectorFromString(KZAspectsForwardInvocationSelectorName), originalImplementation, method_getTypeEncoding(kzAspectsMethod));
    }
}

#define aspect_invoke(aspects, info) \
for (KZAspectIdentifier *aspect in aspects) {\
    if (aspect.block) aspect.block(info);\
}

+ (void)_KZAspectsAreBeingCalledWithInvocation:(NSInvocation *)invocation {
    SEL originalSelector = invocation.selector;
    SEL aliasSelector = [KZLeaksAspect aliasForSelector:invocation.selector];
    invocation.selector = aliasSelector;
    KZAspectContainer *classContainer = [KZLeaksAspect getContainerForClass:[invocation.target class] selector:aliasSelector];
    KZAspectInfo *info = [[KZAspectInfo alloc] initWithInstance:invocation.target invocation:invocation];

    BOOL respondsToAlias = YES;
    Class klass = object_getClass(invocation.target);
    do {
        if ((respondsToAlias = [klass instancesRespondToSelector:aliasSelector])) {
            [invocation invoke];
            break;
        }
    } while (!respondsToAlias && (klass = class_getSuperclass(klass)));

    info.returnValue = invocation.returnValue;
    aspect_invoke(classContainer.aspects, info);

    // If no hooks are installed, call original implementation (usually to throw an exception)
    if (!respondsToAlias) {
        invocation.selector = originalSelector;
        SEL originalForwardInvocationSEL = NSSelectorFromString(KZAspectsForwardInvocationSelectorName);
        if ([[self class] respondsToSelector:originalForwardInvocationSEL]) {
            ((void( *)(id, SEL, NSInvocation *))objc_msgSend)([self class], originalForwardInvocationSEL, invocation);
        } else {
            [[self class] doesNotRecognizeSelector:invocation.selector];
        }
    }
}

+ (KZAspectContainer *)getContainerForClass:(Class)klass selector:(SEL)selector {
    KZAspectContainer *classContainer = nil;
    do {
        classContainer = objc_getAssociatedObject(klass, selector);
        if (classContainer.hasAspects) break;
    } while ((klass = class_getSuperclass(klass)));

    return classContainer;
}

#undef aspect_invoke

@end

#pragma mark - NSInvocation (Aspects)

@implementation NSInvocation (Aspects)

- (id)argumentAtIndex:(NSUInteger)index {
    const char *argType = [self.methodSignature getArgumentTypeAtIndex:index];
    // Skip const type qualifier.
    if (argType[0] == _C_CONST) argType++;

#define WRAP_AND_RETURN(type) do { type val = 0; [self getArgument:&val atIndex:(NSInteger)index]; return @(val); } while (0)
    if (strcmp(argType, @encode(id)) == 0 || strcmp(argType, @encode(Class)) == 0) {
        __autoreleasing id returnObj;
        [self getArgument:&returnObj atIndex:(NSInteger)index];
        return returnObj;
    } else if (strcmp(argType, @encode(SEL)) == 0) {
        SEL selector = 0;
        [self getArgument:&selector atIndex:(NSInteger)index];
        return NSStringFromSelector(selector);
    } else if (strcmp(argType, @encode(Class)) == 0) {
        __autoreleasing Class theClass = Nil;
        [self getArgument:&theClass atIndex:(NSInteger)index];
        return theClass;
        // Using this list will box the number with the appropriate constructor, instead of the generic NSValue.
    } else if (strcmp(argType, @encode(char)) == 0) {
        WRAP_AND_RETURN(char);
    } else if (strcmp(argType, @encode(int)) == 0) {
        WRAP_AND_RETURN(int);
    } else if (strcmp(argType, @encode(short)) == 0) {
        WRAP_AND_RETURN(short);
    } else if (strcmp(argType, @encode(long)) == 0) {
        WRAP_AND_RETURN(long);
    } else if (strcmp(argType, @encode(long long)) == 0) {
        WRAP_AND_RETURN(long long);
    } else if (strcmp(argType, @encode(unsigned char)) == 0) {
        WRAP_AND_RETURN(unsigned char);
    } else if (strcmp(argType, @encode(unsigned int)) == 0) {
        WRAP_AND_RETURN(unsigned int);
    } else if (strcmp(argType, @encode(unsigned short)) == 0) {
        WRAP_AND_RETURN(unsigned short);
    } else if (strcmp(argType, @encode(unsigned long)) == 0) {
        WRAP_AND_RETURN(unsigned long);
    } else if (strcmp(argType, @encode(unsigned long long)) == 0) {
        WRAP_AND_RETURN(unsigned long long);
    } else if (strcmp(argType, @encode(float)) == 0) {
        WRAP_AND_RETURN(float);
    } else if (strcmp(argType, @encode(double)) == 0) {
        WRAP_AND_RETURN(double);
    } else if (strcmp(argType, @encode(BOOL)) == 0) {
        WRAP_AND_RETURN(BOOL);
    } else if (strcmp(argType, @encode(bool)) == 0) {
        WRAP_AND_RETURN(BOOL);
    } else if (strcmp(argType, @encode(char *)) == 0) {
        WRAP_AND_RETURN(const char *);
    } else if (strcmp(argType, @encode(void (^)(void))) == 0) {
        __unsafe_unretained id block = nil;
        [self getArgument:&block atIndex:(NSInteger)index];
        return [block copy];
    } else {
        NSUInteger valueSize = 0;
        NSGetSizeAndAlignment(argType, &valueSize, NULL);

        unsigned char valueBytes[valueSize];
        [self getArgument:valueBytes atIndex:(NSInteger)index];

        return [NSValue valueWithBytes:valueBytes objCType:argType];
    }
    return nil;
#undef WRAP_AND_RETURN
}

- (NSArray *)arguments {
    NSMutableArray *argumentsArray = [NSMutableArray array];
    for (NSUInteger idx = 2; idx < self.methodSignature.numberOfArguments; idx++) {
        [argumentsArray addObject:[self argumentAtIndex:idx] ?: NSNull.null];
    }
    return [argumentsArray copy];
}

- (id)returnValue {
    const char *returnType = self.methodSignature.methodReturnType;
    id __unsafe_unretained returnValue;
    if(!strcmp(returnType, @encode(void))){
        return nil;
    } else if(!strcmp(returnType, @encode(id))) {
        [self getReturnValue:&returnValue];
    } else {
        NSUInteger length = [self.methodSignature methodReturnLength];
        void *buffer = (void *)malloc(length);
        [self getReturnValue:buffer];
        if(!strcmp(returnType, @encode(BOOL))) {
            returnValue = [NSNumber numberWithBool:*((BOOL*)buffer)];
        } else if( !strcmp(returnType, @encode(NSInteger)) ){
            returnValue = [NSNumber numberWithInteger:*((NSInteger*)buffer)];
        } else if( !strcmp(returnType, @encode(int)) ){
            returnValue = [NSNumber numberWithInt:*((int*)buffer)];
        } else if( !strcmp(returnType, @encode(CGFloat)) ){
            returnValue = [NSNumber numberWithFloat:*((CGFloat*)buffer)];
        } else if( !strcmp(returnType, @encode(double)) ){
            returnValue = [NSNumber numberWithDouble:*((double*)buffer)];
        } else {
            returnValue = [NSValue valueWithBytes:buffer objCType:returnType];
        }
        free(buffer);
    }
    return returnValue;
}

@end


#pragma mark - KZAspectInfo

@implementation KZAspectInfo

@synthesize arguments = _arguments;

- (id)initWithInstance:(__unsafe_unretained id)instance invocation:(NSInvocation *)invocation {
    if (self = [super init]) {
        _instance = instance;
        _originalInvocation = invocation;
    }
    return self;
}

- (NSArray *)arguments {
    if (!_arguments) {
        _arguments = self.originalInvocation.arguments;
    }
    return _arguments;
}

@end

#pragma mark - KZAspectIdentifier

@implementation KZAspectIdentifier

- (instancetype)initWithSelector:(SEL)selector cls:(Class)cls block:(KZLeaksAspectBlock)block {
    if (self = [super init]) {
        self.selector = selector;
        self.selector = selector;
        self.block = block;
        self.cls = cls;
    }
    return self;
}

@end

#pragma mark - KZAspectsContainer

@implementation KZAspectContainer

- (BOOL)hasAspects {
    return self.aspects.count > 0;
}

- (void)addAspect:(KZAspectIdentifier *)aspect {
    self.aspects = [(self.aspects ?:@[]) arrayByAddingObject:aspect];
}

- (BOOL)removeAspect:(id)aspect {
    for (NSString *aspectArrayName in @[NSStringFromSelector(@selector(aspects))]) {
        NSArray *array = [self valueForKey:aspectArrayName];
        NSUInteger index = [array indexOfObjectIdenticalTo:aspect];
        if (array && index != NSNotFound) {
            NSMutableArray *newArray = [NSMutableArray arrayWithArray:array];
            [newArray removeObjectAtIndex:index];
            [self setValue:newArray forKey:aspectArrayName];
            return YES;
        }
    }
    return NO;
}

@end
