//
//  NSObject+KZLeaksFinder.m
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/9.
//

#import "NSObject+KZLeaksFinder.h"
#import "KZLeaksFinder.h"
#import <objc/runtime.h>

@implementation NSObject (KZLeaksFinder)

/// 遍历 相关类 或者 子类  把类名和 地址 加入 栈 并开启检测
- (void)willReleaseChildren:(NSArray *)children {
    if (children.count > 0) {
        for (id child in children) {
            // 类名
            [child setKzlf_viewStack:[self.kzlf_viewStack arrayByAddingObject:NSStringFromClass([child class])]];
            // 内存地址
            [child setKzlf_parentPtrs:[self.kzlf_parentPtrs setByAddingObject:@((uintptr_t)child)]];
            // 开始监测 会先调用 本类分离的 willDealloc 里面会调用super 到NSObject
            [child willDealloc];
        }
        NSLog(@"%@", self.kzlf_viewStack.description);
    }
}

/// 判断是否开启 检测
- (BOOL)willDealloc {
    NSString *className = NSStringFromClass([self class]);
    // 如果在白名单里面 不做处理
    if ([KZLeaksFinder.shareFinder.whiteList containsObject:className])
        return NO;
    // 对于UIControl子类 和 UITouch 不做监控
    if ([KZLeaksFinder.shareFinder.currentSender isEqual:self])
        return NO;
    
    // 原理  如果对象两秒之后没有释放 表示产生了内存泄漏 如果对象销毁 strongSelf我空 kzlf_assertNotDealloc调用失效
    __weak id weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(KZLeaksFinderObjectDeallocTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        __strong id strongSelf = weakSelf;
        [strongSelf kzlf_assertNotDealloc];
    });
    
    return YES;
}

- (void)kzlf_assertNotDealloc {
    [KZLeaksFinder.shareFinder addLeakedObject:self];
}

+ (void)enableLeaksFinder { }

#pragma mark setter&getter

- (NSArray *)kzlf_viewStack {
    NSArray *viewStack = objc_getAssociatedObject(self, @selector(kzlf_viewStack));
    if (viewStack == nil) {
        /// 先把自己加进入
        viewStack = [NSMutableArray arrayWithObject:NSStringFromClass([self class])];
        objc_setAssociatedObject(self, @selector(kzlf_viewStack), viewStack, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return viewStack;
}

- (void)setKzlf_viewStack:(NSArray *)kzlf_viewStack {
    objc_setAssociatedObject(self, @selector(kzlf_viewStack), kzlf_viewStack, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (NSSet *)kzlf_parentPtrs {
    NSSet *parentPtrs = objc_getAssociatedObject(self, @selector(kzlf_parentPtrs));
    if (parentPtrs == nil) {
        parentPtrs = [NSSet setWithObject:@((uintptr_t)self)];
        objc_setAssociatedObject(self, @selector(kzlf_parentPtrs), parentPtrs, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return parentPtrs;
}

- (void)setKzlf_parentPtrs:(NSSet *)kzlf_parentPtrs {
    objc_setAssociatedObject(self, @selector(kzlf_parentPtrs), kzlf_parentPtrs, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
