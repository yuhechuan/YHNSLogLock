//
//  KZLeaksProxy.h
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZLeaksProxy : NSObject

@property (nonatomic, weak) id object;

@property (nonatomic, strong) NSNumber *objectPtr;

@property (nonatomic, strong) NSArray *viewStack;

@end

NS_ASSUME_NONNULL_END
