//
//  KZLeaksFinder.h
//  KZLeaksFinder
//
//  Created by qianye on 2021/8/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define KZLeaksFinderObjectDeallocTime      2.0

/*
 MLeaksFinder + FBRetainCycleDetector
 */

typedef void (^KZLeaksFinderBlock)(NSString *leakType, NSString *leakInfo);

@interface KZLeaksFinder : NSObject

@property (nonatomic, strong) NSMutableSet *whiteList;

@property (nonatomic, weak) id currentSender;

+ (instancetype)shareFinder;

- (void)enableLeaksFinder:(KZLeaksFinderBlock)block;

- (void)addLeakedObject:(id)object;
- (void)removeLeakedObjectPtr:(NSNumber *)ptr;

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
