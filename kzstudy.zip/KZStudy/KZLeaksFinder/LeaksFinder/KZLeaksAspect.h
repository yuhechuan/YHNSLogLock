//
//  KZLeaksAspect.h
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZAspectInfo : NSObject

@property (nonatomic, unsafe_unretained) id instance;
@property (nonatomic, strong) NSArray *arguments;
@property (nonatomic, strong) NSInvocation *originalInvocation;
@property (nonatomic, strong) id returnValue;

- (id)initWithInstance:(__unsafe_unretained id)instance invocation:(NSInvocation *)invocation;

@end

typedef void (^KZLeaksAspectBlock)(KZAspectInfo *info);

@interface KZLeaksAspect : NSObject

+ (void)hook:(Class)cls selector:(SEL)selector usingBlock:(KZLeaksAspectBlock)block;

@end

NS_ASSUME_NONNULL_END
