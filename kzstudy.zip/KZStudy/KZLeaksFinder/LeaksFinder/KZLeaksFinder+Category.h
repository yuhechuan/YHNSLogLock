//
//  KZLeaksFinder+Category.h
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/9.
//

#import "KZLeaksFinder.h"


NS_ASSUME_NONNULL_BEGIN

@interface KZLeaksFinder (Category)

@end

NS_ASSUME_NONNULL_END
