//
//  KZLeaksFinder.m
//  KZLeaksFinder
//
//  Created by qianye on 2021/8/28.
//

#import "KZLeaksFinder.h"
#import "NSObject+KZLeaksFinder.h"
#import <objc/runtime.h>
#import "KZLeaksProxy.h"
#import "KZRetainDetector.h"

static const void *const kzlfHasBeenPoppedKey = &kzlfHasBeenPoppedKey;
static const void *const kzlfPoppedDetailVCKey = &kzlfPoppedDetailVCKey;
static const void *const kzlfLeakedObjectProxyKey = &kzlfLeakedObjectProxyKey;

@interface KZLeaksFinder ()

@property (nonatomic, strong) NSMutableSet *leakedObjectPtrs;
@property (nonatomic, copy) KZLeaksFinderBlock block;
@property (nonatomic, strong) KZRetainDetector *detector;

@end

@implementation KZLeaksFinder

+ (instancetype)shareFinder {
    static KZLeaksFinder *leaksFinder;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        leaksFinder = [[KZLeaksFinder alloc] init];
    });
    return leaksFinder;
}

- (instancetype)init {
    if (self = [super init]) {
        self.whiteList = [NSMutableSet setWithObjects:
                          @"UIFieldEditor", // UIAlertControllerTextField
                          @"UINavigationBar",
                          @"_UIAlertControllerActionView",
                          @"_UIVisualEffectBackdropView",
                          @"_UIAlertControllerView",
                          nil];
        NSString *systemVersion = [UIDevice currentDevice].systemVersion;
        if ([systemVersion compare:@"10.0" options:NSNumericSearch] != NSOrderedAscending) {
            [self.whiteList addObject:@"UISwitch"];
        }
        
        self.leakedObjectPtrs = [NSMutableSet set];
        // 成员变量过滤器
        self.detector = [[KZRetainDetector alloc] initWithConfiger:nil];
    }
    return self;
}

- (void)enableLeaksFinder:(KZLeaksFinderBlock)block {
    self.block = block;
    
    [UIApplication enableLeaksFinder];
    [UITouch enableLeaksFinder];
    [UIViewController enableLeaksFinder];
    [UINavigationController enableLeaksFinder];
}

- (void)addLeakedObject:(id)object {
    NSAssert([NSThread isMainThread], @"Must be in main thread.");
    
    if (![object kzlf_parentPtrs].count) return;
    
    // 是否有交集 防止重复弹框
    if (![self.leakedObjectPtrs intersectsSet:[object kzlf_parentPtrs]]) {
        KZLeaksProxy *proxy = [[KZLeaksProxy alloc] init];
        proxy.object = object;
        proxy.objectPtr = @((uintptr_t)object);
        proxy.viewStack = [object kzlf_viewStack];
        // 把proxy 关联到 未销毁的对象上面  如果对象后期销毁 提示弹框
        objc_setAssociatedObject(object, kzlfLeakedObjectProxyKey, proxy, OBJC_ASSOCIATION_RETAIN);
        
        [self showAlertWithTitle:@"Memory Leak" message:proxy.viewStack.description proxy:proxy];
        [self.leakedObjectPtrs addObject:@((uintptr_t)proxy.object)];
        
        if (self.block) self.block(@"Memory Leak", [proxy.viewStack componentsJoinedByString:@"->"]);
    }
}

- (void)removeLeakedObjectPtr:(NSNumber *)ptr {
    [self.leakedObjectPtrs removeObject:ptr];
}

#pragma mark - show alert

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message {
    [self showAlertWithTitle:title message:message proxy:nil];
}

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message proxy:(KZLeaksProxy *)proxy {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:[NSString stringWithFormat:@"%@", message] preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alertController addAction:okAction];
    
    if (proxy.object) {
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"Retain Cycle" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self.detector setCandidate:proxy.object];
            NSSet *retainCycles = [self.detector findRetainCycles];
            
            BOOL hasFound = NO;
            for (NSArray *retainCycle in retainCycles) {
                NSInteger index = 0;
                for (KZObjectiveCGraphElement *element in retainCycle) {
                    if (element.object == proxy.object) {
                        NSArray *shiftedRetainCycle = [self shiftArray:retainCycle toIndex:index];
                        if (self.block) self.block(@"Retain Cycle", [NSString stringWithFormat:@"%@", shiftedRetainCycle]);
                        [self showAlertWithTitle:@"Retain Cycle" message:[NSString stringWithFormat:@"%@", shiftedRetainCycle] proxy:nil];
                        
                        hasFound = YES;
                        break;
                    }
                    ++index;
                }
                if (hasFound) break;
            }
            if (!hasFound) {
                if (self.block) self.block(@"Retain Cycle", @"Retain Cycle: Fail to find a retain cycle");
                [self showAlertWithTitle:@"Retain Cycle" message:@"Retain Cycle: Fail to find a retain cycle" proxy:nil];
            }
        }];
        [alertController addAction:confirmAction];
    }
    
    UIViewController *presentedViewController = [self findPresentedViewController:[self getKeyWindow].rootViewController];
    [presentedViewController presentViewController:alertController animated:YES completion:nil];
}

- (UIViewController *)findPresentedViewController:(UIViewController *)controller {
    UIViewController *presentedViewController = controller;
    while (presentedViewController.presentedViewController) {
        presentedViewController = presentedViewController.presentedViewController;
    }
    return presentedViewController;
}

- (NSArray *)shiftArray:(NSArray *)array toIndex:(NSInteger)index {
    if (index == 0) {
        return array;
    }
    
    NSRange range = NSMakeRange(index, array.count - index);
    NSMutableArray *result = [[array subarrayWithRange:range] mutableCopy];
    [result addObjectsFromArray:[array subarrayWithRange:NSMakeRange(0, index)]];
    return result;
}

#pragma mark - other

- (UIWindow *)getKeyWindow {
    NSArray *windows = [UIApplication sharedApplication].windows;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if ([scene isKindOfClass:UIWindowScene.class] && [((UIWindowScene *)scene).screen isEqual:UIScreen.mainScreen]) {
                windows = ((UIWindowScene *)scene).windows;
                break;
            }
        }
    }
    
    UIWindow *targetWindow = nil;
    for (UIWindow *window in windows) {
        if (!window.hidden && window.rootViewController != nil) {
            if (targetWindow == nil || window.isKeyWindow) {
                targetWindow = window;
            }
        }
    }
    return targetWindow;
}

@end
