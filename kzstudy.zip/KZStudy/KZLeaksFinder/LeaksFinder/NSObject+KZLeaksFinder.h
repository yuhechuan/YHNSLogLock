//
//  NSObject+KZLeaksFinder.h
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (KZLeaksFinder)

@property (nonatomic, strong) NSArray *kzlf_viewStack;

@property (nonatomic, strong) NSSet *kzlf_parentPtrs;

- (BOOL)willDealloc;
- (void)willReleaseChildren:(NSArray *)children;
+ (void)enableLeaksFinder;

@end

NS_ASSUME_NONNULL_END
