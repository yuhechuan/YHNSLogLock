//
//  KZLeaksFinder+Category.m
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/9.
//

#import "KZLeaksFinder+Category.h"
#import "NSObject+KZLeaksFinder.h"
#import <objc/runtime.h>
#import <UIKit/UIKit.h>

static const void *const kzlfHasBeenPoppedKey = &kzlfHasBeenPoppedKey;
static const void *const kzlfPoppedDetailVCKey = &kzlfPoppedDetailVCKey;
static const void *const kzlfLeakedObjectProxyKey = &kzlfLeakedObjectProxyKey;

static void kzlfSwizzleClass(Class clas, SEL originalSEL, SEL swizzledSEL) {
    Method originalMethod = class_getInstanceMethod(clas, originalSEL);
    Method swizzledMethod = class_getInstanceMethod(clas, swizzledSEL);
    
    BOOL didAddMethod = class_addMethod(clas, originalSEL, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
    
    if (didAddMethod) {
        class_replaceMethod(clas, swizzledSEL, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
    } else {
        method_exchangeImplementations(originalMethod, swizzledMethod);
    }
}


@implementation UIApplication (KZLeaksFinder)

+ (void)enableLeaksFinder {
    static dispatch_once_t applicaiton_onceToken;
    dispatch_once(&applicaiton_onceToken, ^{
        kzlfSwizzleClass(self, @selector(sendAction:to:from:forEvent:), @selector(kzlf_swizzled_sendAction:to:from:forEvent:));
    });
}

// 对于 UIControl的子类 存一下
- (BOOL)kzlf_swizzled_sendAction:(SEL)action to:(id)target from:(id)sender forEvent:(UIEvent *)event {
    KZLeaksFinder.shareFinder.currentSender = target;
    return [self kzlf_swizzled_sendAction:action to:target from:sender forEvent:event];
}

@end

@implementation UITouch (KZLeaksFinder)

+ (void)enableLeaksFinder {
    static dispatch_once_t touch_onceToken;
    dispatch_once(&touch_onceToken, ^{
        kzlfSwizzleClass(self, @selector(setView:), @selector(kzlf_swizzled_setView:));
    });
}

- (void)kzlf_swizzled_setView:(UIView *)view {
    [self kzlf_swizzled_setView:view];
    
    if (view) {
        KZLeaksFinder.shareFinder.currentSender = view;
    }
}


@end

@implementation UITabBarController (KZLeaksFinder)

- (BOOL)willDealloc {
    // 没在白名单 不做处理
    if (![super willDealloc]) return NO;
    
    [self willReleaseChildren:self.viewControllers];
    
    return YES;
}

@end

@implementation UINavigationController (KZLeaksFinder)

/**
 * 1.push 出来的  pop  popTopController   popTopRoot
 *   pop的时候存一个标记位 表示控制器要 退出  在viewDidDisappear 里面判断标记位如果是YES 触发泄漏检测
 * 2. present 出来的
 *  dismissViewControllerAnimated 被调用时  触发 泄漏检测
 */

+ (void)enableLeaksFinder {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        kzlfSwizzleClass(self, @selector(pushViewController:animated:), @selector(kzlf_swizzled_pushViewController:animated:));
        kzlfSwizzleClass(self, @selector(popViewControllerAnimated:), @selector(kzlf_swizzled_popViewControllerAnimated:));
        kzlfSwizzleClass(self, @selector(popToViewController:animated:), @selector(kzlf_swizzled_popToViewController:animated:));
        kzlfSwizzleClass(self, @selector(popToRootViewControllerAnimated:), @selector(kzlf_swizzled_popToRootViewControllerAnimated:));
    });
}

- (void)kzlf_swizzled_pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.splitViewController) {
        id detailViewController = objc_getAssociatedObject(self, kzlfPoppedDetailVCKey);
        if ([detailViewController isKindOfClass:[UIViewController class]]) {
            [detailViewController willDealloc];
            objc_setAssociatedObject(self, kzlfPoppedDetailVCKey, nil, OBJC_ASSOCIATION_RETAIN);
        }
    }
    
    [self kzlf_swizzled_pushViewController:viewController animated:animated];
}

- (UIViewController *)kzlf_swizzled_popViewControllerAnimated:(BOOL)animated {
    /// 要销毁的控制器
    UIViewController *poppedViewController = [self kzlf_swizzled_popViewControllerAnimated:animated];
    if (!poppedViewController) return nil;
    
    if (self.splitViewController &&
        self.splitViewController.viewControllers.firstObject == self &&
        self.splitViewController == poppedViewController.splitViewController) {
        objc_setAssociatedObject(self, kzlfPoppedDetailVCKey, poppedViewController, OBJC_ASSOCIATION_RETAIN);
        return poppedViewController;
    }
    /// 要销毁的控制器 字段 设置为 yes 当 poppedViewController 走 viewDidDisappear 的时候 触发 泄漏监听
    objc_setAssociatedObject(poppedViewController, kzlfHasBeenPoppedKey, @(YES), OBJC_ASSOCIATION_RETAIN);
    
    return poppedViewController;
}

- (NSArray<UIViewController *> *)kzlf_swizzled_popToViewController:(UIViewController *)viewController animated:(BOOL)animated {
    NSArray<UIViewController *> *poppedViewControllers = [self kzlf_swizzled_popToViewController:viewController animated:animated];
    
    for (UIViewController *viewController in poppedViewControllers) {
        [viewController willDealloc];
    }
    
    return poppedViewControllers;
}

- (NSArray<UIViewController *> *)kzlf_swizzled_popToRootViewControllerAnimated:(BOOL)animated {
    NSArray<UIViewController *> *poppedViewControllers = [self kzlf_swizzled_popToRootViewControllerAnimated:animated];
    
    for (UIViewController *viewController in poppedViewControllers) {
        [viewController willDealloc];
    }
    
    return poppedViewControllers;
}

- (BOOL)willDealloc {
    // 没在白名单 不做处理
    if (![super willDealloc]) return NO;
    
    [self willReleaseChildren:self.viewControllers];
    
    return YES;
}

@end

@implementation UIViewController (KZLeaksFinder)

+ (void)enableLeaksFinder {
    kzlfSwizzleClass(self, @selector(viewDidDisappear:), @selector(kzlf_swizzled_viewDidDisappear:));
    kzlfSwizzleClass(self, @selector(viewWillAppear:), @selector(kzlf_swizzled_viewWillAppear:));
    kzlfSwizzleClass(self, @selector(dismissViewControllerAnimated:completion:), @selector(kzlf_swizzled_dismissViewControllerAnimated:completion:));
}

/// 如果 当前控制器是  因为 pop 走的 Disappear
- (void)kzlf_swizzled_viewDidDisappear:(BOOL)animated {
    [self kzlf_swizzled_viewDidDisappear:animated];
    
    if ([objc_getAssociatedObject(self, kzlfHasBeenPoppedKey) boolValue]) {
        [self willDealloc];
    }
}

/// 清空字段
- (void)kzlf_swizzled_viewWillAppear:(BOOL)animated {
    [self kzlf_swizzled_viewWillAppear:animated];
    
    objc_setAssociatedObject(self, kzlfHasBeenPoppedKey, @(NO), OBJC_ASSOCIATION_RETAIN);
}

/// dismiss 触发 泄漏监听
- (void)kzlf_swizzled_dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion {
    [self kzlf_swizzled_dismissViewControllerAnimated:flag completion:completion];
    
    UIViewController *dismissedViewController = self.presentedViewController;
    if (!dismissedViewController && self.presentingViewController) {
        dismissedViewController = self;
    }
    
    if (!dismissedViewController) return;
    
    [dismissedViewController willDealloc];
}

- (BOOL)willDealloc {
    // 没在白名单 不做处理
    if (![super willDealloc]) return NO;
    
    [self willReleaseChildren:self.childViewControllers];
    if (self.presentedViewController) {
        [self willReleaseChildren:@[self.presentedViewController]];
    }
    
    if (self.isViewLoaded) [self willReleaseChildren:@[self.view]];
    
    return YES;
}

@end

@implementation UIPageViewController (KZLeaksFinder)

- (BOOL)willDealloc {
    // 没在白名单 不做处理
    if (![super willDealloc]) return NO;
    
    [self willReleaseChildren:self.viewControllers];
    
    return YES;
}

@end

@implementation UISplitViewController (KZLeaksFinder)

- (BOOL)willDealloc {
    // 没在白名单 不做处理
    if (![super willDealloc]) return NO;
    
    [self willReleaseChildren:self.viewControllers];
    
    return YES;
}

@end

@implementation UIView (KZLeaksFinder)

- (BOOL)willDealloc {
    // 没在白名单 不做处理
    if (![super willDealloc]) return NO;
    
    [self willReleaseChildren:self.subviews];
    
    return YES;
}

@end
