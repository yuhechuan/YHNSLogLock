//
//  KZLeaksProxy.m
//  KZLeaksFinder
//
//  Created by qianye on 2021/9/9.
//

#import "KZLeaksProxy.h"
#import "KZLeaksFinder.h"

@implementation KZLeaksProxy

// 2s 之后 销毁 表示
- (void)dealloc {
    NSNumber *objectPtr = _objectPtr;
    NSArray *viewStack = _viewStack;
    dispatch_async(dispatch_get_main_queue(), ^{
        [KZLeaksFinder.shareFinder removeLeakedObjectPtr:objectPtr];
        
        [KZLeaksFinder.shareFinder showAlertWithTitle:@"Object Deallocated" message:[NSString stringWithFormat:@"%@", viewStack]];
    });
}

@end
