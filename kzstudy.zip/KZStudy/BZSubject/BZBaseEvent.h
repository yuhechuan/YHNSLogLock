//
//  BZBaseEvent.h
//  BZBoss
//
//  Created by yuhechuan on 2022/11/17.
//

#import <Foundation/Foundation.h>
#import "BZEvent.h"

typedef void (^BZBaseEventDisposeBlcok)(BZArgument *argument);

@interface BZBaseEvent : NSObject<BZEvent>

- (void)dispose:(BZBaseEventDisposeBlcok)disposeBlcok;

@end
