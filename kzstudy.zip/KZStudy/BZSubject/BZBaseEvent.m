//
//  BZBaseEvent.m
//  BZBoss
//
//  Created by yuhechuan on 2022/11/17.
//

#import "BZBaseEvent.h"
#import "BZArgument.h"

@interface BZBaseEvent ()

@end

@implementation BZBaseEvent

- (void)disposeEvent:(BZArgument *)argument {
    /// 子类实现
}

- (void)disposeEventType:(int)eventType {
    /// 子类实现
}

- (void)dispose:(BZBaseEventDisposeBlcok)disposeBlcok {
    BZArgument *arg = [[BZArgument alloc]init];
    if(disposeBlcok) {
        disposeBlcok(arg);
    }
    [self disposeEvent:arg];
}

@end
