//
//  BZBaseDispatch.h
//  BZBoss-BZBoss
//
//  Created by yuhechuan on 2022/11/16.
//

#import <Foundation/Foundation.h>
#import "BZSubjectNode.h"
#import "BZStore.h"

/// 调度中心
@interface BZBaseDispatch : BZStore

- (instancetype)initWithNode:(id<BZSubjectNode>)node;

- (void)reloadAllNodes;
- (void)reloadNodeSubJectClass:(Class)subJectClass;

@end

