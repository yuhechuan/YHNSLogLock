//
//  BZSubject.h
//  Pods
//
//  Created by yuhechuan on 2022/11/16.
//

#ifndef BZSubject_h
#define BZSubject_h

@protocol BZSubject<NSObject>

@optional

/// 一个业务线会回调多次
- (void)packagingNetType:(int)netType infoDict:(NSDictionary *)infoDict;

/// 获取当前业务的 请求体 可返回多个
- (NSArray *)subjectNetModels;

/// 关联的事件
- (Class)relatedSubjectEvent;

@end

#endif /* BZSubject_h */
