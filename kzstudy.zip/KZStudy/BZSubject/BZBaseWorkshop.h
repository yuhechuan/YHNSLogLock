//
//  BZBaseWorkshop.h
//  KZStudy
//
//  Created by yuhechuan on 2022/12/27.
//

#import "BZStore.h"
/// 车间 用于管理业务线
@interface BZBaseWorkshop : BZStore

@end
