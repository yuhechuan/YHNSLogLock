//
//  BZArgument.h
//  BZBoss-BZBoss
//
//  Created by yuhechuan on 2022/11/16.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "BZStore.h"

@interface BZArgument : BZStore
/// 通用的一些参数
@property (nonatomic, copy) NSString *stringValue;
@property (nonatomic, assign) BOOL boolValue;
@property (nonatomic, assign) int intValue;
@property (nonatomic, assign) CGFloat floatValue;
@property (nonatomic, copy) NSArray *arrayValue;
@property (nonatomic, copy) NSDictionary *dictValue;
@property (nonatomic, strong) UIView *viewValue;
@property (nonatomic, copy) void (^blockValue)(void);

/// 非通用的参数可以 通过 storeValue 存储 通过 valueWithStoreClass 取出

@end
