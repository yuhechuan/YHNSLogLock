//
//  BZEvent.h
//  Pods
//
//  Created by yuhechuan on 2022/11/16.
//

#ifndef BZEvent_h
#define BZEvent_h

@class BZArgument;

@protocol BZEvent<NSObject>

@optional

- (void)disposeEvent:(BZArgument *)argument;
- (void)disposeEventType:(int)eventType;

@end


#endif /* BZEvent_h */

