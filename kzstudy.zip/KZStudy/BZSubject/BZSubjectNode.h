//
//  BZSubjectNode.h
//  BZBoss
//
//  Created by yuhechuan on 2022/11/17.
//

#ifndef BZSubjectNode_h
#define BZSubjectNode_h

@class BZArgument;

@protocol BZSubjectNode <NSObject>

@optional

/// 当前节点的子节点
- (NSArray <id<BZSubjectNode>>*)childSubjectNodes;
/// 带参数 的 钩子
- (BZArgument *)hookNodeWithArgument:(BZArgument *)argument;
/// 关联的业务线
- (Class)relatedSubject;

/// 整体刷新方法
- (void)reloadNode;

@end

#endif /* BZSubjectNode_h */
