//
//  BZArgument.m
//  BZBoss-BZBoss
//
//  Created by yuhechuan on 2022/11/16.
//

#import "BZArgument.h"

@interface BZArgument ()

@end

@implementation BZArgument

@end
