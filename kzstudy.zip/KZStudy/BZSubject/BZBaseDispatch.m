//
//  BZBaseDispatch.m
//  BZBoss-BZBoss
//
//  Created by yuhechuan on 2022/11/16.
//

#import "BZBaseDispatch.h"
#import "BZEvent.h"
#import "BZSubject.h"
#import "BZSubjectNode.h"

@interface BZDemand : NSObject

@property (nonatomic, strong) id<BZSubject> subject;
@property (nonatomic, strong) id<BZEvent> event;
@property (nonatomic, strong) id<BZSubjectNode> node;

@end

@implementation BZDemand

@end

@interface BZBaseDispatch ()

@property (nonatomic, strong) NSMutableArray <id<BZSubjectNode>>*allSubjectNodes;
@property (nonatomic, strong) NSMutableDictionary <NSString *, BZDemand *>*subjectNodeMap;

@end

@implementation BZBaseDispatch

- (instancetype)initWithNode:(id<BZSubjectNode>)node {
    if (self = [super init]) {
        [self initializeNode:node];
    }
    return self;
}

- (void)initializeNode:(id<BZSubjectNode>)node {
    if (!node) {
        return;
    }
    [self packageNode:node];
}

- (void)packageNode:(id<BZSubjectNode>)node {
    NSArray <id<BZSubjectNode>> *nodes = [self subjectNodes:node];
    if (nodes.count == 0) {
        return;
    }
    for (id<BZSubjectNode> nd in nodes) {
        [self buildRelateWithNode:nd];
        [self packageNode:nd];
    }
}

- (void)buildRelateWithNode:(id<BZSubjectNode>)node {
    [self.allSubjectNodes addObject:node];
    
    id<BZSubject> subject = nil;
    id<BZEvent> event = nil;
    if ([node respondsToSelector:@selector(relatedSubject)]) {
        Class class = [node relatedSubject];
        if (class && class != NULL) {
            subject = [[class alloc]init];
        }
    }
    
    if (subject && [subject respondsToSelector:@selector(relatedSubjectEvent)]) {
        Class class = [subject relatedSubjectEvent];
        if (class && class != NULL) {
            event = [[class alloc]init];
        }
    }
    BZDemand *demand = [[BZDemand alloc]init];
    demand.subject = subject;
    demand.event = event;
    demand.node = node;
    
    self.subjectNodeMap[NSStringFromClass([subject class])] = demand;
    /// 当前业务线 存在 则存入池子
    if (subject) {
        [self storeValue:subject storeClass:[subject class]];
    }
}

- (void)reloadAllNodes {
    for (id<BZSubjectNode> node in self.allSubjectNodes) {
        if ([node respondsToSelector:@selector(reloadNode)]) {
            [node reloadNode];
        }
    }
}

- (void)reloadNodeSubJectClass:(Class)subJectClass {
    if (!subJectClass || subJectClass == NULL) {
        return;
    }
    NSString *key = NSStringFromClass(subJectClass);
    BZDemand *demand = self.subjectNodeMap[key];
    if ([demand.node respondsToSelector:@selector(reloadNode)]) {
        [demand.node reloadNode];
    }
}

- (NSArray <id<BZSubjectNode>> *)subjectNodes:(id<BZSubjectNode>)node {
    if ([node respondsToSelector:@selector(childSubjectNodes)]) {
        return [node childSubjectNodes];
    }
    return @[];
}

- (NSMutableArray<id<BZSubjectNode>> *)allSubjectNodes {
    if(!_allSubjectNodes) {
        _allSubjectNodes = [NSMutableArray array];
    }
    return _allSubjectNodes;
}

- (NSMutableDictionary<NSString *,BZDemand *>*)subjectNodeMap {
    if(!_subjectNodeMap) {
        _subjectNodeMap = [NSMutableDictionary dictionary];
    }
    return _subjectNodeMap;
}


@end
