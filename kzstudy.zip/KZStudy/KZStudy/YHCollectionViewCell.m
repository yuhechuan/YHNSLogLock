//
//  YHCollectionViewCell.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/9.
//

#import "YHCollectionViewCell.h"

@interface YHCollectionViewCell ()

@property (nonatomic, strong) UILabel *title;

@end

@implementation YHCollectionViewCell

- (instancetype)init {
    if (self = [super init]) {
        [self setUp];
    }
    return self;
}

- (void)setUp {
}

- (void)refreshTitle:(NSString *)title {
    self.title.text = title;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.title.frame = self.bounds;
}

- (UILabel *)title {
    if (!_title) {
        _title = [[UILabel alloc]init];
        _title.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];;
        _title.font = [UIFont systemFontOfSize:14];
        _title.textAlignment = NSTextAlignmentCenter;
        self.backgroundColor = [UIColor colorWithRed:235/255.0 green:235/255.0 blue:235/255.0 alpha:1];
        [self.contentView addSubview:_title];
    }
    return _title;
}



@end
