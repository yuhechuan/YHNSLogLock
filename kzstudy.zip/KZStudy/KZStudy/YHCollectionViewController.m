//
//  YHCollectionViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2022/3/9.
//

#import "YHCollectionViewController.h"
#import "UICollectionView+YHFastProxy.h"
#import "YHCollectionViewCell.h"

@interface YHCollectionViewController ()<UIScrollViewDelegate, UICollectionViewDelegate>

@property (nonatomic, strong) UICollectionView *collectionView;


@end

@implementation YHCollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"快捷列表CollectionView";

    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = [UIColor redColor];
    
    self.collectionView.delegateTarget = self;
    
    [self.collectionView.fastProxy bz_register:^(YHCollectionViewInfo * _Nonnull info) {
        info.cellArr = @[[YHCollectionViewCell class]];
        info.itemSize = CGSizeMake(100, 30);
        info.minimumLineSpacing = 20;
        info.minimumInteritemSpacing = 10;
        info.sectionInset = UIEdgeInsetsMake(64, 20, 45, 20);
    }];
    self.collectionView.fastProxy.cellForItemAtIndexPath = ^(UICollectionViewCell * _Nonnull cell, YHCollectionViewCellInfo * _Nonnull cellInfo, NSIndexPath * _Nonnull indexPath) {
        if ([cell isKindOfClass:[YHCollectionViewCell class]]) {
            YHCollectionViewCell *yhcell = (YHCollectionViewCell *)cell;
            [yhcell refreshTitle:cellInfo.data];
        }
    };
    __weak typeof(self) weakself = self;
    self.collectionView.fastProxy.didSelectItemAtIndexPath = ^(YHCollectionViewCellInfo * _Nonnull cellInfo, NSIndexPath * _Nonnull indexPath) {
        [weakself dismissViewControllerAnimated:YES completion:nil];
    };
    
    NSMutableArray *arr = [NSMutableArray array];
    for (int i = 0; i < 50; i ++) {
        NSString *s = [NSString stringWithFormat:@"第%d行",i];
        [arr addObject:s];
    }
    [self.collectionView.fastProxy bz_reload:arr];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSLog(@"开始滚动 scrollViewDidScroll");
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"开始布局 willDisplayCell");
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:[UICollectionViewFlowLayout new]];
        [self.view addSubview:_collectionView];
    }
    return _collectionView;
}

@end
