//
//  YHCollectionViewController.h
//  KZStudy
//
//  Created by yuhechuan on 2022/3/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YHCollectionViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
