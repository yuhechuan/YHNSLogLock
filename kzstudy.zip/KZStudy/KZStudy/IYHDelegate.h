//
//  IYHDelegate.h
//  KZStudy
//
//  Created by yuhechuan on 2021/12/20.
//

@class YHStudent;

@protocol YHTestDelegate <NSObject>

- (void)text:(YHStudent *)s;

@end





