//
//  AppDelegate.m
//  KZStudy
//
//  Created by yuhechuan on 2021/5/6.
//

#import "AppDelegate.h"
#import "KZLeaksFinder.h"
#import "ViewController.h"
#import "AFNetworkReachabilityManager.h"
#import "NSObject+KZExtension.h"
#import "YHTableViewTestController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc]initWithFrame:UIScreen.mainScreen.bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:[[ViewController alloc]init]];
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    
    [[KZLeaksFinder shareFinder] enableLeaksFinder:^(NSString * _Nonnull leakType, NSString * _Nonnull leakInfo) {
    }];
    
    ///[[AFNetworkReachabilityManager sharedManager] startMonitoring];
   // [self addRunLoopObserver];
    return YES;
}


@end

