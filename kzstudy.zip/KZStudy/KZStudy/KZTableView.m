//
//  KZTableView.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/2.
//

#import "KZTableView.h"

@implementation KZTableView

- (void)reloadData {
    self.isRefreshing = YES;
    [super reloadData];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.isRefreshing = NO;
}

- (void)setContentSize:(CGSize)contentSize {
    [super setContentSize:contentSize];
}
//- (void)setNeedsLayout {
//    [super setNeedsLayout];
//}
//
//- (void)reloadData {
//    [super reloadData];
//}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height + 10);
//}
//
//- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    NSLog(@"开始%s",__func__);
//    //[super touchesMoved:touches withEvent:event];
//    NSLog(@"结束%s",__func__);
//}
//
//- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    NSLog(@"开始%s",__func__);
//    [super touchesEnded:touches withEvent:event];
//    NSLog(@"结束%s",__func__);
//}
//
//- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    NSLog(@"开始%s",__func__);
//    //[super touchesCancelled:touches withEvent:event];
//    NSLog(@"结束%s",__func__);
//}
//
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRequireFailureOfGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
//    return NO;
//}
//
//- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
//    return YES;
//}

@end
