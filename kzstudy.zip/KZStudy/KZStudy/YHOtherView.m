//
//  YHOtherView.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/12.
//

#import "YHOtherView.h"


@implementation YHView2

- (void)layoutSubviews {
    [super layoutSubviews];
}

@end

@implementation YHOtherView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        YHView2 *view = [[YHView2 alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
        view.backgroundColor = [UIColor orangeColor];
        [self addSubview:view];
        self.view2 = view;
        self.backgroundColor = [UIColor blueColor];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"%@", self.nextResponder);
}

@end
