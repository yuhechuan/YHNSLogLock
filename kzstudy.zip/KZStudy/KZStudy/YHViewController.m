//
//  YHViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2021/9/8.
//

#import "YHViewController.h"

@interface YHViewController ()<UIContextMenuInteractionDelegate>

@property (nonatomic, strong) UIView *buleView;
@property (nonatomic, strong) UIView *redView;
@property (nonatomic, strong) UIViewController *previewVc;

@end

@implementation YHViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)addContextMenuInteraction {
    CGFloat with = 200;
    CGFloat heigt = 100;
    CGFloat x = (self.view.bounds.size.width - with) / 2.0;
    CGFloat y = 200;
    UIView *redView = [[UIView alloc]initWithFrame:CGRectMake(x, y, with, heigt)];
    redView.backgroundColor = [UIColor redColor];
    redView.layer.cornerRadius = 8;
    self.redView = redView;
    [self.view addSubview:redView];
    
    
    UIView *blueView = [[UIView alloc]initWithFrame:CGRectMake(x, CGRectGetMaxY(redView.frame) + 50, with, heigt)];
    blueView.backgroundColor = [UIColor blueColor];
    blueView.layer.cornerRadius = 8;
    self.buleView = blueView;
    [self.view addSubview:blueView];
    
    self.view.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.1];
    
    if (@available(iOS 13.0, *)) {
        UIContextMenuInteraction *menu= [[UIContextMenuInteraction alloc]initWithDelegate:self];
        [redView addInteraction:menu];
    } else {
        // Fallback on earlier versions
    }
}

- (nullable UIContextMenuConfiguration *)contextMenuInteraction:(UIContextMenuInteraction *)interaction configurationForMenuAtLocation:(CGPoint)location  API_AVAILABLE(ios(13.0)){
    UIContextMenuConfiguration *config = [UIContextMenuConfiguration configurationWithIdentifier:@"123" previewProvider:^UIViewController * _Nullable{
        return self.previewVc;
    } actionProvider:^UIMenu * _Nullable(NSArray<UIMenuElement *> * _Nonnull suggestedActions) {
        UIAction *ac1 = [UIAction actionWithTitle:@"喜欢" image:[UIImage new] identifier:@"1" handler:^(__kindof UIAction * _Nonnull action) {
        }];
        UIAction *ac2 = [UIAction actionWithTitle:@"分享" image:[UIImage new]  identifier:@"2" handler:^(__kindof UIAction * _Nonnull action) {
           
        }];
        UIAction *ac3 = [UIAction actionWithTitle:@"复制" image:[UIImage new]  identifier:@"3" handler:^(__kindof UIAction * _Nonnull action) {
            
        }];
        return [UIMenu menuWithTitle:@"菜单" children:@[ac1,ac2,ac3]];
    }];
    return config;
}

- (nullable UITargetedPreview *)contextMenuInteraction:(UIContextMenuInteraction *)interaction configuration:(UIContextMenuConfiguration *)configuration highlightPreviewForItemWithIdentifier:(id<NSCopying>)identifier {
    return [[UITargetedPreview alloc]initWithView:self.redView];
}

- (nullable UITargetedPreview *)contextMenuInteraction:(UIContextMenuInteraction *)interaction configuration:(UIContextMenuConfiguration *)configuration dismissalPreviewForItemWithIdentifier:(id<NSCopying>)identifier {
    return [[UITargetedPreview alloc]initWithView:self.redView];
}

- (void)contextMenuInteraction:(UIContextMenuInteraction *)interaction willPerformPreviewActionForMenuWithConfiguration:(UIContextMenuConfiguration *)configuration animator:(id<UIContextMenuInteractionCommitAnimating>)animator {
    [animator addCompletion:^{
        [self presentViewController:self.previewVc animated:YES completion:nil];
    }];
}


- (UIViewController *)previewVc {
    if(!_previewVc) {
        UIViewController *vc1 = [[UIViewController alloc]init];
        vc1.view.backgroundColor = [UIColor blueColor];
        vc1.modalPresentationStyle = UIModalPresentationFullScreen;
        _previewVc = vc1;
    }
    return _previewVc;
}

@end
