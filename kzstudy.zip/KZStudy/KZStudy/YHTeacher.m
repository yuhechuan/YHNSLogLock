//
//  YHTeacher.m
//  KZStudy
//
//  Created by yuhechuan on 2021/9/8.
//

#import "YHTeacher.h"

@implementation YHTeacher

- (void)saySomething{
    NSLog(@"%p",_kc_name);
}

@end
