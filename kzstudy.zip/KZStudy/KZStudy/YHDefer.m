//
//  YHDefer.m
//  KZStudy
//
//  Created by yuhechuan on 2021/8/24.
//

#import "YHDefer.h"

// .m 文件
void deferFunction (__strong executeCleanupBlock *block) {
    (*block)();
}

@implementation YHDefer

+ (YHDefer *)sharedDefer {
    static YHDefer *Defer = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Defer = [[YHDefer alloc] init];
    });
    return Defer;
}


@end
