//
//  YHOtherView.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YHView2 : UIView

@end

@interface YHOtherView : UIView

@property (nonatomic, strong) YHView2 *view2;

@end

NS_ASSUME_NONNULL_END
