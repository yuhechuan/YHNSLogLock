//
//  YHTeacher.h
//  KZStudy
//
//  Created by yuhechuan on 2021/9/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

__attribute__((objc_direct_members))

@interface YHTeacher : NSObject

@property (nonatomic, copy) NSString *kc_name;
@property (nonatomic, copy, direct) NSString *dr_name;

- (void)saySomething __attribute__((objc_direct));

@end

NS_ASSUME_NONNULL_END
