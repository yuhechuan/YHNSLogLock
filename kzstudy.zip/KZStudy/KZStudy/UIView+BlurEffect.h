//
//  UIView+BlurEffect.h
//  BZBasic
//
//  Created by yuhechuan on 2022/4/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (BlurEffect)

// 给当前视图添加一个毛玻璃效果
- (void)addBlurEffect;
- (void)addBlurEffectRect:(CGRect)rect;

// 移除当前视图的毛玻璃效果
- (void)removeBlurEffect;

@end

NS_ASSUME_NONNULL_END
