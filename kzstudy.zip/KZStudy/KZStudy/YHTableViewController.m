//
//  YHTableViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2021/12/29.
//

#import "YHTableViewController.h"
#import "UITableView+YHFastProxy.h"
#import "YHTableViewCell.h"
#import "YHStudent.h"
#import "YHCollectionViewController.h"
#import "KZTableView.h"

@interface YHTableViewController ()<UIScrollViewDelegate,UITableViewDelegate>

@property (nonatomic, strong) KZTableView *tableView;
@property (nonatomic, strong) YHStudent *student;

@end

@implementation YHTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;

    self.navigationItem.title = @"快捷列表TableView";
    self.view.backgroundColor = [UIColor redColor];
    // Do any additional setup after loading the view.
    YHStudent *s = self.student;
    s.myBlock = ^{
        [self testBlock];
    };

   // self.tableView.delegateTarget = self;
        
    [self.tableView.fastProxy bz_register:^(YHTableViewInfo * _Nonnull info) {
        info.cellArr = @[[YHTableViewCell class]];
        info.rowHeight = 60;
    }];
    self.tableView.fastProxy.cellForRowAtIndexPath = ^(UITableViewCell * _Nonnull cell, YHTableViewCellInfo * _Nonnull cellInfo, NSIndexPath * _Nonnull indexPath) {
        if (cellInfo.cellType == [YHTableViewCell class]) {
            YHTableViewCell *myCell = (YHTableViewCell *)cell;
            [myCell refreshText:cellInfo.data];
        }
    };
    __weak typeof(self) weakself = self;
    self.tableView.fastProxy.didSelectRowAtIndexPath = ^(YHTableViewCellInfo * _Nonnull cellInfo, NSIndexPath * _Nonnull indexPath) {
        if (indexPath.row % 2 == 0) {
            [weakself dismissViewControllerAnimated:YES completion:nil];
        } else {
            YHCollectionViewController *c = [[YHCollectionViewController alloc]init];
            c.modalPresentationStyle = UIModalPresentationOverFullScreen;
            [weakself.navigationController pushViewController:c animated:YES];
        }
    };
    self.tableView.contentInset = UIEdgeInsetsMake(25, 0, 15, 0);
    NSMutableArray *arr = [NSMutableArray array];
    for (int i = 0; i < 50; i ++) {
        NSString *s = [NSString stringWithFormat:@"第 %d 行",i];
        [arr addObject:s];
    }
    
    [self.tableView.fastProxy bz_reload:arr];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)testBlock {
    NSLog(@"testBlock");
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSLog(@"开始滚动了");
}

- (KZTableView *)tableView {
    if (!_tableView) {
        _tableView = [[KZTableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (YHStudent *)student {
    if (!_student) {
        _student = [[YHStudent alloc]init];
    }
    return _student;
}


- (void)dealloc {
    NSLog(@"");
}

@end
