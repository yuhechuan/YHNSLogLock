//
//  YHLayer.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/2.
//

#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface YHLayer : CALayer

@end

NS_ASSUME_NONNULL_END
