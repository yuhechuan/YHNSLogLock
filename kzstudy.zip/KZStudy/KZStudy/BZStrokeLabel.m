//
//  BZStrokeLabel.m
//  KZStudy
//
//  Created by yuhechuan on 2024/9/4.
//

#import "BZStrokeLabel.h"

@interface BZMarkInnerLabel : UILabel

@end

@implementation BZMarkInnerLabel

@end

@interface BZStrokeLabel ()

@property (nonatomic, strong) UIImageView *markImageView;
@property (nonatomic, strong) BZMarkInnerLabel *markLabel;
@property (nonatomic, strong) UIColor *originTextColor;
@property (nonatomic, assign) CGFloat paragraphOffset;
@property (nonatomic, strong, readwrite) NSMutableAttributedString *readCurrentAttributedString;


@end

@implementation BZStrokeLabel

- (instancetype)init {
    if (self = [super init]) {
        [self setUp];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setUp];
    }
    return self;
}

- (void)setUp {
    self.outerColor = [UIColor blackColor];
    self.innerColor = [UIColor whiteColor];
    self.outerBorderWidth = 0;
    self.innerBorderWidth = 0;
    self.paragraphOffset = 0;
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGSize s = [super sizeThatFits:size];
    return CGSizeMake(s.width, s.height + 2 *self.paragraphOffset);
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _markImageView.frame = self.bounds;
    _markLabel.frame = self.bounds;
}

- (void)setText:(NSString *)text {
    self.markLabel.text = text;
    self.attributedText = [[NSAttributedString alloc]initWithString:text];
}

- (void)setAttributedText:(NSAttributedString *)attributedText {
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithAttributedString:attributedText];
    if (self.paragraphOffset > 0) {
        
        CGFloat kern = self.paragraphOffset;
        
        NSParagraphStyle *style = [attributedString attribute:NSParagraphStyleAttributeName atIndex:0 effectiveRange:NULL];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        if (style) {
            [paragraphStyle setParagraphStyle:style];
        }
        paragraphStyle.lineBreakMode = self.lineBreakMode;
        paragraphStyle.alignment = self.textAlignment;
        paragraphStyle.headIndent = kern;
        paragraphStyle.tailIndent = - kern;
        paragraphStyle.firstLineHeadIndent = kern;
        [paragraphStyle setLineSpacing:kern];
        [attributedString addAttribute:NSKernAttributeName value:@(kern) range:NSMakeRange(0, [attributedString length])];
        [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [attributedString length])];
    }
    self.readCurrentAttributedString = attributedString;
    self.markLabel.attributedText = attributedString;
    [super setAttributedText:attributedString];
}

- (void)setFont:(UIFont *)font {
    self.markLabel.font = font;
    [super setFont:font];
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    self.markLabel.textAlignment = textAlignment;
    [super setTextAlignment:textAlignment];
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    self.markLabel.lineBreakMode = lineBreakMode;
    [super setLineBreakMode:lineBreakMode];
}

- (void)setNumberOfLines:(NSInteger)numberOfLines {
    self.markLabel.numberOfLines = numberOfLines;
    [super setNumberOfLines:numberOfLines];
}


- (void)drawRect:(CGRect)rect {
    self.originTextColor = self.textColor;
    
    CGFloat s_wid_1 = self.outerBorderWidth + self.innerBorderWidth;
    CGFloat s_wid_2 = self.innerBorderWidth;
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineJoin(context, kCGLineJoinRound);

    if (s_wid_1 > s_wid_2) {
        CGContextSetLineWidth(context, s_wid_1);
        CGContextSetTextDrawingMode(context, kCGTextStroke);
        /// 最外层轮廓颜色
        self.textColor = self.outerColor;
        [super drawTextInRect:rect];
    }
    
    if (s_wid_2 > 0) {
        CGContextSetLineWidth(context, s_wid_2);
        CGContextSetTextDrawingMode(context, kCGTextStroke);
        /// 内轮廓颜色
        self.textColor = self.innerColor;
        [super drawTextInRect:rect];
    }
    
    /// 没有mark的时候展示本来文字
    if (!_markImageView) {
        CGContextSetTextDrawingMode(context, kCGTextFill);
        self.textColor = self.originTextColor;
        [super drawTextInRect:rect];
    }
}

- (void)setMarkImage:(UIImage *)markImage {
    _markImage = markImage;
    self.markImageView.frame = self.bounds;
    self.markImageView.image = markImage;
    self.markImageView.layer.mask = self.markLabel.layer;
    self.markImageView.userInteractionEnabled = YES;
}


- (CGFloat)paragraphOffset {
    return  (_outerBorderWidth + _innerBorderWidth) *0.5;
}

- (UIImageView *)markImageView {
    if (!_markImageView) {
        _markImageView = [[UIImageView alloc]init];
        [self addSubview:_markImageView];
    }
    return _markImageView;
}

- (BZMarkInnerLabel *)markLabel {
    if (!_markLabel) {
        _markLabel = [[BZMarkInnerLabel alloc]init];
    }
    return _markLabel;
}

@end
