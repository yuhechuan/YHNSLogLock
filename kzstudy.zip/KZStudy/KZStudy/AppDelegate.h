//
//  AppDelegate.h
//  KZStudy
//
//  Created by yuhechuan on 2021/5/6.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

