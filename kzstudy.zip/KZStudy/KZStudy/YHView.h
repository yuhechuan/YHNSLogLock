//
//  YHView.h
//  KZStudy
//
//  Created by yuhechuan on 2021/9/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YHView1 : UIView

@end

@interface YHView : UIView

@property (nonatomic, strong) YHView1 *view1;

@end

NS_ASSUME_NONNULL_END
