//
//  YHLabel.m
//  KZStudy
//
//  Created by yuhechuan on 2022/4/2.
//

#import "YHLabel.h"

@implementation YHLabel

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
}

- (CGSize)sizeThatFits:(CGSize)size {
    return [super sizeThatFits:size];
}

@end
