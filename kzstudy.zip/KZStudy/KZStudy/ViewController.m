//
//  ViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2021/5/6.
//

#import "ViewController.h"
#import "YPSeniorLabel.h"
#import "NSMutableAttributedString+YP.h"
#import <objc/runtime.h>
#import <sys/mman.h>
#import <sys/stat.h>
#import "YHDefer.h"
#import "YHStudent.h"
#import "YHTeacher.h"
#import "YHView.h"
#import "YHViewController.h"
#include <stdint.h>
#include <stdio.h>
#include <sanitizer/coverage_interface.h>
#import "KZPCrashMachException.h"
#import "IYHDelegate.h"
#import "YHTableViewController.h"
#import "YHBlockLayout.h"
#import "YHCollectionViewController.h"
#import "YHTextView.h"
#import "YHLabel.h"
#import "YPMenuItem.h"
#import "YPMenuStyleConfig.h"
#import "YPMenuController.h"
#import "KZTrackingDBDelay.h"
#import "YH3DViewController.h"
#import "YHHighTextView.h"
#import "KZTrackingDatabase.h"
#import "YHMaskView.h"
#import "NSString+KZExtension.h"
#import "NSObject+KZExtension.h"
#import "YHDLTestViewController.h"
#import "NSMethodSignature+OCMAdditions.h"
#import <Masonry/Masonry.h>
#import "KZPGeneralComponents.h"
#import "YHTableViewTestController.h"
#import "dlfcn.h"
#import "BZTrackingTest.h"
#import "BZStrokeLabel.h"
#import "TTTAttributedLabel.h"
#import "BZLineHeightHelper.h"

#define KZM_COLOR(_red,_green,_blue) [UIColor colorWithRed:_red/255. green:_green/255. blue:_blue/255. alpha:1]
#define IS_IPAD ([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad)

@BeeHiveMod(Demaine);


static CFTimeInterval _g_startWorkTime = -1;
// 打印 对象的引用计数
extern uintptr_t _objc_rootRetainCount(id obj);
// 打印 当前自动释放池里面的内容
extern void _objc_autoreleasePoolPrint(void);


#define onExit(funcName)\
    __strong void(^block)(void) __attribute__((cleanup(funcName), unused)) = ^

static void executeblock(__strong void(^*b)(void)) {
    (*b)();
}

@interface ViewController ()<YPSeniorLabelProtocol,YPSelectMenuProtocol,UIContextMenuInteractionDelegate>

@property (atomic, strong) NSObject *obj;
@property (nonatomic, assign) int num;
@property (nonatomic, strong) NSMutableArray      *mArray;
@property (nonatomic, copy) void(^myBlock)(void);
@property (nonatomic, copy) void(^myBlockTwo)(void);
@property (nonatomic, weak) id <YHTestDelegate> delegate;
@property (nonatomic, strong) UITableView *tableview;
@property (nonatomic, strong) CALayer *viewBgLayer;
@property (nonatomic, strong) YHTextView *textView;
@property (nonatomic, strong) UILabel *yuText;
@property (nonatomic, strong) KZTrackingDatabase *trackingDB;

@property (nonatomic, strong) YPSeniorLabel *sl;
@property (nonatomic, strong) BZTrackingTest *trackingTest;


@end

@implementation ViewController {
    dispatch_semaphore_t _semaphore;
    dispatch_source_t _timer;
    dispatch_queue_t _timerQueue;
    int _count;
    dispatch_queue_t    _queue;
    dispatch_source_t _eventUnion;
    
}

- (void)test23466 {
    NSString *str = @"发多少 啊啥的佛嘎说18-25岁，，在校大学生优先。女生，学历...山东矿机浩丰科技的思考和公交卡返回的是看电视剧很关键安会计师恢复健康收到货发";
    NSRange range = [str rangeOfString:@"佛嘎说"];
    
    
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithString:str];

    self.sl = [[YPSeniorLabel alloc]initWithFrame:CGRectMake(10, 100, self.view.frame.size.width - 20, 0)];
    self.sl.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    [attr setBackgroundColor:[UIColor greenColor] range:range];
   
    self.sl.attributedString = attr;
    [self.sl sizeToFit];

    [self.view addSubview:self.sl];
    
   
}

- (KZTrackingDatabase *)trackingDB {
    if (!_trackingDB) {
        _trackingDB = [[KZTrackingDatabase alloc]init];
    }
    return _trackingDB;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear: animated];
}

- (void)viewIsAppearing:(BOOL)animated {
    [super viewIsAppearing:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"主控制";
   // [BZLineHeightHelper testLineHeight:self.view];
    [self testMyLabel];
}

- (void)testMyLabel {
    UILabel *st = [[UILabel alloc]init];
    CGFloat width = self.view.frame.size.width - 100;
    st.frame = CGRectMake(50, 150, width, self.view.frame.size.height - 200);
    st.backgroundColor = [[UIColor orangeColor] colorWithAlphaComponent:0.1];
    st.textColor = [UIColor blueColor];
    st.font = [UIFont boldSystemFontOfSize:30];
    st.numberOfLines = 0;
    st.attributedText = [[NSAttributedString alloc]initWithString:@"表姐说：“我这个弟弟呀，大学毕业之后，不肯做正经工作，在老家给他安排职位也不去，去年夏天开始他住在我这里，整天闷在卧室，非写什么小说，还说要当推理作家。他虽说是本科大学生，认识几个字，但作家是需要天赋的，他是什么材料我能不知道？他姐夫看不过就说了他两句，不想他一气之下竟离家出走了。打电话也联系不上，家里人本想报警，他却发来微信说自己一切都好，等干出一番事业就回来。不过到现在又有好长时间没有消息了。”说话时，外表坚强的表姐慢慢湿润了眼眶。"];
    [st sizeToFit];
    [self.view addSubview:st];
}

- (void)testAttribeStringFont {
    NSString *text = @"当您收到可疑邮件时，在无法确认邮件安全性情况下.";
    NSRange rang1 = [text rangeOfString:@"当您收到可疑邮件时，"];
    NSRange rang2 = [text rangeOfString:@"在无法确认邮件安全性情况下."];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc]initWithString:text];
    [string setFont:[UIFont systemFontOfSize:20] range:rang1];
    [string setFont:[UIFont systemFontOfSize:20] range:rang2];
    [string enumerateAttribute:NSFontAttributeName inRange:NSMakeRange(0, string.length) options:0 usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
        NSLog(@"");
    }];
    NSLog(@"%@",string);
}

- (void)testStrokeLabel {
    BZStrokeLabel *st = [[BZStrokeLabel alloc]init];
    CGFloat width = self.view.frame.size.width - 100;
    st.frame = CGRectMake(50, 150, width, self.view.frame.size.height - 200);
    st.backgroundColor = [[UIColor orangeColor] colorWithAlphaComponent:0.1];
    st.textColor = [UIColor whiteColor];
    st.outerColor = [UIColor blueColor];
    st.innerColor = [UIColor redColor];
    st.font = [UIFont boldSystemFontOfSize:15];
    st.innerBorderWidth = 2;
    st.outerBorderWidth = 2;
    st.numberOfLines = 4;
    st.lineBreakMode = NSLineBreakByTruncatingTail;
    st.text = @"表姐说：“我这个弟弟呀，大学毕业之后，不肯做正经工作，在老家给他安排职位也不去，去年夏天开始他住在我这里，整天闷在卧室，非写什么小说，还说要当推理作家。他虽说是本科大学生，认识几个字，但作家是需要天赋的，他是什么材料我能不知道？他姐夫看不过就说了他两句，不想他一气之下竟离家出走了。打电话也联系不上，家里人本想报警，他却发来微信说自己一切都好，等干出一番事业就回来。不过到现在又有好长时间没有消息了。”说话时，外表坚强的表姐慢慢湿润了眼眶。";
    [st sizeToFit];
    
    [self splitStringContainerSize:CGSizeMake(width, 10000) numberOfLines:4 attributedText:st.readCurrentAttributedString];
    
    [self.view addSubview:st];
}

- (void)splitStringContainerSize:(CGSize)containerSize
                       numberOfLines:(NSUInteger)numberOfLines
                      attributedText:(NSMutableAttributedString *)attributedText
                                {
    NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
    layoutManager.usesFontLeading = NO;
                                    
    NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:containerSize];
    textContainer.maximumNumberOfLines = numberOfLines;
                                
    [layoutManager addTextContainer:textContainer];
                                    [attributedText enumerateAttribute:NSFontAttributeName inRange:NSMakeRange(0, attributedText.length) options:kNilOptions usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
                                        if (value) {
                                            [attributedText addAttribute:@"NSOriginalFont" value:value range:range];
                                        }
                                    }];
    NSTextStorage *textStorage = attributedText ? [[NSTextStorage alloc] initWithAttributedString:attributedText] : [[NSTextStorage alloc] init];
    [textStorage addLayoutManager:layoutManager];
                                    
    [layoutManager ensureLayoutForTextContainer:textContainer];
                                    
                                    
     
    CGRect boundingRect = [layoutManager usedRectForTextContainer:textContainer];
    __block int count = 0;
    [layoutManager enumerateLineFragmentsForGlyphRange:NSMakeRange(0, attributedText.length) 
                                            usingBlock:^(CGRect rect, CGRect usedRect, NSTextContainer * _Nonnull textContainer, NSRange glyphRange, BOOL * _Nonnull stop) {
        count ++;
    }];
                                    NSLog(@"当前行数: %d",count);
                                    
}


- (void)addGCDSource {
    _eventUnion = dispatch_source_create(DISPATCH_SOURCE_TYPE_DATA_ADD, 0, 0, dispatch_get_main_queue());
   dispatch_source_set_event_handler(_eventUnion, ^{
       double gapMsec = (CACurrentMediaTime() - _g_startWorkTime) * 1000;
       NSLog(@"%f",gapMsec);
       NSLog(@"event Union === "); //执行
   });
    dispatch_activate(_eventUnion);
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    [self.trackingTest test1];
//    [self.trackingTest test2];
//    [self.trackingTest test3];
//    [self.trackingTest test4];
//    [self.trackingTest test5];
    [self testAttribeStringFont];
}

- (void)goYHTableViewTestController {
    YHTableViewTestController *vc  =[[YHTableViewTestController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}


- (void)beforeBatchUploadTrackingDatas:(NSArray *)parameters {
    if (parameters.count <= 5) {
        [self batchUploadTrackingDatas:parameters];
    } else {
        NSUInteger location = parameters.count / 2;
        NSArray *before = [parameters subarrayWithRange:NSMakeRange(0, location)];
        NSArray *after = [parameters subarrayWithRange:NSMakeRange(location, parameters.count - before.count)];
        [self beforeBatchUploadTrackingDatas:before];
        [self beforeBatchUploadTrackingDatas:after];
    }
}

- (void)batchUploadTrackingDatas:(NSArray *)parameters {
    NSLog(@"%@", parameters);
}


- (void)testLabel1234560 {
    NSLog(@"中间0");
}

- (void)testLabel1234561 {
    NSLog(@"中间1");
}
- (void)testLabel1234562 {
    NSLog(@"中间2");
}
- (void)testLabel1234563 {
    NSLog(@"中间4");
}

- (void)testLabel1 {
    YPSeniorLabel *label = [[YPSeniorLabel alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width - 40, 0)];
    label.numberOfLines = 0;
    label.font = [UIFont systemFontOfSize:17];
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.2];
    [self.view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo (self.view).offset(100);
        make.left.equalTo(self.view).offset(20);
        make.right.equalTo(self.view).offset(-20);
    }];
    label.attributedString = [[NSMutableAttributedString alloc]initWithString:@"我刹住车，熄火，解下安全带，打开四角闪。我心暗想，要不是这辆日本鬼子造的车，哥哥我今天就交待在这了。日本鬼子坏归坏，车的质量还真不错我刹住车，熄火，解下安全带，打开四角闪。我心暗想，要不是这辆日本鬼子造的车，哥哥我今天就交待在这了。日本鬼子坏归坏，车的质量还真不错"];
}

- (void)testLabel2 {
    UILabel *label = [[UILabel alloc]init];
    label.numberOfLines = 0;
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.2];
    [self.view addSubview:label];
    [label mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo (self.view).offset(100);
        make.left.equalTo(self.view).offset(20);
        make.right.equalTo(self.view).offset(-20);
        make.centerX.equalTo(self.view);
    }];
    label.attributedText = [[NSMutableAttributedString alloc]initWithString:@"我刹住车，熄火，解下安全带，打开四角闪。我心暗想，要不是这辆日本鬼子造的车，哥哥我今天就交待在这了。日本鬼子坏归坏，车的质量还真不错我刹住车，熄火，解下安全带，打开四角闪。我心暗想，要不是这辆日本鬼子造的车，哥哥我今天就交待在这了。日本鬼子坏归坏，车的质量还真不错"];
}


- (NSString *)extend {
    return @"";
}

- (void)textD110 {
    // 方法签名
    SEL sel = @selector(extend);
    Method method = class_getInstanceMethod([self class], sel);
    struct objc_method_description *description = method_getDescription(method);
    NSLog(@"方法签名:%s",description->types);
}

- (void)textDemo101 {
    dispatch_async(_queue, ^{
        NSLog(@"我在子线程: %@",[NSThread currentThread]);
    });
}

- (void)tapGestureRecognizerTest {
    NSLog(@"点击手势");
}

- (void)afterDelayTest {
    NSLog(@"延时方法调用了");
}

- (void)inertData:(NSString *)data {
    KZTrackingDBInfo *info = [KZTrackingDBInfo new];
    info.trackingJosnData = data;
    [self.trackingDB dbInsertTracking:info];
}

- (void)getInertData  {
    __weak __typeof(self)weakSelf = self;

    [self.trackingDB dbGetAllTrackingInfoResultBlock:^(NSArray<KZTrackingDBInfo *> * _Nonnull trackings) {
        KZTrackingDBInfo *f = trackings.firstObject;
        [weakSelf.trackingDB dbDeleteTrackingId:f.trackingId];
    }];
}


- (void)startTrackingUpload:(NSDictionary *)parameter {
    
}
- (void)startBatchTrackingUpload:(NSArray *)parameters response:(KZTrackingResponse)response {
    
}

- (void)leart {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"网络变化" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alertController addAction:okAction];
    UIViewController *presentedViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    [presentedViewController presentViewController:alertController animated:YES completion:nil];
}

- (NSArray *)splitAvailableInfo:(NSArray *)uploadDatas {
    NSInteger length = uploadDatas.count;
    NSInteger middle = length >> 1;
    NSArray *left = [uploadDatas subarrayWithRange:NSMakeRange(0, middle)];
    NSArray *right = [uploadDatas subarrayWithRange:NSMakeRange(middle, length - middle)];
    return @[left, right];
}

- (void)textDemo28 {
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    queue.maxConcurrentOperationCount = 1;
    [queue addOperationWithBlock:^{
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSLog(@"1");
        });
    }];
    [queue addOperationWithBlock:^{
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSLog(@"2");
        });
    }];
    [queue addOperationWithBlock:^{
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSLog(@"3");
        });
    }];
    [queue addOperationWithBlock:^{
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSLog(@"4");
        });
    }];
    [queue addOperationWithBlock:^{
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSLog(@"5");
        });
    }];
}

- (void)textDemo27 {
    self.textView = [[YHTextView alloc]initWithFrame:CGRectMake(20, 100, self.view.frame.size.width - 40, 200)];
    self.textView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.textView];
}

- (void)textDemo26 {
    NSString *name = @"今日立减50元";
    NSString *sub = @"50元";
    NSRange range = [name rangeOfString:sub];
    
    UILabel *yhLable = [[UILabel alloc]initWithFrame:CGRectMake(100, 100, 200, 100)];
    yhLable.textColor = [UIColor blackColor];
    yhLable.font = [UIFont systemFontOfSize:18];
    yhLable.text = name;
    
    NSMutableAttributedString *s = [[NSMutableAttributedString alloc]initWithString:name];
    [s addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:range];
    yhLable.attributedText = s;
    
    yhLable.text = @"";
    
    
    [self.view addSubview:yhLable];
    
}

- (YHStudent *)stu {
    YHStudent *s = [[YHStudent alloc]init];
    return s;
}

- (void)textDemo25 {
    onExit(executeblock) {
        NSLog(@"yuhechuan");
    };
}

- (void)textDemo24 {
    // 类方法的 是判断 是否等于元类对象
    [YHStudent isKindOfClass:[YHStudent class]];
    [YHStudent isMemberOfClass:[YHStudent class]];
    YHStudent *student = [[YHStudent alloc]init];
    [student isKindOfClass:[YHStudent class]];
    [student isMemberOfClass:[YHStudent class]];
}


// 奇葩的面试题
- (void)textDemo23 {
    /**
     为什么能调用成功:
     cls -> obj -> class
     Student->isa->class
     类的方法调用 寻找内存结构是一样的
     
     printName 为什么打印 ViewController
     栈的内存是 从高到底
     obj
     cls (isa 往下+ 8个字节就是_name的内存  现在正好是 ViewController)
     ViewController
     */
    id cls = [YHStudent class];
    void *obj = &cls;
    [(__bridge id)obj printName];
    
}

- (void)textDemo22 {
    __weak YHStudent *s =nil;
    {
        YHStudent *ss = [[YHStudent alloc]init];
        ss.name = @"yuhehcuan";
        s = ss;
    }
    NSLog(@"%@",s.name);
}

- (void)textDemo21 {
    int a = 0;
    NSString *k = @"1";
    YHStudent *s = [[YHStudent alloc]init];
    void(^block)(void) = ^{
        NSLog(@"%d",a);
        NSLog(@"%@",k);
        NSLog(@"%@",s);
        
    };
    
    
    void *blockObjectReference = (__bridge void *)block;
    struct block_layout *bl = blockObjectReference;
    NSLog(@"大小1 --- %zd",bl->descriptor->size);// 8
    
    const size_t ptrSize = sizeof(void *);
    NSLog(@"大小2 --- %zd", ptrSize);
    [YHBlockLayout getSignatureWithBlock:block];
    
    BOOL f1 = (bl->flags & BLOCK_HAS_COPY_DISPOSE);
    BOOL f2 = (bl->flags & BLOCK_HAS_CTOR);
    
    NSLog(@"标志位f1 --- %d", f1);
    NSLog(@"标志位f2 --- %d", f2);
    
    
}

- (void)textDemo20 {
    NSString * str = @"abcdefgihjsdfdfabcdefgihjsdfdfabcdefgihjsdfdfabcdefgihjsdfdf";
    NSString * str1 = [NSString stringWithFormat:@"abc"];
    NSString * str2 = [NSString stringWithFormat:@"abcdefgihjsdfdf"];
    
    NSLog(@"%p",str);
    NSLog(@"%p",str1);
    NSLog(@"%p",str2);
}

- (void)textDemo19 {
    self.viewBgLayer = [CALayer layer];
    self.viewBgLayer.frame = self.view.bounds;
    self.viewBgLayer.backgroundColor = [UIColor whiteColor].CGColor;
    
    CATransition *t = [[CATransition alloc]init];
    t.type = kCATransitionFade;
    t.duration = 0.5;
    self.viewBgLayer.actions = @{@"backgroundColor":t};
    [self.view.layer addSublayer:self.viewBgLayer];
}

- (void)textDemo18 {
    YHStudent *s1 = [[YHStudent alloc]init];
    s1.name = @"yuhechuan";
    s1.age = 31;
    
    YHStudent *s2 = s1;
    
    NSLog(@"hash1 == %ld",[s1 hash]);
    NSLog(@"hash2 == %ld",[s2 hash]);
}

- (void)textDomo17 {
    if (@available(iOS 10.0, *)) {
        UIGraphicsImageRenderer *red = [[UIGraphicsImageRenderer alloc]initWithSize:CGSizeMake(0, 0) format:nil];
        [red imageWithActions:^(UIGraphicsImageRendererContext * _Nonnull rendererContext) {
            
        }];
    } else {
        // Fallback on earlier versions
    }
}

- (void)textDemo16 {
    // 当信号量 >0 wait可以过 切信号量-1  当==0 阻塞
    dispatch_semaphore_t sem = dispatch_semaphore_create(1); // 1, 2
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        sleep(0.5);
        NSLog(@"a: %@", [NSThread currentThread]);
        
        dispatch_semaphore_signal(sem);
    });
    
    dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        NSLog(@"b: %@", [NSThread currentThread]);
        
        dispatch_semaphore_signal(sem);
    });
    
    dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        NSLog(@"c: %@", [NSThread currentThread]);
    });
}


- (void)textDemo15 {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textN1) name:@"yuhechuan" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textN2) name:@"yuhechuan" object:nil];
}

- (void)textN1 {
    NSLog(@"前面的");
    sleep(2);
}

- (void)textN2 {
    NSLog(@"后面的");
}



- (void)textDemo14 {
    [KZPCrashMachException activeCrashPlugin:&yhhandleCrashInformation];
}

static void yhhandleCrashInformation(KZPCrashInformation *crashInfo) {
    
}

-  (void)textDemo13 {
    //create monitor timer
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, _timerQueue);
    dispatch_source_set_timer(_timer, DISPATCH_TIME_NOW, 5.0 * NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(_timer, ^{
        double gapMsec = (CACurrentMediaTime() - _g_startWorkTime) * 1000;
        NSLog(@"%f",gapMsec);
        _g_startWorkTime = CACurrentMediaTime();
    });
    dispatch_resume(_timer);
}

-  (void)textDemo12 {
    _semaphore = dispatch_semaphore_create(0);
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSLog(@"1");
        int result = dispatch_semaphore_wait(self->_semaphore, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)));
        NSLog(@"2");
    });
}

- (void)semaphoreBlock:(void(^)(void))block {
    
}

- (void)textDemo11 {
    NSString *str = CFBridgingRelease(CFStringCreateWithCString(NULL, "可接受的恢复健康收到货个艰苦奋斗交房的看后感艰苦奋斗回房间可低功耗", kCFStringEncodingUTF8 ));
    NSLog(@"%ld", (long)CFGetRetainCount((__bridge CFTypeRef)(str)));
    CFRelease((__bridge CFTypeRef)(str));
    NSLog(@"%ld", (long)CFGetRetainCount((__bridge CFTypeRef)(str)));
    
    NSLog(@"%@",str);
}

- (void)textDemo10 {
    NSString *a = @"abc";
    NSString *b = [a copy];
    NSString *c = [b mutableCopy];
    NSString *d = [c copy];
    
    NSLog(@"%d%d%d%d",CFGetRetainCount((__bridge CFTypeRef)(a)),CFGetRetainCount((__bridge CFTypeRef)(b)),CFGetRetainCount((__bridge CFTypeRef)(c)),CFGetRetainCount((__bridge CFTypeRef)(d)));
    NSLog(@"%@%@%@%@",a,b,c,d);
    
}


//// 提供回调函数
//void __sanitizer_cov_trace_pc_guard(uint32_t *guard) {
//    Dl_info info;
//    // 获取当前函数的返回地址
//    void *PC = __builtin_return_address(0);
//    // 根据返回地址，获取相关的信息
//    dladdr(PC, &info);
//    // 打印与 PC 最近的符号名称
//    printf("guard:%p 开始执行:%s \n", PC, info.dli_sname);
//}
//
//
//
// void __sanitizer_cov_trace_pc_guard_init(uint32_t *start, uint32_t *stop) {
// static uint64_t N;
// if (start == stop || *start) return;
// 
// printf("INIT: %p %p\n", start, stop);
// for (uint32_t *x = start; x < stop; x++)
// *x = ++N;
// }


- (void)textDemo5 {
    YHStudent *s = [[YHStudent alloc]init];
    __weak __typeof(s) weakS = s;
    self.myBlock = ^{
        __strong __typeof(weakS) strongS = weakS;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [strongS mytest];
        });
    };
    self.myBlock();
}


- (void)textDemo4 {
    YHView *view = [[YHView alloc]init];
    view.frame = CGRectMake(0, 100, self.view.frame.size.width, 200);
    [self.view addSubview:view];
}

- (NSMutableArray *)mArray{
    if (!_mArray) _mArray = [NSMutableArray arrayWithCapacity:1];
    return _mArray;
}

- (void)textDemo3 {
    NSMutableArray *arr = [NSMutableArray arrayWithObjects:@"1",@"2", nil];
    self.mArray = arr;
    
    void (^kcBlock)(void) = ^{
        [arr addObject:@"3"];
        [self.mArray addObject:@"a"];
        NSLog(@"KC %@",arr);
        NSLog(@"Cooci: %@",self.mArray);
    };
    [arr addObject:@"4"];
    [self.mArray addObject:@"5"];
    
    arr = nil;
    self.mArray = nil;
    
    kcBlock();
}

- (void)textDemo2{
    dispatch_queue_t queue = dispatch_queue_create("cooci", DISPATCH_QUEUE_CONCURRENT);
    NSLog(@"1");
    dispatch_async(queue, ^{
        NSLog(@"2");
        dispatch_sync(queue, ^{
            NSLog(@"3");
        });
        NSLog(@"4");
    });
    NSLog(@"5");
}

- (void)textDemo1{
    
    dispatch_queue_t queue = dispatch_queue_create("cooci", NULL);
    NSLog(@"1");
    dispatch_async(queue, ^{
        NSLog(@"2");
        dispatch_sync(queue, ^{
            NSLog(@"3");
        });
        NSLog(@"4");
    });
    NSLog(@"5");
}


- (void)textDemo6 {
    
    dispatch_queue_t queue = dispatch_queue_create("cooci", NULL);
    dispatch_async(queue, ^{
        NSLog(@"1");
        sleep(1);
        NSLog(@"2");
    });
    
    dispatch_async(queue, ^{
        NSLog(@"3");
        sleep(2);
        NSLog(@"4");
    });
}

- (void)textDemo7 {
    dispatch_queue_t queue = dispatch_queue_create("cooci", NULL);
    
    dispatch_async(queue, ^{
        sleep(1);
        NSLog(@"1 %@",[NSThread currentThread]);
    });
    
    dispatch_async(queue, ^{
        sleep(1);
        NSLog(@"2 %@",[NSThread currentThread]);
    });
    
    
    
    dispatch_sync(queue, ^{
        sleep(1);
        NSLog(@"3 %@",[NSThread currentThread]);
    });
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
    });
    
    dispatch_async(queue, ^{
        sleep(1);
        NSLog(@"4 %@",[NSThread currentThread]);
    });
    
    dispatch_async(queue, ^{
        sleep(1);
        NSLog(@"5 %@",[NSThread currentThread]);
    });
    
}

- (void)textDemo8 {
    dispatch_queue_t queue = dispatch_queue_create("queue_rw", DISPATCH_CURRENT_QUEUE_LABEL);
    for (int i = 0; i < 100; i ++) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            dispatch_async(queue, ^{
                NSLog(@"%d,%@",i,[NSThread currentThread]);
            });
        });
    }
    
}

- (void)textDemo9 {
    for (int i = 0; i < 1000; i ++) {
        __block UIImage *image;
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            image = [[UIImage alloc]init];
            NSLog(@"%@%@",image,[NSThread currentThread]);
        });
    }
}

- (void)MTDemo{
    while (self.num < 5) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            self.num++;
        });
    }
    NSLog(@"KC : %d",self.num);
}

- (void)KSDemo{
    
    for (int i= 0; i<10000; i++) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            self.num++;
        });
    }
    NSLog(@"Cooci : %d",self.num);
}

- (void)test7 {
    Class cls = [YHStudent class];
    void  *kc = &cls;
    [(__bridge id)kc directMethod];
}

- (void)test6 {
    NSObject *objc = [NSObject new];
    NSLog(@"%ld",CFGetRetainCount((__bridge CFTypeRef)(objc)));
    
    void(^block1)(void) = ^{
        NSLog(@"---%ld",CFGetRetainCount((__bridge CFTypeRef)(objc)));
    };
    block1();
    
    void(^__weak block2)(void) = ^{
        NSLog(@"---%ld",CFGetRetainCount((__bridge CFTypeRef)(objc)));
    };
    block2();
    
    void(^block3)(void) = [block2 copy];
    block3();
    
    __block NSObject *obj = [NSObject new];
    void(^block4)(void) = ^{
        NSLog(@"---%ld",CFGetRetainCount((__bridge CFTypeRef)(obj)));
    };
    block4();
}

- (void)arrtest {
        
    /*
     1、NSFontAttributeName （value是UIFont对象）： 文本大小
     2、NSParagraphStyleAttributeName（value是NSParagraphStyle对象） ： 段落风格（设置首行，行间距，对齐方式什么的）
     3、NSForegroundColorAttributeName（value是UIColor对象） ： 文本颜色
     4、NSBackgroundColorAttributeName（value是UIColor对象） ： 文本背景色
     5、NSLigatureAttributeName （value是NSNumber对象）： 设置为文本连体  0 没有连体字符  1 使用默认的连体字符(不是是所有字体都支持)
     6、NSKernAttributeName （value是NSNumber对象）： 字符间隔（文字间距, 字符间距正值间距加宽，负值间距变窄）
     7、NSStrikethroughStyleAttributeName （value是NSNumber对象）： 文本添加删除线（1-7单删除线依次加粗、9-15双删除线依次加粗）
     
     8、NSUnderlineStyleAttributeName （value是NSNumber对象, 是个枚举 NSUnderlineStyle）： 文本设置下划线
     9、NSStrokeColorAttributeName（value是UIColor对象） ： 设置文本描边颜色
     10、NSStrokeWidthAttributeName （value是NSNumber对象,正值镂空, 负值描边）：设置描边宽度，和NSStrokeColorAttributeName同时使用能使文字空心
     11、NSShadowAttributeName（value是NSShadow对象） ： 设置文本阴影,单独设置好用的（11.4系统)
     
     12、NSTextEffectAttributeName（value是NSString  ） ： 设置文本特殊效果   目前只有一个可用效果NSTextEffectLetterpressStyle（凸版印刷效果）
     
     13、NSAttachmentAttributeName （value是NSTextAttachment对象）：设置文本附件，常用于图文混排
     
     14、NSLinkAttributeName （value是NSURL or NSString）：链接 不能在UILabel和UITextField使用，只能用UITextView来进行，实现他的代理，在代理方法里面进行URL跳转
     
     15、NSBaselineOffsetAttributeName （value是NSNumber对象）：文字基线偏移
     16、NSUnderlineColorAttributeName （value是UIColor对象）：下划线颜色
     17、NSStrikethroughColorAttributeName （value是UIColor对象）：删除线颜色
     
     18、NSObliquenessAttributeName （value是NSNumber对象）：设置字体倾斜度
     
     19、NSExpansionAttributeName（value是NSNumber对象）：设置字体的横向拉伸
     
     20、NSWritingDirectionAttributeName（value是NSNumber对象）：设置文字书写方向，从左向右书写或者从右向左书写
     
     21、NSVerticalGlyphFormAttributeName（value是NSNumber对象）：设置文字排版方向
     0为水平排版的字，1为垂直排版的字。注意,在iOS中, 总是以横向排版
     
     */
    
    
    
    
}

- (void)arrtest1 {
    UILabel *l = [[UILabel alloc]initWithFrame:CGRectMake(50, 100, self.view.bounds.size.width - 100, 300)];
    l.backgroundColor = [[UIColor cyanColor] colorWithAlphaComponent:0.1];
    l.numberOfLines = 0;
    NSString *str = @"飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!";
    
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithString:str];
    NSTextAttachment *a = [[NSTextAttachment alloc]init];
    a.image = [UIImage imageNamed:@"git.png"];
    a.bounds = CGRectMake(0, -10, 32, 32);
    NSAttributedString *im = [NSAttributedString attributedStringWithAttachment:a];
    [attr insertAttributedString:im atIndex:10];
    
    l.attributedText = attr;
    
    
    [self.view addSubview:l];
}

- (void)test1234 {
    YPSeniorLabel *l = [[YPSeniorLabel alloc]initWithFrame:CGRectMake(50, 100, 0, 0)];
    l.numberOfLines = 0;
    NSString *str = @"飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!";
    l.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    l.textColor = [UIColor blueColor];
    l.font = [UIFont systemFontOfSize:18];
    l.attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    [l sizeToFit];
    [self.view addSubview:l];
}

- (void)test123 {
    
    YPMenuStyleConfig *config = [[YPMenuStyleConfig alloc] init];
    config.menuType = YPMenuControllerSystem;
    config.barBackgroundColor = KZM_COLOR(245, 247, 247);
    config.titleColor = [UIColor whiteColor];;
    config.titleFont = [UIFont systemFontOfSize:15];
    config.menuContentEdge = UIEdgeInsetsMake(0, 5, 0, 5);
    config.barShadowColor = UIColor.darkTextColor;
    config.breakThroughEvent = NO;
    [YPMenuController sharedMenuController].styleConfig = config;
    
    NSString *str = @"飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!";
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithString:str];
    
    YPSeniorLabel *l = [[YPSeniorLabel alloc]initWithFrame:CGRectMake(50, 100, 300, 500)];
    l.delegate = self;
    l.menuDelegate = self;
    l.canSelectOperation = YES;
    l.useWordSelect = YES;
    l.canShowMagnifier =YES;
    
    l.font = [UIFont systemFontOfSize:16.0];
    NSString *unfoldString = @"...查看详情";
    NSMutableAttributedString *str2 = [[NSMutableAttributedString alloc] initWithString:unfoldString attributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize:16.0],
        NSForegroundColorAttributeName: UIColor.blueColor
    }];
    l.truncationAttrStr = [str2 copy];
    
    __weak typeof(l) weakl = l;
    
    l.truncationAction = ^{
        NSLog(@"尾部事件");
        weakl.numberOfLines = 0;
    };
    l.lineBreakMode = NSLineBreakByTruncatingTail;
    l.numberOfLines = 5;
    
    l.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    l.attributedString = attr;
    
    UITapGestureRecognizer *g = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGestureRecognizerTest)];
    l.userInteractionEnabled = YES;
    [l addGestureRecognizer:g];
    [self.view addSubview:l];
}
#pragma mark =========== YPSeniorLabelProtocol ===========
- (BOOL)seniorLabelShouldBeginSelecting:(YPSeniorLabel *)seniorLabel
{
    return YES;
}

#pragma mark =========== YPSelectMenuProtocol ===========
- (NSArray <YPMenuItem *> *)customMenuItems
{
    BOOL isHighLight= YES;
    return @[
        [[YPMenuItem alloc] initSystemWithAction:NSSelectorFromString(isHighLight ? @"menuHighLightAction:":@"menuCancelHighLightAction:")
                                           title:isHighLight?@"高亮显示":@"取消高亮"]
    ];
}

- (BOOL)canPerfomSelector:(SEL)aSelector
{
    //    if (aSelector == NSSelectorFromString(@"menuHighLightAction:") ||
    //        aSelector == NSSelectorFromString(@"menuCancelHighLightAction:")) {
    //         return YES;
    //    }
    return YES;
}

- (void)currentSelectContent:(NSString *)selectContent
{
}

- (BOOL)shouldShowMenuWithSeniorLabel:(YPSeniorLabel *)seniorLabel selectContent:(NSAttributedString *)selectContent range:(NSRange)range
{
    return YES;
}

// 高亮
- (void)menuHighLightAction:(id)sender {
    
}
// 取消高亮
- (void)menuCancelHighLightAction:(id)sender {
    
}



- (void)test234 {
    NSString *str = @"飞机上的旅客要靠枕.我向他解释经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好18612764897.表示出一副没有枕头会死的样子,我很无奈的从头等舱给他要了一个枕头落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!市场12345678";
    NSRange range = [str rangeOfString:@"市场12345678"];
    
    
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithString:str];

    YPSeniorLabel *l = [[YPSeniorLabel alloc]initWithFrame:CGRectMake(10, 100, self.view.frame.size.width - 20, 300)];
    l.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    
    YPAutoDetectConfig *c = [[YPAutoDetectConfig alloc]initWithDetectType:YPAutoDetectCheckType_All];
    NSMutableAttributedString *autoDetectStr = [YPSeniorLayout createAutoDetectAttrWithOriginalAttr:attr
                                                                detectConfig:c];
    
    YPLinkAttribute *linkAttr = [[YPLinkAttribute alloc] init];
    linkAttr.clickAction = ^(NSAttributedString *attrStr, NSRange textRange) {
        NSLog(@"Link单击");
    };
    [autoDetectStr setLink:linkAttr range:range];
    
    [autoDetectStr setFont:[UIFont boldSystemFontOfSize:20]];

    
    l.attributedString = autoDetectStr;

    [self.view addSubview:l];
}

- (void)test1 {
    NSString *str = @"飞机上的旅客要靠枕. 我向他解释 经济舱不提供枕头,如果头等舱有富余的枕头才可以提供给他.他都反复强调自己的腰不好.表示出一副没有枕头会死的样子.点击我呀,我很无奈的从头等舱给他要了一个枕头.[git]落地之后,在下飞机的途中非得要我的联系方式.我反复表示并不方便给联系方式.他非得知道哪里不方便.我说:算了吧,你的腰不好!";
    NSRange range1 = [str rangeOfString:@"济舱不提供枕头,"];
    NSRange range2 = [str rangeOfString:@"飞机上的旅客要靠枕"];
    NSRange range22 = [str rangeOfString:@"我向他解释"];
    NSRange range3 = [str rangeOfString:@"我的联系方式"];
    NSRange range4 = [str rangeOfString:@"在下飞机"];
    NSRange range5 = [str rangeOfString:@"点击我呀"];
    NSRange range6 = [str rangeOfString:@"可以提供给他"];
    NSRange range7 = [str rangeOfString:@"他非得知道"];
    NSRange range8 = [str rangeOfString:@"不方便给"];
    NSRange range9 = [str rangeOfString:@"你的腰不好"];
    
    
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]initWithString:str];
    
     // 阴影
     NSShadow *shadow = [[NSShadow alloc]init];
     shadow.shadowOffset = CGSizeMake(0, 3);
     shadow.shadowColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
     [attr setShadow:shadow range:range6];
     
     // markdown 里面的引用 >
     YPQuoteAttribute *a = [[YPQuoteAttribute alloc]init];
     a.quoteColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
     a.quoteWidth = 200;
     a.quoteLeft = 20;
     [attr setQuote:a range:range1];
     
     // 边框
     YPBorderAttribute *b = [[YPBorderAttribute alloc]init];
     b.borderWidth = 0.5;
     b.borderStyle = YPBorderNormal;
     b.borderColor = [UIColor greenColor];
     b.fillColor = [UIColor greenColor];
     b.cornerRadius = 5;
     b.insets = UIEdgeInsetsMake(-5, -20, -5, -20);
     
     [attr setBorder:b range:range22];
     
     //
     YPLinkAttribute *link = [[YPLinkAttribute alloc]init];
     link.highlightColor = [UIColor blueColor];
     link.highlightBackViewColor = [UIColor yellowColor];
     [attr setLink:link range:range3];
     
     [attr setColor:[UIColor blueColor] range:range4];
     
     
     [attr setColor:[UIColor blueColor] range:range5];
     
     YPLinkAttribute *linkAttr = [[YPLinkAttribute alloc] init];
     linkAttr.highlightColor = [UIColor yellowColor];
     linkAttr.clickAction = ^(NSAttributedString *attrStr, NSRange textRange) {
     NSLog(@"Link单击");
     };
     [attr setLink:linkAttr range:range5];
     
     NSMutableAttributedString *e =
     [NSMutableAttributedString configAttachmentStringContent:[UIImage imageNamed:@"git.png"] attachmentSize:CGSizeMake(32, 32) representString:@"[git]" alignToFont:[UIFont boldSystemFontOfSize:20] attachmentAlignment:YPAttachmentAlignmentCenter clickAction:^(NSAttributedString *attrStr, NSRange textRange) {
     NSLog(@"图片点击");
     }];
     
     [attr appendAttributedString:e];
    
    
    [attr setFont:[UIFont boldSystemFontOfSize:20]];
    
    YPLinkAttribute *linkAttr0 = [[YPLinkAttribute alloc] init];
    linkAttr.clickAction = ^(NSAttributedString *attrStr, NSRange textRange) {
        NSString *sub = [attr attributedSubstringFromRange:textRange].string;
        NSLog(@"Link单击");
    };
    [attr setColor:[UIColor blueColor] range:range8];
    [attr setLink:linkAttr0 range:range8];
    
    YPLinkAttribute *linkAttr1 = [[YPLinkAttribute alloc] init];
    linkAttr1.clickAction = ^(NSAttributedString *attrStr, NSRange textRange) {
        NSString *sub = [attr attributedSubstringFromRange:textRange].string;
        NSLog(@"Link单击");
    };
    [attr setColor:[UIColor yellowColor] range:range7];
    [attr setLink:linkAttr0 range:range7];
    
    NSDictionary *attrDic = @{NSForegroundColorAttributeName:[UIColor redColor],NSStrikethroughStyleAttributeName:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle)};
    [attr setAttributes:attrDic range:range9];
    
    YPSeniorLabel *l = [[YPSeniorLabel alloc]initWithFrame:CGRectMake(10, 100, self.view.frame.size.width - 20, 300)];
    
    
    NSString *unfoldString = @"...查看详情";
    NSMutableAttributedString *str2 = [[NSMutableAttributedString alloc] initWithString:unfoldString attributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize:20.0],
        NSForegroundColorAttributeName: UIColor.blueColor
    }];
    l.truncationAttrStr = [str2 copy];
    
    __weak typeof(l) weakl = l;
    
    l.truncationAction = ^{
        NSLog(@"尾部事件");
        weakl.numberOfLines = 0;
        weakl.truncationAttrStr = nil;
    };
    l.lineBreakMode = NSLineBreakByTruncatingTail;
    l.numberOfLines = 0;
    
    l.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    l.attributedString = attr;
    [self.view addSubview:l];
}


- (void)test4 {
    // 分母 为int 0 会崩溃, 为double 不会崩溃
    NSLog(@"before");
    defer {
        NSLog(@"yuhechuan");
    };
    NSLog(@"after");
}




- (void)test11 {
    NSLog(@"%@",[NSThread currentThread]);
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    //获取全局并发队列
    //dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    dispatch_queue_t queue = dispatch_queue_create("contact_search_queue", DISPATCH_QUEUE_CONCURRENT);
    
    
    //创建队列组
    dispatch_group_t group = dispatch_group_create();
    dispatch_group_enter(group);
    BOOL layerOpaque = self.view.opaque;
    CGFloat scale = [UIScreen mainScreen].scale;
    CGSize size = self.view.bounds.size;
    for (int i = 0; i < 1000; i ++) {
        dispatch_async(queue, ^{
            @synchronized (self) {
                dict[[NSThread currentThread].description] = [NSString stringWithFormat:@"%d",i];
            }
            UIGraphicsBeginImageContextWithOptions(size, layerOpaque, scale);
            UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            if (i == 999) {
                dispatch_group_leave(group);
            }
        });
    }
    //拦截通知
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        NSLog(@"%ld", dict.allKeys.count);
    });
}

- (void)test3 {
    NSLog(@"test3 执行了");
}

- (void)test5 {
    NSMutableArray *arr = [NSMutableArray arrayWithArray:@[@"",@"",@"",@"",@""]];
    
    [arr removeObject:@""];
    NSLog(@"%@",arr);
}

/*
 -(void)uploadLogToRemoteWithPath:(NSString *)path AppId:(nonnull NSString *)appID UserID:(nonnull NSString *)uid complete:(nonnull completeBlock_t)callback paraStr:(NSString *)paraStr{
 if (callback) {
 callbackBlock = callback;
 }
 if (!uploadQueue) {
 uploadQueue = dispatch_queue_create("SSUploadLog", NULL);
 }
 dispatch_async(uploadQueue, ^{
 if (uploading) {
 if (callbackBlock) {
 callbackBlock(1,@"The file is being uploaded.");
 }
 return ;
 }
 NSFileManager *fileManager = [NSFileManager defaultManager];
 if ([fileManager fileExistsAtPath:path]) {
 if ([[fileManager attributesOfItemAtPath:path error:nil] fileSize] == 0) {
 if (callbackBlock) {
 callbackBlock(3,@"The file'length is zero.");
 }
 return;
 }
 failArray = [NSMutableArray array];
 task_id = [self md5:[NSString stringWithFormat:@"%.0f%@%@",[[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970],appID,uid]];
 
 NSInteger index = 1;
 dispatch_group_t group = dispatch_group_create();
 
 NSInputStream *inputStream = [[NSInputStream alloc] initWithFileAtPath: path];
 [inputStream open];
 
 NSInteger maxLength = 1024*1024*5;//每次读取5M 日志
 
 NSMutableData * myBuffer = [NSMutableData dataWithLength:maxLength];
 uint8_t * readBuffer = [myBuffer mutableBytes];
 NSData * buffer = nil;
 BOOL endOfStreamReached = NO;
 uploading = YES;
 while (!endOfStreamReached)
 {
 NSInteger bytesRead = [inputStream read: readBuffer maxLength:maxLength];
 if (bytesRead == 0)
 {
 endOfStreamReached = YES;
 }
 else if (bytesRead == -1)
 {
 endOfStreamReached = YES;
 uploading = NO;
 if (callbackBlock) {
 callbackBlock(5,@"read file error");
 }
 }
 else
 {
 buffer = [NSData dataWithBytes:readBuffer length:bytesRead];
 
 NSData *data1 =[paraStr dataUsingEncoding:NSUTF8StringEncoding];
 NSMutableData *allData = [NSMutableData dataWithData:buffer];
 [allData appendData:data1];
 if ([fileManager fileExistsAtPath:kBufferPath]) {
 [allData writeToFile:kBufferPath atomically:YES];
 }else{
 if ([fileManager createFileAtPath:kBufferPath contents:nil attributes:nil]) {
 [allData writeToFile:kBufferPath atomically:YES];
 }
 }
 
 if ([fileManager fileExistsAtPath:kZipPath]) {
 [fileManager removeItemAtPath:kZipPath error:nil];
 }
 
 SSOldZipArchive * zip = [[SSOldZipArchive alloc]init];
 if ([zip CreateZipFile2:kZipPath]) {
 [zip addFileToZip:kBufferPath newname:@"SDK_LOG.txt"];
 [zip CloseZipFile2];
 }
 NSLog(@"%@-----",kZipPath);
 NSString *base64Encode = [[NSData dataWithContentsOfFile:kZipPath] base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
 
 [self postLogWithappID:appID uid:uid Log:base64Encode group:group index:index];
 
 index++;
 
 [fileManager removeItemAtPath:kZipPath error:nil];
 }
 }
 if (buffer==nil) {
 if (callbackBlock) {
 callbackBlock(3,@"The file'length is zero.");
 }
 return;
 }else{
 buffer = nil;
 }
 [inputStream close];//关闭流
 dispatch_group_notify(group, uploadQueue, ^{
 if (failArray.count == 0) {
 uploading = NO;
 [[NSFileManager defaultManager] removeItemAtPath:kBufferPath error:nil];
 if (callbackBlock) {
 callbackBlock(0,task_id);
 }
 }else{
 [self retryUpload];
 }
 });
 }else{
 if (callbackBlock) {
 callbackBlock(2,@"local log path is nil");
 }
 }
 });
 }
 */

- (void)test111 {
    for (int i = 0; i < 1000; i ++) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            self.obj = [[NSObject alloc]init];
        });
    }
}

- (BZTrackingTest *)trackingTest {
    if (!_trackingTest) {
        _trackingTest = [[BZTrackingTest alloc]init];
    }
    return _trackingTest;
}

@end
