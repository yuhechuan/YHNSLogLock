//
//  YHStudent.m
//  KZStudy
//
//  Created by yuhechuan on 2021/9/7.
//

#import "YHStudent.h"

@implementation YHStudent

- (instancetype)init {
    if (self = [super init]) {
//        NSLog(@"%@  %@", [self class], [super class]);
//        NSLog(@"%@  %@", [self superclass], [super superclass]);

    }
    return self;
}

- (void)mytest {
    NSString *name1 = NSStringFromClass([YHStudent class]);
    NSString *name2 = NSStringFromClass([self class]);
    NSLog(@"");
}

- (void)directMethod {
    NSLog(@"测试");
}

- (void)printName {
    NSLog(@"%@",self.name);
}


@end
