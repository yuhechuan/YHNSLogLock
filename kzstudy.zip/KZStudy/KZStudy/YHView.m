//
//  YHView.m
//  KZStudy
//
//  Created by yuhechuan on 2021/9/8.
//

#import "YHView.h"
#import "YHLayer.h"



@implementation YHView1

- (void)layoutSubviews {
    [super layoutSubviews];
}

@end

@interface YHView ()


@end

@implementation YHView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        YHView1 *view = [[YHView1 alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
        view.backgroundColor = [UIColor orangeColor];
        self.view1 = view;
        [self addSubview:view];
        self.backgroundColor = [UIColor redColor];
    }
    return self;
}


- (void)layoutSubviews {
    [super layoutSubviews];
}



@end
