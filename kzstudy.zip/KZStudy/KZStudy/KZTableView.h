//
//  KZTableView.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/2.
//

#import <UIKit/UIKit.h>

@interface KZTableView : UITableView

@property (nonatomic, assign) BOOL isRefreshing;

@end
