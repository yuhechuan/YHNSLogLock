//
//  UIView+BlurEffect.m
//  BZBasic
//
//  Created by yuhechuan on 2022/4/20.
//

#import "UIView+BlurEffect.h"

@implementation UIView (BlurEffect)

- (void)addBlurEffect {
    [self addBlurEffectRect:self.bounds];
}

- (void)addBlurEffectRect:(CGRect)rect {
    // 先移除老的
    [self removeBlurEffect];
    
    self.backgroundColor = UIColor.whiteColor;
    // 设置毛玻璃效果
    UIBlurEffectStyle style = appIsLightMode() ? UIBlurEffectStyleExtraLight : UIBlurEffectStyleDark;
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:(style)];
    UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
    effectView.frame = rect;
    [self addSubview:effectView];
    [self sendSubviewToBack:effectView];
    objc_setAssociatedObject(self, @selector(addBlurEffect), effectView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:USERSTYLE_CHANGED object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUserStyleChanged:) name:USERSTYLE_CHANGED object:nil];
}

- (void)removeBlurEffect {
    UIVisualEffectView *old = objc_getAssociatedObject(self, @selector(addBlurEffect));
    if (old) {
        [old removeFromSuperview];
        objc_setAssociatedObject(self, @selector(addBlurEffect), nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [[NSNotificationCenter defaultCenter] removeObserver:self name:USERSTYLE_CHANGED object:nil];
    }
}

- (void)onUserStyleChanged:(NSNotification *)notify {
    UIBlurEffectStyle style = appIsLightMode() ? UIBlurEffectStyleExtraLight : UIBlurEffectStyleDark;
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:(style)];
    UIVisualEffectView *effectView = objc_getAssociatedObject(self, @selector(addBlurEffect));
    if (effectView) {
        effectView.effect = effect;
    }
}



@end
