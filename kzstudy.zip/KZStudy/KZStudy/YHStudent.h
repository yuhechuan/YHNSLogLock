//
//  YHStudent.h
//  KZStudy
//
//  Created by yuhechuan on 2021/9/7.
//

#import "YHTeacher.h"
#import "IYHDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface YHStudent : YHTeacher

@property (nonatomic,copy) NSString *name;
@property (nonatomic, assign) int age;
@property (nonatomic, strong) id vc;
@property (nonatomic, copy) void(^myBlock)(void);

- (void)mytest;
- (void)directMethod;
- (void)printName;

@end

NS_ASSUME_NONNULL_END
