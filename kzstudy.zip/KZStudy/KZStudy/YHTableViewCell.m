//
//  YHTableViewCell.m
//  KZStudy
//
//  Created by yuhechuan on 2021/12/29.
//

#import "YHTableViewCell.h"

@interface YHTableViewCell ()

@property (nonatomic, strong) UILabel *titleText;
@property (nonatomic, strong) UIView *touchHotView;

@end

@implementation YHTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUp];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.titleText.frame = CGRectMake(20, 0, self.frame.size.width - 40, self.frame.size.height);
    self.touchHotView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
}

- (void)setUp {
    [self.contentView addSubview:self.titleText];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)refreshText:(NSString *)text {
    self.titleText.text = text;
}

- (UILabel *)titleText {
    if (!_titleText) {
        _titleText = [[UILabel alloc]init];
        _titleText.font = [UIFont systemFontOfSize:18];
        _titleText.textColor = [UIColor blackColor];
    }
    return _titleText;
}

- (UIView *)touchHotView {
    if (!_touchHotView) {
        _touchHotView = [[UIView alloc]init];
        [self.contentView addSubview:_touchHotView];
        [self.contentView sendSubviewToBack:_touchHotView];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hotViewTapView:)];
        [_touchHotView addGestureRecognizer:tap];
    }
    return _touchHotView;
}

- (void)hotViewTapView:(UITapGestureRecognizer *)tap {
    [CATransaction lock];
    self.deleteCell(self);
    [CATransaction unlock];
}


@end
