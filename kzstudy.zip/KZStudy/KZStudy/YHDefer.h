//
//  YHDefer.h
//  KZStudy
//
//  Created by yuhechuan on 2021/8/24.
//

#import <Foundation/Foundation.h>

#define defer_concat_(A, B) A ## B
#define defer_concat(A, B) defer_concat_(A, B)

typedef void(^executeCleanupBlock)(void);

#if defined(__cplusplus)
extern "C" {
#endif
void deferFunction (__strong executeCleanupBlock _Nonnull *_Nonnull block);
#if defined(__cplusplus)
}
#endif

#ifndef defer
#define defer \
__strong executeCleanupBlock defer_concat(blk, __LINE__) __attribute__((cleanup(deferFunction), unused)) = ^
#endif


@interface YHDefer : NSObject

+ (YHDefer *_Nullable)sharedDefer;

@end

