//
//  YHImageDecoder.m
//  KZStudy
//
//  Created by yuhechuan on 2021/9/7.
//

#import "YHImageDecoder.h"

@implementation YHImageDecoder

+ (UIImage *)imageDecoderWithImageName:(NSString *)imageName {
    if (!imageName || imageName.length == 0) {
        return nil;
    }
    UIImage *image = [UIImage imageNamed:imageName];
    CGImageRef cgImageRef = [image CGImage];
    
    // 获取图片宽高
    GLuint width = (GLuint)CGImageGetWidth(cgImageRef);
    GLuint height = (GLuint)CGImageGetHeight(cgImageRef);

    //获取图片的rect
    CGRect rect = CGRectMake(0, 0, width, height);

    //获取图片的颜色空间
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();


    // 创建上下文
    /**
    CGBitmapContextCreate(void * __nullable data,
        size_t width, size_t height, size_t bitsPerComponent, size_t bytesPerRow,
        CGColorSpaceRef cg_nullable space, uint32_t bitmapInfo)

    data：开辟的图片内存区域，此处传 imageData NULL 自动分配内存
    width:  图片宽度
    height：图片高度
    bitsPerComponent：每个颜色分量所占bit数，此处传8位
    bytesPerRow：每一行占用字节数，此处为 width * 4
    space：颜色空间
    bitmapInfo：位图的信息，此处采用RGBA，即kCGImageAlphaPremultipliedLast
    */
    CGContextRef context = CGBitmapContextCreate(NULL, width, height, 8, width * 4, colorSpace, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);

    // 将图片翻转过来(图片默认是倒置的)
    // 图片的坐标系左上角为(0,0)，纹理坐标左下角为(0,0)，因此需要翻转
    CGContextTranslateCTM(context, 0, height);
    CGContextScaleCTM(context, 1.0f, -1.0f);

    // 绘制前先清除颜色空间和绘图区域，防止残留数据
    CGColorSpaceRelease(colorSpace);
    CGContextClearRect(context, rect);

    // 对图片进行重新绘制，得到一张新的解压缩后的位图
    CGContextDrawImage(context, rect, cgImageRef);

//    // 设置图片纹理属性
//    // 获取纹理ID
//    GLuint textureID;
//    glGenTextures(1, &textureID); // 获取一个纹理句柄
//    glBindTexture(GL_TEXTURE_2D, textureID); // 将句柄绑定到纹理目标上，GL_TEXTURE_2D等
//
//    // 设置纹理属性
//    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
//    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
//    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

//    // 结束后是否数据
//    glBindTexture(GL_TEXTURE_2D, 0); // 将纹理目标重新绑定为0
    CGImageRef destImageRef = CGBitmapContextCreateImage(context);
    UIImage *grayImage = [UIImage imageWithCGImage:destImageRef];
    CGContextRelease(context); // 释放context
    CFRelease(destImageRef);

    return grayImage;
    
}

@end
