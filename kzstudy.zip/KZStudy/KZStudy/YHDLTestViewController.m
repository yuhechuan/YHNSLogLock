//
//  YHDLTestViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2023/6/5.
//

#import "YHDLTestViewController.h"
#import "YHDefer.h"

@interface YHDLTestViewController ()

@property (nonatomic, strong) YHDefer *myDefer;

@end

@implementation YHDLTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.myDefer = [YHDefer sharedDefer];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)dealloc {
    NSLog(@"YHDLTestViewController 销毁了");
}

@end
