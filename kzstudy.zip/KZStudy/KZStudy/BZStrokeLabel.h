//
//  BZStrokeLabel.h
//  KZStudy
//
//  Created by yuhechuan on 2024/9/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BZStrokeLabel : UILabel
/// 启用 图片 mark
@property (nonatomic, strong) UIImage *markImage;
/// 外圈轮廓颜色
@property (nonatomic, strong) UIColor *outerColor;
/// 内圈轮廓颜色
@property (nonatomic, strong) UIColor *innerColor;
/// 默认是 字体宽度
@property (nonatomic, assign) float outerBorderWidth;
/// 默认是 字体宽度
@property (nonatomic, assign) float innerBorderWidth;

@property (nonatomic, strong, readonly) NSMutableAttributedString *readCurrentAttributedString;

@end

NS_ASSUME_NONNULL_END
