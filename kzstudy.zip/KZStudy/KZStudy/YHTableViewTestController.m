//
//  YHTableViewTestController.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/2.
//

#import "YHTableViewTestController.h"
#import "KZTableView.h"
#import "YHTableViewCell.h"
#import "NSObject+KZExtension.h"
#import "YHView.h"
#import "YHOtherView.h"

static NSMutableArray *list1 = nil;

@interface YHTableViewTestController ()<UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate>

@property (nonatomic, strong) KZTableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataList;
@property (nonatomic, strong) NSMutableArray *list2;
@property (nonatomic, strong) YHView *view1;
@property (nonatomic, strong) YHOtherView *view2;
@property (nonatomic, assign) NSInteger maxIndex;
@property (nonatomic, assign) NSInteger minIndex;
@property (nonatomic, strong) NSTimer *timer;


@end

@implementation YHTableViewTestController

- (instancetype)init {
    if (self = [super init]) {
        NSLog(@"%s",__func__);
    }
    return self;
}

//- (void)loadView {
//    self.view = [[UIView alloc]init];
//    NSLog(@"%s",__func__);
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%s",__func__);
    
    self.navigationItem.title = @"测试TableView";
    UIBarButtonItem *bar = [[UIBarButtonItem alloc]initWithTitle:@"刷新" style:UIBarButtonItemStylePlain target:self action:@selector(refresh)];
    self.navigationItem.rightBarButtonItem = bar;
    self.view.backgroundColor = [UIColor whiteColor];
   
    [self addMoreYHView];
}

- (void)addTimerAction {
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.5 repeats:YES block:^(NSTimer * _Nonnull timer) {
        if (self.dataList.count > 0) {
            [self.tableView reloadData];
        }
    }];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)refresh {
    [self.tableView reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"%s",__func__);
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"%s",__func__);
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    NSLog(@"%s",__func__);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    NSLog(@"%s",__func__);
}

- (void)addYHView {
    YHView *yview = [[YHView alloc]initWithFrame:CGRectMake(50, 100, self.view.frame.size.width - 100, 200)];
    [self.view addSubview:yview];
}

- (void)addMoreYHView {
    YHView *yview = [[YHView alloc]initWithFrame:CGRectMake(50, 100, self.view.frame.size.width - 100, 200)];
    [self.view addSubview:yview];
    self.view1 = yview;
    
    YHOtherView *yview1 = [[YHOtherView alloc]initWithFrame:CGRectMake(50, CGRectGetMaxY(yview.frame) + 20, self.view.frame.size.width - 100, 200)];
    [self.view addSubview:yview1];
    self.view2 = yview1;
    self.view2.hidden = YES;
    
    NSArray *subviews = self.view.subviews;
    NSLog(@"");
}


- (void)addTableView {
    int count = 500;
    for (int i = 0; i < count; i ++) {
        NSString *s = [NSString stringWithFormat:@"第 %d 行",i];
        [self.dataList addObject:s];
    }
    [self.tableView registerClass:[YHTableViewCell class] forCellReuseIdentifier:NSStringFromClass([YHTableViewCell class])];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSLog(@"%s",__func__);
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    NSLog(@"%s",__func__);
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSLog(@"%s",__func__);
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:10 inSection:0];
    void(^myBlock)(void) = ^ {
        NSLog(@"%@", indexPath);
    };
    indexPath = [NSIndexPath indexPathForRow:11 inSection:0];
    NSLog(@"%@", indexPath);
    myBlock();
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
    YHTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([YHTableViewCell class]) forIndexPath:indexPath];
    cell.indexPath = indexPath;
    __weak __typeof(self)weakSelf = self;
    cell.deleteCell = ^(YHTableViewCell * _Nonnull curCell) {
        [weakSelf deleteCellIndexPath:indexPath cell:curCell];
    };
    [cell refreshText:self.dataList[indexPath.row]];
    return cell;
}


//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
//    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
//    return 5;
//}
//
//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
//    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
//    return 5;
//}

//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
//    UIView *h = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 20)];
//    h.backgroundColor = [UIColor redColor];
//    return h;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
//    [self logOfString:[NSString stringWithFormat:@"%s",__func__]];
//    UIView *h = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 20)];
//    h.backgroundColor = [UIColor blueColor];
//    return h;
//}

- (void)deleteCellIndexPath:(NSIndexPath *)indexPath cell:(YHTableViewCell *)cell{
    NSLog(@"第%ld行", (long)indexPath.row);
    NSLog(@"第%ld行", (long)[self.tableView indexPathForCell:cell].row);
//    [self.tableView performBatchUpdates:^{
//
//        } completion:^(BOOL finished) {
//        }];
//    [self.tableView performBatchUpdates:^{
//        if (indexPath.row < self.dataList.count) {
//            [self.dataList removeObjectAtIndex:indexPath.row];
//            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
//        }
//           
//        } completion:^(BOOL finished) {
//           [self.tableView reloadData];
//        }];
}

- (void)deleteCellAction:(YHTableViewCell *)cell {
//    [self.tableView layoutIfNeeded];
    NSIndexPath *index1 = [self.tableView indexPathForCell:cell];
    NSIndexPath *index2 = cell.indexPath;
    if (index1.row != index2.row) {
        NSLog(@"测试1");
    }
    if (!index1 || !index2) {
        NSLog(@"测试1");
    }
    [self.tableView performBatchUpdates:^{
            [self.dataList removeObjectAtIndex:index1.row];
            [self.tableView deleteRowsAtIndexPaths:@[index1] withRowAnimation:UITableViewRowAnimationTop];
        } completion:^(BOOL finished) {
           [self.tableView reloadData];
        }];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"第%ld行", (long)indexPath.row);
}


- (void)logIndexPath {
    [self.tableView reloadData];
    [self.tableView layoutIfNeeded];
    NSArray *cells = self.tableView.visibleCells;
    NSMutableArray *arr = [NSMutableArray array];
    for (YHTableViewCell *cell in cells) {
        [arr addObject:@(cell.indexPath.row)];
    }
    NSLog(@"cell所有数据:%@",arr);
}

- (void)logVisibleCells {
    NSArray *cells = self.tableView.visibleCells;
    NSLog(@"cell所有数据:%@",cells);
}

- (void)logOfString:(NSString *)log {
    return;
    NSLog(@"%@",log);
}

- (KZTableView *)tableView {
    if (!_tableView) {
        _tableView = [[KZTableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height -200) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor=[UIColor redColor];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (NSMutableArray *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

- (void)dealloc {
    [self.timer invalidate];
    self.timer = nil;
}


@end
