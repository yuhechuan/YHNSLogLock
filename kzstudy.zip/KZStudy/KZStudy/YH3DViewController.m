//
//  YH3DViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2022/7/20.
//

#import "YH3DViewController.h"
#import "YH3DPreview.h"
#import "YHColumnarView.h"
@interface YH3DViewController ()

@end

@implementation YH3DViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
//    CGFloat h = self.view.bounds.size.height / 2.0;
//    YH3DPreview *p = [[YH3DPreview alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height / 4.0, self.view.bounds.size.width, h)];
//    [self.view addSubview:p];
    
    CGFloat width = 100;
    CGFloat height = 50;
    
    YHColumnarView *c = [[YHColumnarView alloc]initWithFrame:CGRectMake(150, 150, width, height)];
    [self.view addSubview:c];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
