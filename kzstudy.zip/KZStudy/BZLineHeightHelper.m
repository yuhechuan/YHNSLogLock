//
//  BZLineHeightHelper.m
//  KZStudy
//
//  Created by yuhechuan on 2024/10/22.
//

#import "BZLineHeightHelper.h"
#import "NSMutableAttributedString+YP.h"


@implementation BZLineHeightHelper

+ (UILabel *)test {
    NSString *text = @"OceanBase 社区版是一款开源分布式 HTAP（Hybrid Transactional/Analytical Processing）数据库管理系统，具有原生分布式架构，支持金融级高可用、透明水平扩展、分布式事务、多租户和语法兼容等企业级特性。OceanBase 内核通过大规模商用场景的考验，已服务众多行业客户，现面向未来持续构建内核技术竞争力。";
    
    // NSString *text = @"OceanBase 社区版是一款开源分布式";
    
    NSMutableAttributedString *allAttr = [[NSMutableAttributedString alloc]initWithString:text];
    
    UIFont *font = [UIFont systemFontOfSize:18];
    CGFloat lineHeight = 30;
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(40, 120, 320, 200)];
    label.numberOfLines = 0;
    label.font = font;
    label.textColor = [UIColor blackColor];
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    
    [self lineHeightFix:allAttr lineHeight:lineHeight font:font];
    allAttr.lineSpacing = 5;
    
    label.attributedText = allAttr;
    [label sizeToFit];
    return label;
}

+ (void)testLineHeight:(UIView *)bgView {
    CGFloat bg_width = bgView.frame.size.width;
    CGFloat bg_height = bgView.frame.size.height;

    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, bg_width, bg_height)];
    [bgView addSubview:scrollView];
    CGFloat y = 50;
    UILabel *label = nil;
    NSString *text = @"OceanBase 社区版是一款开源分布式";
    
    label = [self configTest:text bg_width:bg_width bg_y:y config:^(NSMutableAttributedString *attribute) {
        
    }];
    [scrollView addSubview:label];
    y = CGRectGetMaxY(label.frame) + 20;
    
    
    text = @"OceanBase 社区版是一款开源分布式 HTAP（Hybrid Transactional/Analytical Processing）数据库管理系统，具有原生分布式架构，支持金融级高可用、透明水平扩展、分布式事务、多租户和语法兼容等企业级特性。";
    label = [self configTest:text bg_width:bg_width bg_y:y config:^(NSMutableAttributedString *attribute) {
    }];
    
    text = @"OceanBase 社区版是一款开源分布式 HTAP（Hybrid Transactional/Analytical Processing）数据库管理系统，具有原生分布式架构，支持金融级高可用、透明水平扩展、分布式事务、多租户和语法兼容等企业级特性。";
    label = [self configTest:text bg_width:bg_width bg_y:y config:^(NSMutableAttributedString *attribute) {
        attribute.lineSpacing = 5;
    }];
    
    text = @"OceanBase 社区版是一款开源分布式 HTAP（Hybrid Transactional/Analytical Processing）数据库管理系统，具有原生分布式架构，支持金融级高可用、透明水平扩展、分布式事务、多租户和语法兼容等企业级特性。";
    label = [self configTest:text bg_width:bg_width bg_y:y config:^(NSMutableAttributedString *attribute) {
        attribute.lineSpacing = 5;
        attribute.headIndent = 15;
    }];
    
    [scrollView addSubview:label];
    
    
}


+ (UILabel *)configTest:(NSString *)text bg_width:(CGFloat)bg_width bg_y:(CGFloat)bg_y config:(void(^)(NSMutableAttributedString *attribute)) config {
    NSMutableAttributedString *allAttr = [[NSMutableAttributedString alloc]initWithString:text];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, bg_width, 0)];
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];;
    label.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.1];
    allAttr.font = font;
    allAttr.color = [UIColor blueColor];
    label.numberOfLines = 0;
    CGFloat lineHeight = 30;

    [self lineHeightFix:allAttr lineHeight:lineHeight font:font];
    if (config) {
        config(allAttr);
    }
    label.attributedText = allAttr;
    [label sizeToFit];
    label.frame = CGRectMake(20, bg_y, bg_width - 40, label.frame.size.height);
    return label;
}

+ (void)lineHeightFix:(NSMutableAttributedString *)allAttr
           lineHeight:(CGFloat)lineHeight
                 font:(UIFont *)font {
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.maximumLineHeight = lineHeight;
    paragraphStyle.minimumLineHeight = lineHeight;
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:paragraphStyle forKey:NSParagraphStyleAttributeName];
    CGFloat baselineOffset = (lineHeight - font.lineHeight) / 2.0;
    [attributes setObject:@(baselineOffset) forKey:NSBaselineOffsetAttributeName];
    [allAttr addAttributes:attributes range:NSMakeRange(0, allAttr.length)];
}

@end
