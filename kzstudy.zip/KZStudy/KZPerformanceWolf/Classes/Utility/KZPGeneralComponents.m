//
//  KZPGeneralComponents.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import "KZPGeneralComponents.h"
#import <objc/runtime.h>

//swizzle instance method
void kzp_swizzleInstanceMethod(Class originClass, Class proxyClass, SEL originSelector, SEL proxySelector) {
    
    if (!originClass || !proxyClass || !originSelector || !proxySelector) return;
    
    Method originMethod = class_getInstanceMethod(originClass, originSelector);
    Method proxyMethod = class_getInstanceMethod(proxyClass, proxySelector);
    
    if (!originMethod || !proxyMethod) return;
    class_replaceMethod(originClass, proxySelector, method_getImplementation(originMethod), method_getTypeEncoding(originMethod));
    class_replaceMethod(originClass, originSelector, method_getImplementation(proxyMethod), method_getTypeEncoding(proxyMethod));
    
}

//swizzle class method
void kzp_swizzleClassMethod(Class originClass, Class proxyClass, SEL originSelector, SEL proxySelector) {
    
    if (!originClass || !proxyClass || !originSelector || !proxySelector) return;
    
    Method originMethod = class_getClassMethod(originClass, originSelector);
    Method proxyMethod = class_getClassMethod(proxyClass, proxySelector);
    
    if (!originMethod || !proxyMethod) return;
    Class originMetaClass = objc_getMetaClass(class_getName(originClass));
    
    class_replaceMethod(originMetaClass, proxySelector, method_getImplementation(originMethod), method_getTypeEncoding(originMethod));
    class_replaceMethod(originMetaClass, originSelector, method_getImplementation(proxyMethod), method_getTypeEncoding(proxyMethod));
}


NSString * kzp_runloopActivityMapString(CFRunLoopActivity activity) {
    switch (activity) {
        case kCFRunLoopEntry:
            return @"kCFRunLoopEntry";

        case kCFRunLoopBeforeTimers:
            return @"kCFRunLoopBeforeTimers";
            
        case kCFRunLoopBeforeSources:
            return @"kCFRunLoopBeforeSources";
            
        case kCFRunLoopBeforeWaiting:
            return @"kCFRunLoopBeforeWaiting";
            
        case kCFRunLoopAfterWaiting:
            return @"kCFRunLoopAfterWaiting";
            
        case kCFRunLoopExit:
            return @"kCFRunLoopExit";
            
        case kCFRunLoopAllActivities:
            return @"kCFRunLoopAllActivities";

    }
    return @"UnknownActivity";
}
