//
//  KZPGeneralMacros.h
//  Pods
//
//  Created by Yaping Liu on 5/9/19.
//

#ifndef KZPGeneralMacros_h
#define KZPGeneralMacros_h

/** Performance entry keys **/
#define KZP_EXCEPTION_TYPE                  @"Exception_type"
#define KZP_EXCEPTION_INFO                  @"Exception_info"
#define KZP_IMAGES_INFO                     @"Images_info"
#define KZP_SYSTEM_ENV                      @"System_env"
#define KZP_USER_ENV                        @"User_env"


/** System entry keys **/
#define KZP_SYSTEM_DATE                     @"date"
#define KZP_SYSTEM_TIMESTAMP                @"timeStamp"
#define KZP_SYSTEM_APP_VERSION              @"app_version"
#define KZP_SYSTEM_APP_BUILD                @"app_build"
#define KZP_SYSTEM_VERSION                  @"system_version"
#define KZP_SYSTEM_MACHINE_CODE             @"machine_code"
#define KZP_SYSTEM_NAME                     @"system_name"
#define KZP_SYSTEM_OS_VERSION               @"os_version"
#define KZP_SYSTEM_PAGE_BACKTRACE           @"page_backtrace"
#define KZP_SYSTEM_APPBUNDLE_NAME           @"app_bundle_name"
#define KZP_SYSTEM_APP_UUID                 @"app_uuid"
#define KZP_SYSTEM_CPU_ARCH                 @"sys_cpu_arch"
#define KZP_SYSTEM_APP_CPU_ARCH             @"app_cpu_arch"


/** Freeze entry keys **/
#define KZP_FREEZE_TYPE                     @"freeze_type"
#define KZP_FREEZE_INTERVAL                 @"freeze_interval"
#define KZP_FREEZE_BACKTRACE_TOTAL          @"freeze_backtrace_total"
#define KZP_FREEZE_BACKTRACE_COUNT          @"freeze_backtrace_count"
#define KZP_FREEZE_MAIN_BACKTRACE           @"freeze_main_backtrace"


/** Crash entry keys **/
#define KZP_CRASH_TYPE                      @"crash_type"
#define KZP_CRASH_REASON                    @"crash_reason"
#define KZP_CRASH_DESC                      @"crash_desc"
#define KZP_CRASH_LAST_BACKTRACE            @"crash_last_backtrace"
#define KZP_CRASH_FAULT_ADDR                @"crash_fault_address"
#define KZP_CRASH_THREADS                   @"crash_threads"
#define KZP_CRASH_MARK_SLIDE                @"crash_mark_slide"
#define KZP_CRASH_MARK_IMAGE                @"crash_mark_image"

/** Net entry keys **/
#define KZP_APINET_STATUS                   @"net_status"
#define KZP_APINET_ERROR_CODE               @"net_error_code"
#define KZP_APINET_ERROR_DESC               @"net_error_desc"
#define KZP_APINET_HOST                     @"net_host"
#define KZP_APINET_PATH                     @"net_path"
#define KZP_APINET_QUERY                    @"net_query"
#define KZP_APINET_TOTAL_INTERVAL           @"net_total_interval"
#define KZP_APINET_DNS_INTERVAL             @"net_dns_interval"

/** Backtrace related keys **/
//Symbol info keys for `DL_info`.
#define KZP_SI_INSTRUCT_ADDRESS             @"si_instruct_addr"
#define KZP_SI_IMAGE_NAME                   @"si_img_name"
#define KZP_SI_IMAGE_ADDRESS                @"si_img_addr"
#define KZP_SI_SYMBOL_NAME                  @"si_sym_name"
#define KZP_SI_SYMBOL_ADDRESS               @"si_sym_addr"

//Link image keys
#define KZP_LI_NAME                         @"li_name"
#define KZP_LI_UUID                         @"li_uuid"
#define KZP_LI_ADDRESS                      @"li_addr"
#define KZP_LI_SIEZE                        @"li_size"
#define KZP_LI_ARCH                         @"li_arch"

//Thread entry keys
#define KZP_T_NUM                           @"t_num"
#define KZP_T_CURRENT                       @"t_current"
#define KZP_T_NAME                          @"t_name"
#define KZP_T_BACKTRACE                     @"t_backtrace"
#define KZP_T_MARKED                        @"t_marked"


/** Freeze type values **/
#define KZP_FREEZE_TYPE_LAUNCH              @"Launch"
#define KZP_FREEZE_TYPE_MAINTHREAD          @"MainThread"
#define KZP_FREEZE_TYPE_ENTERFORGROUND      @"EnterForground"

/** Crash type values **/
#define KZP_CRASH_TYPE_NSEXCEPTION          @"NSException"
#define KZP_CRASH_TYPE_SIGNAL               @"Signal"
#define KZP_CRASH_TYPE_MACH                 @"Mach"


/** Format address for string **/
//format pointer
#define POINTER_SHORT_HEX_FMT "0x%" PRIxPTR
#if defined(__LP64__)
#define POINTER_HEX_FMT       "0x%016" PRIxPTR
#else
#define POINTER_HEX_FMT       "0x%08" PRIxPTR
#endif
//format uintptr_t
#define STR_FMT_HEX_ADDRESS(_addr)\
([NSString stringWithFormat:@POINTER_HEX_FMT,(uintptr_t)(_addr)])

#define KZPDIC_SAVE_SAFETY(_dic, _value, _key)\
if(_value) _dic[_key] = _value

#endif /* KZPGeneralMacros_h */
