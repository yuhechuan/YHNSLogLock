//
//  KZPGeneralComponents.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import <Foundation/Foundation.h>
#import "KZPGeneralMacros.h"
#import "KZPerformanceDataCenter+Private.h"

NS_ASSUME_NONNULL_BEGIN

#ifdef __cplusplus
extern "C" {
#endif
@protocol KZPerformanceMonitorProtocol <NSObject>

+ (instancetype)shareMonitor;

- (BOOL)isMonitoring;

- (void)startMonitor;

- (void)stopMonitor;

@end

//swizzle instance method
extern void kzp_swizzleInstanceMethod(Class originClass, Class proxyClass, SEL originSelector, SEL proxySelector);

//swizzle class method
extern void kzp_swizzleClassMethod(Class originClass, Class proxyClass, SEL originSelector, SEL proxySelector);

extern NSString * kzp_runloopActivityMapString(CFRunLoopActivity activity);

#ifdef __cplusplus
}  // extern "C"
#endif


NS_ASSUME_NONNULL_END
