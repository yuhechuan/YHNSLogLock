//
//  KZPerformanceDataCenter.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/14/19.
//

#import "KZPerformanceDataCenter+Private.h"
#import "KZPMachOContentAssistor.h"
#import "KZPGeneralMacros.h"
#import "KZPSystemEnvInfoAssistor.h"
#import <sys/stat.h>
#import <sys/time.h>
#import "KZPGeneralComponents.h"
#import <CommonCrypto/CommonCrypto.h>
#import <CommonCrypto/CommonDigest.h>

//10 days with `864000 = 60*60*24*10`
#define KZP_DATA_MAX_SAVE_DAYS_SECS   864000

//delay upload time
#define KZP_DATA_LOCAL_DELAY_UPLOAD_SECS   3

@implementation KZPUploadExceptionData
@end

@interface KZPerformanceDataCenter ()

@property (nonatomic, strong) dispatch_queue_t ioHandleQueue;

@property (nonatomic, copy) KZPUploadExceptionDataBlock uploadBlock;

@property (nonatomic, strong) NSMutableArray *pagesBacktrace;

@end

@implementation KZPerformanceDataCenter

+ (instancetype)shareDataCenter {
    static KZPerformanceDataCenter *center = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        center = [[KZPerformanceDataCenter alloc] init];
    });
    return center;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _ioHandleQueue = dispatch_queue_create("com.LYPDoit.KZPerformanceWolf.KZPerformanceDataCenter.ioHandleQueue", DISPATCH_QUEUE_SERIAL);
        self.pagesBacktrace = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)saveDataForType:(KZPDataType)dataType
               infoEntry:(NSDictionary *)infoEntry {
    if (!infoEntry) return;
    
    if (dataType == KZPDataTypeCrash) {
        [self saveExceptionDetailForType:dataType infoEntry:infoEntry identifierUUID:nil immediateUpload:NO];

    }else{
        dispatch_async(_ioHandleQueue, ^{;
            [self saveExceptionDetailForType:dataType infoEntry:infoEntry identifierUUID:nil immediateUpload:YES];
        });
    }
}

- (void)customSaveDataForType:(KZPDataType)dataType
                    infoEntry:(NSDictionary *)infoEntry
               identifierUUID:(NSString *)identifierUUID
              immediateUpload:(BOOL)immediateUpload
{
    dispatch_async(_ioHandleQueue, ^{;
        [self saveExceptionDetailForType:dataType infoEntry:infoEntry identifierUUID:identifierUUID immediateUpload:immediateUpload];
    });
}


- (void)saveExceptionDetailForType:(KZPDataType)dataType
                         infoEntry:(NSDictionary *)infoEntry
                    identifierUUID:(NSString *)identifierUUID
                   immediateUpload:(BOOL)immediateUpload
{
    NSString *exceptionName = performanceDataTypeName(dataType);
    if (!exceptionName) return;
    
    /** Create performance entry **/
    NSMutableDictionary *performEntry = [[NSMutableDictionary alloc] init];
    //exception type
    performEntry[KZP_EXCEPTION_TYPE] = exceptionName;
    //exception info
    performEntry[KZP_EXCEPTION_INFO] = infoEntry;
    //link images
    if (dataType == KZPDataTypeCrash || dataType == KZPDataTypeFreezing) {
        performEntry[KZP_IMAGES_INFO] = kzp_getBinaryImageEntries();
    }
    //system environment
    NSMutableDictionary *environmentDic = kzp_systemInfo().mutableCopy;
    NSMutableString *pagesBacktrace = [[NSMutableString alloc] init];
    for (NSString *pageName in self.pagesBacktrace) {
        [pagesBacktrace appendFormat:@"%@-->",pageName];
    }
    environmentDic[KZP_SYSTEM_PAGE_BACKTRACE] = pagesBacktrace;
    performEntry[KZP_SYSTEM_ENV] = environmentDic;
    
    //user environment
    KZPAcquireUserCustomInfos userBlock = [KZPerformanceDataCenter shareDataCenter].userInfosBlock;
    if (userBlock) {
        NSDictionary *userInfo = userBlock(dataType);
        if (userInfo) {
            performEntry[KZP_USER_ENV] = userInfo;
        }
    }
    
    /** Send to user **/
    if (self.exceptionNotifyBlock) {
        self.exceptionNotifyBlock(dataType, performEntry.copy);
    }
    
    /** Save and report **/
    if (![NSJSONSerialization isValidJSONObject:performEntry]) {
        NSLog(@"KZPerformance exception entry is invalid json object!");
        return;
    }
    NSError *exceSerializationError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:performEntry options:NSJSONWritingPrettyPrinted error:&exceSerializationError];
    if (exceSerializationError){
        NSLog(@"KZPerformance exception data serialized failed with error: %@",exceSerializationError);
        return;
    }

    NSString *reportID = identifierUUID;
    if (!reportID || reportID.length < 1) {
        reportID = [NSUUID UUID].UUIDString;
    }
    //save to disk
    NSString *jsonPath = @"";
    NSString *saveDir = kzp_monitorDirPathWithType(dataType);
    if (saveDir){
        jsonPath = [NSString stringWithFormat:@"%@/%@.json",saveDir,reportID];
        [[NSFileManager defaultManager] createFileAtPath:jsonPath contents:jsonData attributes:nil];
    }
    //upload
    if (immediateUpload && self.uploadBlock) {
        self.uploadBlock(dataType, jsonData, jsonPath, reportID);
    }

}

- (void)autoUploadUsingBlock:(KZPUploadExceptionDataBlock)uploadBlock {
    [self autoUploadUsingBlock:uploadBlock startupDatas:nil];
}

- (void)autoImmediateUploadUsingBlock:(KZPUploadExceptionDataBlock)uploadBlock
                         startupDatas:(KZPUploadExceptionDatas)startupDatas
{
    [self autoUploadUsingBlock:uploadBlock startupDatas:startupDatas];
}

- (void)autoUploadUsingBlock:(KZPUploadExceptionDataBlock)uploadBlock
                startupDatas:(KZPUploadExceptionDatas)startupDatas
{
    if (!uploadBlock) return;
    if (self.uploadBlock) return;
    self.uploadBlock = uploadBlock;
    NSMutableArray *excDatas = [[NSMutableArray alloc] init];
    void (^launchReport)(KZPDataType) = ^(KZPDataType dataType){
        NSString *dirPath = kzp_monitorDirPathWithType(dataType);
        if (dirPath) {
            NSArray *allFiles = [[NSFileManager defaultManager] subpathsAtPath:dirPath];
            if (allFiles.count < 1) return;
            for (NSString *fileN in allFiles) {
                if (![fileN hasSuffix:@".json"]) continue;
                NSString *fullPath = [NSString stringWithFormat:@"%@/%@",dirPath,fileN];
                //check for file
                if (fileIsExpiredAtPath(fullPath)) {
                    [[NSFileManager defaultManager] removeItemAtPath:fullPath error:nil];
                    continue;
                }
                //upload
                NSData *jsonData = [[NSData alloc] initWithContentsOfFile:fullPath];
                if (!jsonData) continue;
                NSString *reportID = [fileN stringByReplacingOccurrencesOfString:@".json" withString:@""];
                if (startupDatas) {
                    KZPUploadExceptionData *data = [[KZPUploadExceptionData alloc] init];
                    data.dataType = dataType;
                    data.uploadData = jsonData;
                    data.filePath = fullPath;
                    data.reportID = reportID;
                    [excDatas addObject:data];
                }else{
                    uploadBlock(dataType, jsonData, fullPath, reportID);
                }
            }
        }
    };
    if (startupDatas) {
        dispatch_async(_ioHandleQueue, ^{
            launchReport(KZPDataTypeCrash);
            launchReport(KZPDataTypeFreezing);
            launchReport(KZPDataTypeAPINet);
            startupDatas(excDatas);
        });
    }else{
        //delay upload data
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,
                                     (int64_t)(KZP_DATA_LOCAL_DELAY_UPLOAD_SECS * NSEC_PER_SEC)),
                       _ioHandleQueue, ^{
            launchReport(KZPDataTypeCrash);
            launchReport(KZPDataTypeFreezing);
            launchReport(KZPDataTypeAPINet);
        });
    }
}

- (void)deleteCacheWithDataType:(KZPDataType)dataType reportID:(NSString *)reportID {
    dispatch_async(_ioHandleQueue, ^{
        NSString *subDir = kzp_monitorDirPathWithType(dataType);
        if (!subDir) return;
        NSString *filePath = [NSString stringWithFormat:@"%@/%@.json",subDir,reportID];
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
    });
}

- (NSArray <NSString *> *)getAllExceptionPathsForType:(KZPDataType)dataType {
    NSMutableArray *allPaths = [[NSMutableArray alloc] init];
    dispatch_sync(_ioHandleQueue, ^{
        NSString *dirPath = kzp_monitorDirPathWithType(dataType);
        if (dirPath) {
            NSArray *allFiles = [[NSFileManager defaultManager] subpathsAtPath:dirPath];
            for (NSString *fileN in allFiles) {
                NSString *fullPath = [NSString stringWithFormat:@"%@/%@",dirPath,fileN];
                [allPaths addObject:fullPath];
            }
        }
    });
    return allPaths;
}

//Check file whether is expired.
static BOOL fileIsExpiredAtPath(NSString *filePath) {
    if (!filePath) return NO;
    time_t curTime = 0U;
    struct timeval curTimeVal;
    if (0 == gettimeofday(&curTimeVal, NULL)) {
        curTime = curTimeVal.tv_sec;
    }
    struct stat st;
    if (0 == lstat([filePath UTF8String], &st)) {
        if (S_ISREG(st.st_mode)){
            //file create time
            time_t crtTime = st.st_birthtime;
            //check whether need delete
            if ((curTime - crtTime) >= KZP_DATA_MAX_SAVE_DAYS_SECS) {
                return YES;
            }
        }
    }
    return NO;
}

#pragma mark -- Controller backtrace
- (void)enableControllerBacktrace {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class pageClass = UIViewController.class;
        Class proxyClass = KZPerformanceDataCenter.class;
        
        SEL pageSelector = @selector(viewDidAppear:);
        SEL proxySelector = @selector(kzp_bactrace_viewDidAppear:);
        kzp_swizzleInstanceMethod(pageClass, proxyClass, pageSelector, proxySelector);
    });
}

- (void)kzp_bactrace_viewDidAppear:(BOOL)animated {
    [self kzp_bactrace_viewDidAppear:animated];
    
    NSString *className = NSStringFromClass(self.class);
    KZPerformanceDataCenter *dataCenter = [KZPerformanceDataCenter shareDataCenter];
    dispatch_async(dataCenter.ioHandleQueue, ^{
        if (className) {
            [dataCenter.pagesBacktrace addObject:className];
            if (dataCenter.pagesBacktrace.count > 12) {
                [dataCenter.pagesBacktrace removeObjectAtIndex:0];
            }
        }
    });
}

#pragma mark -- Save Dir Path
//sub dir path by type
NSString *kzp_monitorDirPathWithType(KZPDataType type) {
    NSString *subDirName = performanceDataTypeName(type);
    if (!subDirName) return nil;
    
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) firstObject];
    NSString *subDirPath = [NSString stringWithFormat:@"%@/KZPerformanceWolf/%@",documentPath,subDirName];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:subDirPath]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:subDirPath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return subDirPath;
}

//sub dir name
static NSString *performanceDataTypeName(KZPDataType type) {
    NSString *typeName = nil;
    switch (type) {
        case KZPDataTypeCrash:
            typeName = @"Crash";
            break;
        case KZPDataTypeFreezing:
            typeName = @"Freeze";
            break;
        case KZPDataTypeAPINet:
            typeName = @"Network";
            break;
        case KZPDataTypeMemory:
            typeName = @"Memory";
            break;
        case KZPDataTypeNone:
        default:
            break;
    }
    return typeName;
}

#pragma mark -- Reports module
- (NSString *)generateReportWithDataType:(KZPDataType)type
                            performEntry:(NSDictionary *)performEntry {
    
    NSMutableString *report = [[NSMutableString alloc] init];
    [report appendString:generateReportHeader(performEntry)];
    NSDictionary *exceptionDic = performEntry[KZP_EXCEPTION_INFO];
    switch (type) {
        case KZPDataTypeCrash:
            [report appendString:formatCrashInfoEntryToReport(exceptionDic)];
            break;
        case KZPDataTypeFreezing:
            [report appendString:formatFreezeInfoEntryToReport(exceptionDic)];
            break;
        case KZPDataTypeAPINet:
            [report appendString:formatAPINetInfoEntryToReport(exceptionDic)];
            break;
        case KZPDataTypeMemory:
        case KZPDataTypeNone:
            break;
    }
    NSDictionary *userDic = performEntry[KZP_USER_ENV];
    if (userDic) {
        [report appendFormat:@"User Info:\n%@\n", userDic];
    }
    return report;
}

static NSString *generateReportHeader(NSDictionary *performEntry) {

    NSMutableString *reportHeader = @"KanZhun Performance Report\n".mutableCopy;
    
    [reportHeader appendFormat:@"Exception Type: %@\n",performEntry[KZP_EXCEPTION_TYPE]];
    
    NSDictionary *systemData = performEntry[KZP_SYSTEM_ENV];
    if (systemData) {
        [reportHeader appendFormat:@"App Bundle Name : %@\n" , systemData[KZP_SYSTEM_APPBUNDLE_NAME]];

        [reportHeader appendFormat:@"Occur Date : %@\n" , systemData[KZP_SYSTEM_DATE]];
        
        [reportHeader appendFormat:@"App Version : %@ ( %@ )\n" , systemData[KZP_SYSTEM_APP_VERSION], systemData[KZP_SYSTEM_APP_BUILD]];
        
        [reportHeader appendFormat:@"System Name : %@\n" , systemData[KZP_SYSTEM_NAME]];
        
        [reportHeader appendFormat:@"System Version : %@\n" , systemData[KZP_SYSTEM_VERSION]];

        [reportHeader appendFormat:@"OS Version : %@\n" , systemData[KZP_SYSTEM_OS_VERSION]];
        
        [reportHeader appendFormat:@"Machine Name : %@\n" , systemData[KZP_SYSTEM_MACHINE_CODE]];
        
        [reportHeader appendFormat:@"Controller Backtrace : %@\n" , systemData[KZP_SYSTEM_PAGE_BACKTRACE]];
    }
    return reportHeader;
}

//Crash report
static NSString *formatCrashInfoEntryToReport(NSDictionary *infoEntry) {
    if (!infoEntry || ![infoEntry isKindOfClass:NSDictionary.class]) {
        return @"Crash info dictionary invalid!";
    }
    
    NSString *crashType = infoEntry[KZP_CRASH_TYPE];
    if (!crashType) return @"Crash info dictionary invalid with type!";
    
    NSMutableString *crashInfoString = [[NSMutableString alloc] init];
    //crash type
    [crashInfoString appendFormat:@"Crash Type: %@\n",crashType];
    
    //reason
    [crashInfoString appendFormat:@"Crash Reason: %@\n",infoEntry[KZP_CRASH_REASON]];
    
    //desc
    NSString *desc = infoEntry[KZP_CRASH_DESC];
    if (desc) {
        [crashInfoString appendFormat:@"Crash Desc: %@\n",desc];
    }
    
    //fault addr
    uintptr_t faultAddr = [infoEntry[KZP_CRASH_FAULT_ADDR] unsignedLongValue];
    [crashInfoString appendFormat:@"Crash Fault Address: "POINTER_HEX_FMT"\n\n",faultAddr];
    
    //backtrace
    [crashInfoString appendFormat:@"Last Exception Backtrace:\n%@\n\n",kzp_formatSymbolBacktraceEntriesToString(infoEntry[KZP_CRASH_LAST_BACKTRACE])];
    
    //all thread
    NSArray *threadEntries = infoEntry[KZP_CRASH_THREADS];
    if (threadEntries && threadEntries.count > 0) {
        [crashInfoString appendFormat:@"There are %lu threads of stack information:\n", (unsigned long)threadEntries.count];
        [crashInfoString appendFormat:@"%@\n",kzp_formatThreadBacktraceEntriesToString(threadEntries)];
    }
    return crashInfoString;
}

//Freeze report
static NSString *formatFreezeInfoEntryToReport(NSDictionary *infoEntry) {
    if (!infoEntry || ![infoEntry isKindOfClass:NSDictionary.class]) {
        return @"Freeze info dictionary invalid!";
    }
    NSString *freezeType = infoEntry[KZP_FREEZE_TYPE];
    if (!freezeType) return @"Freeze info dictionary invalid with type!";
    
    NSMutableString *freezeInfoString = [[NSMutableString alloc] init];
    
    //freeze type
    [freezeInfoString appendFormat:@"Freeze Type: %@\n",freezeType];
    
    //freeze interval
    double interval = [infoEntry[KZP_FREEZE_INTERVAL] doubleValue];
    [freezeInfoString appendFormat:@"Freeze Interval: %f\n", interval];
    
    //freeze stack info
    long backtraceCount = [infoEntry[KZP_FREEZE_BACKTRACE_COUNT] longValue];
    long backtraceTotal = [infoEntry[KZP_FREEZE_BACKTRACE_TOTAL] longValue];
    [freezeInfoString appendFormat:@"Freeze stack occur: %ld\n", backtraceCount];
    [freezeInfoString appendFormat:@"Log stack total: %ld\n\n", backtraceTotal];

    //freeze call backtraces
    NSArray *stacks = infoEntry[KZP_FREEZE_MAIN_BACKTRACE];
    if (stacks && stacks.count > 0) {
        for (int i = 0; i < stacks.count; i++) {
            NSArray *backtraces = stacks[i];
            NSString *perStack = kzp_formatSymbolBacktraceEntriesToString(backtraces);
            [freezeInfoString appendFormat:@"Stack backtrace %d:\n%@\n\n", i, perStack];
        }
    }
    
    return freezeInfoString;
}

//APINet report
static NSString *formatAPINetInfoEntryToReport(NSDictionary *infoEntry) {
    if (!infoEntry || ![infoEntry isKindOfClass:NSDictionary.class]) {
        return @"APINet info dictionary invalid!";
    }
    NSMutableString *netInfoString = [[NSMutableString alloc] init];
    [netInfoString appendFormat:@"%@", infoEntry];
    return netInfoString;
}

@end
