//
//  KZPSymbolicAssistor.c
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/25/19.
//

#include "KZPSymbolicAssistor.h"
#import "KZPDynamicLinkAssistor.h"
#include <mach-o/nlist.h>
#include <string.h>
#include <limits.h>

#if defined(__LP64__)
#define KZP_NLIST struct nlist_64
#else
#define KZP_NLIST struct nlist
#endif


/** Remove any pointer tagging from an instruction address
 * On armv7 the least significant bit of the pointer distinguishes
 * between thumb mode (2-byte instructions) and normal mode (4-byte instructions).
 * On arm64 all instructions are 4-bytes wide so the two least significant
 * bytes should always be 0.
 * On x86_64 and i386, instructions are variable length so all bits are
 * signficant.
 */
#if defined(__arm64__)
#define DETAG_INSTRUCTION_ADDRESS(A) ((A) & ~(3UL))
#elif defined(__arm__)
#define DETAG_INSTRUCTION_ADDRESS(A) ((A) & ~(1UL))
#elif defined(__x86_64__)
#define DETAG_INSTRUCTION_ADDRESS(A) (A)
#elif defined(__i386__)
#define DETAG_INSTRUCTION_ADDRESS(A) (A)

#endif

/** Step backwards by one instruction.
 * The backtrace of an objective-C program is expected to contain return
 * addresses not call instructions, as that is what can easily be read from
 * the stack. This is not a problem except for a few cases where the return
 * address is inside a different symbol than the call address.
 */
#define CALL_INSTRUCTION_FROM_RETURN_ADDRESS(A) (DETAG_INSTRUCTION_ADDRESS((A)) - 1)



//Get image index for virtual memory address.
static uint32_t imageIndexContainVMAddress(const uintptr_t address) {
    const uint32_t imageCount = _dyld_image_count();
    const struct mach_header* header = 0;
    
    for(uint32_t imgIndex = 0; imgIndex < imageCount; imgIndex++) {
        header = _dyld_get_image_header(imgIndex);
        if(header != NULL) {
            //Original address without add slide.
            uintptr_t originalAddr = address - (uintptr_t)_dyld_get_image_vmaddr_slide(imgIndex);
            uintptr_t cmdPtr = kzp_firstLoadCommandAddressForHeader(header);
            if(cmdPtr == 0) continue;
            
            for(uint32_t iCmd = 0; iCmd < header->ncmds; iCmd++) {
                const struct load_command* loadCmd = (struct load_command*)cmdPtr;
                if(loadCmd->cmd == LC_SEGMENT) {
                    const struct segment_command* segCmd = (struct segment_command*)cmdPtr;
                    if(originalAddr >= segCmd->vmaddr &&
                       originalAddr < segCmd->vmaddr + segCmd->vmsize) {
                        return imgIndex;
                    }
                    
                }else if(loadCmd->cmd == LC_SEGMENT_64) {
                    const struct segment_command_64* segCmd = (struct segment_command_64*)cmdPtr;
                    if(originalAddr >= segCmd->vmaddr &&
                       originalAddr < segCmd->vmaddr + segCmd->vmsize) {
                        return imgIndex;
                    }
                }
                cmdPtr += loadCmd->cmdsize;
            }
        }
    }
    return UINT_MAX;
}

//Get hardware data segment base address for image index.
static uintptr_t originSegmentBaseAddrForImageIndex(const uint32_t idx) {
    const struct mach_header* header = _dyld_get_image_header(idx);
    
    uintptr_t cmdPtr = kzp_firstLoadCommandAddressForHeader(header);
    if(cmdPtr == 0) return 0;
    /**
     Image file may not be all mapped to the memory,
     he is from the image file `fileoff` in start mapping,
     the size of the map is `filesize`,
     and mapped to the virtual memory addresses from `vmaddr` began without slide,
     the size of the virtual memory is `vmsize`.
     `vmsize` may be greater than or equal to `filesize` and
     the rest of the memory of the segment is allocated zero fill on demand.
     */
    for(uint32_t i = 0;i < header->ncmds; i++) {
        const struct load_command* loadCmd = (struct load_command*)cmdPtr;
        if(loadCmd->cmd == LC_SEGMENT) {
            const struct segment_command* segmentCmd = (struct segment_command*)cmdPtr;
            if(strcmp(segmentCmd->segname, SEG_LINKEDIT) == 0) {
                return segmentCmd->vmaddr - segmentCmd->fileoff;
            }
        }
        else if(loadCmd->cmd == LC_SEGMENT_64) {
            const struct segment_command_64* segmentCmd = (struct segment_command_64*)cmdPtr;
            if(strcmp(segmentCmd->segname, SEG_LINKEDIT) == 0) {
                return (uintptr_t)(segmentCmd->vmaddr - segmentCmd->fileoff);
            }
        }
        cmdPtr += loadCmd->cmdsize;
    }
    return 0;
}

bool kzp_asyncSafe_dladdr(const uintptr_t address, Dl_info *symbolInfo) {
    
    symbolInfo->dli_fname = NULL;
    symbolInfo->dli_fbase = NULL;
    symbolInfo->dli_sname = NULL;
    symbolInfo->dli_saddr = NULL;
    
    //According to kscrash we should clean the address.
    uintptr_t returnAddress = CALL_INSTRUCTION_FROM_RETURN_ADDRESS(address);
    
    const uint32_t idx = imageIndexContainVMAddress(returnAddress);
    if(idx == UINT_MAX) return false;
    
    const struct mach_header* header = _dyld_get_image_header(idx);
    /*
     _dyld_get_image_vmaddr_slide, two reasons:
     (1)When loading the image, it must be loaded into the place where the virtual memory is unoccupied, so the address of the image will be offset from the virtual address.
     (2)ASLR (Address space layout randomization) for application security.
     */
    const uintptr_t imageVMAddrSlide = (uintptr_t)_dyld_get_image_vmaddr_slide(idx);
    const uintptr_t addressWithoutSlide = returnAddress - imageVMAddrSlide;
    const uintptr_t segmentBase = originSegmentBaseAddrForImageIndex(idx);
    if(segmentBase == 0) return false;
    const uintptr_t segmentBaseWithSlide = segmentBase + imageVMAddrSlide;
    
    symbolInfo->dli_fname = _dyld_get_image_name(idx);
    symbolInfo->dli_fbase = (void*)header;
    
    //Get symbol is closest to the address from SYMTAB load command.
    const KZP_NLIST *nearestEntry = NULL;
    uintptr_t shortestDistance = ULONG_MAX;
    uintptr_t cmdPtr = kzp_firstLoadCommandAddressForHeader(header);
    if(cmdPtr == 0) return false;
    
    for(uint32_t iCmd = 0; iCmd < header->ncmds; iCmd++) {
        const struct load_command* loadCmd = (struct load_command*)cmdPtr;
        if(loadCmd->cmd == LC_SYMTAB) {
            const struct symtab_command* symtabCmd = (struct symtab_command*)cmdPtr;
            //`symbolTable` is symbol table address with slide.
            const KZP_NLIST* symbolTable = (KZP_NLIST*)(segmentBaseWithSlide + symtabCmd->symoff);
            const uintptr_t stringTable = segmentBaseWithSlide + symtabCmd->stroff;
            
            for(uint32_t iSym = 0; iSym < symtabCmd->nsyms; iSym++) {
                //If n_value is 0, the symbol refers to an external object.
                if(symbolTable[iSym].n_value != 0) {
                    //`symbolAddress` is specific symbol address without add slide.
                    uintptr_t symbolAddress = symbolTable[iSym].n_value;
                    uintptr_t currentDistance = addressWithoutSlide - symbolAddress;
                    if((addressWithoutSlide >= symbolAddress) &&
                       (currentDistance <= shortestDistance))
                    {
                        nearestEntry = symbolTable + iSym;
                        shortestDistance = currentDistance;
                    }
                }
            }
            if(nearestEntry != NULL) {
                symbolInfo->dli_saddr = (void*)(nearestEntry->n_value + imageVMAddrSlide);
                if(nearestEntry->n_desc == 16) {
                    /**
                     The `n_desc` is REFERENCED_DYNAMICALLY which binary is 16,
                     indicate image has been stripped, name is meaningless,
                     and will get "_mh_execute_header" string from `stringTable`.
                     */
                    symbolInfo->dli_sname = NULL;
                    
                }else{
                    symbolInfo->dli_sname = (char*)((intptr_t)stringTable + (intptr_t)nearestEntry->n_un.n_strx);
                    if(*symbolInfo->dli_sname == '_') {
                        symbolInfo->dli_sname++;
                    }
                }
                break;
            }
        }
        cmdPtr += loadCmd->cmdsize;
    }
    return true;
}

