//
//  KZPDynamicLinkAssistor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/26/19.
//

#ifndef KZPDynamicLinkAssistor_h
#define KZPDynamicLinkAssistor_h

#include <stdio.h>
#include <mach-o/dyld.h>
#import <mach/mach.h>

typedef struct {
    uint64_t address;
    uint64_t vmAddress;
    uint64_t size;
    const char* name;
    const uint8_t* uuid;
    int cpuType;
    int cpuSubType;
    uint64_t majorVersion;
    uint64_t minorVersion;
    uint64_t revisionVersion;
} KZPBinaryImage;

typedef struct {
    uintptr_t backtraceBuffer[66];
    int useBufferLength;
} KZPBacktraceBuffer;

/**
 The `mach_thread_self()` reference counting semantics differ from `mach_task_self()`,
 `mach_thread_self()` which acquires a new reference to the backing thread.
 */
uintptr_t kzp_mach_thread_self(void);

/**
 Get backtrace addresses for mcontext_t struct.
 */
bool kzp_mContextBacktrace(mcontext_t mContext,
                           KZPBacktraceBuffer *buffer);

/**
 Get backtrace addresses for thread_t object.
 */
bool kzp_backtraceForMachThread(thread_t machThread,
                                KZPBacktraceBuffer *buffer);

/**
 Get fault address.
 */
uintptr_t kzp_faultAddressForThread(thread_t machThread);


/**
 Get the address of the first load_command struct following a header,
 and the address without add slide.
*/
uintptr_t kzp_firstLoadCommandAddressForHeader(const struct mach_header* const header);

/**
 Get the KZPBinaryImage struct for image index.
 */
bool kzp_getBinaryImageStruct(int index, KZPBinaryImage* buffer);

/**
 Get the mach thread name.
 */
bool kzp_getThreadNameForMachThread(thread_t thread,
                                    char* const nameBuffer);

#pragma mark -- Thread suspend
extern
void kzp_suspendEnvironment(void);

extern
void kzp_resumeEnvironment(void);

extern
void kzp_addThreadWithoutSuspend(thread_t thread);

#endif /* KZPDynamicLinkAssistor_h */
