//
//  KZPMachOContentAssistor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/28/19.
//

#import <Foundation/Foundation.h>
#import "KZPDynamicLinkAssistor.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPMachOContentAssistor : NSObject

#ifdef __cplusplus
extern "C" {
#endif
    
#pragma mark -- Thread module

thread_t kzp_getMainThread(void);

/**
 Get main thread backtrace entry.
 */
extern
NSDictionary *kzp_mainThreadBacktraceEntry(void);

/**
 Get main thread backtrace buffer.
 */
BOOL kzp_mainThreadBacktraceBuffer(KZPBacktraceBuffer *buffer);

/**
 Get current thread backtrace entry.
 */
extern
NSDictionary *kzp_currentThreadBacktraceEntry(void);

/**
 Get all threads entries.
 */
extern
NSArray *kzp_allThreadBacktraceEntries(thread_t markThread);

/**
 Format all threads backtrace entries string.
 */
extern
NSString *kzp_formatThreadBacktraceEntriesToString(NSArray *entries);

#pragma mark -- Backtrace module
/**
 Get symbolicate entries.
 */
extern
NSArray *kzp_symbolBacktracesToEntries(const uintptr_t* const backtraceBuffer,
                                       const int backtraceLength);

/**
 Get symbolicate entries and address slide.
 @param addrSlide   The address slide which for classify exceptions.
 */
extern
NSArray *kzp_symbolBacktracesToEntriesWithAddrSlide(const uintptr_t* const backtraceBuffer,
                                                    const int backtraceLength,
                                                    long * _Nullable addrSlide,
                                                    NSString * _Nullable * _Nullable slideImageName,
                                                    BOOL getSlideIsMainTreadCrash);

/**
 Format backtrace entires to string.
 */
extern
NSString *kzp_formatSymbolBacktraceEntriesToString(NSArray *entries);

#pragma mark -- Binary images module
/**
 Get symbolicate entries.
 */
extern
NSArray *kzp_getBinaryImageEntries(void);

/**
 Get symbolicate format string.
 */
extern
NSString * kzp_formatBinaryImageEntriesToString(NSArray *entries);

/**
 Get this application's UUID.
 @return The UUID.
*/
extern
NSString* kzp_getApplicationUUID(void);

/**
 Convert raw UUID bytes to a readable string.
 @param uuidBytes The UUID bytes (must be 16 bytes long).
 @return The readable form of the UUID.
 */
extern
NSString* kzp_uuidBytesToString(const uint8_t* uuidBytes);

/**
 Get cpu arch name from cpu type and sub type.
 */
extern
NSString* kzp_archFromCpuType(cpu_type_t cpuType, cpu_subtype_t cpuSubType);

#ifdef __cplusplus
}  // extern "C"
#endif

@end

NS_ASSUME_NONNULL_END
