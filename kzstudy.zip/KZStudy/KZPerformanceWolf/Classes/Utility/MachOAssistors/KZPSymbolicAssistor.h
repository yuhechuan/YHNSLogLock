//
//  KZPSymbolicAssistor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/25/19.
//

#ifndef KZPSymbolicAssistor_h
#define KZPSymbolicAssistor_h

#include <stdio.h>
#include <dlfcn.h>

/**
 Asyc safe dladdr without locks.
 Use `n_desc` to ensure thread safety when ohter thread that
 add or remove an image during the iteration.
 */
bool kzp_asyncSafe_dladdr(const uintptr_t address, Dl_info *symbolInfo);

#endif /* KZPSymbolicAssistor_h */
