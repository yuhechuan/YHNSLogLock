//
//  KZPMachOContentAssistor.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/28/19.
//

#import "KZPMachOContentAssistor.h"
#import <mach/mach.h>
#include "KZPSymbolicAssistor.h"
#import "KZPGeneralMacros.h"
#import "KZPSystemEnvInfoAssistor.h"

#define kAppleRedactedText  @"<redacted>"


@implementation KZPMachOContentAssistor

#pragma mark -- Thread module

thread_t kzp_getMainThread(void) {
    static thread_t mach_main_thread = THREAD_NULL;
    if (mach_main_thread == THREAD_NULL) {
        const task_t currentTask = mach_task_self();
        thread_act_array_t list;
        mach_msg_type_number_t count = 0;
        kern_return_t kr = task_threads(currentTask, &list, &count);
        if(kr != KERN_SUCCESS) {
            return THREAD_NULL;
        }
        mach_main_thread = list[0];
        //Clean up the thread array.
        for(mach_msg_type_number_t i = 0; i < count; i++) {
            mach_port_deallocate(currentTask, list[i]);
        }
        vm_deallocate(currentTask, (vm_address_t)list, sizeof(thread_t) * count);
    }
    return mach_main_thread;
}

NSDictionary *kzp_mainThreadBacktraceEntry(void) {
    return infoEntryWithThread(kzp_getMainThread(), 0, THREAD_NULL);
}

BOOL kzp_mainThreadBacktraceBuffer(KZPBacktraceBuffer *buffer) {
    return kzp_backtraceForMachThread(kzp_getMainThread(), buffer);
}

NSDictionary *kzp_currentThreadBacktraceEntry(void) {
    return infoEntryWithThread((thread_t)kzp_mach_thread_self(), -1, THREAD_NULL);
}

static NSDictionary *infoEntryWithThread(thread_t thread, int index , thread_t markThread) {
    if (thread == THREAD_NULL) return @{};
    
    NSMutableDictionary *threadDic = [[NSMutableDictionary alloc] init];
    //num
    threadDic[KZP_T_NUM] = @(index);
    
    //name
    char name[100];
    bool nameResult = kzp_getThreadNameForMachThread(thread, name);
    if (nameResult) {
        threadDic[KZP_T_NAME] = [NSString stringWithUTF8String:name];
    }
    
    //backtrace
    KZPBacktraceBuffer buffer = {0};
    bool bufferResult = kzp_backtraceForMachThread(thread, &buffer);
    if (bufferResult) {
        threadDic[KZP_T_BACKTRACE] = kzp_symbolBacktracesToEntries(buffer.backtraceBuffer, buffer.useBufferLength);
    }
    
    //is marked thread
    if (markThread != THREAD_NULL && markThread == thread) {
        threadDic[KZP_T_MARKED] = @(YES);
    }
    return threadDic;
}

NSArray *kzp_allThreadBacktraceEntries(thread_t markThread) {
    NSMutableArray *threadEntries = [[NSMutableArray alloc] init];
    const task_t currentTask = mach_task_self();
    thread_act_array_t list;
    mach_msg_type_number_t count = 0;
    
    kern_return_t kr = task_threads(currentTask, &list, &count);
    if(kr != KERN_SUCCESS) {
        return threadEntries;
    }
    
    for(int i = 0; i < count; i++) {
        thread_t thread = list[i];
        [threadEntries addObject:infoEntryWithThread(thread, i, markThread)];
    }
    
    //Clean up the thread array.
    for(mach_msg_type_number_t i = 0; i < count; i++) {
        mach_port_deallocate(currentTask, list[i]);
    }
    vm_deallocate(currentTask, (vm_address_t)list, sizeof(thread_t) * count);
    
    return threadEntries.copy;
}

NSString *kzp_formatThreadBacktraceEntriesToString(NSArray *entries) {
    NSMutableString *resultString = [[NSMutableString alloc] init];
    for(int i = 0; i < entries.count; i++) {
        NSDictionary *entry = entries[i];
        //title
        int num = [entry[KZP_T_NUM] intValue];
        if (num < 0) {
            [resultString appendString:@"Thread "];
            
        }else{
            [resultString appendFormat:@"Thread %d ",num];
        }
        NSString *name = entry[KZP_T_NAME];
        if (name) {
            [resultString appendFormat:@"name: %@\n", name];
        }else{
            [resultString appendString:@":\n"];
        }
        //marked
        BOOL marked = [entry[KZP_T_MARKED] boolValue];
        if (marked) {
            [resultString appendString:@"Thread marked:\n"];
        }
        //backtrace infos
        [resultString appendString:kzp_formatSymbolBacktraceEntriesToString(entry[KZP_T_BACKTRACE])];
    }
    return [resultString copy];
}

#pragma mark -- Backtrace module

NSArray *kzp_symbolBacktracesToEntries(const uintptr_t* const backtraceBuffer,
                                       const int backtraceLength)
{
    return kzp_symbolBacktracesToEntriesWithAddrSlide(backtraceBuffer, backtraceLength, NULL, NULL, NO);
}

NSArray *kzp_symbolBacktracesToEntriesWithAddrSlide(const uintptr_t* const backtraceBuffer,
                                                    const int backtraceLength,
                                                    long *addrSlide,
                                                    NSString ** slideImageName,
                                                    BOOL getSlideIsMainTreadCrash)
{
    NSString *appBundleName = nil;
    BOOL shouldCalculateMark = addrSlide || slideImageName;
    if (shouldCalculateMark) {
        NSDictionary *sysDic = kzp_systemInfo();
        appBundleName = sysDic[KZP_SYSTEM_APPBUNDLE_NAME];
    }
    //first line slide
    long firstSlideNum = 0;
    NSString *firstSlideImg = nil;
    //app slide
    long appSlideNum = 0;
    NSString *appSlideImg = nil;
    NSInteger appIndex = 0;
    
    NSMutableArray *dlinfoArray = [[NSMutableArray alloc] init];
    for(int i = 0; i < backtraceLength; i++) {
        Dl_info dlinfo = {0};
        uintptr_t instructAddr = backtraceBuffer[i];
        bool dlResult = kzp_asyncSafe_dladdr(instructAddr, &dlinfo);
        if (!dlResult || !dlinfo.dli_fbase) continue;
        //SI_info entry
        NSMutableDictionary *dlinfoEntry = [[NSMutableDictionary alloc] init];
        //instruct address with slide
        dlinfoEntry[KZP_SI_INSTRUCT_ADDRESS] = @((uintptr_t)instructAddr);
        //image address with slide
        dlinfoEntry[KZP_SI_IMAGE_ADDRESS] = @((uintptr_t)dlinfo.dli_fbase);
        //image name
        NSString *imgName = fileNameForImagePath(dlinfo.dli_fname);
        if (imgName) {
            dlinfoEntry[KZP_SI_IMAGE_NAME] = imgName;
        }else{
            dlinfoEntry[KZP_SI_IMAGE_NAME] = @"Unknonw";
        }
        //symbol address with add slide
        dlinfoEntry[KZP_SI_SYMBOL_ADDRESS] = @((uintptr_t)dlinfo.dli_saddr);
        //symbol name
        if (dlinfo.dli_sname) {
            NSString *symName = [NSString stringWithUTF8String:dlinfo.dli_sname];
            if (symName && ![kAppleRedactedText isEqualToString:symName]) {
                dlinfoEntry[KZP_SI_SYMBOL_NAME] = symName;
            }
        }
        if (shouldCalculateMark) {
            //first line
            if (i == 0) {
                firstSlideNum = (uintptr_t)instructAddr - (uintptr_t)dlinfo.dli_fbase;
                firstSlideImg = imgName;
            }
            BOOL shouldUseAppSlide = !appSlideImg && appBundleName && imgName && [imgName containsString:appBundleName];
            if (shouldUseAppSlide) {
                appSlideNum = (uintptr_t)instructAddr - (uintptr_t)dlinfo.dli_fbase;
                appSlideImg = imgName;
                appIndex = dlinfoArray.count;
            }
        }
        [dlinfoArray addObject:dlinfoEntry];
    }
    if (shouldCalculateMark) {
        //set app slide when name is app bundle name and first occured and cransh on main thread without at penult index.
        BOOL isAppMainFunc = getSlideIsMainTreadCrash && dlinfoArray.count == appIndex + 2;
        if (appSlideImg && !isAppMainFunc) {
            if (addrSlide) *addrSlide = appSlideNum;
            if (slideImageName) *slideImageName = appSlideImg;
            
        }else{
            if (addrSlide) *addrSlide = firstSlideNum;
            if (slideImageName) *slideImageName = firstSlideImg;
        }
           
    }
    return dlinfoArray;
}


NSString *kzp_formatSymbolBacktraceEntriesToString(NSArray *entries) {
    NSMutableString *backtraceFormat = [[NSMutableString alloc] init];
    
    for (int i = 0; i < entries.count; i++) {
        NSDictionary *dlinfoEntry = entries[i];
        uintptr_t imageAddr = [dlinfoEntry[KZP_SI_IMAGE_ADDRESS] unsignedLongValue];
        if (!imageAddr) continue;
        NSString *imageName = dlinfoEntry[KZP_SI_IMAGE_NAME];
        if(!imageName) {
            imageName = STR_FMT_HEX_ADDRESS(imageAddr);
        }
        
        NSString *symbolName = dlinfoEntry[KZP_SI_SYMBOL_NAME];
        if (!symbolName) {
            uintptr_t instructAddr = [dlinfoEntry[KZP_SI_INSTRUCT_ADDRESS] unsignedLongValue];
            symbolName = STR_FMT_HEX_ADDRESS(instructAddr);
        }
        NSString *formatInfo = [NSString stringWithFormat:@"%2d   %-20s   %@\n" ,i, imageName.UTF8String, symbolName];
        [backtraceFormat appendString:formatInfo];
    }
    [backtraceFormat appendFormat:@"\n"];
    
    return backtraceFormat.copy;
}

#pragma mark -- Binary images module

NSString * kzp_formatBinaryImageEntriesToString(NSArray *entries) {
    NSMutableString *binaryImagesDesc = [[NSMutableString alloc] init];

    for (int index = 0; index < entries.count; index++) {
        NSDictionary *infoEntry = entries[index];
        NSString *path = infoEntry[KZP_LI_NAME];
        NSString *name = [path lastPathComponent];
        NSString *uuid = infoEntry[KZP_LI_UUID];
        uint64_t address = [infoEntry[KZP_LI_ADDRESS] longLongValue];
        uint64_t size = [infoEntry[KZP_LI_SIEZE] longLongValue];
        NSString *cpuArch = infoEntry[KZP_LI_ARCH];
        [binaryImagesDesc appendFormat:@POINTER_SHORT_HEX_FMT " - " POINTER_SHORT_HEX_FMT " %@ %@  <%@> %@\n",
         (uintptr_t)address,
         (uintptr_t)(address + size) - 1,
         name,
         cpuArch,
         uuid,
         path];
    }
    return binaryImagesDesc.copy;
}


NSArray *kzp_getBinaryImageEntries() {
    NSMutableArray *imageEntries = [[NSMutableArray alloc] init];
    int imagesCount = _dyld_image_count();
    for (int index = 0; index < imagesCount; index++) {
        KZPBinaryImage image = {0};
        kzp_getBinaryImageStruct(index, &image);
        if (image.name) {
            NSMutableDictionary *imageEntry = [[NSMutableDictionary alloc] init];
            NSString *path = [NSString stringWithUTF8String:image.name];
            imageEntry[KZP_LI_NAME] = path;
            NSString *uuid = kzp_uuidBytesToString(image.uuid);
            if (uuid) {
                imageEntry[KZP_LI_UUID] = uuid;
            }
            imageEntry[KZP_LI_ADDRESS] = @(image.address);
            imageEntry[KZP_LI_SIEZE] = @(image.size);
            imageEntry[KZP_LI_ARCH] = kzp_archFromCpuType(image.cpuType, image.cpuSubType);
            [imageEntries addObject:imageEntry];
        }
    }
    return imageEntries;
}

NSString* kzp_uuidBytesToString(const uint8_t* uuidBytes) {
    if (!uuidBytes) return nil;
    
    CFUUIDRef uuidRef = CFUUIDCreateFromUUIDBytes(NULL, *((CFUUIDBytes*)uuidBytes));
    NSString *formatUUID = (__bridge_transfer NSString*)CFUUIDCreateString(NULL, uuidRef);
    CFRelease(uuidRef);
    return formatUUID;
    
}

NSString* kzp_archFromCpuType(cpu_type_t cpuType, cpu_subtype_t cpuSubType) {
    NSString *arch = @"unknown_arch";
    
    switch (cpuType)
    {
        case CPU_TYPE_ARM:
            switch (cpuSubType)
        {
            case CPU_SUBTYPE_ARM_V6:
                arch = @"armv6";
                break;
                
            case CPU_SUBTYPE_ARM_V7:
                arch = @"armv7";
                break;
                
            case CPU_SUBTYPE_ARM_V7S:
                arch = @"armv7s";
                break;
                
            default:
                arch = @"arm-unknown";
                break;
        }
            break;
            
#ifdef CPU_TYPE_ARM64
        case CPU_TYPE_ARM64:
            switch (cpuSubType)
        {
            case CPU_SUBTYPE_ARM_ALL:
                arch = @"arm64";
                break;
                
#ifdef CPU_SUBTYPE_ARM_V8
            case CPU_SUBTYPE_ARM_V8:
                arch = @"arm64";
                break;
#endif
                
#ifdef CPU_SUBTYPE_ARM64E
            case CPU_SUBTYPE_ARM64E:
                arch = @"arm64e";
                break;
#endif
            default:
                arch = @"arm64-unknown";
                break;
        }
            break;
#endif
            
        case CPU_TYPE_X86:
            arch = @"i386";
            break;
            
        case CPU_TYPE_X86_64:
            arch = @"x86_64";
            break;
            
        case CPU_TYPE_POWERPC:
            arch = @"powerpc";
            break;
    }
    
    return arch;
}

static NSString *fileNameForImagePath(const char* const path) {
    if(path == NULL) return nil;
    
    char *lastFile = strrchr(path, '/');
    const char *fileName = lastFile == NULL ? path : lastFile + 1;
    return [NSString stringWithUTF8String:fileName];
}

NSString* kzp_getApplicationUUID(void)
{
    NSString* result = nil;
    
    NSBundle* mainBundle = [NSBundle mainBundle];
    NSDictionary* infoDict = [mainBundle infoDictionary];
    NSString* bundlePath = [mainBundle bundlePath];
    NSString* executableName = infoDict[@"CFBundleExecutable"];
    NSString* exePath = [bundlePath stringByAppendingPathComponent:executableName];
    
    if(exePath != nil)
    {
        const uint8_t* uuidBytes = getImageUUIDForImageName(exePath.UTF8String, true);
        if(uuidBytes == NULL)
        {
            // OSX app image path should use last path component.
            uuidBytes = getImageUUIDForImageName(exePath.lastPathComponent.UTF8String, false);
        }
        if(uuidBytes != NULL)
        {
            result = kzp_uuidBytesToString(uuidBytes);
        }
    }
    
    return result ?: @"Unknown";
}

static const uint8_t* getImageUUIDForImageName(const char* const imageName, bool exactMatch)
{
    if(imageName == NULL) return NULL;
    //get image index
    uint32_t iImg = UINT32_MAX;
    const uint32_t imageCount = _dyld_image_count();

    for(uint32_t index = 0; index < imageCount; index++)
    {
        const char* name = _dyld_get_image_name(index);
        if(exactMatch)
        {
            if(strcmp(name, imageName) == 0)
            {
                iImg = index;
                break;
            }
        } else {
            if(strstr(name, imageName) != NULL)
            {
                iImg = index;
                break;
            }
        }
    }
    if(iImg == UINT32_MAX) return NULL;
    
    //get uuid for image
    const struct mach_header* header = _dyld_get_image_header(iImg);
    if(header != NULL)
    {
        uintptr_t cmdPtr = kzp_firstLoadCommandAddressForHeader(header);
        if(cmdPtr != 0)
        {
            for(uint32_t iCmd = 0;iCmd < header->ncmds; iCmd++)
            {
                const struct load_command* loadCmd = (struct load_command*)cmdPtr;
                if(loadCmd->cmd == LC_UUID)
                {
                    struct uuid_command* uuidCmd = (struct uuid_command*)cmdPtr;
                    return uuidCmd->uuid;
                }
                cmdPtr += loadCmd->cmdsize;
            }
        }
    }
    return NULL;
}

@end
