//
//  KZPDynamicLinkAssistor.c
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/26/19.
//

#include "KZPDynamicLinkAssistor.h"
#include <string.h>
#include <pthread.h>

#pragma mark -- Backtrace addresses

//Macro for CPU architectrure
#if defined(__arm64__)
//__es
#define KZP_THREAD_ES_STATE_COUNT           ARM_EXCEPTION_STATE64_COUNT
#define KZP_THREAD_ES_STATE                 ARM_EXCEPTION_STATE64
#define KZP_FAULT_ADDRESS                   __far
//__ss
#define KZP_THREAD_SS_STATE_COUNT           ARM_THREAD_STATE64_COUNT
#define KZP_THREAD_SS_STATE                 ARM_THREAD_STATE64
#define KZP_FRAME_POINTER                   __fp
#define KZP_STACK_POINTER                   __sp
#define KZP_INSTRUCTION_ADDRESS             __pc
#define KZP_LINK_ADDRESS(_context)          ((_context)->__ss.__lr)

#elif defined(__arm__)
//__es
#define KZP_THREAD_ES_STATE_COUNT           ARM_EXCEPTION_STATE_COUNT
#define KZP_THREAD_ES_STATE                 ARM_EXCEPTION_STATE
#define KZP_FAULT_ADDRESS                   __far
//__ss
#define KZP_THREAD_SS_STATE_COUNT           ARM_THREAD_STATE_COUNT
#define KZP_THREAD_SS_STATE                 ARM_THREAD_STATE
#define KZP_FRAME_POINTER                   __r[7]
#define KZP_STACK_POINTER                   __sp
#define KZP_INSTRUCTION_ADDRESS             __pc
#define KZP_LINK_ADDRESS(_context)          ((_context)->__ss.__lr)

#elif defined(__x86_64__)
//__es
#define KZP_THREAD_ES_STATE_COUNT           x86_EXCEPTION_STATE64_COUNT
#define KZP_THREAD_ES_STATE                 x86_EXCEPTION_STATE64
#define KZP_FAULT_ADDRESS                   __faultvaddr
//__ss
#define KZP_THREAD_SS_STATE_COUNT           x86_THREAD_STATE64_COUNT
#define KZP_THREAD_SS_STATE                 x86_THREAD_STATE64
#define KZP_FRAME_POINTER                   __rbp
#define KZP_STACK_POINTER                   __rsp
#define KZP_INSTRUCTION_ADDRESS             __rip
#define KZP_LINK_ADDRESS(_context)          0

#elif defined(__i386__)
//__es
#define KZP_THREAD_ES_STATE_COUNT           x86_EXCEPTION_STATE32_COUNT
#define KZP_THREAD_ES_STATE                 x86_EXCEPTION_STATE32
#define KZP_FAULT_ADDRESS                   __faultvaddr
//__ss
#define KZP_THREAD_SS_STATE_COUNT           x86_THREAD_STATE32_COUNT
#define KZP_THREAD_SS_STATE                 x86_THREAD_STATE32
#define KZP_FRAME_POINTER                   __ebp
#define KZP_STACK_POINTER                   __esp
#define KZP_INSTRUCTION_ADDRESS             __eip
#define KZP_LINK_ADDRESS(_context)          0

#endif

static thread_t _g_reservedThreads[10];
static int _g_reservedThreadsMaxIndex = sizeof(_g_reservedThreads) / sizeof(_g_reservedThreads[0]) - 1;
static int _g_reservedThreadsCount = 0;

typedef struct KZStackFrameEntry{
    const struct KZStackFrameEntry *const previous;
    /**
     `instruction_address` which save instruction address that next will be executed,
     and the instruction address act as function return address.
     */
    const uintptr_t instruction_address;
} KZStackFrameEntry;


uintptr_t kzp_mach_thread_self(void) {
    // 获取当前所在的线程
    thread_t current_thread = mach_thread_self();
    //获取当前所在的进程
    mach_port_deallocate(mach_task_self(), current_thread);
    return (uintptr_t)current_thread;
}

/**
 According to `https://linux.die.net/man/3/pthread_getname_np`,
 the buffer specified by name must be at least 16 characters in length.
 */
 bool kzp_getThreadNameForMachThread(thread_t thread,
                                       char* const nameBuffer) {
    pthread_t pthread = pthread_from_mach_thread_np(thread);
    if(pthread != 0 &&
       pthread_getname_np(pthread, nameBuffer, sizeof(nameBuffer)) == 0 &&
       nameBuffer[0] != 0)
    {
        return true;
    }
    return false;
}

//Copy stack frame entry safely.
static kern_return_t frameMemoryCopy(const void *const src,
                                     void *const dst,
                                     const size_t byteCount) {
    
    vm_size_t bytesCopied = 0;
    kern_return_t result = vm_read_overwrite(mach_task_self(),
                                             (vm_address_t)src,
                                             (vm_size_t)byteCount,
                                             (vm_address_t)dst,
                                             &bytesCopied);
    if(result != KERN_SUCCESS) {
        return 0;

    }
    return (int)bytesCopied;
}

bool kzp_mContextBacktrace(mcontext_t mContext,
                           KZPBacktraceBuffer *buffer) {
    
    if (!mContext) return false;

    //next instruction address
    const uintptr_t instructionAddress = mContext->__ss.KZP_INSTRUCTION_ADDRESS;
    if(instructionAddress == 0) return false;
    int addrIndex = 0;
    buffer->backtraceBuffer[addrIndex] = instructionAddress;
    
    
    //link register
    /**
     The link register used to hold return address for a function call,
     if available, is the second address in the trace.
     */
    uintptr_t linkRegister = KZP_LINK_ADDRESS(mContext);
    if (linkRegister) {
        buffer->backtraceBuffer[++addrIndex] = linkRegister;
    }
    
    //recursive frame entry
    KZStackFrameEntry frameEntry = {0};
    const uintptr_t framePtr = mContext->__ss.KZP_FRAME_POINTER;
    if (framePtr && frameMemoryCopy((void *)framePtr, &frameEntry, sizeof(frameEntry))) {
        int maxBufferLength = sizeof(buffer->backtraceBuffer)/sizeof(buffer->backtraceBuffer[0]) - 1;
        while (addrIndex < maxBufferLength) {
            if (!frameEntry.instruction_address) break;
            buffer->backtraceBuffer[++addrIndex] = frameEntry.instruction_address;
            if (!frameEntry.previous ||
                !frameMemoryCopy(frameEntry.previous, &frameEntry, sizeof(frameEntry))) {
                break;
            }
        }
    }
    //get buffer length from addrIndex + 1
    buffer->useBufferLength = ++addrIndex;
    return true;
}

bool kzp_backtraceForMachThread(thread_t machThread,
                                KZPBacktraceBuffer *buffer) {
    if (machThread == THREAD_NULL) {
        return false;
    }
    //The mcontext_t is struct pointer to _STRUCT_MCONTEXT.
    _STRUCT_MCONTEXT contextStructVar = {0};
    mcontext_t mContext = &contextStructVar;
    mach_msg_type_number_t state_count = KZP_THREAD_SS_STATE_COUNT;
    kern_return_t kern_result = thread_get_state(machThread,
                                                 KZP_THREAD_SS_STATE,
                                                 (thread_state_t)&(mContext->__ss),
                                                 &state_count);
    if(kern_result != KERN_SUCCESS) {
        return false;
    }
    
    return kzp_mContextBacktrace(mContext, buffer);
}

uintptr_t kzp_faultAddressForThread(thread_t machThread) {
    if (machThread == THREAD_NULL) {
        return 0;
    }
    //The mcontext_t is struct pointer to _STRUCT_MCONTEXT.
    _STRUCT_MCONTEXT contextStructVar = {0};
    mcontext_t mContext = &contextStructVar;
    mach_msg_type_number_t state_count = KZP_THREAD_ES_STATE_COUNT;
    kern_return_t kern_result = thread_get_state(machThread,
                                                 KZP_THREAD_ES_STATE,
                                                 (thread_state_t)&(mContext->__es),
                                                 &state_count);
    if(kern_result != KERN_SUCCESS) {
        return 0;
    }
    
    return mContext->__es.KZP_FAULT_ADDRESS;
}

#pragma mark -- Thread suspend

static inline bool isThreadInNotSuspendList(thread_t thread, thread_t* list, int listCount)
{
    for(int i = 0; i < listCount; i++)
    {
        if(list[i] == thread)
        {
            return true;
        }
    }
    return false;
}

void kzp_suspendEnvironment()
{
    kern_return_t kr;
    const task_t thisTask = mach_task_self();
    const thread_t thisThread = (thread_t)kzp_mach_thread_self();
    thread_act_array_t threads;
    mach_msg_type_number_t numThreads;
    
    if((kr = task_threads(thisTask, &threads, &numThreads)) != KERN_SUCCESS)
    {
        printf("task_threads: %s", mach_error_string(kr));
        return;
    }
    
    for(mach_msg_type_number_t i = 0; i < numThreads; i++)
    {
        thread_t thread = threads[i];
        if(thread != thisThread && !isThreadInNotSuspendList(thread, _g_reservedThreads, _g_reservedThreadsCount))
        {
            if((kr = thread_suspend(thread)) != KERN_SUCCESS)
            {
                // Record the error and keep going.
                printf("thread_suspend (%08x): %s", thread, mach_error_string(kr));
            }
        }
    }
    
    for(mach_msg_type_number_t i = 0; i < numThreads; i++)
    {
        mach_port_deallocate(thisTask, threads[i]);
    }
    vm_deallocate(thisTask, (vm_address_t)threads, sizeof(thread_t) * numThreads);

}

void kzp_resumeEnvironment()
{
    kern_return_t kr;
    const task_t thisTask = mach_task_self();
    const thread_t thisThread = (thread_t)kzp_mach_thread_self();
    thread_act_array_t threads;
    mach_msg_type_number_t numThreads;
    
    if((kr = task_threads(thisTask, &threads, &numThreads)) != KERN_SUCCESS)
    {
        printf("task_threads: %s", mach_error_string(kr));
        return;
    }
    
    for(mach_msg_type_number_t i = 0; i < numThreads; i++)
    {
        thread_t thread = threads[i];
        if(thread != thisThread && !isThreadInNotSuspendList(thread, _g_reservedThreads, _g_reservedThreadsCount))
        {
            if((kr = thread_resume(thread)) != KERN_SUCCESS)
            {
                // Record the error and keep going.
                printf("thread_resume (%08x): %s", thread, mach_error_string(kr));
            }
        }
    }
    
    for(mach_msg_type_number_t i = 0; i < numThreads; i++)
    {
        mach_port_deallocate(thisTask, threads[i]);
    }
    vm_deallocate(thisTask, (vm_address_t)threads, sizeof(thread_t) * numThreads);
}

void kzp_addThreadWithoutSuspend(thread_t thread)
{
    int nextIndex = _g_reservedThreadsCount;
    if(nextIndex > _g_reservedThreadsMaxIndex)
    {
        return;
    }
    _g_reservedThreads[_g_reservedThreadsCount++] = thread;
}

#pragma mark -- Load command
uintptr_t kzp_firstLoadCommandAddressForHeader(const struct mach_header* const header) {
    if (header->magic == MH_MAGIC ||
        header->magic == MH_CIGAM) {
        return (uintptr_t)(header + 1);
        
    }else if (header->magic == MH_MAGIC_64 ||
              header->magic == MH_CIGAM_64) {
        return (uintptr_t)(((struct mach_header_64*)header) + 1);
        
    }else{
        return 0;//The header or image is damaged.
    }
}

#pragma mark -- Binary image structs
bool kzp_getBinaryImageStruct(int index, KZPBinaryImage* buffer) {
    //Mach header for index
    const struct mach_header* header = _dyld_get_image_header((unsigned)index);
    if(header == NULL) return false;
    
    uintptr_t cmdPtr = kzp_firstLoadCommandAddressForHeader(header);
    if(cmdPtr == 0) return false;
    
    /*TEXT segment (LC_SEGMENT/LC_SEGMENT_64) to get the image size.
     LC_UUID type get UUID.
     LC_ID_DYLIB type get dylib version.
     */
    uint64_t imageSize = 0;
    uint64_t imageVmAddr = 0;
    uint64_t version = 0;
    uint8_t* uuid = NULL;
    
    for(uint32_t iCmd = 0; iCmd < header->ncmds; iCmd++)
    {
        struct load_command* loadCmd = (struct load_command*)cmdPtr;
        switch(loadCmd->cmd)
        {
            case LC_SEGMENT:
            {
                struct segment_command* segCmd = (struct segment_command*)cmdPtr;
                if(strcmp(segCmd->segname, SEG_TEXT) == 0)
                {
                    imageSize = segCmd->vmsize;
                    imageVmAddr = segCmd->vmaddr;
                }
                break;
            }
            case LC_SEGMENT_64:
            {
                struct segment_command_64* segCmd = (struct segment_command_64*)cmdPtr;
                if(strcmp(segCmd->segname, SEG_TEXT) == 0)
                {
                    imageSize = segCmd->vmsize;
                    imageVmAddr = segCmd->vmaddr;
                }
                break;
            }
            case LC_UUID:
            {
                struct uuid_command* uuidCmd = (struct uuid_command*)cmdPtr;
                uuid = uuidCmd->uuid;
                break;
            }
            case LC_ID_DYLIB:
            {
                
                struct dylib_command* dc = (struct dylib_command*)cmdPtr;
                version = dc->dylib.current_version;
                break;
            }
        }
        cmdPtr += loadCmd->cmdsize;
    }
    
    buffer->address = (uintptr_t)header;//address with slide
    buffer->vmAddress = imageVmAddr;
    buffer->size = imageSize;
    buffer->name = _dyld_get_image_name((unsigned)index);
    buffer->uuid = uuid;
    buffer->cpuType = header->cputype;
    buffer->cpuSubType = header->cpusubtype;
    buffer->majorVersion = version >> 16;
    buffer->minorVersion = (version >> 8) & 0xff;
    buffer->revisionVersion = version & 0xff;
    
    return true;
}




