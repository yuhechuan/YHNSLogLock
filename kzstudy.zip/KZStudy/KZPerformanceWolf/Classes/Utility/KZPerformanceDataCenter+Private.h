//
//  KZPerformanceDataCenter+Private.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 5/17/19.
//

#import "KZPerformanceDataCenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPerformanceDataCenter (Private)

- (void)saveDataForType:(KZPDataType)dataType
              infoEntry:(NSDictionary *)infoEntry;


@end

NS_ASSUME_NONNULL_END
