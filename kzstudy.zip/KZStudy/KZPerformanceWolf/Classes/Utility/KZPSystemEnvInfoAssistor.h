//
//  KZPSystemEnvInfoAssistor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 5/10/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZPSystemEnvInfoAssistor : NSObject

#ifdef __cplusplus
extern "C" {
#endif

extern
BOOL kzp_isDebugging(void);

extern
NSString *kzp_machineName(void);

extern
NSDictionary *kzp_systemInfo(void);

#ifdef __cplusplus
}  // extern "C"
#endif

@end

NS_ASSUME_NONNULL_END
