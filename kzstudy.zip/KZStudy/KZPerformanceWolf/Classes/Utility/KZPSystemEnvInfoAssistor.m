//
//  KZPSystemEnvInfoAssistor.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 5/10/19.
//

#import "KZPSystemEnvInfoAssistor.h"
#include <sys/sysctl.h>
#import <sys/utsname.h>
#import "KZPGeneralMacros.h"
#import <UIKit/UIKit.h>
#import "KZPMachOContentAssistor.h"

@implementation KZPSystemEnvInfoAssistor
/**
 * 判断是否 正在处于调试状态,
 * 原因是我们监听了EXC_BREAKPOINT这类型的Exception，一旦启动 app 联调后， 会立即触发EXC_BREAKPOINT。而这段代码处理完后，会进入下一个循环等待，可主线程这是还等着消息处理结果，这就造成等待死锁。
 */
BOOL kzp_isDebugging(void) {
    struct kinfo_proc procInfo;
    size_t structSize = sizeof(procInfo);
    int mib[] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()};
    
    if(sysctl(mib, sizeof(mib)/sizeof(*mib), &procInfo, &structSize, NULL, 0) != 0) {
        return NO;
    }
    return (procInfo.kp_proc.p_flag & P_TRACED) != 0;
}

NSString *kzp_machineName(void) {
    NSString *machineName = @"Unknow_machine";
    struct utsname systemInfo;
    uname(&systemInfo);
    if (strlen(systemInfo.machine) < 1) return machineName;
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    if (platform) machineName = platform;
        
    return machineName;
}

static NSString *formatStringWithDate(NSDate *date) {
    static NSDateFormatter *formatter = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd-HH-mm-ss"];
    });
    if (!date) date = [NSDate date];
    return [formatter stringFromDate:date];
}

NSDictionary *kzp_systemInfo(void) {
    NSMutableDictionary *systemInfo = [[NSMutableDictionary alloc] init];
    
    //date
    NSDate *date = NSDate.date;
    KZPDIC_SAVE_SAFETY(systemInfo,
                       formatStringWithDate(date),
                       KZP_SYSTEM_DATE);
    NSString *time = [NSString stringWithFormat:@"%.0f", date.timeIntervalSince1970*1000];
    KZPDIC_SAVE_SAFETY(systemInfo,
                       time,
                       KZP_SYSTEM_TIMESTAMP);
    static NSMutableDictionary *fixedSystemInfo = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        fixedSystemInfo = [[NSMutableDictionary alloc] init];
        //version
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"],
                           KZP_SYSTEM_APP_VERSION);
        //build
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"],
                           KZP_SYSTEM_APP_BUILD);
        //system
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           [[UIDevice currentDevice] systemName],
                           KZP_SYSTEM_NAME);
        //system version
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           [[UIDevice currentDevice] systemVersion],
                           KZP_SYSTEM_VERSION);
        //machine code
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           kzp_machineName(),
                           KZP_SYSTEM_MACHINE_CODE);
        //os version
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           sysctlContentWithName("kern.osversion"),
                           KZP_SYSTEM_OS_VERSION);
        //executable name
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleExecutable"],
                           KZP_SYSTEM_APPBUNDLE_NAME);
        //app uuid
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           kzp_getApplicationUUID(),
                           KZP_SYSTEM_APP_UUID);
        
        //system cpu type
        int cpuType = sysctlInt32ForName("hw.cputype");
        int cpuSubType = sysctlInt32ForName("hw.cpusubtype");
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           kzp_archFromCpuType(cpuType, cpuSubType),
                           KZP_SYSTEM_CPU_ARCH);
        
        //app cpu type
        const struct mach_header* header = _dyld_get_image_header(0);
        KZPDIC_SAVE_SAFETY(fixedSystemInfo,
                           kzp_archFromCpuType(header->cputype, header->cpusubtype),
                           KZP_SYSTEM_APP_CPU_ARCH);
    });

    [systemInfo addEntriesFromDictionary:fixedSystemInfo];
    return systemInfo.copy;
}

static int32_t sysctlInt32ForName(const char* const name)
{
    int32_t value = 0;
    size_t size = sizeof(value);
    int32_t re = sysctlbyname(name, &value, &size, NULL, 0);
    if (re != 0) {
        return 0;
    }
    return value;
}

static NSString *sysctlContentWithName(const char* name)
{
    int size = (int)stringSizeForName(name, NULL, 0);
    if(size <= 0)
    {
        return nil;
    }
    
    char* value = malloc((size_t)size);
    if(stringSizeForName(name, value, size) <= 0)
    {
        free(value);
        return nil;
    }
    NSString *result = [NSString stringWithUTF8String:value];
    free(value);
    return result;
}

static int stringSizeForName(const char* const  name,
                           char* const value,
                           const int maxSize)
{
    size_t size = value == NULL ? 0 : (size_t)maxSize;
    
    if(sysctlbyname(name, value, &size, NULL, 0) != 0) {
        return 0;
    }
    return (int)size;
}

@end
