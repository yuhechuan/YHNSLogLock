//
//  KZPerformanceWolf.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import <Foundation/Foundation.h>
#import "KZPInterfaceNetworkMonitor.h"
#import "KZPFreezeMonitor.h"
#import "KZPCrashMonitor.h"
#import "KZPRebootMonitor.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(NSUInteger, KZPerformanceType) {
    KZPerformanceNone = 0,
    KZPerformanceAll = 0xFFFFFFFF,
    KZPerformanceNetwork = 1 << 0,
    KZPerformanceCrash = 1 << 1,
    KZPerformanceFreeze = 1 << 2,
};

extern
void kzp_startMonitor(KZPerformanceType options);

extern
void kzp_stopMonitor(void);

extern
BOOL kzp_monitorState(void);


NS_ASSUME_NONNULL_END
