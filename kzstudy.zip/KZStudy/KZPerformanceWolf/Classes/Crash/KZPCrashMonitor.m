//
//  KZPCrashMonitor.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/12/19.
//

#import "KZPCrashMonitor.h"
#import "KZPMachOContentAssistor.h"
#include "KZPSystemEnvInfoAssistor.h"
#import "KZPRebootMonitor.h"

static BOOL _g_isCrashMonitoring = NO;

#define KZP_CHECK_PLUGIN(_plugin, _sel)\
([plugin conformsToProtocol:@protocol(KZPCrashMonitorProtocol)] && [plugin respondsToSelector:@selector(activeCrashPlugin:)])

inline static NSArray * crashPluginsClass(void) {
    return @[KZPCrashObjcException.class,
             KZPCrashUnixSignal.class,
             KZPCrashMachException.class
             ];
}

@implementation KZPCrashMonitor

+ (instancetype)shareMonitor {
    static KZPCrashMonitor *monitor = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        monitor = [[KZPCrashMonitor alloc] init];
    });
    return monitor;
}

- (void)startMonitor {
    if (kzp_isDebugging() || _g_isCrashMonitoring) return;
    for (Class <KZPCrashMonitorProtocol>plugin in crashPluginsClass()) {
        if (KZP_CHECK_PLUGIN(plugin, @selector(activeCrashPlugin:))) {
            [plugin activeCrashPlugin:&handleCrashInformation];
        }
    }
    _g_isCrashMonitoring = YES;
}

- (void)stopMonitor {
    if (!_g_isCrashMonitoring) return;
    for (Class <KZPCrashMonitorProtocol>plugin in crashPluginsClass()) {
        if (KZP_CHECK_PLUGIN(plugin, @selector(inactivateCrashPlugin))) {
            [plugin inactivateCrashPlugin];
        }
    }
    _g_isCrashMonitoring = NO;
}

- (BOOL)isMonitoring {
    return _g_isCrashMonitoring;
}

static void handleCrashInformation(KZPCrashInformation *crashInfo) {
    
    NSMutableDictionary *crashInfoDic = [[NSMutableDictionary alloc] init];
    //crash type
    switch (crashInfo->crashType) {
        case KZPCrashTypeNSException:
            crashInfoDic[KZP_CRASH_TYPE] = KZP_CRASH_TYPE_NSEXCEPTION;
            break;
        case KZPCrashTypeSignal:
            crashInfoDic[KZP_CRASH_TYPE] = KZP_CRASH_TYPE_SIGNAL;
            break;
        case KZPCrashTypeMach:
            crashInfoDic[KZP_CRASH_TYPE] = KZP_CRASH_TYPE_MACH;
            break;
        case KZPCrashTypeNone:
        default:
            crashInfoDic[KZP_CRASH_TYPE] = @"Unknown Crash";
            break;
    }
    
    //reason
    if (crashInfo->crashReason) {
        crashInfoDic[KZP_CRASH_REASON] = [NSString stringWithUTF8String:crashInfo->crashReason];
    }
    
    //desc
    if (crashInfo->crashDescription) {
        crashInfoDic[KZP_CRASH_DESC] = [NSString stringWithUTF8String:crashInfo->crashDescription];
    }
    
    //fault addr
    crashInfoDic[KZP_CRASH_FAULT_ADDR] = @(crashInfo->faultAddress);
    
    //backtrace
    BOOL crashOnMainThread = NO;
    if (crashInfo->crashThread == kzp_getMainThread()) {
        crashOnMainThread = YES;
    }
    if (crashInfo->backtraceBuffer) {
        long addressSlide = 0;
        NSString *slideImgName = nil;
        crashInfoDic[KZP_CRASH_LAST_BACKTRACE] = kzp_symbolBacktracesToEntriesWithAddrSlide(crashInfo->backtraceBuffer->backtraceBuffer, crashInfo->backtraceBuffer->useBufferLength, &addressSlide, &slideImgName, crashOnMainThread);
        crashInfoDic[KZP_CRASH_MARK_SLIDE] = @(addressSlide);
        if (slideImgName) {
            crashInfoDic[KZP_CRASH_MARK_IMAGE] = slideImgName;
        }
    }
    
    //all thread
    crashInfoDic[KZP_CRASH_THREADS] = kzp_allThreadBacktraceEntries(crashInfo->crashThread);
    kzp_resumeEnvironment();
    
    [[KZPRebootMonitor shareMonitor] appTerminateByCrash];
    [[KZPerformanceDataCenter shareDataCenter] saveDataForType:KZPDataTypeCrash
                                                     infoEntry:crashInfoDic];

    [[KZPCrashMonitor shareMonitor] stopMonitor];

}

@end
