//
//  KZPCrashUnixSignal.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/15/19.
//

#import "KZPCrashUnixSignal.h"
#import <signal.h>

//machine context from unix signal context
#ifdef __arm64__
#define KZP_UMCONTEXT uc_mcontext64
typedef ucontext64_t kzp_ucontext_t;
#else
#define KZP_UMCONTEXT uc_mcontext
typedef ucontext_t kzp_ucontext_t;
#endif

#if defined(__LP64__)
/**
 Signal handler with SA_SIGINFO args with 64bit regs information.
 https://lists.apple.com/archives/darwin-dev/2005/Nov/msg00094.html
 */
#define KZP_SIGACTION_FLAGS  (SA_SIGINFO | SA_ONSTACK | SA_64REGSET)
#else
#define KZP_SIGACTION_FLAGS  (SA_SIGINFO | SA_ONSTACK)
#endif

struct signal_code_name {
    const int sig_code;
    const char *sig_code_name;
};

struct signal_num_name {
    const int sig_num;
    const char *sig_num_name;
    struct signal_code_name signal_codes[10];
};

static KZPCrashInformation _g_crashInfo;
static KZPCrashHandler *_g_handler = NULL;
static BOOL _g_isSignalMonitoring = NO;
//Signal will use this stack.
static stack_t _g_signalHandleStack = {0};
//save old sigactions
static struct sigaction *_g_oldSigactions = NULL;

// 8种崩溃信号
static const int _g_unixSignals[] = {
    SIGABRT, SIGBUS,  SIGFPE, SIGILL,
    SIGPIPE, SIGSEGV, SIGSYS, SIGTRAP,
};

/*
 Warning : When add `signal_code_name` to signal_codes array,
 you should check `signal_codes[10]`,default is 10.
 */
static struct signal_num_name _g_signal_num_names[] = {
    /** SIGABRT **/
    {SIGABRT, "SIGABRT",{}},

    /** SIGPIPE **/
    {SIGPIPE, "SIGPIPE",{}},
    
    /** SIGSYS **/
    {SIGSYS, "SIGSYS",{}},
    
    /** SIGSEGV **/
    {SIGSEGV, "SIGSEGV",{
#ifdef SEGV_NOOP
        {SEGV_NOOP, "SEGV_NOOP"},
#endif
        {SEGV_MAPERR, "SEGV_MAPERR"},
        {SEGV_ACCERR, "SEGV_ACCERR"},
    }
    },
    
    /** SIGBUS **/
    {SIGBUS, "SIGBUS",{
#ifdef BUS_NOOP
        {BUS_NOOP, "BUS_NOOP"},
#endif
        {BUS_ADRALN, "BUS_ADRALN"},
        {BUS_ADRERR, "BUS_ADRERR"},
        {BUS_OBJERR, "BUS_OBJERR"},
    }
    },

    /** SIGTRAP **/
    {SIGTRAP, "SIGTRAP",{
        {TRAP_BRKPT, "TRAP_BRKPT"},
        {TRAP_TRACE, "TRAP_TRACE"},
    }
    },

    /** SIGFPE **/
    {SIGFPE, "SIGFPE",{
#ifdef FPE_NOOP
        {FPE_NOOP, "FPE_NOOP"},
#endif
        {FPE_FLTDIV, "FPE_FLTDIV"},
        {FPE_FLTOVF, "FPE_FLTOVF"},
        {FPE_FLTUND, "FPE_FLTUND"},
        {FPE_FLTRES, "FPE_FLTRES"},
        {FPE_FLTINV, "FPE_FLTINV"},
        {FPE_FLTSUB, "FPE_FLTSUB"},
        {FPE_INTDIV, "FPE_INTDIV"},
        {FPE_INTOVF, "FPE_INTOVF"},
    }
    },

    /** SIGILL **/
    {SIGILL, "SIGILL",{
#ifdef ILL_NOOP
            {ILL_NOOP, "ILL_NOOP"},
#endif
            {ILL_ILLOPC, "ILL_ILLOPC"},
            {ILL_PRVOPC, "ILL_PRVOPC"},
            {ILL_ILLOPN, "ILL_ILLOPN"},
            {ILL_ILLADR, "ILL_ILLADR"},
            {ILL_PRVREG, "ILL_PRVREG"},
            {ILL_COPROC, "ILL_COPROC"},
            {ILL_ILLTRP, "ILL_ILLTRP"},
            {ILL_BADSTK, "ILL_BADSTK"},
        }
    },
};

@implementation KZPCrashUnixSignal


+ (BOOL)isActive {
    return _g_isSignalMonitoring;
}

+ (void)activeCrashPlugin:(KZPCrashHandler *)handler {
    if (_g_isSignalMonitoring) return;
    _g_handler = handler;
    ///malloc signal stack
    if (_g_signalHandleStack.ss_size == 0) {
        _g_signalHandleStack.ss_size = SIGSTKSZ;
        _g_signalHandleStack.ss_sp = malloc(_g_signalHandleStack.ss_size);
    }
    /**
     sigaltstack 函数的作用：

     ① 分配一块内存区，当然是从堆中分配，这块内存区就称为“可替换信号栈”(alternate signal stack)，顾名思义，我们就是希望将信号处理函数的栈挪到堆中，而不和进程共用一块栈区。

     ② 使用 sigaltstack() 系统调用通知内核“可替换信号栈”已经建立。

     ③ 接着建立信号处理函数，此时需要对 sigaction() 函数的 sa_flags 成员设立 SA_ONSTACK 标志，该标志告诉内核信号处理函数的栈帧就在“可替换信号栈”上建立。

     回到 sigaltstack() 函数，该函数的第 1 个参数 sigstack 是一个 stack_t 结构的指针，该结构存储了一个“可替换信号栈” 的位置及属性信息。第 2 个参数 old_sigstack 也是一个 stack_t 类型指针，它用来返回上一次建立的“可替换信号栈”的信息(如果有的话)。
     */
    ///register signal stack
    if (sigaltstack(&_g_signalHandleStack, NULL) < 0) {
        NSLog(@"Can't register signal stack!");
        return;
    }
    ///sigaction
    int signalCount = sizeof(_g_unixSignals)/sizeof(_g_unixSignals[0]);
    //initial old action buffer
    if(_g_oldSigactions == NULL) {
        _g_oldSigactions = malloc(sizeof(*_g_oldSigactions) * (unsigned)signalCount);
    }
    
    //register new actions
    struct sigaction newAction = getHandleSigaction();

    for (int i = 0; i < signalCount; i++) {
        
        struct sigaction oldAction;
        // 触发特定崩溃信号 时回调
        if(sigaction(_g_unixSignals[i], &newAction, &oldAction) != 0) {
            resetSignals();
            NSLog(@"Failed ot register signal!");
            return;
        }
        _g_oldSigactions[i] = oldAction;
    }
    _g_isSignalMonitoring = YES;
}

+ (void)recaptureSignalOwnership {
    if (!_g_isSignalMonitoring) return;

    //register new actions
    struct sigaction newAction = getHandleSigaction();
    
    int signalCount = sizeof(_g_unixSignals)/sizeof(_g_unixSignals[0]);
    for (int i = 0; i < signalCount; i++) {
        if(sigaction(_g_unixSignals[i], &newAction, NULL) != 0) {
            resetSignals();
            NSLog(@"Failed to register signal when recapture ownership!");
            return;
        }
    }
}

static struct sigaction getHandleSigaction(void) {
    struct sigaction newAction = {{0}};
    newAction.sa_flags = KZP_SIGACTION_FLAGS;
    sigemptyset(&newAction.sa_mask);
    newAction.sa_sigaction = &unixSignalHandler;
    return  newAction;
}

+ (void)inactivateCrashPlugin {
    if (!_g_isSignalMonitoring) return;
    resetSignals();
    _g_isSignalMonitoring = NO;
}

static void resetSignals(void) {
    
    int sigCount = sizeof(_g_unixSignals)/sizeof(_g_unixSignals[0]);
    for (int i = 0; i < sigCount; i++) {
        sigaction(_g_unixSignals[i], &_g_oldSigactions[i], NULL);
    }
    if (_g_oldSigactions) free(_g_oldSigactions);
    if (_g_signalHandleStack.ss_sp) free(_g_signalHandleStack.ss_sp);
    _g_signalHandleStack = (stack_t){0};
    _g_oldSigactions = NULL;
    _g_handler = NULL;
}

// 信号奔溃之后会 回调此方法
static void unixSignalHandler(int signal, siginfo_t* signalInfo, void* userContext) {

    if (_g_handler) {
        kzp_suspendEnvironment();
        KZPCrashInformation *crashInfo = &_g_crashInfo;
        
        //Crash type
        crashInfo->crashType = KZPCrashTypeSignal;

        //Crash thread
      
        crashInfo->crashThread = (thread_t)kzp_mach_thread_self();
        
        //Get signal name and signal code name.
        // 获取crash原因 和 crash描述 
        const char *sigName = "";
        const char *codeName = NULL;
        int sigCount = sizeof(_g_signal_num_names)/sizeof(_g_signal_num_names[0]);
        for (int i = 0; i < sigCount; i++) {
            struct signal_num_name sig = _g_signal_num_names[i];
            if (sig.sig_num == signalInfo->si_signo) {
                sigName = sig.sig_num_name;
                int codeCount = sizeof(sig.signal_codes)/sizeof(sig.signal_codes[0]);
                for (int j = 0; j < codeCount; j++) {
                    struct signal_code_name code = sig.signal_codes[j];
                    if (code.sig_code_name && code.sig_code == signalInfo->si_code) {
                        codeName = code.sig_code_name;
                        break;
                    }
                }
                break;
            }
        }
        crashInfo->crashReason = sigName;
        crashInfo->crashDescription = codeName;

        //Fault address
        /**
         When the signal is SIGILL or SIGFPE, si_addr contains the address of
         the faulting instruction.
         When the signal is SIGSEGV or SIGBUS, si_addr contains the address of
         the faulting memory reference.
         Although for x86 there are cases of SIGSEGV
         for which si_addr cannot be determined and is NULL.
         */
        crashInfo->faultAddress = (uintptr_t)signalInfo->si_addr;
        
        //Last exception backtrace
        KZPBacktraceBuffer backtraceBuffer = {0};
        mcontext_t mContext = ((kzp_ucontext_t*)userContext)->KZP_UMCONTEXT;
        bool bufferResult = kzp_mContextBacktrace(mContext, &backtraceBuffer);
        if (bufferResult) {
            crashInfo->backtraceBuffer = &backtraceBuffer;
        }
        
        _g_handler(crashInfo);
    }
    //use `raise` let system capture crash.
    raise(signal);

}

@end
