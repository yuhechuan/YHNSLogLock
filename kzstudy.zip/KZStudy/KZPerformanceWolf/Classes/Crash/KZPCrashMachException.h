//
//  KZPCrashMachException.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/15/19.
//

#import <Foundation/Foundation.h>
#import "KZPCrashComponents.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPCrashMachException : NSObject <KZPCrashMonitorProtocol>

@end

NS_ASSUME_NONNULL_END
