//
//  KZPCrashMonitor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/12/19.
//

#import <Foundation/Foundation.h>
#import "KZPGeneralComponents.h"
#import "KZPCrashObjcException.h"
#import "KZPCrashUnixSignal.h"
#import "KZPCrashMachException.h"

/**
 Mach 异常

 最底层的内核级异常。用户态的开发者可以直接通过Mach API设置thread，task，host的异常端口，来捕获Mach异常。

 Unix 信号

 又称BSD 信号，如果开发者没有捕获Mach异常，则会被host层的方法ux_exception()将异常转换为对应的UNIX信号，并通过方法threadsignal()将信号投递到出错线程。可以通过方法signal(x, SignalHandler)来捕获signal。

 NSException

 应用级异常，它是未被捕获的Objective-C异常，导致程序向自身发送了SIGABRT信号而崩溃，是app自己可控的，对于未捕获的Objective-C异常，是可以通过try catch来捕获的，或者通过NSSetUncaughtExceptionHandler()机制来捕获。
 
 * iOS Crash/崩溃/异常 捕获
 * https://www.jianshu.com/p/3f6775c02257
 
 */


NS_ASSUME_NONNULL_BEGIN
// 崩溃
@interface KZPCrashMonitor : NSObject <KZPerformanceMonitorProtocol>

@end

NS_ASSUME_NONNULL_END
