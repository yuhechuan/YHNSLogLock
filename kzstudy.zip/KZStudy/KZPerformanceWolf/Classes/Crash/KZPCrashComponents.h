//
//  KZPCrashComponents.h
//  Pods
//
//  Created by Yaping Liu on 4/15/19.
//

#ifndef KZPCrashComponents_h
#define KZPCrashComponents_h

#import <Foundation/Foundation.h>
#include "KZPDynamicLinkAssistor.h"

typedef NS_ENUM(NSInteger, KZPCrashType) {
    KZPCrashTypeNone,
    KZPCrashTypeNSException,
    KZPCrashTypeSignal,
    KZPCrashTypeMach,
};

typedef struct KZPCrashInformation {
    KZPCrashType crashType;
    thread_t crashThread;
    const char *crashReason;
    const char *crashDescription;
    uintptr_t faultAddress;
    KZPBacktraceBuffer *backtraceBuffer;
    
}KZPCrashInformation;

typedef void KZPCrashHandler(KZPCrashInformation *crashInfo);

@protocol KZPCrashMonitorProtocol <NSObject>

+ (BOOL)isActive;

+ (void)activeCrashPlugin:(KZPCrashHandler *)handler;

+ (void)inactivateCrashPlugin;

@end


#endif /* KZPCrashComponents_h */
