
//
//  KZPCrashMachException.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/15/19.
//

#import "KZPCrashMachException.h"
#include <mach/mach.h>
#include <pthread.h>

/**
 https://lists.apple.com/archives/carbon-dev/2005/Apr/msg00159.html
 The following values are used to EXC_SOFTWARE exception.
 */
#ifndef EXC_UNIX_BAD_SYSCALL
#define EXC_UNIX_BAD_SYSCALL    0x10000     /* SIGSYS */
#endif

#ifndef EXC_UNIX_BAD_PIPE
#define EXC_UNIX_BAD_PIPE       0x10001     /* SIGPIPE */
#endif

#ifndef EXC_UNIX_ABORT
#define EXC_UNIX_ABORT          0x10002     /* SIGABRT */
#endif


typedef struct {
    //Mach header.
    mach_msg_header_t          header;
    //Mach body.
    mach_msg_body_t            body;
    //Thread state.
    mach_msg_port_descriptor_t thread;
    //Task state.
    mach_msg_port_descriptor_t task;
    //Network data representation.
    NDR_record_t               NDR;
    //Exception type.
    exception_type_t           exception;
    //Exception code count.
    mach_msg_type_number_t     codeCount;
    //Exception code and subcode.
    integer_t code[2];
    //Padding to avoid RCV_TOO_LARGE.
    char                       padding[512];
} Mach_exception_request_message;

typedef struct {
    //Mach header.
    mach_msg_header_t header;
    //Network data representation.
    NDR_record_t      NDR;
    //Return code.
    kern_return_t     returnCode;
} Mach_exception_reply_message;

static KZPCrashInformation _g_crashInfo;
static KZPCrashHandler *_g_handler = NULL;
//monitor state
static BOOL _g_isMachMonitoring = NO;
//exception observer mach port
static mach_port_t _g_exceptionPort = MACH_PORT_NULL;
//monitor thread
static thread_t _g_moniotr_thread;

//old exception ports struct
static struct {
    exception_mask_t        masks[EXC_TYPES_COUNT];
    mach_msg_type_number_t  masksCount;
    exception_handler_t     handlers[EXC_TYPES_COUNT];
    exception_behavior_t    behaviors[EXC_TYPES_COUNT];
    thread_state_flavor_t   flavors[EXC_TYPES_COUNT];
} _g_oldExceptionPorts;


@implementation KZPCrashMachException

+ (BOOL)isActive {
    return _g_isMachMonitoring;
}
/**
 * mach 知识
 * https://www.jianshu.com/p/3f6775c02257
 */

+ (void)activeCrashPlugin:(KZPCrashHandler)handler {
    if (_g_isMachMonitoring) return;
    _g_handler = handler;
    const task_t currentTask = mach_task_self();
    
    //config exception port
    if (!configExceptionPort(currentTask)) {
        goto StartFaild;
    }
    
    //create thread monitor exception
    if (!createThreadToMonitor(currentTask)) {
        goto StartFaild;
    }
    
    _g_isMachMonitoring = YES;
    
    return;
StartFaild:
    resetMachPorts();
}

+ (void)inactivateCrashPlugin {
    if (!_g_isMachMonitoring) return;
    resetMachPorts();
    _g_isMachMonitoring = NO;
}

static BOOL configExceptionPort(const task_t currentTask) {
    kern_return_t result = KERN_RETURN_MAX;
    
    //save old exception ports
    // 获取task的异常端口
    exception_mask_t monitorMasks =
    EXC_MASK_BAD_ACCESS | //Memory access fail
    EXC_MASK_BAD_INSTRUCTION | //Illegal instruction
    EXC_MASK_ARITHMETIC | //Arithmetic exception
    EXC_MASK_SOFTWARE |//Software exception
    EXC_MASK_BREAKPOINT;//Trace or breakpoint
    result = task_get_exception_ports(currentTask,
                                      monitorMasks,
                                      _g_oldExceptionPorts.masks,
                                      &_g_oldExceptionPorts.masksCount,
                                      _g_oldExceptionPorts.handlers,
                                      _g_oldExceptionPorts.behaviors,
                                      _g_oldExceptionPorts.flavors);
    if (result != KERN_SUCCESS) {
        return NO;
    }
    
    //set exception port receive right
    // 创建调用者指定的端口 权限类型
    result = mach_port_allocate(currentTask,
                                MACH_PORT_RIGHT_RECEIVE,
                                &_g_exceptionPort);
    if (result != KERN_SUCCESS) {
        return NO;
    }
    
    //set exception port send right
    // 将指定的端口插入目标task
    result = mach_port_insert_right(currentTask,
                                    _g_exceptionPort,
                                    _g_exceptionPort,
                                    MACH_MSG_TYPE_MAKE_SEND);
    
    if (result != KERN_SUCCESS) {
        return NO;
    }
    
    //install exception port
    // 设置task的异常端口
    result = task_set_exception_ports(currentTask,
                                      monitorMasks,
                                      _g_exceptionPort,
                                      EXCEPTION_DEFAULT | MACH_EXCEPTION_CODES,
                                      THREAD_STATE_NONE);
    if (result != KERN_SUCCESS) {
        return NO;
    }

    return YES;
}

static BOOL createThreadToMonitor(const task_t currentTask) {
    int error = 0;
    
    //init thread attr
    pthread_attr_t thread_attr;
    error = pthread_attr_init(&thread_attr);
    if (error != 0) {
        return NO;
    }
    // 线程的分离状态
    // 父线程在创建子线程之后,，父线程不会去等待子线程结束再去运行自己接下来的程序；
    pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);
    
    pthread_t monitor_pthread;
    //create thread
    error = pthread_create(&monitor_pthread,
                           &thread_attr,
                           &machExceptionHandler, // 新创建的线程从xx函数的地址开始运行
                           NULL);
    pthread_attr_destroy(&thread_attr);
    if (error != 0) {
        return NO;
    }else{
        // 转换pthread_t 为 mach_port_t
        thread_t thread = pthread_mach_thread_np(monitor_pthread);
        _g_moniotr_thread = thread;
        kzp_addThreadWithoutSuspend(thread);
        return YES;
    }
}

static void* machExceptionHandler(void* const uContext) {
    //wait crash message
    Mach_exception_request_message requestMsg = {{0}};
    while (YES) {
        NSLog(@"yuhechuan === mach_msg");
        // 切换到内核态 等待被唤起
        kern_return_t result = mach_msg(&requestMsg.header,
                                        MACH_RCV_MSG,
                                        0,
                                        sizeof(requestMsg),
                                        _g_exceptionPort,
                                        MACH_MSG_TIMEOUT_NONE,
                                        MACH_PORT_NULL);
        if (result == KERN_SUCCESS) {
            break;
        } 
    }
    
    if (_g_handler) {
        kzp_suspendEnvironment();
        KZPCrashInformation *crashInfo = &_g_crashInfo;
        
        //Crash type
        crashInfo->crashType = KZPCrashTypeMach;
        
        //Crash thread
        crashInfo->crashThread = requestMsg.thread.name;
        
        //Crash detail
        crashInfo->crashReason = exceptionTypeName(requestMsg.exception);
        NSString *desc = [NSString stringWithFormat:@"%s (%s)",returnCodeName(requestMsg.code[0]),signalForMachException(requestMsg.exception,requestMsg.code[0])];
        crashInfo->crashDescription = desc.UTF8String;
        
        //Fault address
        crashInfo->faultAddress = kzp_faultAddressForThread(requestMsg.thread.name);
        
        //Last exception backtrace
        KZPBacktraceBuffer backtraceBuffer = {0};
        bool bufferResult = kzp_backtraceForMachThread(requestMsg.thread.name, &backtraceBuffer);
        if (bufferResult) {
            crashInfo->backtraceBuffer = &backtraceBuffer;
        }
        
        _g_handler(crashInfo);
    }

    //Send a message to notify the system to handle.
    Mach_exception_reply_message replyMsg = {{0}};
    replyMsg.header = requestMsg.header;
    replyMsg.NDR = requestMsg.NDR;
    replyMsg.returnCode = KERN_FAILURE;
    mach_msg(&replyMsg.header,
             MACH_SEND_MSG,
             sizeof(replyMsg),
             0,
             MACH_PORT_NULL,
             MACH_MSG_TIMEOUT_NONE,
             MACH_PORT_NULL);
    return NULL;
}

static void resetMachPorts(void) {
    
    if (_g_oldExceptionPorts.masksCount > 0){
        const task_t currentTask = mach_task_self();
        // Reinstall old exception ports.
        for(mach_msg_type_number_t i = 0; i < _g_oldExceptionPorts.masksCount; i++)
        {
            kern_return_t kr;
            kr = task_set_exception_ports(currentTask,
                                          _g_oldExceptionPorts.masks[i],
                                          _g_oldExceptionPorts.handlers[i],
                                          _g_oldExceptionPorts.behaviors[i],
                                          _g_oldExceptionPorts.flavors[i]);
            if(kr != KERN_SUCCESS) {
                NSLog(@"KZP mach reset original failed!");
            }
        }
    }
    if (_g_moniotr_thread != (thread_t)kzp_mach_thread_self()) {
        thread_terminate(_g_moniotr_thread);
        _g_moniotr_thread = 0;
    }
    _g_oldExceptionPorts.masksCount = 0;
    _g_exceptionPort = MACH_PORT_NULL;
    _g_handler = NULL;
}

static char *exceptionTypeName(exception_type_t excType) {
#define EXCEPTION_TRANSFORM_STR(_type_name)  \
if (excType == _type_name) return #_type_name
    
    EXCEPTION_TRANSFORM_STR(EXC_BAD_ACCESS);
    EXCEPTION_TRANSFORM_STR(EXC_BAD_INSTRUCTION);
    EXCEPTION_TRANSFORM_STR(EXC_ARITHMETIC);
    EXCEPTION_TRANSFORM_STR(EXC_EMULATION);
    EXCEPTION_TRANSFORM_STR(EXC_SOFTWARE);
    EXCEPTION_TRANSFORM_STR(EXC_BREAKPOINT);
    EXCEPTION_TRANSFORM_STR(EXC_SYSCALL);
    EXCEPTION_TRANSFORM_STR(EXC_MACH_SYSCALL);
    EXCEPTION_TRANSFORM_STR(EXC_RPC_ALERT);
    EXCEPTION_TRANSFORM_STR(EXC_CRASH);
    return "Unknown";
}

static char * signalForMachException(exception_type_t exception, mach_exception_code_t code)
{
    switch(exception)
    {
        case EXC_ARITHMETIC:
            return "SIGFPE";
        case EXC_BAD_ACCESS:
            /**
             Stack overflow should result in a SIGSEGV,
             but a guard page access will trigger KERN_PROTECTION_FAILURE (SIGBUS),
             so we should know that.
             */
            return code == KERN_INVALID_ADDRESS ? "SIGSEGV" : "SIGBUS";
        case EXC_BAD_INSTRUCTION:
            return "SIGILL";
        case EXC_BREAKPOINT:
            return "SIGTRAP";
        case EXC_EMULATION:
            return "SIGEMT";
        case EXC_SOFTWARE:
        {
            switch (code)
            {
                case EXC_UNIX_BAD_SYSCALL:
                    return "SIGSYS";
                case EXC_UNIX_BAD_PIPE:
                    return "SIGPIPE";
                case EXC_UNIX_ABORT:
                    return "SIGABRT";
                case EXC_SOFT_SIGNAL:
                    return "SIGKILL";
            }
            break;
        }
    }
    return "";
}


static char *returnCodeName(integer_t returnCode) {
    
#define RETURNCODE_TRANSFORM_STR(_return_code)  \
if (returnCode == _return_code) return #_return_code
    
    RETURNCODE_TRANSFORM_STR(KERN_SUCCESS);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_ADDRESS);
    RETURNCODE_TRANSFORM_STR(KERN_PROTECTION_FAILURE);
    RETURNCODE_TRANSFORM_STR(KERN_NO_SPACE);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_ARGUMENT);
    RETURNCODE_TRANSFORM_STR(KERN_FAILURE);
    RETURNCODE_TRANSFORM_STR(KERN_RESOURCE_SHORTAGE);
    RETURNCODE_TRANSFORM_STR(KERN_NOT_RECEIVER);
    RETURNCODE_TRANSFORM_STR(KERN_NO_ACCESS);
    RETURNCODE_TRANSFORM_STR(KERN_MEMORY_FAILURE);
    RETURNCODE_TRANSFORM_STR(KERN_MEMORY_ERROR);
    RETURNCODE_TRANSFORM_STR(KERN_ALREADY_IN_SET);
    RETURNCODE_TRANSFORM_STR(KERN_NOT_IN_SET);
    RETURNCODE_TRANSFORM_STR(KERN_NAME_EXISTS);
    RETURNCODE_TRANSFORM_STR(KERN_ABORTED);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_NAME);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_TASK);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_RIGHT);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_VALUE);
    RETURNCODE_TRANSFORM_STR(KERN_UREFS_OVERFLOW);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_CAPABILITY);
    RETURNCODE_TRANSFORM_STR(KERN_RIGHT_EXISTS);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_HOST);
    RETURNCODE_TRANSFORM_STR(KERN_MEMORY_PRESENT);
    RETURNCODE_TRANSFORM_STR(KERN_MEMORY_DATA_MOVED);
    RETURNCODE_TRANSFORM_STR(KERN_MEMORY_RESTART_COPY);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_PROCESSOR_SET);
    RETURNCODE_TRANSFORM_STR(KERN_POLICY_LIMIT);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_POLICY);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_OBJECT);
    RETURNCODE_TRANSFORM_STR(KERN_ALREADY_WAITING);
    RETURNCODE_TRANSFORM_STR(KERN_DEFAULT_SET);
    RETURNCODE_TRANSFORM_STR(KERN_EXCEPTION_PROTECTED);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_LEDGER);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_MEMORY_CONTROL);
    RETURNCODE_TRANSFORM_STR(KERN_INVALID_SECURITY);
    RETURNCODE_TRANSFORM_STR(KERN_NOT_DEPRESSED);
    RETURNCODE_TRANSFORM_STR(KERN_TERMINATED);
    RETURNCODE_TRANSFORM_STR(KERN_LOCK_SET_DESTROYED);
    RETURNCODE_TRANSFORM_STR(KERN_LOCK_UNSTABLE);
    RETURNCODE_TRANSFORM_STR(KERN_LOCK_OWNED);
    RETURNCODE_TRANSFORM_STR(KERN_LOCK_OWNED_SELF);
    RETURNCODE_TRANSFORM_STR(KERN_SEMAPHORE_DESTROYED);
    RETURNCODE_TRANSFORM_STR(KERN_RPC_SERVER_TERMINATED);
    RETURNCODE_TRANSFORM_STR(KERN_RPC_TERMINATE_ORPHAN);
    RETURNCODE_TRANSFORM_STR(KERN_RPC_CONTINUE_ORPHAN);
    RETURNCODE_TRANSFORM_STR(KERN_NOT_SUPPORTED);
    RETURNCODE_TRANSFORM_STR(KERN_NODE_DOWN);
    RETURNCODE_TRANSFORM_STR(KERN_NOT_WAITING);
    RETURNCODE_TRANSFORM_STR(KERN_OPERATION_TIMED_OUT);
    RETURNCODE_TRANSFORM_STR(KERN_CODESIGN_ERROR);
    return "Unknown";
}


@end
