//
//  KZPCrashObjcException.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/15/19.
//

#import <Foundation/Foundation.h>
#import "KZPCrashComponents.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPCrashObjcException : NSObject <KZPCrashMonitorProtocol>

+ (void)updateOjbcExceptionOwnership;

@end

NS_ASSUME_NONNULL_END
