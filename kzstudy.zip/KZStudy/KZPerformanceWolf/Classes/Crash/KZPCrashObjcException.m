//
//  KZPCrashObjcException.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 4/15/19.
//

#import "KZPCrashObjcException.h"

static KZPCrashInformation _g_crashInfo;
static KZPCrashHandler *_g_handler = NULL;
static BOOL _g_isNSExceptionMonitoring = NO;
static NSUncaughtExceptionHandler *_g_oldUncaughtExceptionHandler = NULL;

@implementation KZPCrashObjcException

+ (BOOL)isActive {
    return _g_isNSExceptionMonitoring;
}

+ (void)activeCrashPlugin:(KZPCrashHandler *)handler {
    if (_g_isNSExceptionMonitoring) return;
    _g_handler = handler;
    //一个指向顶级错误处理函数的指针，在该函数中，您可以在程序终止之前执行最后一分钟的日志记录。
    // 储存之前的 函数指针
    _g_oldUncaughtExceptionHandler = NSGetUncaughtExceptionHandler();
    NSSetUncaughtExceptionHandler(&exceptionHandler);
    _g_isNSExceptionMonitoring = YES;
}

+ (void)inactivateCrashPlugin {
    if (!_g_isNSExceptionMonitoring) return;
    NSSetUncaughtExceptionHandler(_g_oldUncaughtExceptionHandler);
    _g_handler = NULL;
    _g_isNSExceptionMonitoring = NO;
}

// 刷新 hook
+ (void)updateOjbcExceptionOwnership {
    if (!_g_isNSExceptionMonitoring) return;
    NSUncaughtExceptionHandler *currentHandler = NSGetUncaughtExceptionHandler();
    if (currentHandler != &exceptionHandler) {
        _g_oldUncaughtExceptionHandler = currentHandler;
        NSSetUncaughtExceptionHandler(&exceptionHandler);
    }
}

static void exceptionHandler(NSException *exception){
    if (_g_handler) {
        kzp_suspendEnvironment();
        KZPCrashInformation *crashInfo = &_g_crashInfo;
        
        //Crash type
        crashInfo->crashType = KZPCrashTypeNSException;
        
        //Crash thread
        crashInfo->crashThread = (thread_t)kzp_mach_thread_self();
        
        //Crash brief
        crashInfo->crashReason = exception.name.UTF8String;
        crashInfo->crashDescription = exception.reason.UTF8String;

        //Last exception backtrace
        KZPBacktraceBuffer backtraceBuffer = {0};
        NSArray* addresses = [exception callStackReturnAddresses];
        int numFrames = (int)addresses.count;
        for(NSUInteger i = 0; i < numFrames; i++) {
            backtraceBuffer.backtraceBuffer[i] = (uintptr_t)[addresses[i] unsignedLongLongValue];
        }
        backtraceBuffer.useBufferLength = numFrames;
        crashInfo->backtraceBuffer = &backtraceBuffer;
        
        _g_handler(crashInfo);
    }
    //system will can't catch crash when use `kill(getpid(),SIGKILL)`.
    // 调用系统原来的 处理方式
    if (_g_oldUncaughtExceptionHandler) {
        _g_oldUncaughtExceptionHandler(exception);
    }
}


@end
