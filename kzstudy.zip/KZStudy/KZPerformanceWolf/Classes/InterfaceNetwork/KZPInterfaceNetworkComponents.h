//
//  KZPInterfaceNetworkComponents.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/14/19.
//

#ifndef KZPInterfaceNetworkComponents_h
#define KZPInterfaceNetworkComponents_h

#import <Foundation/Foundation.h>

@class KZPInterfaceNetworkMetrics;


typedef void (^KZPInterfaceNetworkMetricsBlcok)(KZPInterfaceNetworkMetrics *metrics,
                                                NSURLSessionTask *completeTask,
                                                NSError *error);


#endif /* KZPInterfaceNetworkComponents_h */
