//
//  KZPInterfaceNetworkMetrics.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/12/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZPInterfaceNetworkMetrics : NSObject

@property (nonatomic, strong, nullable) NSMutableData *receivedData;

/*
 An object encapsulating the metrics for a session task.
 */
@property (nonatomic, strong) NSURLSessionTaskMetrics *taskMetrics API_AVAILABLE(ios(10.0));

@end

NS_ASSUME_NONNULL_END
