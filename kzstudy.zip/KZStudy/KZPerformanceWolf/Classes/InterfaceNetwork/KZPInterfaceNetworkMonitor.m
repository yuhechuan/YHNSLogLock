//
//  KZPInterfaceNetworkMonitor.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import "KZPInterfaceNetworkMonitor.h"
#import "KZPSessionDelegateProxy.h"

static BOOL _g_isNetworkMonitoring = NO;

@implementation KZPInterfaceNetworkMonitor

#pragma mark -- KZPerformanceMonitorProtocol
+ (instancetype)shareMonitor {
    static KZPInterfaceNetworkMonitor *monitor = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        monitor = [[KZPInterfaceNetworkMonitor alloc] init];
    });
    return monitor;
}

- (BOOL)isMonitoring {
    return _g_isNetworkMonitoring;
}

- (void)startMonitor {
    _g_isNetworkMonitoring = YES;
}

- (void)stopMonitor {
    _g_isNetworkMonitoring = NO;
}

#pragma mark -- Hook Session
+ (void)initialize {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self swizzleSessionDelegateConfig];
    });
}

+ (void)swizzleSessionDelegateConfig{
    Class sessionClass = NSURLSession.class;
    Class proxyClass = KZPInterfaceNetworkMonitor.class;
    
    SEL sessionSelector = @selector(sessionWithConfiguration:delegate:delegateQueue:);
    SEL proxySelector = NSSelectorFromString(@"kzp_sessionWithConfiguration:delegate:delegateQueue:");
    // hook 网络代理配置
    kzp_swizzleClassMethod(sessionClass, proxyClass, sessionSelector, proxySelector);
}

+ (NSURLSession *)kzp_sessionWithConfiguration:(NSURLSessionConfiguration *)configuration delegate:(nullable id <NSURLSessionDelegate>)delegate delegateQueue:(nullable NSOperationQueue *)queue {
    
    NSString *delegateName = NSStringFromClass(delegate.class);
    
    // 获取所有 可能的网络代理对象
    NSMutableArray *monitorDelegates = [[NSMutableArray alloc] init];
    [monitorDelegates addObjectsFromArray:getDefaultSessionDelegates()];
    NSArray *customDelegates = [KZPInterfaceNetworkMonitor shareMonitor].customSessionDelegates;
    if (customDelegates && customDelegates.count > 0) {
        [monitorDelegates addObjectsFromArray:customDelegates];
    }
    // 判断是否需要开启网络监控
    if (!delegate ||
        ![monitorDelegates containsObject:delegateName] ||
        !_g_isNetworkMonitoring) {
        return [self kzp_sessionWithConfiguration:configuration delegate:delegate delegateQueue:queue];
    }
    // 主处理对象 
    KZPSessionDelegateProxy *proxy = [KZPSessionDelegateProxy sessionDelegateWithTargetObject:delegate];
 
    proxy.metricsBlock = [KZPInterfaceNetworkMonitor shareMonitor].metricsBlock;
    proxy.fullNetInfoMonitor = [KZPInterfaceNetworkMonitor shareMonitor].fullNetInfoMonitor;
    // proxy 拦截原来代理
    return [self kzp_sessionWithConfiguration:configuration delegate:proxy delegateQueue:queue];
}

static NSArray *getDefaultSessionDelegates(void) {
    static NSArray *delegates = nil;
    if (!delegates) {
        delegates = @[@"AFURLSessionManager",
                      @"AFHTTPSessionManager",
                      @"YPWebImageDownloader",
                      @"SDWebImageDownloader"];
    }
    return delegates;
}
@end
