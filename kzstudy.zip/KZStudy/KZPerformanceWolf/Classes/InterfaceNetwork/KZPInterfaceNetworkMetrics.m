//
//  KZPInterfaceNetworkMetrics.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/12/19.
//

#import "KZPInterfaceNetworkMetrics.h"

@interface KZPInterfaceNetworkMetrics ()

@end

@implementation KZPInterfaceNetworkMetrics

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.receivedData = [[NSMutableData alloc] init];
    }
    return self;
}


@end
