//
//  KZPInterfaceNetworkMonitor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import <Foundation/Foundation.h>
#import "KZPGeneralComponents.h"
#import "KZPInterfaceNetworkComponents.h"
#import "KZPInterfaceNetworkMetrics.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPInterfaceNetworkMonitor : NSObject <KZPerformanceMonitorProtocol>

@property (nonatomic, assign) BOOL fullNetInfoMonitor;

@property (nonatomic, strong, nullable) NSArray <NSString *>*customSessionDelegates;

@property (nonatomic, copy, nullable) KZPInterfaceNetworkMetricsBlcok metricsBlock;

@end

NS_ASSUME_NONNULL_END
