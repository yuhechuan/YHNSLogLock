//
//  KZPSessionDelegateProxy.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import "KZPSessionDelegateProxy.h"
#import "KZPGeneralComponents.h"
#import "KZPInterfaceNetworkMetrics.h"

#define KZP_DelegatePerformSelSafetyCheck (self.originDelegate && [self.originDelegate respondsToSelector:_cmd])

#define kSessionMetricsSelector  @"URLSession:task:didFinishCollectingMetrics:"

#define kSessionCompleteSelector  @"URLSession:task:didCompleteWithError:"

#define kSessionReceiveDataSelector  @"URLSession:dataTask:didReceiveData:"

typedef NSMutableDictionary <NSNumber *,KZPInterfaceNetworkMetrics *> KZPTaskMetricsDic;

@interface KZPSessionDelegateProxy ()

@property (nonatomic, weak) id originDelegate;

@property (nonatomic, strong) KZPTaskMetricsDic *tasksMetricsDic;

@property (nonatomic, strong) dispatch_queue_t safeOperationQueue;

@end


@implementation KZPSessionDelegateProxy

#pragma mark -- Initial
+ (instancetype)sessionDelegateWithTargetObject:(id)targetObject {
    KZPSessionDelegateProxy *proxy = [KZPSessionDelegateProxy alloc];
    proxy.originDelegate = targetObject;
    proxy.tasksMetricsDic = [[KZPTaskMetricsDic alloc] init];
    proxy.safeOperationQueue = dispatch_queue_create("com.LYPDoit.KZPerformanceWolf.KZPSessionDelegateProxy", DISPATCH_QUEUE_SERIAL);
    proxy.fullNetInfoMonitor = NO;
    
    return proxy;
}

#pragma mark -- NSProxy

// 这个也可以
//- (id)forwardingTargetForSelector:(SEL)aSelector {
//    if (self.originDelegate) {
//        return self.originDelegate;
//    }
//}

// 转发不需要 拦截的代理方法
- (void)forwardInvocation:(NSInvocation *)invocation {
    if (self.originDelegate) {
        [invocation invokeWithTarget:self.originDelegate];
    }
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)selector {
    return [self.originDelegate methodSignatureForSelector:selector];
}

- (BOOL)respondsToSelector:(SEL)aSelector {
    if ([self.originDelegate respondsToSelector:aSelector]) {
        return YES;
    }
    NSString *sel = NSStringFromSelector(aSelector);
    if ([sel isEqualToString:kSessionMetricsSelector] ||
        [sel isEqualToString:kSessionCompleteSelector] ||
        [sel isEqualToString:kSessionReceiveDataSelector]) {
        return YES;
    }
    return NO;
}

//resole call `invalidateAndCancel` or `finishTasksAndInvalidate` maybe crash.
- (void)URLSession:(NSURLSession *)session didBecomeInvalidWithError:(nullable NSError *)error {
    if (KZP_DelegatePerformSelSafetyCheck) {
        [self.originDelegate URLSession:session didBecomeInvalidWithError:error];
    }
}

#pragma mark -- NSURLSessionDataDelegate
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    if (KZP_DelegatePerformSelSafetyCheck) {
        [self.originDelegate URLSession:session dataTask:dataTask didReceiveData:data];
    }
    if (self.fullNetInfoMonitor) {
        dispatch_async(self.safeOperationQueue, ^{
            if (!data) return;
            KZPInterfaceNetworkMetrics *networkMetrics = [self getMetricsForTaskIdentifier:dataTask.taskIdentifier];
            [networkMetrics.receivedData appendData:data];
        });
    }
}

#pragma mark -- NSURLSessionTaskDelegate
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    if (KZP_DelegatePerformSelSafetyCheck) {
        [self.originDelegate URLSession:session task:task didCompleteWithError:error];
    }
    dispatch_async(self.safeOperationQueue, ^{
        KZPInterfaceNetworkMetrics *networkMetrics = [self getMetricsForTaskIdentifier:task.taskIdentifier];
        NSHTTPURLResponse *response = nil;
        if ([task.response isKindOfClass:NSHTTPURLResponse.class]) {
            response = (NSHTTPURLResponse *)task.response;
        }

        if (self.metricsBlock) {
            self.metricsBlock(networkMetrics, task, error);
        }
        networkMetrics.receivedData = nil;
        // 如果网络发生错误 进行记录
        if (error) {
            if (error.code == NSURLErrorDNSLookupFailed || // 连接失败，因为DNS查找失败。-1006
                error.code == NSURLErrorBadURL ||          // 由于URL格式错误，连接失败。 -1000
                error.code == NSURLErrorCannotConnectToHost || // 连接失败，因为无法与主机建立连接。-1004
                error.code == NSURLErrorCannotFindHost) {      // 连接失败，因为找不到主机。--1003

                NSMutableDictionary *entryDic = [[NSMutableDictionary alloc] init];
                
                NSNumber *statCode = @(0);
                // 获取状态码
                if (response) statCode = @(response.statusCode);
                NSURLComponents *componets = [[NSURLComponents alloc] initWithURL:task.originalRequest.URL resolvingAgainstBaseURL:NO];
                if(@available(iOS 10.0, *)) {
                    NSNumber *taskInterval = nil;
                    NSNumber *dnsInterval = nil;
                    // 创建任务到完成任务的时间间隔
                    taskInterval = @(networkMetrics.taskMetrics.taskInterval.duration);
                    NSArray *metrics = networkMetrics.taskMetrics.transactionMetrics;
                    if (metrics.count > 0) {
                        NSURLSessionTaskTransactionMetrics *m = metrics[0];
                        if (m.domainLookupStartDate && m.domainLookupEndDate) {
                            // dns查找时间
                            dnsInterval = @([m.domainLookupEndDate timeIntervalSinceDate:m.domainLookupStartDate]);
                        }
                    }
                    KZPDIC_SAVE_SAFETY(entryDic,
                                       taskInterval,
                                       KZP_APINET_TOTAL_INTERVAL);
                    KZPDIC_SAVE_SAFETY(entryDic,
                                       dnsInterval,
                                       KZP_APINET_DNS_INTERVAL);
                }
                // 状态码
                KZPDIC_SAVE_SAFETY(entryDic,
                                   statCode,
                                   KZP_APINET_STATUS);
                // error code
                KZPDIC_SAVE_SAFETY(entryDic,
                                   formatStringWithErrorCode(error.code),
                                   KZP_APINET_ERROR_CODE);
                // error 描述
                KZPDIC_SAVE_SAFETY(entryDic,
                                   error.userInfo[NSLocalizedDescriptionKey],
                                   KZP_APINET_ERROR_DESC);
                // host
                KZPDIC_SAVE_SAFETY(entryDic,
                                   componets.host,
                                   KZP_APINET_HOST);
                // path
                KZPDIC_SAVE_SAFETY(entryDic,
                                   componets.path,
                                   KZP_APINET_PATH);
                // query
                KZPDIC_SAVE_SAFETY(entryDic,
                                   componets.query,
                                   KZP_APINET_QUERY);
                [[KZPerformanceDataCenter shareDataCenter] saveDataForType:KZPDataTypeAPINet infoEntry:entryDic];
            }
        }
        [self.tasksMetricsDic removeObjectForKey:@(task.taskIdentifier)];
    });
}
// 收集完信息回调
/**
 taskInterval : task从开始到结束总共用的时间
 redirectCount : task重定向的次数
 transactionMetrics : 一个task从发出请求到收到数据过程中派生出的每个子请求, 它是一个装着许多NSURLSessionTaskTransactionMetrics对象的数组. 每个对象都代表一个子过程
 */
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didFinishCollectingMetrics:(NSURLSessionTaskMetrics *)metrics  API_AVAILABLE(ios(10.0)){
    if (KZP_DelegatePerformSelSafetyCheck){
        [self.originDelegate URLSession:session task:task didFinishCollectingMetrics:metrics];
    }
    dispatch_async(self.safeOperationQueue, ^{
        KZPInterfaceNetworkMetrics *networkMetrics = [self getMetricsForTaskIdentifier:task.taskIdentifier];
        networkMetrics.taskMetrics = metrics;
    });
}

#pragma mark -- Private

- (KZPInterfaceNetworkMetrics *)getMetricsForTaskIdentifier:(NSUInteger)taskIdentifier {
     KZPInterfaceNetworkMetrics *networkMetrics = self.tasksMetricsDic[@(taskIdentifier)];
    if (!networkMetrics) {
        networkMetrics = [[KZPInterfaceNetworkMetrics alloc] init];
        self.tasksMetricsDic[@(taskIdentifier)] = networkMetrics;
    }
    return networkMetrics;
}

static NSString *formatStringWithErrorCode(NSInteger code) {
#define ERROR_CODE_TRANSFORM_STR(_code)  \
if (code == _code) return @#_code
    
    ERROR_CODE_TRANSFORM_STR(NSURLErrorDNSLookupFailed);
    ERROR_CODE_TRANSFORM_STR(NSURLErrorBadURL);
    ERROR_CODE_TRANSFORM_STR(NSURLErrorCannotConnectToHost);
    ERROR_CODE_TRANSFORM_STR(NSURLErrorCannotFindHost);
    return nil;
}

@end
