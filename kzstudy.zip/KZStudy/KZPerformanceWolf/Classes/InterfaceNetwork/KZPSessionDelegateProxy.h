//
//  KZPSessionDelegateProxy.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import <Foundation/Foundation.h>
#import "KZPInterfaceNetworkComponents.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPSessionDelegateProxy : NSObject <NSURLSessionDelegate>

+ (instancetype)sessionDelegateWithTargetObject:(id)targetObject;

// 是否记录全部 网络请求数据
@property (nonatomic, assign) BOOL fullNetInfoMonitor;

@property (nonatomic, copy) KZPInterfaceNetworkMetricsBlcok metricsBlock;

@end

NS_ASSUME_NONNULL_END
