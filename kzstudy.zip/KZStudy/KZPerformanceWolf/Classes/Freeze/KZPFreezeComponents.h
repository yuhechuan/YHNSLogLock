//
//  KZPFreezeComponents.h
//  Pods
//
//  Created by Yaping Liu on 4/9/19.
//

#ifndef KZPFreezeComponents_h
#define KZPFreezeComponents_h

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, KZPFreezeType) {
    KZPFreezeTypeNone,
    // 主线程卡顿
    KZPFreezeTypeMainThread,
    // app启动
    KZPFreezeTypeLaunch,
    // app 进入前台
    KZPFreezeTypeEnterForground,
};

typedef NSInteger KZPMilliseconds;

#endif /* KZPFreezeComponents_h */
