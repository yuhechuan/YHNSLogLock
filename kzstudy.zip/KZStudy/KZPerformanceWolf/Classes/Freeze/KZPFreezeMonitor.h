//
//  KZPFreezeMonitor.h
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/14/19.
//

#import <Foundation/Foundation.h>
#import "KZPGeneralComponents.h"
#import "KZPFreezeComponents.h"

NS_ASSUME_NONNULL_BEGIN
// 卡顿
@interface KZPFreezeMonitor : NSObject <KZPerformanceMonitorProtocol>
/**
 The mainRunloop freeze limit time in milliseconds.
 Default 2000 millisecond (2s).
 */
@property (nonatomic, assign) KZPMilliseconds freezeLimitMsec;

@end

NS_ASSUME_NONNULL_END
