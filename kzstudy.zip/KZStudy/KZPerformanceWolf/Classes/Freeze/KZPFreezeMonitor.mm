//
//  KZPFreezeMonitor.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/14/19.
//

#import "KZPFreezeMonitor.h"
#import "KZPMachOContentAssistor.h"
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
#import "KZPRebootMonitor.h"

#include "KZPSystemEnvInfoAssistor.h"
#include <map>
#include <vector>

#define kMsecForPerSec                      1000.0

#define kUsecForPerMsec                     1000.0

#define kSignleTimeoutMsec                  50

#define kMainRunloopFreezeLimitMsec         2000

#define kTimerMonitorIntervalMsec           50

#define kStartFreezeLimitIntervalMsec       80

#define kDefaultCacheStacksCount            15

#define kFilterValidBufferLength            4

#define kFreezeDeadLimitIntervalSec         7

#define kFreezeMarkIntervalSec              0.7

static BOOL _g_isFreezeMonitoring = NO;
static CFRunLoopActivity _g_currentActivity;

static CFTimeInterval _g_startWorkTime = -1;

static CFTimeInterval _g_endWorkTime = 0;

static BOOL _g_isFreezing = NO;

static BOOL _g_hasLaunched = NO;
static BOOL _g_didEnterBackground = NO;

@interface KZPFreezeMonitor ()
{
    dispatch_queue_t _freezeMonitorQueue;
    // 子线程
    dispatch_queue_t _freezeTimerQueue;
    // runloop 观察者
    CFRunLoopObserverRef _freezeStartObserver;
    CFRunLoopObserverRef _freezeEndObserver;

    // 超时时间
    NSUInteger _previousSignleTimeOutMsec;
    NSUInteger _currentSignleTimeOutMsec;
    
    //
    KZPBacktraceBuffer _lastBuffer;
    std::vector<KZPBacktraceBuffer> _cacheStacks;
    std::map<uintptr_t, NSInteger> _stackCountMap;
    NSInteger _catchStacksCount;
    NSString *_overLimitSaveUUID;
    
    dispatch_source_t _timer;
}

@end


@implementation KZPFreezeMonitor

#pragma mark -- Monitor protocol
+ (instancetype)shareMonitor {
    static KZPFreezeMonitor *monitor = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        monitor = [[KZPFreezeMonitor alloc] init];
    });
    return monitor;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _freezeMonitorQueue = dispatch_queue_create("com.LYPDoit.KZPerformanceWolf.KZPFreezeMonitor.freezeMonitor", DISPATCH_QUEUE_SERIAL);
        _freezeTimerQueue = dispatch_queue_create("com.LYPDoit.KZPerformanceWolf.KZPFreezeMonitor.freezeTimer", DISPATCH_QUEUE_SERIAL);
        _previousSignleTimeOutMsec = 0;
        _catchStacksCount = 0;
        _currentSignleTimeOutMsec = kSignleTimeoutMsec;
        self.freezeLimitMsec = kMainRunloopFreezeLimitMsec;
        [self registerApplicationNotifications];
    }
    return self;
}

- (void)startMonitor {
    if (kzp_isDebugging() || _g_isFreezeMonitoring) return;

    _g_isFreezeMonitoring = YES;
    
    [self mainRunloopAddObservers];
    
    [self loopCheckMainThread];
}

- (void)stopMonitor {
    if (!_g_isFreezeMonitoring) return;
    
    _g_isFreezeMonitoring = NO;
    
    [self mainRunloopRemoveObservers];
}

- (BOOL)isMonitoring {
    return _g_isFreezeMonitoring;
}

#pragma mark -- Application notifications
- (void)registerApplicationNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didBecomeActive)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(willEnterForeground)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didEnterBackground)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];
}

- (void)willEnterForeground {
    _g_didEnterBackground = NO;
}

- (void)didBecomeActive {
    _g_hasLaunched = YES;
    _g_didEnterBackground = NO;
}

- (void)didEnterBackground {
    _g_didEnterBackground = YES;
}

#pragma mark -- Runloop observers
- (void)mainRunloopAddObservers {
    //common modes (kCFRunLoopDefaultMode/UITrackingRunLoopMode)

    CFRunLoopRef mainRunloop = CFRunLoopGetMain();
    //prior
    CFRunLoopObserverRef commonStartObs = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, kCFRunLoopAllActivities, YES, LONG_MAX, ^(CFRunLoopObserverRef observer, CFRunLoopActivity activity)
    {
        _g_currentActivity = activity;
        if (activity == kCFRunLoopBeforeSources || activity == kCFRunLoopAfterWaiting
            || activity == kCFRunLoopBeforeTimers || activity == kCFRunLoopEntry)
        {
            if (_g_startWorkTime < 0) {
                _g_startWorkTime = CACurrentMediaTime();
            }
        }
    });
    CFRetain(commonStartObs);
    _freezeStartObserver = commonStartObs;
    CFRunLoopAddObserver(mainRunloop, _freezeStartObserver, kCFRunLoopCommonModes);
    
    //last
    CFRunLoopObserverRef commonEndObs = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, kCFRunLoopAllActivities, YES, LONG_MIN, ^(CFRunLoopObserverRef observer, CFRunLoopActivity activity)
    {
        _g_currentActivity = activity;
        if (activity == kCFRunLoopBeforeWaiting || activity == kCFRunLoopExit)
        {
            if (_g_isFreezing) {
                _g_endWorkTime = CACurrentMediaTime();
                _g_isFreezing = NO;
            }
            _g_startWorkTime = -1;
        }
    });
    CFRetain(commonEndObs);
    _freezeEndObserver = commonEndObs;
    CFRunLoopAddObserver(mainRunloop, _freezeEndObserver, kCFRunLoopCommonModes);
}

#pragma mark -- Check
- (void)loopCheckMainThread {
    //create monitor timer
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, _freezeTimerQueue);
    dispatch_source_set_timer(_timer, DISPATCH_TIME_NOW, kTimerMonitorIntervalMsec * NSEC_PER_MSEC, 0);
    dispatch_source_set_event_handler(_timer, ^{
        if (!_g_isFreezeMonitoring || _g_didEnterBackground) return;

        //_startWorkTime is greater than 0 only when runloop is working.
        // 没有处于忙碌状态
        CFTimeInterval loc_startTime = _g_startWorkTime;
        if (loc_startTime < 0) return;
    
        // 当前处于忙碌状态 时间间隔 小于 80毫秒 不做处理
        //whether will start freeze
        double gapMsec = (CACurrentMediaTime() - loc_startTime) * kMsecForPerSec;
        if (gapMsec < kStartFreezeLimitIntervalMsec) return;
        
        _g_isFreezing = YES;

        //start freeze collcect
        NSString *freezeType = @"unknown";
        BOOL startFreeze = YES;
        BOOL hasMarkFreezeState = NO;
        // 阻塞当前线程
        while (YES) {
            if (startFreeze){
                startFreeze = NO;
                if (!_g_hasLaunched) {
                    freezeType = KZP_FREEZE_TYPE_LAUNCH;
                    
                }else if (_g_didEnterBackground){
                    freezeType = KZP_FREEZE_TYPE_ENTERFORGROUND;
                    
                }else{
                    freezeType = KZP_FREEZE_TYPE_MAINTHREAD;
                }
                [self dumpCurrentMainBacktraceStack];
            }
            //current freeze interval
            double freezeInterval = CACurrentMediaTime() - loc_startTime;
            // 如果处于忙碌状态 持续大于 0.7秒 归档一下 数据
            if (!hasMarkFreezeState && freezeInterval > kFreezeMarkIntervalSec) {
                hasMarkFreezeState = YES;
                [[KZPRebootMonitor shareMonitor] appForegroundMainThreadBlock:YES];
            }
            
            // 如果处于忙碌状态 持续大于 7秒 统计卡顿数据 并缓存上传
            if (!self->_overLimitSaveUUID && freezeInterval >= kFreezeDeadLimitIntervalSec) {
                NSDictionary *infoDic = [self logFreezeInfoWithFreezeType:freezeType freezeInterval:freezeInterval];
                if (infoDic) {
                    self->_overLimitSaveUUID = [NSUUID UUID].UUIDString;
                    [[KZPerformanceDataCenter shareDataCenter] customSaveDataForType:KZPDataTypeFreezing infoEntry:infoDic identifierUUID:self->_overLimitSaveUUID immediateUpload:NO];
                }
            }
            // 阻塞50毫秒
            usleep(self->_currentSignleTimeOutMsec * kUsecForPerMsec);
            
            if (!_g_didEnterBackground && _g_isFreezing) {
                // 卡顿产生过程
                [self dumpCurrentMainBacktraceStack];
                
            } else {
                // 卡顿结束后 统计卡顿数据
                [self checkFinishStatusWithFreezeType:freezeType startTime:loc_startTime];
                break;
            }
        }
    });
    dispatch_resume(_timer);
}

// 卡顿过程中 线程调用栈收集  栈最大容量15 最新的15个
- (void)dumpCurrentMainBacktraceStack {
    //whether we should cache current stack.
    BOOL isNeedCache = NO;
    KZPBacktraceBuffer buffer = {0};
    // 线程回溯 =>获取主线程的 线程的调用栈，没有符号化前是内存地址 数组
    BOOL result = kzp_mainThreadBacktraceBuffer(&buffer);

    if (result && buffer.useBufferLength > 0) {
        //mark
        _catchStacksCount++;
        uintptr_t firstAddress = buffer.backtraceBuffer[0];
        NSInteger count = _stackCountMap[firstAddress];
        _stackCountMap[firstAddress] = ++count;
        
        //is full same stack
        // 判断是否是一种调用栈 进行缓存
        if (_lastBuffer.useBufferLength == 0 || buffer.useBufferLength != _lastBuffer.useBufferLength) {
            _lastBuffer = buffer;
            isNeedCache = YES;
        }else {
            for (int i = 0; i < buffer.useBufferLength; i++) {
                if (buffer.backtraceBuffer[i] != _lastBuffer.backtraceBuffer[i]) {
                    _lastBuffer = buffer;
                    isNeedCache = YES;
                    break;
                }
            }
        }
    }
    
    if (isNeedCache) {
        //log current backtrace info
        // 重置 超时时间
        if (_cacheStacks.size() >= kDefaultCacheStacksCount) {
            _cacheStacks.pop_back();
        }
        _cacheStacks.insert(std::begin(_cacheStacks), buffer);
        
        _currentSignleTimeOutMsec = kSignleTimeoutMsec;
        _previousSignleTimeOutMsec = 0;
        
    }else{
        //Fibonacci sequence
        // 超时时间以 斐波纳契数列 累加
        NSUInteger previous = _previousSignleTimeOutMsec;
        _previousSignleTimeOutMsec = _currentSignleTimeOutMsec;
        _currentSignleTimeOutMsec += previous;
    }
}

- (void)checkFinishStatusWithFreezeType:(NSString *)freezeType startTime:(CFTimeInterval)startTime {
    CFTimeInterval freezeInterval = _g_endWorkTime - startTime;

    [[KZPRebootMonitor shareMonitor] appForegroundMainThreadBlock:NO];
    
    //log to cache
    // 卡顿时间超过2秒
    if (freezeInterval >= _freezeLimitMsec/kMsecForPerSec) {
        NSDictionary *infoDic = [self logFreezeInfoWithFreezeType:freezeType freezeInterval:freezeInterval];
        if (infoDic) {
            [[KZPerformanceDataCenter shareDataCenter] saveDataForType:KZPDataTypeFreezing infoEntry:infoDic];
        }
    }

    //delete dead main cache
    if (_overLimitSaveUUID) {
        [[KZPerformanceDataCenter shareDataCenter] deleteCacheWithDataType:KZPDataTypeFreezing reportID:_overLimitSaveUUID];
    }
    
    //clear
    self->_currentSignleTimeOutMsec = kSignleTimeoutMsec;
    self->_previousSignleTimeOutMsec = 0;
    KZPBacktraceBuffer resetBuffer = {0};
    self->_lastBuffer = resetBuffer;
    _cacheStacks.clear();
    _stackCountMap.clear();
    _catchStacksCount = 0;
    _overLimitSaveUUID = nil;
}

- (NSDictionary *)logFreezeInfoWithFreezeType:(NSString *)freezeType
                               freezeInterval:(CFTimeInterval)freezeInterval
{
    //filter
    KZPBacktraceBuffer excBuffer = {0};
    NSInteger excCount = 0;
    for (NSInteger index = 0; index < _cacheStacks.size(); index++) {
        KZPBacktraceBuffer perBuffer = _cacheStacks[index];
        if (perBuffer.useBufferLength < kFilterValidBufferLength) continue;
        uintptr_t firstAddress = perBuffer.backtraceBuffer[0];
        NSInteger count = _stackCountMap[firstAddress];
        if (count > excCount) {
            excCount = count;
            excBuffer = perBuffer;
        }
    }
    //log
    if (excBuffer.useBufferLength  < 1)  return nil;
    //log in cache
    NSMutableDictionary *infoDic = [[NSMutableDictionary alloc] init];
    infoDic[KZP_FREEZE_TYPE] = freezeType;
    infoDic[KZP_FREEZE_INTERVAL] = @(freezeInterval);
    infoDic[KZP_FREEZE_BACKTRACE_TOTAL] = @(_catchStacksCount);
    infoDic[KZP_FREEZE_BACKTRACE_COUNT] = @(excCount);
    NSArray *backtraceEntries = kzp_symbolBacktracesToEntries(excBuffer.backtraceBuffer, excBuffer.useBufferLength);
    infoDic[KZP_FREEZE_MAIN_BACKTRACE] = @[backtraceEntries];
    return  infoDic;
}

#pragma mark -- Release
- (void)mainRunloopRemoveObservers {
    if (_timer) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
    if (_freezeStartObserver) {
        CFRunLoopRemoveObserver(CFRunLoopGetMain(), _freezeStartObserver, kCFRunLoopCommonModes);
        CFRelease(_freezeStartObserver);
    }
    if (_freezeEndObserver) {
        CFRunLoopRemoveObserver(CFRunLoopGetMain(), _freezeEndObserver, kCFRunLoopCommonModes);
        CFRelease(_freezeEndObserver);
    }

}

@end
