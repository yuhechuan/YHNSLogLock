//
//  KZPMemoryMonitor.h
//  KZPerformanceWolf
//
//  Created by EthanDT on 2021/3/4.
//

#import <Foundation/Foundation.h>
#import "KZPGeneralComponents.h"

NS_ASSUME_NONNULL_BEGIN

@interface KZPMemoryMonitor : NSObject <KZPerformanceMonitorProtocol>

@end

NS_ASSUME_NONNULL_END
