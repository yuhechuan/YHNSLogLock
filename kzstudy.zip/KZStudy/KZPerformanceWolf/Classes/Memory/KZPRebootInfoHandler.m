//
//  KZPRebootInfoHandler.m
//  KZPerformanceWolf
//
//  Created by EthanDT on 2021/3/5.
//

#import "KZPRebootInfoHandler.h"
#import "KZPerformanceDataCenter.h"

@implementation KZPRebootInfoHandler

+ (instancetype)createInfoHander {
    KZPRebootInfoHandler *handler = nil;
    @try {
        handler = [NSKeyedUnarchiver unarchiveObjectWithFile:archivePath()];
    } @catch (NSException *exception) {

    } @finally {
        if (handler == nil) {
            handler = [[KZPRebootInfoHandler alloc] init];
            handler.isNewlyInstall = YES;
        }
    }
    return handler;
}

static NSString * archivePath() {
    return [kzp_monitorDirPathWithType(KZPDataTypeMemory) stringByAppendingPathComponent:@"RebootInfo.dat"];
}

- (void)flushToDisk {
    @try {
        [NSKeyedArchiver archiveRootObject:self toFile:archivePath()];
    } @catch (NSException *exception) {} @finally {}
}

- (void)resetInfosWithAppUUID:(NSString *)appUUID
                   sysVersion:(NSString *)sysVersion
             deviceLaunchTime:(uint64_t)deviceLaunchTime
{
    self.appUUID = appUUID;
    self.sysVersion = sysVersion;
    self.isAppCrashed = NO;
    self.isAppTerminateByExit = NO;
    self.isAppTerminateByUser = NO;
    self.isAppEnterBackground = NO;
    self.isAppMainThreadBlock = NO;
    self.deviceLaunchTime = deviceLaunchTime;
    [self flushToDisk];
}

#pragma mark -- NSCoding
- (void)encodeWithCoder:(NSCoder *)coder {
    [coder encodeBool:self.isAppCrashed forKey:@"isAppCrashed"];
    [coder encodeBool:self.isAppTerminateByExit forKey:@"isAppTerminateByExit"];
    [coder encodeBool:self.isAppTerminateByUser forKey:@"isAppTerminateByUser"];
    [coder encodeBool:self.isAppEnterBackground forKey:@"isAppEnterBackground"];
    [coder encodeBool:self.isAppEnterForeground forKey:@"isAppEnterForeground"];
    [coder encodeBool:self.isAppMainThreadBlock forKey:@"isAppMainThreadBlock"];
    [coder encodeObject:self.appUUID forKey:@"appUUID"];
    [coder encodeObject:self.sysVersion forKey:@"sysVersion"];
    [coder encodeInt64:self.deviceLaunchTime forKey:@"deviceLaunchTime"];

}

- (nullable instancetype)initWithCoder:(NSCoder *)coder {
    self = [super init];
    if (self) {
        self.isAppCrashed = [coder decodeBoolForKey:@"isAppCrashed"];
        self.isAppTerminateByExit = [coder decodeBoolForKey:@"isAppTerminateByExit"];
        self.isAppTerminateByUser = [coder decodeBoolForKey:@"isAppTerminateByUser"];
        self.isAppEnterBackground = [coder decodeBoolForKey:@"isAppEnterBackground"];
        self.isAppEnterForeground = [coder decodeBoolForKey:@"isAppEnterForeground"];
        self.isAppMainThreadBlock = [coder decodeBoolForKey:@"isAppMainThreadBlock"];
        self.appUUID = [coder decodeObjectForKey:@"appUUID"];
        self.sysVersion = [coder decodeObjectForKey:@"sysVersion"];
        self.deviceLaunchTime = [coder decodeInt64ForKey:@"deviceLaunchTime"];
    }
    return self;
}


@end
