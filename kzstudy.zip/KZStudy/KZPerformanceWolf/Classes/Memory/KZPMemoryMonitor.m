//
//  KZPMemoryMonitor.m
//  KZPerformanceWolf
//
//  Created by EthanDT on 2021/3/4.
//

#import "KZPMemoryMonitor.h"

static BOOL _g_isMemoryMonitoring = NO;

@implementation KZPMemoryMonitor

+ (instancetype)shareMonitor {
    static KZPMemoryMonitor * monitor = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        monitor = [[KZPMemoryMonitor alloc] init];
    });
    return monitor;
}

- (BOOL)isMonitoring {
    return _g_isMemoryMonitoring;
}

- (void)startMonitor {
    if (_g_isMemoryMonitoring) return;
    _g_isMemoryMonitoring = YES;
}

- (void)stopMonitor {
    if (!_g_isMemoryMonitoring) return;
    _g_isMemoryMonitoring = NO;
}




@end
