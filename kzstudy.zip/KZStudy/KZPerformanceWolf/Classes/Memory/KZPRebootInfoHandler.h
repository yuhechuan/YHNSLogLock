//
//  KZPRebootInfoHandler.h
//  KZPerformanceWolf
//
//  Created by EthanDT on 2021/3/5.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KZPRebootInfoHandler : NSObject <NSCoding>

@property (nonatomic, assign) BOOL isNewlyInstall;

@property (nonatomic, assign) BOOL isAppEnterForeground;

@property (nonatomic, assign) BOOL isAppEnterBackground;

@property (nonatomic, assign) BOOL isAppCrashed;

@property (nonatomic, assign) BOOL isAppTerminateByExit;

@property (nonatomic, assign) BOOL isAppTerminateByUser;

@property (nonatomic, assign) BOOL isAppMainThreadBlock;

@property (nonatomic, assign) uint64_t deviceLaunchTime;

@property (nonatomic, strong) NSString *appUUID;

@property (nonatomic, strong) NSString *sysVersion;
//must use in reboot monitor and should only craete once.
+ (instancetype)createInfoHander;

- (void)flushToDisk;

- (void)resetInfosWithAppUUID:(NSString *)appUUID
                   sysVersion:(NSString *)sysVersion
             deviceLaunchTime:(uint64_t)deviceLaunchTime;


@end

NS_ASSUME_NONNULL_END
