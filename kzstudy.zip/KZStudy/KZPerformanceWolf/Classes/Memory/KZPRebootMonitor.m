//
//  KZPRebootMonitor.m
//  KZPerformanceWolf
//
//  Created by EthanDT on 2021/3/4.
//

#import "KZPRebootMonitor.h"
#import "KZPRebootInfoHandler.h"
#import "KZPSystemEnvInfoAssistor.h"
#import "KZPGeneralMacros.h"


KZPRebootReasonDescription const KZPRebootReasonDescriptionUnknow = @"Unknow";

KZPRebootReasonDescription const KZPRebootReasonDescriptionCrash = @"Crash";

KZPRebootReasonDescription const KZPRebootReasonDescriptionMainThreadDead = @"MainThreadDead";

KZPRebootReasonDescription const KZPRebootReasonDescriptionUserKill = @"UserKill";

KZPRebootReasonDescription const KZPRebootReasonDescriptionExitSignal = @"ExitSignal";

KZPRebootReasonDescription const KZPRebootReasonDescriptionAppUpgrate = @"AppUpgrate";

KZPRebootReasonDescription const KZPRebootReasonDescriptionSystemUpgrate = @"SystemUpgrate";

KZPRebootReasonDescription const KZPRebootReasonDescriptionDeviceReboot = @"DeviceReboot";

KZPRebootReasonDescription const KZPRebootReasonDescriptionBackgroundQuit = @"BackgroundQuit";

KZPRebootReasonDescription const KZPRebootReasonDescriptionForegroundOOM = @"ForegroundOOM";

KZPRebootReasonDescription const KZPRebootReasonDescriptionNewlyInstall = @"NewlyInstall";

static BOOL _g_isRebootMonitoring = NO;

@interface KZPRebootMonitor ()

@property (nonatomic, strong) KZPRebootInfoHandler *infoHandler;

@property (nonatomic, strong) dispatch_block_t foregroundDelayBlock;

@end

@implementation KZPRebootMonitor

+ (instancetype)shareMonitor {
    static KZPRebootMonitor *monitor = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        monitor = [[KZPRebootMonitor alloc] init];
    });
    return monitor;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _reasonType = KZPRebootLastTerminateReasonUnknow;
        _reasonDescription = KZPRebootReasonDescriptionUnknow;
    }
    return self;
}

- (BOOL)isMonitoring {
    return _g_isRebootMonitoring;
}

- (void)startMonitor {
    if (_g_isRebootMonitoring) return;
    _g_isRebootMonitoring = YES;
    
    if (!self.infoHandler) {
        self.infoHandler = [KZPRebootInfoHandler createInfoHander];

        // 进入后台
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(appEnterBackground)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(appEnterBackground)
                                                     name:UIApplicationWillResignActiveNotification
                                                   object:nil];
        // 进入前台
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(appEnterForeground)
                                                     name:UIApplicationWillEnterForegroundNotification
                                                   object:nil];
        // 终止应用
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(appEnterForeground)
                                                     name:UIApplicationDidBecomeActiveNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(appTerminateByUser)
                                                     name:UIApplicationWillTerminateNotification
                                                object:nil];
        /**
         C 库函数 int atexit(void (*func)(void)) 当程序正常终止时，调用指定的函数 func。您可以在任何地方注册你的终止函数，但它会在程序终止的时候被调用。
         */
        atexit(appTerminateByExit);
        
        [self analyzeLastTerminateAppReason];
    }
}

- (void)stopMonitor {
    if (!_g_isRebootMonitoring) return;
    _g_isRebootMonitoring = NO;
}

- (void)analyzeLastTerminateAppReason {
    
    NSString *appUUID = kzp_systemInfo()[KZP_SYSTEM_APP_UUID];
    NSString *sysVersion = kzp_systemInfo()[KZP_SYSTEM_VERSION];
    uint64_t deviceLaunchTime = getDeviceLaunchTime();
    
    //newly install
    if (self.infoHandler.isNewlyInstall) {
        _reasonType = KZPRebootNewlyInstall;
        _reasonDescription = KZPRebootReasonDescriptionNewlyInstall;
        
    }else{
        //last quite
        if (self.infoHandler.isAppCrashed) {
            //app crash
            _reasonType = KZPRebootLastTerminateReasonCrash;
            _reasonDescription = KZPRebootReasonDescriptionCrash;
            
        }else if (self.infoHandler.isAppMainThreadBlock) {
            /**
             1. whatch dog kill
             2. the user can't stand freeze and kills the application manually.
             */
            _reasonType = KZPRebootLastTerminateReasonMainThreadDead;
            _reasonDescription = KZPRebootReasonDescriptionMainThreadDead;

        }else if (self.infoHandler.isAppTerminateByUser) {
            //user kill
            _reasonType = KZPRebootLastTerminateReasonUserKill;
            _reasonDescription = KZPRebootReasonDescriptionUserKill;
            
        } else if (self.infoHandler.isAppTerminateByExit) {
            //call exit()
            _reasonType = KZPRebootLastTerminateReasonExitSignal;
            _reasonDescription = KZPRebootReasonDescriptionExitSignal;

        }else if (self.infoHandler.appUUID && ![self.infoHandler.appUUID isEqualToString:appUUID]) {
            //app upgrate
            _reasonType = KZPRebootLastTerminateReasonAppUpgrate;
            _reasonDescription = KZPRebootReasonDescriptionAppUpgrate;

        }else if (self.infoHandler.sysVersion && ![self.infoHandler.sysVersion isEqualToString:sysVersion]){
            //sys upgrate
            _reasonType = KZPRebootLastTerminateReasonSystemUpgrate;
            _reasonDescription = KZPRebootReasonDescriptionSystemUpgrate;

        }else if (self.infoHandler.deviceLaunchTime > 0 && deviceLaunchTime > self.infoHandler.deviceLaunchTime) {
            //device reboot
            _reasonType = KZPRebootLastTerminateReasonDeviceReboot;
            _reasonDescription = KZPRebootReasonDescriptionDeviceReboot;
            
        }else if (self.infoHandler.isAppEnterBackground) {
            /**
             1. background oom
             2. user kill in background
             */
            _reasonType = KZPRebootLastTerminateReasonBackgroundQuit;
            _reasonDescription = KZPRebootReasonDescriptionBackgroundQuit;

        }else if (self.infoHandler.isAppEnterForeground) {
            /**
             1. foreground oom
             2. boot silently in the background and stay for more than 1 second.
             3. crash occurred, but the crash message was not captured.
             */
            _reasonType = KZPRebootLastTerminateReasonForegroundOOM;
            _reasonDescription = KZPRebootReasonDescriptionForegroundOOM;
            
        }else{
            //unknow
        }
    }

    [self.infoHandler resetInfosWithAppUUID:appUUID
                                 sysVersion:sysVersion
                           deviceLaunchTime:deviceLaunchTime];
}

- (void)appEnterBackground {
    if (self.foregroundDelayBlock) {
        /**
         In order to ensure the accuracy of the app state,
         we should cancel foreground block when enter background.
         */
        dispatch_block_cancel(self.foregroundDelayBlock);
        self.foregroundDelayBlock = nil;
    }
    self.infoHandler.isAppEnterBackground = YES;
    self.infoHandler.isAppEnterForeground = NO;
    [self.infoHandler flushToDisk];
}

- (void)appEnterForeground {

    self.foregroundDelayBlock = dispatch_block_create(DISPATCH_BLOCK_NO_QOS_CLASS, ^{
        self.infoHandler.isAppEnterBackground = NO;
        self.infoHandler.isAppEnterForeground = YES;
        [self.infoHandler flushToDisk];
    });
    //delay modify app status because of silent push.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), self.foregroundDelayBlock);
}

- (void)appTerminateByUser {
    self.infoHandler.isAppTerminateByUser = YES;
    [self.infoHandler flushToDisk];
}

// C 库函数 int atexit(void (*func)(void)) 当程序正常终止时，调用指定的函数 func。您可以在任何地方注册你的终止函数，但它会在程序终止的时候被调用。
void appTerminateByExit() {
    [[KZPRebootMonitor shareMonitor] setAppTerminateByExit];
}

- (void)setAppTerminateByExit {
    self.infoHandler.isAppTerminateByExit = YES;
    [self.infoHandler flushToDisk];
}

- (void)appTerminateByCrash {
    if (!_g_isRebootMonitoring) return;
    self.infoHandler.isAppCrashed = YES;
    [self.infoHandler flushToDisk];
}

- (void)appForegroundMainThreadBlock:(BOOL)isBlock {
    if (!_g_isRebootMonitoring) return;

    static BOOL last = NO;
    if (last != isBlock) {
        last = isBlock;
        self.infoHandler.isAppMainThreadBlock = isBlock;
        [self.infoHandler flushToDisk];
    }
}

static uint64_t getDeviceLaunchTime (void){
    NSTimeInterval time = [NSProcessInfo processInfo].systemUptime;
    NSDate *curDate = [[NSDate alloc] init];
    NSDate *startTime = [curDate dateByAddingTimeInterval:-time];
    return [startTime timeIntervalSince1970];
}

@end
