//
//  KZPRebootMonitor.h
//  KZPerformanceWolf
//
//  Created by EthanDT on 2021/3/4.
//

#import <Foundation/Foundation.h>
#import "KZPGeneralComponents.h"

NS_ASSUME_NONNULL_BEGIN

typedef NSString * KZPRebootReasonDescription;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionUnknow;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionCrash;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionMainThreadDead;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionUserKill;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionExitSignal;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionAppUpgrate;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionSystemUpgrate;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionDeviceReboot;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionBackgroundQuit;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionForegroundOOM;

extern KZPRebootReasonDescription const KZPRebootReasonDescriptionNewlyInstall;


typedef NS_ENUM(NSInteger, KZPRebootLastTerminateReasonType) {
    KZPRebootLastTerminateReasonUnknow = 0,
    //app crash
    KZPRebootLastTerminateReasonCrash,
    /**
     1. whatch dog kill
     2. the user can't stand freeze and kills the application manually.
     */
    KZPRebootLastTerminateReasonMainThreadDead,
    //user kill
    KZPRebootLastTerminateReasonUserKill,
    //call exit()
    KZPRebootLastTerminateReasonExitSignal,
    //app upgrate
    KZPRebootLastTerminateReasonAppUpgrate,
    //sys upgrate
    KZPRebootLastTerminateReasonSystemUpgrate,
    //device reboot
    KZPRebootLastTerminateReasonDeviceReboot,
    /**
     1. background oom
     2. user kill in background
     */
    KZPRebootLastTerminateReasonBackgroundQuit,
    /**
     1. foreground oom
     2. boot silently in the background and stay for more than 1 second.
     3. crash occurred, but the crash message was not captured.
     */
    KZPRebootLastTerminateReasonForegroundOOM,
    //newly install
    KZPRebootNewlyInstall,
};

@interface KZPRebootMonitor : NSObject <KZPerformanceMonitorProtocol>

@property (nonatomic, assign, readonly) KZPRebootLastTerminateReasonType reasonType;

@property (nonatomic, strong, readonly) KZPRebootReasonDescription reasonDescription;

- (void)appTerminateByCrash;

- (void)appForegroundMainThreadBlock:(BOOL)isBlock;

@end

NS_ASSUME_NONNULL_END
