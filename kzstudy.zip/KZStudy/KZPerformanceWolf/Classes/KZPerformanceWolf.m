//
//  KZPerformanceWolf.m
//  KZPerformanceWolf
//
//  Created by Yaping Liu on 3/11/19.
//

#import "KZPerformanceWolf.h"


static KZPerformanceType _g_crurrentMonitorTypes;

inline static NSDictionary * monitorClassesDic(void) {
     return @{
        @(KZPerformanceNetwork) : @"KZPInterfaceNetworkMonitor",
        @(KZPerformanceCrash) : @"KZPCrashMonitor",
        @(KZPerformanceFreeze) : @"KZPFreezeMonitor",
      };
}


BOOL kzp_monitorState(void){

    if (_g_crurrentMonitorTypes != KZPerformanceNone) {
        return YES;
    }
    return NO;
}

static void setMonitorState(BOOL enable) {
    NSDictionary *clssesDic = monitorClassesDic();
    for (NSNumber *typeKey in clssesDic) {
        NSUInteger type = [typeKey unsignedIntegerValue];
        if (_g_crurrentMonitorTypes & type) {
            Class monitorClass = NSClassFromString(clssesDic[typeKey]);
            if ([monitorClass conformsToProtocol:@protocol(KZPerformanceMonitorProtocol)]){
                if (enable) {
                    [[monitorClass shareMonitor] startMonitor];
                }else{
                    [[monitorClass shareMonitor] stopMonitor];
                }
            }
        }
    }
}

void kzp_startMonitor(KZPerformanceType options) {
    if (kzp_monitorState()) return;
    _g_crurrentMonitorTypes = options;

    setMonitorState(YES);
    [[KZPerformanceDataCenter shareDataCenter] enableControllerBacktrace];
}

void kzp_stopMonitor(void) {
    if (!kzp_monitorState())  return;

    setMonitorState(NO);
    
    _g_crurrentMonitorTypes = KZPerformanceNone;

}



