//
//  NSString+Extension.m
//  iTrends
//
//  Created by wujin on 12-7-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "NSString+KZExtension.h"
#import <CommonCrypto/CommonDigest.h>
#include <sys/stat.h>
#include <dirent.h>

NSString * const kStringsNotNullAndEmptyEnd = @"kStringsNotNullAndEmptyEnd";

@implementation NSString (KZExtension)

+ (NSString *)tokenString:(NSData *)data {
    NSUInteger dataLength = data.length;
    if (dataLength == 0) {
        return nil;
    }
    
    const unsigned char *dataBuffer = data.bytes;
    NSMutableString *hexString  = [NSMutableString stringWithCapacity:(dataLength * 2)];
    for (int i = 0; i < dataLength; ++i) {
        [hexString appendFormat:@"%02x", dataBuffer[i]];
    }
    return [hexString copy];
}

+ (CGRect)heightForString:(NSString*)str Size:(CGSize)size Font:(UIFont*)font {
    return [NSString heightForString:str Size:size Font:font Lines:0];
}

+ (CGRect)heightForString:(NSString*)str Size:(CGSize)size Font:(UIFont*)font Lines:(NSInteger)lines {
    if (StringIsNullOrEmpty(str)) {
        return CGRectMake(0, 0, 0, 0);
    }
    static UILabel *lbtext;
    if (lbtext == nil) {
        lbtext = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    } else {
        lbtext.frame = CGRectMake(0, 0, size.width, size.height);
    }
    lbtext.font = font;
    lbtext.text = str;
    lbtext.numberOfLines = lines;
    CGRect rect = [lbtext textRectForBounds:lbtext.frame limitedToNumberOfLines:lines];
    if (rect.size.height < 0 ) rect.size.height = 0;
    if (rect.size.width < 0) rect.size.width = 0;
    return rect;
}

// 判断字符串是否包含指定字符串
- (BOOL)isContainString:(NSString*)str {
    NSRange range = [self rangeOfString:str];
    return (range.location == NSNotFound ? NO : YES);
}

- (BOOL)contains:(NSString *)piece {
    return ( [self rangeOfString:piece].location != NSNotFound );
}

// 返回字符串经过md5加密后的字符
+ (NSString *)stringDecodingByMD5:(NSString*)str {
    NSData* data = [str dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char result[32];
    CC_MD5( data.bytes, (CC_LONG)data.length, result );
    return [NSString stringWithFormat:
            @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}

- (NSString *)md5DecodingString {
    return [NSString stringDecodingByMD5:self];
}

- (NSString *)md5StringFor16 {
    NSString *md5Str = [NSString stringDecodingByMD5:self];
    if (md5Str) {
        return [md5Str substringWithRange:NSMakeRange(8, 16)];
    }
    return nil;
}


+ (NSString *)base64Decode:(NSString *)string {
    unsigned long ixtext, lentext;
    unsigned char ch, inbuf[4], outbuf[4];
    short i, ixinbuf;
    Boolean flignore, flendtext = false;
    const unsigned char *tempcstring;
    NSMutableData *theData;
    
    if (string == nil) {
        return nil;
    }
    
    ixtext = 0;
    
    tempcstring = (const unsigned char *)[string UTF8String];
    
    lentext = [string length];
    
    theData = [NSMutableData dataWithCapacity: lentext];
    
    ixinbuf = 0;
    
    while (true) {
        if (ixtext >= lentext){
            break;
        }
        
        ch = tempcstring [ixtext++];
        
        flignore = false;
        
        if ((ch >= 'A') && (ch <= 'Z')) {
            ch = ch - 'A';
        } else if ((ch >= 'a') && (ch <= 'z')) {
            ch = ch - 'a' + 26;
        } else if ((ch >= '0') && (ch <= '9')) {
            ch = ch - '0' + 52;
        } else if (ch == '+') {
            ch = 62;
        } else if (ch == '=') {
            flendtext = true;
        } else if (ch == '/') {
            ch = 63;
        } else {
            flignore = true;
        }
        
        if (!flignore) {
            short ctcharsinbuf = 3;
            Boolean flbreak = false;
            
            if (flendtext) {
                if (ixinbuf == 0) {
                    break;
                }
                
                if ((ixinbuf == 1) || (ixinbuf == 2)) {
                    ctcharsinbuf = 1;
                } else {
                    ctcharsinbuf = 2;
                }
                
                ixinbuf = 3;
                
                flbreak = true;
            }
            
            inbuf [ixinbuf++] = ch;
            
            if (ixinbuf == 4) {
                ixinbuf = 0;
                
                outbuf[0] = (inbuf[0] << 2) | ((inbuf[1] & 0x30) >> 4);
                outbuf[1] = ((inbuf[1] & 0x0F) << 4) | ((inbuf[2] & 0x3C) >> 2);
                outbuf[2] = ((inbuf[2] & 0x03) << 6) | (inbuf[3] & 0x3F);
                
                for (i = 0; i < ctcharsinbuf; i++) {
                    [theData appendBytes: &outbuf[i] length: 1];
                }
            }
            
            if (flbreak) {
                break;
            }
        }
    }
    
    return [[NSString alloc] initWithData:theData encoding:NSUTF8StringEncoding];// theData;
}

+ (NSData *)base64_Decode:(NSString *)string {
    unsigned long ixtext, lentext;
    unsigned char ch, inbuf[4], outbuf[4];
    short i, ixinbuf;
    Boolean flignore, flendtext = false;
    const unsigned char *tempcstring;
    NSMutableData *theData;
    
    if (string == nil) {
        return nil;
    }
    
    ixtext = 0;
    
    tempcstring = (const unsigned char *)[string UTF8String];
    
    lentext = [string length];
    
    theData = [NSMutableData dataWithCapacity: lentext];
    
    ixinbuf = 0;
    
    while (true) {
        if (ixtext >= lentext){
            break;
        }
        
        ch = tempcstring [ixtext++];
        
        flignore = false;
        
        if ((ch >= 'A') && (ch <= 'Z')) {
            ch = ch - 'A';
        } else if ((ch >= 'a') && (ch <= 'z')) {
            ch = ch - 'a' + 26;
        } else if ((ch >= '0') && (ch <= '9')) {
            ch = ch - '0' + 52;
        } else if (ch == '+') {
            ch = 62;
        } else if (ch == '=') {
            flendtext = true;
        } else if (ch == '/') {
            ch = 63;
        } else {
            flignore = true;
        }
        
        if (!flignore) {
            short ctcharsinbuf = 3;
            Boolean flbreak = false;
            
            if (flendtext) {
                if (ixinbuf == 0) {
                    break;
                }
                
                if ((ixinbuf == 1) || (ixinbuf == 2)) {
                    ctcharsinbuf = 1;
                } else {
                    ctcharsinbuf = 2;
                }
                
                ixinbuf = 3;
                
                flbreak = true;
            }
            
            inbuf [ixinbuf++] = ch;
            
            if (ixinbuf == 4) {
                ixinbuf = 0;
                
                outbuf[0] = (inbuf[0] << 2) | ((inbuf[1] & 0x30) >> 4);
                outbuf[1] = ((inbuf[1] & 0x0F) << 4) | ((inbuf[2] & 0x3C) >> 2);
                outbuf[2] = ((inbuf[2] & 0x03) << 6) | (inbuf[3] & 0x3F);
                
                for (i = 0; i < ctcharsinbuf; i++) {
                    [theData appendBytes: &outbuf[i] length: 1];
                }
            }
            
            if (flbreak) {
                break;
            }
        }
    }
    
    return theData;// theData;
}

- (NSString *)base64Decode {
    return [NSString base64Decode:self];
}

+ (NSString *)base64Encode:(NSData *)data {
    static char base64EncodingTable[64] = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
    };
    int length = (int)[data length];
    unsigned long ixtext, lentext;
    long ctremaining;
    unsigned char input[3], output[4];
    short i, charsonline = 0, ctcopy;
    const unsigned char *raw;
    NSMutableString *result;
    
    lentext = [data length];
    if (lentext < 1)
        return @"";
    result = [NSMutableString stringWithCapacity: lentext];
    raw = [data bytes];
    ixtext = 0;
    
    while (true) {
        ctremaining = lentext - ixtext;
        if (ctremaining <= 0)
            break;
        for (i = 0; i < 3; i++) {
            unsigned long ix = ixtext + i;
            if (ix < lentext)
                input[i] = raw[ix];
            else
                input[i] = 0;
        }
        output[0] = (input[0] & 0xFC) >> 2;
        output[1] = ((input[0] & 0x03) << 4) | ((input[1] & 0xF0) >> 4);
        output[2] = ((input[1] & 0x0F) << 2) | ((input[2] & 0xC0) >> 6);
        output[3] = input[2] & 0x3F;
        ctcopy = 4;
        switch (ctremaining) {
            case 1:
                ctcopy = 2;
                break;
            case 2:
                ctcopy = 3;
                break;
        }
        
        for (i = 0; i < ctcopy; i++)
            [result appendString: [NSString stringWithFormat: @"%c", base64EncodingTable[output[i]]]];
        
        for (i = ctcopy; i < 4; i++)
            [result appendString: @"="];
        
        ixtext += 3;
        charsonline += 4;
        
        if ((length > 0) && (charsonline >= length))
            charsonline = 0;
    }
    return result;
}

- (NSString *)base64Encode {
    return [NSString base64Encode:[self dataUsingEncoding:NSUTF8StringEncoding]];
}


- (NSString *)trimString {
    NSString *newString = nil;
    
    if (StringNotNullAndEmpty(self)) {
        newString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    if (StringIsNullOrEmpty(newString)) {
        newString = @"";
    }
    return newString;
}

- (NSString *)trim {
    return [self trimString];
}


- (id)objectFromJSONString {
    @try {
         return [NSJSONSerialization JSONObjectWithData:[self dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:nil];
    }
    @catch (NSException *exception) {
        return nil;
    }

}

- (NSComparisonResult)floatCompare:(NSString*)other {
    float myValue = [self floatValue];
    float otherValue= [other floatValue];
    if(myValue == otherValue) return NSOrderedSame;
    return (myValue < otherValue ? NSOrderedAscending : NSOrderedDescending);
}

- (NSString*)urlEncodedString {
    CFStringRef encodedCFString = CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                          (__bridge CFStringRef) self,
                                                                          nil,
                                                                          CFSTR("?!@#$^&%*+,:;='\"`<>()[]{}/\\| "),
                                                                          kCFStringEncodingUTF8);
    if (encodedCFString) {
        NSString *encodedString = [[NSString alloc] initWithString:(__bridge_transfer NSString*)encodedCFString];
        if(encodedString) {
            return encodedString;
        }
    }
    
    return @"";
}

- (NSString*)urlDecodedString {
    CFStringRef decodedCFString = CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault,
                                                                                          (__bridge CFStringRef) self,
                                                                                          CFSTR(""),
                                                                                          kCFStringEncodingUTF8);
    if (decodedCFString) {
        NSString *decodedString = [[NSString alloc] initWithString:(__bridge_transfer NSString*)decodedCFString];
        if (decodedString) {
            decodedString = [decodedString stringByReplacingOccurrencesOfString:@"+" withString:@" "];
            decodedString = [decodedString stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
            return decodedString;
        }
    }
    
    return @"";
}

+ (NSString*)urlEncodedKeyValueString:(NSDictionary *)dict {
    NSMutableString *string = [NSMutableString string];
    for (NSString *key in dict) {
        NSObject *value = [dict valueForKey:key];
        if([value isKindOfClass:[NSString class]]) {
            [string appendFormat:@"%@=%@&", [key urlEncodedString], [((NSString*)value) urlEncodedString]];
        } else {
            [string appendFormat:@"%@=%@&", [key urlEncodedString], value];
        }
    }
    
    if ([string length] > 0) {
        [string deleteCharactersInRange:NSMakeRange([string length] - 1, 1)];
    }
    return string;
}

- (BOOL)hasChinese {
    for(int i = 0; i < [self length]; i++) {
        int a = [self characterAtIndex:i];
        if(a > 0x4e00 && a < 0x9fff){
            return YES;
        }
    }
    return NO;
}

@end

@implementation NSString (KZExtension_Regular)

- (NSMutableArray *)itemsForPattern:(NSString *)pattern {
    return [self itemsForPattern:pattern captureGroupIndex:0];
}

- (NSMutableArray *)itemsForPattern:(NSString *)pattern captureGroupIndex:(NSUInteger)index {
    if ( !pattern )
        return nil;
    
    NSError *error = nil;
    NSRegularExpression *regx = [[NSRegularExpression alloc] initWithPattern:pattern
                                                                     options:NSRegularExpressionCaseInsensitive error:&error];
    if (error) {
        NSLog(@"Error for create regular expression:\nString: %@\nPattern %@\nError: %@\n", self, pattern, error);
    } else {
        NSMutableArray *results = [[NSMutableArray alloc] init];
        NSRange searchRange = NSMakeRange(0, [self length]);
        __weak __typeof(self)weakSelf = self;
        [regx enumerateMatchesInString:self options:0 range:searchRange usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop) {
            NSRange groupRange;
            NSUInteger rangNumber = [result numberOfRanges];
            if (index >= rangNumber) {
                groupRange =  result.range;
            } else {
                groupRange =  [result rangeAtIndex:index];
            }
            NSString *match = [weakSelf substringWithRange:groupRange];
            [results addObject:match];
        }];
        return results;
    }
    return nil;
}

- (NSString *)itemForPattern:(NSString *)pattern {
    return [self itemForPattern:pattern captureGroupIndex:0];
}

- (NSString *)itemForPattern:(NSString *)pattern captureGroupIndex:(NSUInteger)index {
    if ( !pattern )
        return nil;
    
    NSError *error = nil;
    NSRegularExpression *regx = [[NSRegularExpression alloc] initWithPattern:pattern
                                                                     options:NSRegularExpressionCaseInsensitive error:&error];
    if (error) {
        NSLog(@"Error for create regular expression:\nString: %@\nPattern %@\nError: %@\n", self, pattern, error);
    } else {
        NSRange searchRange = NSMakeRange(0, [self length]);
        NSTextCheckingResult *result = [regx firstMatchInString:self options:0 range:searchRange];
        NSRange groupRange;
        NSUInteger rangNumber = [result numberOfRanges];
        if (index >= rangNumber) {
            groupRange =  result.range;
        } else {
            groupRange =  [result rangeAtIndex:index];
        }
        NSString *match = [self substringWithRange:groupRange];
        return match;
    }
    
    return nil;
}

@end
