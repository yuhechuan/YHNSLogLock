//
//  UIView+BZAnimation.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/31.
//

#import <UIKit/UIKit.h>

@interface UIView (BZAnimation)

@property (nonatomic, assign, readonly) BOOL isAnimating;

@end
