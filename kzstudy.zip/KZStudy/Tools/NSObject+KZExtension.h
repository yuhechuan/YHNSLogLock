//
//  NSObject+Extention.h
//  iTrends
//
//  Created by wujin on 12-8-29.
//
//

#import <UIKit/UIKit.h>

/** 申明一个 block_self 的指针，指向自身，以用于在block中使用
 */
#if __has_feature(objc_arc)
#define IMP_BLOCK_SELF(type) __weak type *block_self=self;
#else
#define IMP_BLOCK_SELF(type) __block type *block_self=self;
#endif

#define IMP_STRONG_SELF(weakSelf) __strong __typeof(weakSelf) strong_self = weakSelf;

@interface NSObject (KZExtension)

/// 设置关联的一个对象
- (void)setAssociatedObjectRetain:(id)object;

/// 获取通过- setAssociatedObjectRetain:方法关联的对象
- (id)associatedObjectRetain;

/// 将对象转换为josn串
- (NSString *)JSONString;
/// 添加观察者
- (void)addRunLoopObserver;

@end
