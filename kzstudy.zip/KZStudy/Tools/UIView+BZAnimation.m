//
//  UIView+BZAnimation.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/31.
//

#import "UIView+BZAnimation.h"

@implementation UIView (BZAnimation)

/// 是否正在动画中
- (BOOL)isAnimating {
    if (!CGRectEqualToRect([self.layer modelLayer].frame, [self.layer presentationLayer].frame)) {
        return YES;
    }
    return NO;
}

@end
