//
//  NSObject+Extention.m
//  iTrends
//
//  Created by wujin on 12-8-29.
//
//

#import "NSObject+KZExtension.h"
#import <objc/runtime.h>
#import "KZPGeneralComponents.h"

static char kAssociatedObjectRetainKey;

@implementation NSObject (KZExtension)

- (void)setAssociatedObjectRetain:(id)object {
    objc_setAssociatedObject(self, &kAssociatedObjectRetainKey, object, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (id)associatedObjectRetain {
    return objc_getAssociatedObject(self, &kAssociatedObjectRetainKey);
}

- (NSString *)JSONString {
    NSString *result = @"";
    
    @try {
        if ([NSJSONSerialization isValidJSONObject:self]) {
            NSError * error = nil;
            NSData *data = [NSJSONSerialization dataWithJSONObject:self options:0 error:&error];
            if (data && error == nil) {
                result = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            } else {
                @throw [NSException exceptionWithName:@"Error" reason:@"Error Data To JSONString" userInfo:nil];
            }
        } else {
            @throw [NSException exceptionWithName:@"InVaild" reason:@"InValid Object To JSONString" userInfo:nil];
        }
    }
    @catch (NSException *exception) {
        NSCAssert(NO, exception.reason);
    }
    
    return result;
}

- (void)addRunLoopObserver {
    CFRunLoopRef mainRunloop = CFRunLoopGetMain();
    //start
    CFRunLoopObserverRef commonStartObs = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, kCFRunLoopAllActivities, YES, LONG_MAX, ^(CFRunLoopObserverRef observer, CFRunLoopActivity activity) {
        NSLog(@"%@", kzp_runloopActivityMapString(activity));
    });
    CFRetain(commonStartObs);
    CFRunLoopAddObserver(mainRunloop, commonStartObs, kCFRunLoopCommonModes);
}

@end
