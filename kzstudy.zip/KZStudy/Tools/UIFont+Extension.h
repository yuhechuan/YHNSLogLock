//
//  UIFont+Extension.h
//  iTrends
//
//  Created by wujin on 12-6-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 返回指定大小的系统字体
 */
#define F_S(size) [UIFont systemFontOfSize:size]

@interface UIFont (Extension)

+ (UIFont *)CustomFontGBKSize:(float)size;

///苹方 普通
+ (UIFont *)PSCFontSize:(float)size;
///苹方 粗
+ (UIFont *)PSCBoldFontSize:(float)size;
///苹方 中粗
+ (UIFont *)PSCMediumFontSize:(float)size;
///苹方 细
+ (UIFont *)PSCLightFontSize:(float)size;
///看准字体
+ (UIFont *)KZRegularFontSize:(float)size;

@end

