//
//  UIFont+Extension.m
//  iTrends
//
//  Created by wujin on 12-6-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIFont+Extension.h"

@implementation UIFont (Extension)

+ (UIFont *)CustomFontGBKSize:(float)size {
    //iOS8暂时没有苹方字体
    return [UIFont systemFontOfSize:size];
    //    return [UIFont fontWithName:@"PingFang SC" size:size];
}

+ (UIFont *)PSCFontSize:(float)size {
    if (@available(iOS 9.0, *)) {
        UIFont *font = [UIFont fontWithName:@"PingFangSC-Regular" size:size];
        if (font) {
            return font;
        }
    }
    return [UIFont systemFontOfSize:size];
}

+ (UIFont *)PSCBoldFontSize:(float)size {
    if (@available(iOS 9.0, *)) {
        UIFont *font = [UIFont fontWithName:@"PingFangSC-Semibold" size:size];
        if (font) {
            return font;
        }
    }
    
    return [UIFont boldSystemFontOfSize:size];
    
}

+ (UIFont *)PSCMediumFontSize:(float)size {
    if (@available(iOS 9.0, *)) {
        UIFont *font = [UIFont fontWithName:@"PingFangSC-Medium" size:size];
        if (font) {
            return font;
        }
    }
    return [UIFont boldSystemFontOfSize:size];
    
}

+ (UIFont *)PSCLightFontSize:(float)size {
    if (@available(iOS 9.0, *)) {
        UIFont *font = [UIFont fontWithName:@"PingFangSC-Light" size:size];
        if (font) {
            return font;
        }
    } else {
        if (@available(iOS 8.2, *)) {
            return [UIFont systemFontOfSize:size weight:UIFontWeightLight];
        }
    }
    
    return [UIFont systemFontOfSize:size];
}

///看准字体
+ (UIFont *)KZRegularFontSize:(float)size {
    UIFont *font = [UIFont fontWithName:@"kanzhun" size:size];
    if (font) {
        return font;
    }
    return [UIFont boldSystemFontOfSize:size];
}

@end

