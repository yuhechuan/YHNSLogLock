//
//  UINavigationController+Animated.h
//  KZStudy
//
//  Created by yuhechuan on 2021/9/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UINavigationController (Animated)

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated completion: (void (^)(void))completion;

@end

NS_ASSUME_NONNULL_END
