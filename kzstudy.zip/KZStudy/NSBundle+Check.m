//
//  NSBundle+Check.m
//  KZStudy
//
//  Created by yuhechuan on 2022/1/4.
//

#import "NSBundle+Check.h"
#import <objc/runtime.h>

@implementation NSBundle (Check)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self swizzleSessionDelegateConfig];
    });
}

+ (void)swizzleSessionDelegateConfig {
    Class sessionClass = NSBundle.class;
    Class originMetaClass = objc_getMetaClass(class_getName(sessionClass));

    SEL originSelector = @selector(bundleWithPath:);
    SEL proxySelector =  @selector(yh_bundleWithPath:);
    
    Method originMethod = class_getClassMethod(originMetaClass, originSelector);
    Method proxyMethod = class_getClassMethod(originMetaClass, proxySelector);
    
    if (!originMethod || !proxyMethod) return;
    method_exchangeImplementations(originMethod, proxyMethod);
}

+ (instancetype)yh_bundleWithPath:(NSString *)path {
    NSBundle *b = [self yh_bundleWithPath:path];
    if (b) {
        return b;
    }
    path = @"写死的";
    return [self yh_bundleWithPath:path];
}


@end
