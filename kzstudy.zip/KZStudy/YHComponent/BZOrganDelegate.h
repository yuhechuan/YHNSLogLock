//
//  BZOrganDelegate.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/11.
//

#ifndef BZOrganDelegate_h
#define BZOrganDelegate_h
#import "BZOrganDispatcher.h"

@class BZBaseOrgan;

typedef void (^BZOrganNetRequestResponse)(NSError* error, NSDictionary *responseObject);

@protocol BZOrganNetInfo <NSObject>

- (NSString *)organNetInfoPath;
- (NSDictionary *)organNetInfoParam;

@end

@protocol BZOrganViewNode <NSObject>
/**
 * 如果没有绑定 相应的model 这个方法的参数是 nil
 */
- (void)refresh:(BZBaseOrgan *)model;
/**
 * 给业务绑定特定的类型
 */
- (Class)dataOrganClass;

@end

@protocol BZOrganNetRequest <NSObject>

- (void)makeBatchRequest:(NSArray <id<BZOrganNetInfo>>*)batchInfos
                response:(BZOrganNetRequestResponse)response;

- (NSDictionary *)requestBackHandle:(NSDictionary *)responseObject netInfo:(id<BZOrganNetInfo>)netInfo;

@end


#endif /* BZOrganDelegate_h */
