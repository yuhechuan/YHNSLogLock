//
//  BZBaseOrganViewController.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/15.
//

#import <UIKit/UIKit.h>
#import "BZOrganDelegate.h"

@class BZBaseOrgan;

@interface BZBaseOrganViewController : UIViewController<BZOrganViewNode>

@property (nonatomic, strong) BZOrganDispatcher *dispatcher;

@end
