//
//  BZBaseOrganView.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/15.
//

#import "BZBaseOrganView.h"
#import "BZBaseOrgan.h"
#import "BZBaseOrganViewController.h"

@interface BZBaseOrganView ()

@property (nonatomic, weak, readwrite) BZOrganDispatcher *dispatcher;

@end

@implementation BZBaseOrganView

- (void)refresh:(BZBaseOrgan *)model {
    /// 子类实现
}

- (Class)dataOrganClass {
    return NULL;
}


- (BZOrganDispatcher *)dispatcher {
    if (!_dispatcher) {
        UIResponder *responder = self.nextResponder;
        while (responder) {
            if ([responder isKindOfClass:[BZBaseOrganViewController class]]) {
                BZBaseOrganViewController *vc = (BZBaseOrganViewController *)responder;
                _dispatcher = vc.dispatcher;
                break;
            }
            responder = responder.nextResponder;
        }
    }
    return _dispatcher;
}

@end
