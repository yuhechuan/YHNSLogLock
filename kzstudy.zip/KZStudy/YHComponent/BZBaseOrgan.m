//
//  BZBaseOrgan.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/11.
//

#import "BZBaseOrgan.h"

@implementation BZBaseOrgan

- (instancetype)init {
    if (self = [super init]) {
        _dirty = YES;
    }
    return self;
}

- (NSArray <id<BZOrganNetInfo>>*)organNetInfoList {
    return @[];
}

- (void)beforeRequest {
    
}

- (void)backNetInfo:(id<BZOrganNetInfo>)netInfo infoDict:(NSDictionary *)infoDict {
    /// 子类实现  如果没有配置
}

- (void)finishAllRequest {
    
}

- (NSArray <Class>*)childOrgans {
    return @[];
}

@end
