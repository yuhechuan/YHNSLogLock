//
//  BZStore.m
//  BZBoss
//
//  Created by yuhechuan on 2022/11/17.
//

#import "BZStore.h"

@interface BZStore ()

@property (nonatomic, strong) NSMutableDictionary *storeMap;
@property (nonatomic, strong) NSMutableSet *storeSet;

@end

@implementation BZStore

/**
 * 添加事件类型（整数）
 */
- (void)addQuery:(int)queryType {
    [self.storeSet addObject:@(queryType)];
}
/**
 * 查找事件类型(整数)
 */
- (BOOL)findQueryType:(int)queryType {
    return [self.storeSet containsObject:@(queryType)];
}
/**
 * 添加、更新自定义数据
 * 建议cls是obj的类的class
 */
- (void)storeValue:(id)value storeClass:(Class)storeClass{
    if (!value || storeClass == NULL) {
        return;
    }
    NSString *clsName = NSStringFromClass(storeClass);
    if ([self isEmptyString:clsName]) {
        return;
    }
    self.storeMap[clsName] = value;
}
/**
 * 获取自定义数据
 */
- (id)valueWithStoreClass:(Class)storeClass {
    if (storeClass == NULL) {
        return nil;
    }
    NSString *clsName = NSStringFromClass(storeClass);
    if ([self isEmptyString:clsName]) {
        return nil;
    }
    return self.storeMap[clsName];
}

- (NSMutableDictionary *)storeMap {
    if (!_storeMap) {
        _storeMap = [NSMutableDictionary dictionary];
    }
    return _storeMap;
}

- (NSMutableSet *)storeSet {
    if (!_storeSet) {
        _storeSet = [NSMutableSet set];
    }
    return _storeSet;
}

- (BOOL)isEmptyString:(NSString *)str {
    return ((NSNull *)str == [NSNull null] || str == nil || ![str isKindOfClass:[NSString class]] || [str isEqualToString:@""]);
}

@end
