//
//  BZBaseOrganViewController.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/15.
//

#import "BZBaseOrganViewController.h"

@interface BZBaseOrganViewController ()

@end

@implementation BZBaseOrganViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (void)refresh:(BZBaseOrgan *)model {
}

/**
 * 给业务绑定特定的类型
 */
- (Class)dataOrganClass {
    return NULL;
}



- (BZOrganDispatcher *)dispatcher {
    if (!_dispatcher) {
        _dispatcher = [[BZOrganDispatcher alloc]initWithController:self];
    }
    return _dispatcher;
}

@end
