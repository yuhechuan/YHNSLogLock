//
//  BZOrganDispatcher.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/11.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class BZBaseOrgan;

@interface BZOrganDispatcher : NSObject
/**
 * 初始化
 */
- (instancetype)initWithController:(UIViewController *)controller;
/**
 * 开始业务的请求
 */
- (void)beginRequestWithResultBlock:(void (^)(NSError *error, NSDictionary *response))resultBlock;
/**
 * 通过一个自定义view读取与其相关的模型
 */
- (BZBaseOrgan *)readOrganForClass:(Class)nodeClass;


@end
