//
//  BZOrganDispatcher.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/11.
//

#import "BZOrganDispatcher.h"
#import "BZOrganDelegate.h"
#import "BZBaseOrgan.h"
#import "BZOrganConfig.h"

@interface BZOrganDispatcher ()

@property (nonatomic, strong) NSMutableDictionary <NSString *, BZBaseOrgan *>*organCache;
@property (nonatomic, strong) NSMutableDictionary <NSString *, id<BZOrganViewNode>>*nodeViewCache;
@property (nonatomic, weak) UIViewController *controller;

@end

@implementation BZOrganDispatcher

- (instancetype)initWithController:(UIViewController *)controller {
    if (self = [super init]) {
        self.controller = controller;
    }
    return self;
}

- (void)initializeDispatcher {
    if (!self.controller) {
        return;
    }
    [self.organCache removeAllObjects];
    [self.nodeViewCache removeAllObjects];
    
    if ([self.controller conformsToProtocol:@protocol(BZOrganViewNode)]) {
        id<BZOrganViewNode> node = (id<BZOrganViewNode>)self.controller;
        if ([node respondsToSelector:@selector(refresh:)]) {
            NSString *key = NSStringFromClass([node class]);
            self.nodeViewCache[key] = node;
        }
    }
    NSMutableArray *stack = [NSMutableArray array];
    [stack addObject:self.controller.view];
    while (stack.count > 0) {
        UIView *v = stack.firstObject;
        [stack removeObjectAtIndex:0];
        if ([v conformsToProtocol:@protocol(BZOrganViewNode)]) {
            id<BZOrganViewNode> node = (id<BZOrganViewNode>)v;
            NSString *key = NSStringFromClass([node class]);
            if ([node respondsToSelector:@selector(refresh:)]) {
                self.nodeViewCache[key] = node;
            }
            
            if ([node respondsToSelector:@selector(dataOrganClass)]) {
                Class organClass = [node dataOrganClass];
                if (organClass && organClass != NULL && [organClass isKindOfClass:[BZBaseOrgan class]]) {
                    BZBaseOrgan *organ = [[organClass alloc]init];
                    organ.key = key;
                    organ.controller = self.controller;
                    self.organCache[key] = organ;
                }
            }
        }
        [stack addObjectsFromArray:v.subviews];
    }
}

- (void)reloadAll {
    NSArray *nodes = self.nodeViewCache.allValues;
    for (id<BZOrganViewNode> node in nodes) {
        NSString *key = NSStringFromClass([node class]);
        BZBaseOrgan *organ = self.organCache[key];
        [node refresh:organ];
    }
}

- (void)reloadData {
    NSArray *nodes = self.nodeViewCache.allValues;
    for (id<BZOrganViewNode> node in nodes) {
        NSString *key = NSStringFromClass([node class]);
        BZBaseOrgan *organ = self.organCache[key];
        if (!organ || organ.dirty) {
            [node refresh:organ];
        }
    }
}

- (void)beginRequestWithResultBlock:(void (^)(NSError *error, NSDictionary *response))resultBlock {
    /// 放到队列的 尾部
    dispatch_async(dispatch_get_main_queue(), ^{
        [self bz_beginRequestWithResultBlock:resultBlock];
    });
}

- (void)bz_beginRequestWithResultBlock:(void (^)(NSError *error, NSDictionary *response))resultBlock {
    [self initializeDispatcher];
    NSArray *organs = self.organCache.allValues;
    NSMutableArray *netList = [NSMutableArray array];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    for (BZBaseOrgan *org in organs) {
        NSArray *organNetInfoList = [org organNetInfoList];
        for (id<BZOrganNetInfo> info in organNetInfoList) {
            NSString *key = [self keyOrganNetInfo:info];
            if (!key) {
                continue;
            }
            [netList addObject:info];
            dict[key] = org;
        }
        [org beforeRequest];
    }
    if (netList.count == 0) {
        if (resultBlock) {
            resultBlock(nil, nil);
        }
        return;
    }
    __weak __typeof(self)weakSelf = self;
    [[BZOrganConfig sharedInstance].request makeBatchRequest:netList response:^(NSError *error, NSDictionary *responseObject) {
        if (error) {
            if (resultBlock) {
                resultBlock(error, responseObject);
            }
            return;
        }
        for (id<BZOrganNetInfo> info in netList) {
            NSString *key = [weakSelf keyOrganNetInfo:info];
            BZBaseOrgan *org = dict[key];
            NSDictionary *handleDict = [[BZOrganConfig sharedInstance].request requestBackHandle:responseObject netInfo:info];
            [org backNetInfo:info infoDict:handleDict];
        }
        for (BZBaseOrgan *org in organs) {
            [org finishAllRequest];
        }
        [weakSelf reloadAll];
        if (resultBlock) {
            resultBlock(nil, responseObject);
        }
    }];
}

- (NSString *)keyOrganNetInfo:(id<BZOrganNetInfo>)info {
    NSString *pathStr = [info organNetInfoPath];
    if (pathStr.length == 0) {
        return nil;;
    }
    NSDictionary *paramDict = [info organNetInfoParam];
    NSString *paramStr = paramDict ? @(paramDict.hash).stringValue : @"0";
    NSString *key = [NSString stringWithFormat:@"%@_%@",pathStr ,paramStr];
    return key;
}


- (BZBaseOrgan *)readOrganForClass:(Class)nodeClass {
    if (!nodeClass || nodeClass == NULL || ![nodeClass conformsToProtocol:@protocol(BZOrganViewNode)]) {
        return nil;
    }
    return self.organCache[NSStringFromClass(nodeClass)];
}


- (NSMutableDictionary<NSString *,BZBaseOrgan *> *)organCache {
    if (!_organCache) {
        _organCache = [NSMutableDictionary dictionary];
    }
    return _organCache;
}

- (NSMutableDictionary<NSString *,id<BZOrganViewNode>> *)nodeViewCache {
    if (!_nodeViewCache) {
        _nodeViewCache = [NSMutableDictionary dictionary];
    }
    return _nodeViewCache;
}


@end
