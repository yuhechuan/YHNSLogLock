//
//  BZOrganConfig.m
//  KZStudy
//
//  Created by yuhechuan on 2024/7/15.
//

#import "BZOrganConfig.h"

@interface BZOrganConfig ()

@property (nonatomic, strong, readwrite) id<BZOrganNetRequest> request;

@end

@implementation BZOrganConfig

+ (instancetype)sharedInstance {
    static BZOrganConfig *organConfig = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        organConfig = [[BZOrganConfig alloc] init];
    });
    return organConfig;
}

/// 配置请求
- (void)congfigRequest:(id<BZOrganNetRequest>)request {
    if (![request conformsToProtocol:@protocol(BZOrganNetRequest)]) {
        return;
    }
    if (![request respondsToSelector:@selector(makeBatchRequest:response:)]) {
        return;
    }
    self.request = request;
}

@end
