//
//  BZBaseOrgan.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/11.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "BZOrganDelegate.h"

@interface BZBaseOrgan : NSObject

@property (nonatomic, assign) BOOL dirty;
@property (nonatomic, weak) UIViewController *controller;
@property (nonatomic, copy) NSString *key;
/**
 * 此业务需要发起的请求
 */
- (NSArray <id<BZOrganNetInfo>>*)organNetInfoList;
/**
 * 发起请求前回调
 */
- (void)beforeRequest;
/**
 * 网络数据回来了
 * infoDict 为单前 netInfo的网络数据
 */
- (void)backNetInfo:(id<BZOrganNetInfo>)netInfo infoDict:(NSDictionary *)infoDict;
/**
 * 当所有数据处理完毕回调
 */
- (void)finishAllRequest;
/**
 * 子类业务 Class 必须是 BZBaseOrgan的子类型不然得话会无效
 */
- (NSArray <Class>*)childOrgans;

@end
