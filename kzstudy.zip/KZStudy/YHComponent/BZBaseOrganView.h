//
//  BZBaseOrganView.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/15.
//

#import <UIKit/UIKit.h>
#import "BZOrganDelegate.h"

@interface BZBaseOrganView : UIView<BZOrganViewNode>

@property (nonatomic, weak, readonly) BZOrganDispatcher *dispatcher;


@end
