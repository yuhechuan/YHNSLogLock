//
//  BZStore.h
//  BZBoss
//
//  Created by yuhechuan on 2022/11/17.
//

#import <Foundation/Foundation.h>

@interface BZStore : NSObject
/**
 * 添加查询类型（整数）
 */
- (void)addQuery:(int)queryType;
/**
 * 查找类型(整数)
 */
- (BOOL)findQueryType:(int)queryType;
/**
 * 添加、更新自定义数据
 * 建议cls是obj的类的class
 */
- (void)storeValue:(id)value storeClass:(Class)storeClass;
/**
 * 获取自定义数据
 */
- (id)valueWithStoreClass:(Class)storeClass;

@end
