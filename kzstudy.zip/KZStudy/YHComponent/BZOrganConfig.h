//
//  BZOrganConfig.h
//  KZStudy
//
//  Created by yuhechuan on 2024/7/15.
//

#import <Foundation/Foundation.h>
#import "BZOrganDelegate.h"

@interface BZOrganConfig : NSObject

/// 当前用于请求的类
@property (nonatomic, strong, readonly) id<BZOrganNetRequest> request;

/// 单例
+ (instancetype)sharedInstance;

/// 配置请求
- (void)congfigRequest:(id<BZOrganNetRequest>)request;

@end
